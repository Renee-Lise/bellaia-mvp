# Bellaïa Hub v5 — Bella'Studio

> Le cockpit central de l'écosystème Bella'Studio  
> *Bellaïa prépare. Renée-Lise décide.*

---

## Structure du projet

```
bellaia-hub/
├── src/
│   ├── app/
│   │   ├── layout.tsx          ← Layout racine (métadonnées, PWA)
│   │   └── page.tsx            ← Route d'accueil principale (/)
│   └── components/
│       └── BellaiaApp.tsx      ← Application complète (1 fichier)
├── public/
│   └── manifest.json           ← Config PWA installable
├── next.config.js
├── package.json
├── tsconfig.json
└── vercel.json
```

---

## Route d'accueil

**`/` → `src/app/page.tsx`** → affiche `<BellaiaApp />`

L'écran d'entrée (choix Fondatrice / Client) s'affiche automatiquement.

---

## Déploiement sur Vercel (depuis GitHub)

### Étape 1 — Pousser sur GitHub
```bash
# Sur github.dev (depuis ton téléphone)
# 1. Créer un repo : bellaia-hub
# 2. Uploader tous les fichiers du zip
# 3. Committer
```

### Étape 2 — Déployer sur Vercel
```
1. Aller sur vercel.com
2. "Add New Project"
3. Importer le repo GitHub "bellaia-hub"
4. Framework : Next.js (détecté automatiquement)
5. Build Command : npm run build (par défaut)
6. "Deploy"
```

### Étape 3 — Domaine personnalisé (optionnel)
```
Settings → Domains → Ajouter bellaia.studio ou autre
```

---

## Modes d'accès

| Mode | Accès | Données visibles |
|------|-------|-----------------|
| Fondatrice | Bouton ◎ sur l'écran d'accueil | Tout |
| Portail Client | Bouton 🌐 sur l'écran d'accueil | Uniquement données publiques |

---

## Modules actifs (Phase 1)

### Espace Fondatrice
- ◈ Dashboard global avec alertes
- ◉ Portfolio 13 projets (Liste + Kanban)
- ◫ Tâches & Travaux
- ✦ Bella'Secret Home back-office complet
- ⬡ Hub Bella'Studio tous pôles
- € Finances consolidées
- ◎ Assistant IA Bellaïa

### Portail Client
- ✦ Bella'Secret Home (Gate +18, boutique, événements, Club VIP, FAQ)
- 💅 Bella'Odyssée (prestations, réservation RDV, galerie)
- ✨ Events / 🍃 Food / 📋 Vilo / 📚 Éditions / 🌺 Mo Ti-Péyi → placeholder WhatsApp

---

## Phase 2 (à venir)
- Supabase : `https://juewoennvtumkgbrbhme.supabase.co`
- SumUp Hosted Checkout
- Authentification Fondatrice sécurisée
- Espaces publics complets Events, Food, Vilo, Éditions, Mo Ti-Péyi
- PWA icons (icon-192.png, icon-512.png à ajouter dans /public)

---

*Bella'Studio · Sinnamary, Guyane française*
