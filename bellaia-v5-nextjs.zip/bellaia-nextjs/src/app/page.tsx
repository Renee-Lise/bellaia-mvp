import BellaiaApp from "@/components/BellaiaApp";

export default function Home() {
  return <BellaiaApp />;
}
