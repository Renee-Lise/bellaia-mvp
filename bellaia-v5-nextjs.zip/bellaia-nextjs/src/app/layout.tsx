import type { Metadata, Viewport } from "next";

export const metadata: Metadata = {
  title: "Bellaïa — Bella'Studio Hub",
  description: "Le cockpit central de l'écosystème Bella'Studio",
  manifest: "/manifest.json",
  appleWebApp: {
    capable: true,
    statusBarStyle: "black-translucent",
    title: "Bellaïa",
  },
};

export const viewport: Viewport = {
  themeColor: "#0d0b12",
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="fr">
      <body style={{ margin: 0, padding: 0, background: "#0d0b12" }}>
        {children}
      </body>
    </html>
  );
}
