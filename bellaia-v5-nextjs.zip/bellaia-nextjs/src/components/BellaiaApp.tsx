'use client';

import { useState, useEffect, useCallback } from "react";

// ═══════════════════════════════════════════════════════════
// DESIGN TOKENS
// ═══════════════════════════════════════════════════════════
const B = {
  night:"#0d0b12", deep:"#13101e", surface:"#1a1628", card:"#201c30",
  violet:"#7c3aed", violetL:"#9d6ef5", violetG:"rgba(124,58,237,0.2)",
  gold:"#c9a84c", goldL:"#f0d080", goldG:"rgba(201,168,76,0.15)",
  cream:"#f5f0e8", muted:"#8b7fa8", mutedL:"#b8aed0",
  border:"rgba(124,58,237,0.22)", borderG:"rgba(201,168,76,0.28)",
  success:"#80e0a0", danger:"#f4a0a0", warning:"#f0d080",
};
const BSH = {
  fond:"#0e0914", prune:"#2a0d1e", bord:"#6B1A2B", bord2:"#8B2A3B",
  rose:"#C9637A", or:"#C9A96E", creme:"#F5EEE6",
  cremeF:"rgba(245,238,230,.75)", cremeD:"rgba(245,238,230,.4)",
  verre:"rgba(255,255,255,.04)", verre2:"rgba(255,255,255,.07)",
  line:"rgba(201,169,110,.15)", lineMed:"rgba(201,169,110,.3)",
  vert:"#5aaa7a", ora:"#e88c3a", rouge:"#e84444",
};
const BO = {
  fond:"#05040f", prune:"#0d1535", acc:"#3730a3", acc2:"#4f46e5",
  or:"#c9a84c", creme:"#f0eeff", cremeD:"rgba(240,238,255,.4)",
  line:"rgba(99,102,241,0.2)", lineMed:"rgba(99,102,241,0.4)",
  verre:"rgba(255,255,255,.03)", vert:"#5aaa7a", rouge:"#e84444",
};
const FS = "'Georgia',serif";
const SA = "Inter,system-ui,sans-serif";

// ═══════════════════════════════════════════════════════════
// HELPERS
// ═══════════════════════════════════════════════════════════
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2);
const today = () => new Date().toISOString().split("T")[0];
const fmt = d => d ? new Date(d).toLocaleDateString("fr-FR",{day:"2-digit",month:"2-digit",year:"numeric"}) : "—";
const prioC = p => p==="Haute"?B.danger:p==="Moyenne"?B.warning:B.mutedL;
const STATUTS_PROJ = ["Idée","En préparation","En cours","En pause","En attente","À valider","Terminé","Archivé"];
const STATUTS_TACHE = ["À faire","En cours","En attente","Terminé"];
const PRIOS = ["Basse","Moyenne","Haute"];
const POLES = ["Bella'Odyssée","Bella'Events","Bella'Food","Bella'Secret Home","Vilo'Assistance","Bella'Studio Éditions","Mo Ti-Péyi","Ti-Panier","Numérique","Pédagogique","Général"];
const STATUTS_CMD = ["Demande reçue","Validation fondatrice","Paiement en attente","Acompte reçu","Paiement complet reçu","Confirmée","Préparation","Expédiée","Terminée","Annulée"];
const VIP_C = {Bronze:"#8B6030",Argent:"#8a9ab0",Or:BSH.or,Diamant:"#90d0f0"};
const CMD_C = {"Paiement complet reçu":BSH.vert,Terminée:BSH.vert,Expédiée:BSH.rose,Préparation:BSH.bord,"Acompte reçu":BSH.or,"Paiement en attente":BSH.ora,Annulée:BSH.rouge,Confirmée:BSH.vert,"Demande reçue":BSH.or};
const PRESTATIONS_BO = ["Extensions de cils","Blanchiment dentaire","Strass dentaires","Browlift","Lashlift","Soin visage","Autre"];
const sCo = s => ({
  "En cours":{bg:"rgba(124,58,237,0.2)",t:"#c4a8ff"},"En préparation":{bg:"rgba(201,168,76,0.2)",t:"#f0d080"},
  Idée:{bg:"rgba(139,127,168,0.18)",t:"#b8aed0"},"En pause":{bg:"rgba(180,80,80,0.2)",t:"#f4a0a0"},
  Terminé:{bg:"rgba(80,180,120,0.2)",t:"#80e0a0"},Archivé:{bg:"rgba(80,80,80,0.2)",t:"#888"},
  "À faire":{bg:"rgba(139,127,168,0.18)",t:"#b8aed0"},"En attente":{bg:"rgba(201,168,76,0.15)",t:"#f0d080"},
  "À valider":{bg:"rgba(200,120,40,0.2)",t:"#f4c080"},Actif:{bg:"rgba(80,180,120,0.15)",t:"#80e0a0"},
  Inactif:{bg:"rgba(80,80,80,0.2)",t:"#888"},Confirmée:{bg:"rgba(80,180,120,0.2)",t:"#80e0a0"},
  "Paiement complet reçu":{bg:"rgba(80,180,120,0.2)",t:"#80e0a0"},"Acompte reçu":{bg:"rgba(201,168,76,0.2)",t:"#f0d080"},
}[s] || {bg:"rgba(139,127,168,0.18)",t:"#b8aed0"});

// ═══════════════════════════════════════════════════════════
// DONNÉES INITIALES
// ═══════════════════════════════════════════════════════════
const PROJETS_INIT = [
  {id:"p1",titre:"Bella'Odyssée — Lancement",pole:"Bella'Odyssée",priorite:"Haute",statut:"En cours",avancement:45,dateCible:"2026-12-31",revenusEstimes:8000},
  {id:"p2",titre:"Bella'Secret Home V2",pole:"Bella'Secret Home",priorite:"Haute",statut:"En cours",avancement:70,dateCible:"2026-08-01",revenusEstimes:5000},
  {id:"p3",titre:"Alphabet Guyane",pole:"Mo Ti-Péyi",priorite:"Haute",statut:"En cours",avancement:60,dateCible:"2026-08-01",revenusEstimes:3000},
  {id:"p4",titre:"Bella'Events — Été 2026",pole:"Bella'Events",priorite:"Haute",statut:"En cours",avancement:30,dateCible:"2026-09-30",revenusEstimes:4000},
  {id:"p5",titre:"Bella'Food — Lancement",pole:"Bella'Food",priorite:"Moyenne",statut:"En préparation",avancement:15,dateCible:"2026-12-31",revenusEstimes:3500},
  {id:"p6",titre:"Maman Femme & Cheffe",pole:"Bella'Studio Éditions",priorite:"Moyenne",statut:"Idée",avancement:5,dateCible:"2027-01-01",revenusEstimes:2000},
  {id:"p7",titre:"Mon Grand Voyage à Travers la Bible",pole:"Pédagogique",priorite:"Moyenne",statut:"En cours",avancement:25,dateCible:"2026-12-31",revenusEstimes:1500},
  {id:"p8",titre:"Fiches pédagogiques Guyane",pole:"Pédagogique",priorite:"Moyenne",statut:"En cours",avancement:40,dateCible:"2026-09-01",revenusEstimes:1200},
  {id:"p9",titre:"Projet Métiers",pole:"Pédagogique",priorite:"Basse",statut:"En préparation",avancement:10,dateCible:"2026-12-31",revenusEstimes:800},
  {id:"p10",titre:"Vilo'Assistance — Offre",pole:"Vilo'Assistance",priorite:"Moyenne",statut:"En cours",avancement:50,dateCible:"2026-12-31",revenusEstimes:2500},
  {id:"p11",titre:"Bellaïa Enterprise",pole:"Numérique",priorite:"Haute",statut:"En cours",avancement:72,dateCible:"2026-07-15",revenusEstimes:0},
  {id:"p12",titre:"Ti-Panier App",pole:"Ti-Panier",priorite:"Basse",statut:"Idée",avancement:5,dateCible:"2027-06-01",revenusEstimes:1000},
  {id:"p13",titre:"Mo Ti-Péyi — Collection 2",pole:"Mo Ti-Péyi",priorite:"Moyenne",statut:"En préparation",avancement:10,dateCible:"2026-12-31",revenusEstimes:2000},
];
const PRODS_BSH_INIT = [
  {id:"p1",name:"Ensemble Dentelle Noir",cat:"Lingerie",prix:39,promo:null,isNew:true,ico:"🖤",desc:"Ensemble 2 pièces dentelle guipure. XS–6XL+.",stock:12,min:3,achat:15},
  {id:"p2",name:"Nuisette Satin Rose",cat:"Lingerie",prix:34,promo:27,isNew:false,ico:"🌸",desc:"Nuisette satin brossé, bretelles réglables. S–4XL.",stock:2,min:3,achat:12},
  {id:"p3",name:"Body Brodé Or",cat:"Lingerie",prix:45,promo:null,isNew:true,ico:"✨",desc:"Body string broderies dorées.",stock:8,min:3,achat:18},
  {id:"p4",name:"Coffret Nuit de Velours",cat:"Coffrets",prix:79,promo:null,isNew:false,ico:"🎁",desc:"Lingerie + bougie massage + huile + carte.",stock:8,min:3,achat:35},
  {id:"p5",name:"Coffret Première Tentation",cat:"Coffrets",prix:49,promo:null,isNew:false,ico:"🌹",desc:"Lingerie + mini bougie + carte personnalisée.",stock:5,min:3,achat:22},
  {id:"p6",name:"Bougie Massage Vanille",cat:"Bougies",prix:24,promo:null,isNew:false,ico:"🕯️",desc:"Fond à basse température — huile au toucher.",stock:15,min:5,achat:8},
  {id:"p7",name:"Huile Corps Aphrodite",cat:"Huiles",prix:29,promo:22,isNew:false,ico:"💧",desc:"Huile de massage sèche, non grasse.",stock:3,min:5,achat:9},
  {id:"p8",name:"Coffret Secret Couple",cat:"Couples",prix:89,promo:null,isNew:false,ico:"💑",desc:"Accessoires + bougie + huile + surprise.",stock:6,min:2,achat:40},
];
const EVTS_BSH_INIT = [
  {id:"e1",ico:"✨",nom:"Soirée Découverte",date:"2026-07-15",lieu:"Sinnamary",cap:20,dispo:7,prix:25,desc:"2h30 d'univers BSH en petit comité."},
  {id:"e2",ico:"🌹",nom:"Secret Singles Femme",date:"2026-07-22",lieu:"Kourou",cap:15,dispo:3,prix:35,desc:"Soirée privée pour célibataires."},
  {id:"e3",ico:"📸",nom:"Boudoir Session",date:"2026-07-29",lieu:"Sinnamary",cap:8,dispo:5,prix:89,desc:"Shooting photo privé. Tous niveaux."},
];
const CLIENTES_BSH_INIT = [
  {id:"CL001",nom:"Marie S.",ville:"Sinnamary",canal:"WhatsApp",vip:"Or",total:287,tel:"+594690000001",notes:"Cliente fidèle",preferences:"Lingerie dentelle, taille M"},
  {id:"CL002",nom:"Kathy R.",ville:"Kourou",canal:"TikTok",vip:"Argent",total:78,tel:"+594690000002",notes:"",preferences:""},
  {id:"CL003",nom:"Aline B.",ville:"Matoury",canal:"Instagram",vip:"Diamant",total:589,tel:"+594690000004",notes:"Meilleure cliente 2025",preferences:"Coffrets premium"},
];
const CMDS_BSH_INIT = [
  {id:"BSH-001",client:"Marie S.",produit:"Coffret Nuit de Velours",montant:79,acompte:0,statut:"Terminée",date:"2026-06-01",pmt:"Stripe"},
  {id:"BSH-002",client:"Kathy R.",produit:"Ensemble Dentelle Noir",montant:39,acompte:0,statut:"Paiement complet reçu",date:"2026-06-02",pmt:"PayPal"},
  {id:"BSH-003",client:"Aline B.",produit:"Coffret Secret Couple",montant:89,acompte:45,statut:"Acompte reçu",date:"2026-06-03",pmt:"SumUp",notes:"Solde à régler"},
];
const FAQ_BSH = [
  ["Comment commander ?","Via WhatsApp (+594 694 35 60 37), le site ou lors d'un événement."],
  ["Les colis sont-ils discrets ?","Oui. Emballage neutre sans mention du contenu."],
  ["Livrez-vous en Guyane ?","Oui — et aux Antilles et en France métropolitaine."],
  ["Modes de paiement ?","CB, Espèces, PayPal, Revolut, SumUp, Stripe."],
  ["Puis-je venir seule à un événement ?","Oui, absolument. La plupart viennent seules."],
  ["Comment devenir VIP ?","Par fidélité, participation aux événements ou recommandation."],
];
const VIP_LEVELS = [
  {level:"Bronze",prix:"Gratuit",color:"#8B6030",avs:["Accès nouveautés en avant-première","Informations privées","Précommandes"]},
  {level:"Argent",prix:"5€/mois",color:"#8a9ab0",avs:["+ Remises exclusives","Invitations early access","Accès événements prioritaires"]},
  {level:"Or",prix:"15€/mois",color:BSH.or,avs:["+ Ventes privées","Coffrets surprise","Priorité absolue événements","Tarifs négociés"]},
  {level:"Diamant",prix:"29€/mois",color:"#90d0f0",avs:["+ VIP Night exclusif","Cadeaux premium","Collections limitées en avant-première","Suivi personnel fondatrice"]},
];

// ═══════════════════════════════════════════════════════════
// STORAGE HOOK — localStorage (compatible Next.js/Vercel)
// ═══════════════════════════════════════════════════════════
function useStore(key, init) {
  const [data, setData] = useState(init);
  const [ready, setReady] = useState(false);
  useEffect(() => {
    try {
      const raw = typeof window !== "undefined" ? localStorage.getItem(key) : null;
      if (raw) setData(JSON.parse(raw));
    } catch {}
    setReady(true);
  }, [key]);
  const save = useCallback(async val => {
    const next = typeof val === "function" ? val(data) : val;
    setData(next);
    try {
      if (typeof window !== "undefined") {
        localStorage.setItem(key, JSON.stringify(next));
      }
    } catch {}
    return next;
  }, [key, data]);
  return [data, save, ready];
}

// ═══════════════════════════════════════════════════════════
// ATOMS BELLAÏA
// ═══════════════════════════════════════════════════════════
const Bdg = ({s}) => { const c = sCo(s); return <span style={{display:"inline-flex",padding:"3px 10px",borderRadius:99,background:c.bg,color:c.t,fontSize:10,fontWeight:700,whiteSpace:"nowrap"}}>{s}</span>; };
const PBar = ({v, col}) => <div style={{height:5,background:"rgba(255,255,255,0.07)",borderRadius:99,overflow:"hidden"}}><div style={{height:"100%",width:`${Math.min(v||0,100)}%`,background:`linear-gradient(90deg,${col||B.violet},${B.violetL})`,borderRadius:99,transition:"width 0.5s"}}/></div>;
const SH = ({t, s}) => <div style={{marginBottom:16}}><h2 style={{margin:0,fontSize:20,fontWeight:800,color:B.cream,fontFamily:FS,letterSpacing:"-0.02em"}}>{t}</h2>{s&&<p style={{margin:"3px 0 0",fontSize:12,color:B.muted}}>{s}</p>}</div>;

const Btn = ({onClick, children, v="primary", sm, full, disabled}) => {
  const st = {
    primary:{background:`linear-gradient(135deg,${B.violet},#5b21b6)`,color:"#fff",border:"none"},
    gold:{background:`linear-gradient(135deg,${B.gold},#a07030)`,color:B.night,border:"none"},
    ghost:{background:"transparent",color:B.mutedL,border:`1px solid ${B.border}`},
    danger:{background:"rgba(180,80,80,0.2)",color:B.danger,border:"1px solid rgba(180,80,80,0.3)"},
    success:{background:"rgba(80,180,120,0.15)",color:B.success,border:`1px solid rgba(80,180,120,0.3)`},
  };
  return <button onClick={onClick} disabled={disabled} style={{...st[v],padding:sm?"6px 12px":"10px 18px",borderRadius:10,fontWeight:700,fontSize:sm?11:13,cursor:disabled?"not-allowed":"pointer",opacity:disabled?0.5:1,width:full?"100%":"auto",fontFamily:SA,transition:"opacity 0.2s"}}>{children}</button>;
};
const Inp = ({value, onChange, placeholder, type="text", rows}) => {
  const s = {width:"100%",background:B.surface,border:`1px solid ${B.border}`,borderRadius:10,padding:"9px 12px",color:B.cream,fontSize:13,outline:"none",fontFamily:SA,boxSizing:"border-box"};
  return rows ? <textarea value={value} onChange={onChange} placeholder={placeholder} rows={rows} style={{...s,resize:"vertical"}}/> : <input value={value} onChange={onChange} placeholder={placeholder} type={type} style={s}/>;
};
const Sel = ({value, onChange, options}) => <select value={value} onChange={onChange} style={{width:"100%",background:B.surface,border:`1px solid ${B.border}`,borderRadius:10,padding:"9px 12px",color:B.cream,fontSize:13,outline:"none",fontFamily:SA,boxSizing:"border-box"}}>{options.map(o=><option key={o} value={o}>{o}</option>)}</select>;
const Fld = ({label, children}) => <div style={{marginBottom:14}}><label style={{fontSize:11,fontWeight:700,color:B.mutedL,letterSpacing:"0.06em",textTransform:"uppercase",display:"block",marginBottom:5}}>{label}</label>{children}</div>;

function Mdl({title, onClose, children}) {
  return (
    <div style={{position:"fixed",inset:0,background:"rgba(0,0,0,0.85)",zIndex:500,display:"flex",alignItems:"flex-end",justifyContent:"center"}} onClick={onClose}>
      <div onClick={e=>e.stopPropagation()} style={{background:B.deep,borderRadius:"20px 20px 0 0",border:`1px solid ${B.border}`,padding:"20px 16px 32px",width:"100%",maxWidth:430,maxHeight:"90vh",overflowY:"auto"}}>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:18}}>
          <h3 style={{margin:0,fontSize:17,fontWeight:800,color:B.cream,fontFamily:FS}}>{title}</h3>
          <button onClick={onClose} style={{background:"none",border:"none",color:B.muted,fontSize:20,cursor:"pointer",padding:"0 4px"}}>✕</button>
        </div>
        {children}
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════
// ATOMS BSH
// ═══════════════════════════════════════════════════════════
const BTag = ({c=BSH.bord, children, sz=9}) => <span style={{background:`${c}22`,border:`1px solid ${c}55`,color:c,borderRadius:3,padding:"2px 7px",fontSize:sz,fontWeight:700,whiteSpace:"nowrap"}}>{children}</span>;
const BBtn = ({children, v="ghost", sz="md", onClick, full=false, disabled=false}) => {
  const base = {cursor:disabled?"not-allowed":"pointer",borderRadius:8,fontFamily:SA,fontWeight:600,transition:"all .2s",border:"none",display:"inline-flex",alignItems:"center",justifyContent:"center",gap:4,opacity:disabled?0.5:1};
  const sizes = {sm:{padding:"6px 12px",fontSize:11},md:{padding:"10px 20px",fontSize:13},lg:{padding:"14px 28px",fontSize:15}};
  const vs = {gold:{background:`linear-gradient(135deg,${BSH.or},#a87a3e)`,color:BSH.fond},bord:{background:`linear-gradient(135deg,${BSH.bord},${BSH.bord2})`,color:BSH.creme},ghost:{background:"none",border:`1px solid ${BSH.line}`,color:BSH.cremeF},danger:{background:`${BSH.rouge}22`,border:`1px solid ${BSH.rouge}44`,color:BSH.rouge}};
  return <button onClick={onClick} disabled={disabled} style={{...base,...sizes[sz],...vs[v],width:full?"100%":"auto"}}>{children}</button>;
};
const BCard = ({children, accent=false, style:s={}}) => <div style={{background:BSH.verre,border:`1px solid ${BSH.line}`,borderRadius:14,padding:"14px 16px",borderTop:accent?`3px solid ${BSH.bord}`:`1px solid ${BSH.line}`,...s}}>{children}</div>;

// ═══════════════════════════════════════════════════════════
// ATOMS BO
// ═══════════════════════════════════════════════════════════
const OCard = ({children, accent=false, style:s={}}) => <div style={{background:BO.verre,border:`1px solid ${BO.line}`,borderRadius:14,padding:"14px 16px",borderTop:accent?`3px solid ${BO.acc}`:`1px solid ${BO.line}`,...s}}>{children}</div>;
const OBtn = ({children, v="ghost", sz="md", onClick, full=false}) => {
  const base = {cursor:"pointer",borderRadius:8,fontFamily:SA,fontWeight:600,border:"none",display:"inline-flex",alignItems:"center",justifyContent:"center",gap:4};
  const sizes = {sm:{padding:"6px 12px",fontSize:11},md:{padding:"10px 20px",fontSize:13}};
  const vs = {primary:{background:`linear-gradient(135deg,${BO.acc},${BO.acc2})`,color:"#fff"},gold:{background:`linear-gradient(135deg,${BO.or},#a87a3e)`,color:BO.fond||"#000"},ghost:{background:"none",border:`1px solid ${BO.line}`,color:BO.cremeD}};
  return <button onClick={onClick} style={{...base,...sizes[sz],...vs[v],width:full?"100%":"auto"}}>{children}</button>;
};
const OTag = ({c=BO.acc, children, sz=9}) => <span style={{background:`${c}22`,border:`1px solid ${c}55`,color:c,borderRadius:3,padding:"2px 7px",fontSize:sz,fontWeight:700,whiteSpace:"nowrap"}}>{children}</span>;


// ═══════════════════════════════════════════════════════════
// ── HUB CLIENT
// ═══════════════════════════════════════════════════════════
const UNIVERS = [
  {id:"bsh",  nom:"Bella'Secret Home",   tag:"Lingerie & Désir",      ico:"✦",  bg:"#2a0d1e", acc:BSH.bord,  acc2:"#8B2A3B", or:BSH.or,  badge:"+18", gate:true},
  {id:"bo",   nom:"Bella'Odyssée",       tag:"Beauté & Soins",         ico:"💅", bg:"#0b0d1a", acc:BO.acc,    acc2:BO.acc2,   or:BO.or,   badge:"RDV"},
  {id:"bev",  nom:"Bella'Events",        tag:"Événements & Soirées",   ico:"✨", bg:"#0d1a14", acc:"#065f46", acc2:"#059669", or:"#c9a84c",badge:"Events"},
  {id:"bfd",  nom:"Bella'Food",          tag:"Traiteur & Menus",       ico:"🍃", bg:"#0f1a0d", acc:"#15803d", acc2:"#16a34a", or:"#c9a84c",badge:"Food"},
  {id:"vilo", nom:"Vilo'Assistance",     tag:"Assistance Administrative",ico:"📋",bg:"#0d1520", acc:"#1d4ed8", acc2:"#2563eb", or:"#c9a84c",badge:"Admin"},
  {id:"bse",  nom:"Bella'Studio Éditions",tag:"Ebooks & Formations",  ico:"📚", bg:"#12100d", acc:"#92400e", acc2:"#b45309", or:"#c9a84c",badge:"Digital"},
  {id:"mtp",  nom:"Mo Ti-Péyi",          tag:"Livres jeunesse Guyane", ico:"🌺", bg:"#1a0d18", acc:"#7e22ce", acc2:"#9333ea", or:"#c9a84c",badge:"Pédago"},
];

function HubClient({onSelectUnivers, onBack}) {
  return (
    <div style={{display:"flex",flexDirection:"column",height:"100vh",background:B.night,fontFamily:SA}}>
      {/* Header */}
      <div style={{padding:"14px 16px 12px",borderBottom:`1px solid ${B.border}`,background:B.deep,flexShrink:0,display:"flex",alignItems:"center",gap:12}}>
        <button onClick={onBack} style={{background:"none",border:"none",color:B.muted,cursor:"pointer",fontSize:18,padding:"0 4px"}}>‹</button>
        <div>
          <div style={{fontSize:14,fontWeight:800,color:B.cream,fontFamily:FS}}>Bella'Studio</div>
          <div style={{fontSize:10,color:B.muted,letterSpacing:"0.08em"}}>Portail Client — Choisissez votre univers</div>
        </div>
      </div>

      {/* Grille univers */}
      <div style={{flex:1,overflowY:"auto",padding:"16px 14px 24px"}}>
        <p style={{fontSize:12,color:B.muted,marginBottom:16,textAlign:"center",lineHeight:1.6}}>
          Bienvenue dans l'univers Bella'Studio ✦<br/>Sélectionnez votre espace
        </p>
        <div style={{display:"flex",flexDirection:"column",gap:12}}>
          {UNIVERS.map(u => (
            <button key={u.id} onClick={() => onSelectUnivers(u.id)} style={{background:`linear-gradient(135deg,${u.bg},${u.acc}18)`,border:`1px solid ${u.acc}40`,borderRadius:18,padding:"18px 20px",cursor:"pointer",textAlign:"left",fontFamily:SA,width:"100%",position:"relative",overflow:"hidden"}}>
              <div style={{position:"absolute",top:-20,right:-20,width:80,height:80,borderRadius:"50%",background:`${u.acc}25`,filter:"blur(20px)"}}/>
              <div style={{display:"flex",alignItems:"center",gap:14}}>
                <div style={{width:48,height:48,borderRadius:14,background:`${u.acc}30`,border:`1px solid ${u.acc}50`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:24,flexShrink:0}}>
                  {u.ico}
                </div>
                <div style={{flex:1}}>
                  <div style={{display:"flex",alignItems:"center",gap:8,marginBottom:3}}>
                    <span style={{fontSize:15,fontWeight:800,color:"#fff",fontFamily:FS}}>{u.nom}</span>
                    <span style={{background:`${u.acc}40`,border:`1px solid ${u.acc}60`,color:u.or,borderRadius:4,padding:"1px 6px",fontSize:9,fontWeight:800}}>{u.badge}</span>
                  </div>
                  <div style={{fontSize:12,color:"rgba(255,255,255,0.6)"}}>{u.tag}</div>
                </div>
                <span style={{color:`${u.acc}cc`,fontSize:20}}>›</span>
              </div>
            </button>
          ))}
        </div>
        <div style={{textAlign:"center",marginTop:20,padding:"14px",background:B.surface,borderRadius:12,border:`1px solid ${B.border}`}}>
          <div style={{fontSize:12,color:B.muted,lineHeight:1.7}}>
            📞 Nous contacter<br/>
            <span style={{color:B.gold,fontWeight:700}}>+594 694 35 60 37</span><br/>
            <span style={{fontSize:10}}>bella.studio973@hotmail.com</span>
          </div>
        </div>
      </div>
    </div>
  );
}

// ── COMPOSANT FAQ ITEM (hook en dehors de map)
function FAQItem({q, r}) {
  const [open, setOpen] = useState(false);
  return (
    <div>
      <button onClick={() => setOpen(!open)} style={{width:"100%",background:BSH.verre,border:`1px solid ${BSH.line}`,borderRadius:open?"10px 10px 0 0":10,padding:"11px 14px",color:BSH.creme,cursor:"pointer",textAlign:"left",display:"flex",justifyContent:"space-between",alignItems:"center",fontSize:12,fontFamily:SA}}>
        <span style={{lineHeight:1.4,flex:1,paddingRight:8}}>{q}</span>
        <span style={{color:BSH.or,flexShrink:0}}>{open?"▲":"▼"}</span>
      </button>
      {open && <div style={{background:`${BSH.bord}0e`,border:`1px solid ${BSH.bord}30`,borderTop:"none",borderRadius:"0 0 10px 10px",padding:"11px 14px",fontSize:12,color:BSH.cremeF,lineHeight:1.75}}>{r}</div>}
    </div>
  );
}

// ═══════════════════════════════════════════════════════════
// ── ESPACE CLIENT BSH
// ═══════════════════════════════════════════════════════════
function ClientBSH({produits, evenements, onBack, onNewCommande}) {
  const [gate, setGate] = useState(false);
  const [page, setPage] = useState("accueil");
  const [cart, setCart] = useState([]);
  const [fav, setFav] = useState([]);
  const [modal, setModal] = useState(null);
  const [pmtChoisi, setPmtChoisi] = useState("WhatsApp");
  const [nomClient, setNomClient] = useState("");
  const cartN = cart.reduce((s,i) => s+i.qty, 0);
  const cartT = cart.reduce((s,i) => s+(i.promo||i.prix)*i.qty, 0);
  const addCart = p => setCart(c => { const e=c.find(x=>x.id===p.id); return e?c.map(x=>x.id===p.id?{...x,qty:x.qty+1}:x):[...c,{...p,qty:1}]; });
  const togFav = id => setFav(f => f.includes(id)?f.filter(x=>x!==id):[...f,id]);

  const genId = () => "BSH-" + Date.now().toString().slice(-6);

  const confirmerCommande = async () => {
    const id = genId();
    const produitStr = cart.map(i=>`${i.name} ×${i.qty}`).join(", ");
    const cmd = {
      id,
      client: nomClient || "Client web",
      produit: produitStr,
      montant: cartT,
      acompte: 0,
      statut: "Demande reçue",
      date: today(),
      pmt: pmtChoisi,
      notes: `Commande web — ${new Date().toLocaleString("fr-FR")}`,
    };
    if (onNewCommande) await onNewCommande(cmd);
    const pmtInfo = pmtChoisi === "PayPal" ? `\nPayPal : vilosarlise972@gmail.com` : pmtChoisi === "WhatsApp" ? `\nPaiement à confirmer avec la fondatrice` : `\nMode de paiement : ${pmtChoisi}`;
    const msg = `🌹 *NOUVELLE COMMANDE ${id}*\n\nClient : ${nomClient || "Non renseigné"}\nProduits : ${produitStr}\nTotal : ${cartT}€\nPaiement : ${pmtChoisi}${pmtInfo}\nDate : ${new Date().toLocaleString("fr-FR")}\n\nMerci de confirmer ma commande.`;
    setCart([]);
    setNomClient("");
    setModal(null);
    window.open(`https://wa.me/594694356037?text=${encodeURIComponent(msg)}`, "_blank");
  };

  // Gate +18
  if (!gate) return (
    <div style={{display:"flex",flexDirection:"column",height:"100vh",background:`radial-gradient(ellipse at 20% 0%,${BSH.prune},${BSH.fond})`,alignItems:"center",justifyContent:"center",fontFamily:SA,padding:"20px"}}>
      <div style={{textAlign:"center",maxWidth:320,width:"100%"}}>
        <div style={{fontFamily:FS,fontSize:26,color:BSH.or,letterSpacing:3,marginBottom:4}}>✦ Bella'Secret Home</div>
        <div style={{fontSize:9,color:BSH.cremeD,letterSpacing:4,marginBottom:32}}>L'INTIMITÉ ÉLEVÉE AU RANG D'ART</div>
        <div style={{background:BSH.verre2,border:`1px solid ${BSH.line}`,borderRadius:18,padding:"28px 22px"}}>
          <div style={{fontSize:40,marginBottom:12}}>🔞</div>
          <div style={{fontFamily:FS,fontSize:16,color:BSH.creme,marginBottom:8}}>Accès réservé aux adultes</div>
          <div style={{fontSize:12,color:BSH.cremeD,marginBottom:24,lineHeight:1.7}}>Ce site contient du contenu réservé aux personnes majeures. En entrant, vous certifiez avoir 18 ans ou plus.</div>
          <div style={{display:"flex",flexDirection:"column",gap:10}}>
            <BBtn v="gold" sz="md" full onClick={() => setGate(true)}>✓ J'ai 18 ans ou plus — Entrer</BBtn>
            <BBtn v="ghost" sz="sm" full onClick={onBack}>✕ Retour au portail</BBtn>
          </div>
        </div>
      </div>
    </div>
  );

  const PAGES = [{id:"accueil",l:"🏠"},{id:"boutique",l:"🛍"},{id:"evenements",l:"✨"},{id:"vip",l:"💎"},{id:"faq",l:"❓"}];

  return (
    <div style={{display:"flex",flexDirection:"column",height:"100vh",background:`radial-gradient(ellipse at 10% 0%,${BSH.prune},${BSH.fond} 60%)`,fontFamily:SA}}>
      {/* Header BSH */}
      <div style={{padding:"10px 14px",borderBottom:`1px solid ${BSH.line}`,display:"flex",justifyContent:"space-between",alignItems:"center",background:"rgba(0,0,0,0.3)",flexShrink:0}}>
        <div>
          <div style={{fontFamily:FS,fontSize:14,color:BSH.or,letterSpacing:2}}>✦ Bella'Secret Home</div>
          <div style={{fontSize:8,color:BSH.cremeD,letterSpacing:3}}>INTIMITÉ · ÉLÉGANCE · DÉSIR</div>
        </div>
        <div style={{display:"flex",gap:7,alignItems:"center"}}>
          {cartN > 0 && <button onClick={() => setModal("cart")} style={{background:`${BSH.bord}33`,border:`1px solid ${BSH.bord}`,borderRadius:8,padding:"5px 10px",color:BSH.creme,cursor:"pointer",fontSize:11,fontFamily:SA}}>🛍 {cartN} · {cartT}€</button>}
          <button onClick={onBack} style={{background:"none",border:`1px solid ${BSH.line}`,borderRadius:8,padding:"5px 9px",color:BSH.cremeD,cursor:"pointer",fontSize:10,fontFamily:SA}}>‹ Portail</button>
        </div>
      </div>

      {/* Nav BSH */}
      <div style={{display:"flex",justifyContent:"space-around",padding:"8px 12px",borderBottom:`1px solid ${BSH.line}`,background:"rgba(0,0,0,0.2)",flexShrink:0}}>
        {PAGES.map(p => (
          <button key={p.id} onClick={() => setPage(p.id)} style={{display:"flex",flexDirection:"column",alignItems:"center",gap:2,background:"none",border:"none",cursor:"pointer",padding:"4px 8px",borderBottom:page===p.id?`2px solid ${BSH.or}`:"2px solid transparent"}}>
            <span style={{fontSize:18}}>{p.l}</span>
            <span style={{fontSize:8,color:page===p.id?BSH.or:BSH.cremeD,fontWeight:700,textTransform:"capitalize"}}>{p.id}</span>
          </button>
        ))}
      </div>

      {/* Contenu */}
      <div style={{flex:1,overflowY:"auto",padding:"14px",color:BSH.creme}}>

        {/* ── ACCUEIL ── */}
        {page === "accueil" && (
          <div style={{display:"flex",flexDirection:"column",gap:14}}>
            <div style={{textAlign:"center",padding:"16px 0 8px"}}>
              <div style={{fontFamily:FS,fontSize:24,color:BSH.or,letterSpacing:2,marginBottom:6}}>Bienvenue ✦</div>
              <div style={{fontSize:13,color:BSH.cremeD,lineHeight:1.8}}>L'intimité élevée au rang d'art.<br/>Lingerie premium · Coffrets sensuels · Soirées privées</div>
            </div>
            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
              {produits.slice(0,4).map(p => (
                <BCard key={p.id} accent style={{padding:"12px",cursor:"pointer"}} onClick={() => setPage("boutique")}>
                  <div style={{fontSize:30,textAlign:"center",padding:"8px 0",background:`${BSH.bord}18`,borderRadius:9,marginBottom:7}}>{p.ico||"🌹"}</div>
                  <div style={{fontFamily:FS,fontSize:11,fontWeight:600,color:BSH.creme,marginBottom:3,lineHeight:1.3}}>{p.name}</div>
                  <div style={{fontSize:14,fontWeight:700,color:BSH.or,fontFamily:FS}}>{p.promo||p.prix}€</div>
                </BCard>
              ))}
            </div>
            <BCard accent style={{textAlign:"center",padding:"18px 16px"}}>
              <div style={{fontFamily:FS,fontSize:16,color:BSH.or,marginBottom:6}}>Commander facilement ✦</div>
              <div style={{fontSize:12,color:BSH.cremeD,marginBottom:14,lineHeight:1.7}}>Boutique en ligne · Livraison Guyane & DOM-TOM<br/>Emballage discret garanti</div>
              <BBtn v="bord" sz="md" full onClick={() => window.open("https://wa.me/594694356037","_blank")}>💬 Commander via WhatsApp</BBtn>
            </BCard>
            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:9}}>
              {[{ico:"✨",t:"Événements",sub:evenements.length+" à venir",p:"evenements"},{ico:"💎",t:"Club VIP",sub:"4 niveaux exclusifs",p:"vip"}].map(c => (
                <BCard key={c.t} style={{textAlign:"center",padding:"14px 10px",cursor:"pointer"}} onClick={() => setPage(c.p)}>
                  <div style={{fontSize:24,marginBottom:5}}>{c.ico}</div>
                  <div style={{fontFamily:FS,fontSize:12,fontWeight:700,color:BSH.creme}}>{c.t}</div>
                  <div style={{fontSize:10,color:BSH.cremeD,marginTop:2}}>{c.sub}</div>
                </BCard>
              ))}
            </div>
          </div>
        )}

        {/* ── BOUTIQUE ── */}
        {page === "boutique" && (
          <div style={{display:"flex",flexDirection:"column",gap:11}}>
            <h2 style={{fontFamily:FS,fontSize:18,color:BSH.or,margin:0}}>Boutique</h2>
            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
              {produits.map(p => (
                <BCard key={p.id} accent style={{padding:"11px",cursor:"pointer"}} onClick={() => setModal({type:"prod",p})}>
                  <div style={{position:"relative"}}>
                    <div style={{fontSize:30,textAlign:"center",padding:"7px 0",background:`${BSH.bord}18`,borderRadius:8,marginBottom:6}}>{p.ico||"🌹"}</div>
                    <button onClick={e=>{e.stopPropagation();togFav(p.id);}} style={{position:"absolute",top:2,right:2,background:"none",border:"none",cursor:"pointer",fontSize:13}}>{fav.includes(p.id)?"❤️":"🤍"}</button>
                  </div>
                  {p.isNew && <BTag c={BSH.vert} sz={8}>Nouveau</BTag>}
                  <div style={{fontFamily:FS,fontSize:11,fontWeight:600,color:BSH.creme,margin:"4px 0 3px",lineHeight:1.3}}>{p.name}</div>
                  <div style={{marginBottom:7}}>
                    {p.promo ? <><span style={{fontSize:14,fontWeight:700,color:BSH.or,fontFamily:FS}}>{p.promo}€</span><span style={{fontSize:10,color:BSH.cremeD,textDecoration:"line-through",marginLeft:4}}>{p.prix}€</span></> : <span style={{fontSize:14,fontWeight:700,color:BSH.or,fontFamily:FS}}>{p.prix}€</span>}
                  </div>
                  <BBtn v="bord" sz="sm" full onClick={e=>{e.stopPropagation();addCart(p);}}>+ Panier</BBtn>
                </BCard>
              ))}
            </div>
          </div>
        )}

        {/* ── ÉVÉNEMENTS ── */}
        {page === "evenements" && (
          <div style={{display:"flex",flexDirection:"column",gap:11}}>
            <h2 style={{fontFamily:FS,fontSize:18,color:BSH.or,margin:0}}>Événements</h2>
            {evenements.map(e => {
              const pct = Math.round(((e.cap-e.dispo)/e.cap)*100)||0;
              return (
                <BCard key={e.id} accent style={{cursor:"pointer"}} onClick={() => setModal({type:"evt",e})}>
                  <div style={{display:"flex",gap:12,alignItems:"flex-start"}}>
                    <div style={{fontSize:26,flexShrink:0,marginTop:2}}>{e.ico||"✨"}</div>
                    <div style={{flex:1}}>
                      <div style={{fontFamily:FS,fontSize:14,fontWeight:700,color:BSH.creme,marginBottom:3}}>{e.nom}</div>
                      <div style={{fontSize:11,color:BSH.cremeD,marginBottom:8,lineHeight:1.5}}>{e.desc}</div>
                      <div style={{display:"flex",gap:5,flexWrap:"wrap",marginBottom:9}}>
                        <BTag c={BSH.or} sz={9}>📅 {fmt(e.date)}</BTag>
                        <BTag c={BSH.bord} sz={9}>📍 {e.lieu}</BTag>
                        <BTag c={BSH.rose} sz={9}>🎟 {e.prix}€</BTag>
                      </div>
                      <div style={{background:"rgba(255,255,255,.05)",borderRadius:3,height:4,marginBottom:4}}><div style={{background:`linear-gradient(90deg,${BSH.bord},${BSH.rose})`,height:"100%",borderRadius:3,width:`${pct}%`}}/></div>
                      <div style={{fontSize:10,color:BSH.cremeD}}>{e.dispo} place{e.dispo!==1?"s":""} restante{e.dispo!==1?"s":""}</div>
                    </div>
                  </div>
                </BCard>
              );
            })}
          </div>
        )}

        {/* ── CLUB VIP ── */}
        {page === "vip" && (
          <div style={{display:"flex",flexDirection:"column",gap:11}}>
            <h2 style={{fontFamily:FS,fontSize:18,color:BSH.or,margin:0,textAlign:"center"}}>Club VIP ✦</h2>
            <p style={{color:BSH.cremeD,textAlign:"center",fontSize:12,margin:0,lineHeight:1.7}}>Un cercle exclusif d'expériences et de privilèges.</p>
            {VIP_LEVELS.map(v => (
              <BCard key={v.level} style={{borderTop:`4px solid ${v.color}`,padding:"16px 14px"}}>
                <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:10}}>
                  <div style={{fontFamily:FS,fontSize:16,fontWeight:700,color:v.color}}>{v.level}</div>
                  <div style={{fontSize:14,color:BSH.or,fontWeight:700}}>{v.prix}</div>
                </div>
                {v.avs.map(a => <div key={a} style={{fontSize:11,color:BSH.cremeD,marginBottom:5,display:"flex",gap:7}}><span style={{color:v.color,flexShrink:0}}>✓</span>{a}</div>)}
                <div style={{marginTop:12}}>
                  <BBtn v="bord" sz="sm" full onClick={() => window.open(`https://wa.me/594694356037?text=Bonjour, je souhaite rejoindre le Club VIP ${v.level} Bella'Secret Home`,"_blank")}>Rejoindre le Club {v.level} →</BBtn>
                </div>
              </BCard>
            ))}
          </div>
        )}

        {/* ── FAQ ── */}
        {page === "faq" && (
          <div style={{display:"flex",flexDirection:"column",gap:9}}>
            <h2 style={{fontFamily:FS,fontSize:18,color:BSH.or,margin:0}}>Questions fréquentes</h2>
            {FAQ_BSH.map(([q,r]) => <FAQItem key={q} q={q} r={r}/>)}
          </div>
        )}
      </div>

      {/* MODALS */}
      {modal === "cart" && (
        <Mdl title="Ma commande 🛍️" onClose={() => setModal(null)}>
          {cart.length === 0 ? <p style={{color:B.muted,textAlign:"center",padding:"16px"}}>Votre panier est vide.</p> : <>
            {/* Récap produits */}
            {cart.map(i => (
              <div key={i.id} style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"8px 0",borderBottom:`1px solid ${B.border}`}}>
                <div style={{display:"flex",gap:9,alignItems:"center"}}><span style={{fontSize:20}}>{i.ico}</span><span style={{fontSize:12,color:B.cream}}>{i.name} ×{i.qty}</span></div>
                <div style={{display:"flex",gap:9,alignItems:"center"}}>
                  <span style={{fontSize:13,color:B.gold,fontWeight:700}}>{(i.promo||i.prix)*i.qty}€</span>
                  <button onClick={() => setCart(c=>c.filter(x=>x.id!==i.id))} style={{background:"none",border:"none",color:B.danger,cursor:"pointer",fontSize:16}}>✕</button>
                </div>
              </div>
            ))}
            <div style={{display:"flex",justifyContent:"space-between",margin:"14px 0 16px"}}>
              <span style={{fontSize:16,color:B.cream,fontFamily:FS}}>Total</span>
              <span style={{fontSize:22,fontWeight:700,color:B.gold,fontFamily:FS}}>{cartT}€</span>
            </div>
            {/* Nom client */}
            <div style={{marginBottom:12}}>
              <label style={{fontSize:11,fontWeight:700,color:B.mutedL,letterSpacing:"0.06em",textTransform:"uppercase",display:"block",marginBottom:5}}>Votre prénom</label>
              <input value={nomClient} onChange={e=>setNomClient(e.target.value)} placeholder="Prénom (facultatif)" style={{width:"100%",background:B.surface,border:`1px solid ${B.border}`,borderRadius:10,padding:"9px 12px",color:B.cream,fontSize:13,outline:"none",fontFamily:SA,boxSizing:"border-box"}}/>
            </div>
            {/* Mode de paiement */}
            <div style={{marginBottom:18}}>
              <label style={{fontSize:11,fontWeight:700,color:B.mutedL,letterSpacing:"0.06em",textTransform:"uppercase",display:"block",marginBottom:8}}>Mode de paiement</label>
              <div style={{display:"flex",flexWrap:"wrap",gap:7}}>
                {[
                  {id:"WhatsApp",ico:"💬",label:"WhatsApp"},
                  {id:"SumUp",ico:"💳",label:"SumUp"},
                  {id:"PayPal",ico:"🅿",label:"PayPal"},
                  {id:"Revolut",ico:"🔵",label:"Revolut"},
                  {id:"Espèces",ico:"💵",label:"Espèces"},
                ].map(p => (
                  <button key={p.id} onClick={() => setPmtChoisi(p.id)} style={{padding:"7px 12px",borderRadius:9,border:`2px solid ${pmtChoisi===p.id?BSH.or:BSH.line}`,background:pmtChoisi===p.id?`${BSH.or}22`:"transparent",color:pmtChoisi===p.id?BSH.or:BSH.cremeD,cursor:"pointer",fontSize:12,fontWeight:pmtChoisi===p.id?700:400,fontFamily:SA}}>
                    {p.ico} {p.label}
                  </button>
                ))}
              </div>
              {pmtChoisi === "PayPal" && <div style={{fontSize:11,color:B.gold,marginTop:8}}>📧 vilosarlise972@gmail.com</div>}
            </div>
            {/* Bouton confirmer */}
            <Btn v="gold" full onClick={confirmerCommande}>
              ✅ Confirmer & envoyer sur WhatsApp →
            </Btn>
            <p style={{textAlign:"center",fontSize:10,color:B.muted,marginTop:8,lineHeight:1.6}}>
              Un numéro de commande sera généré automatiquement.<br/>La fondatrice recevra votre commande en temps réel.
            </p>
          </>}
        </Mdl>
      )}
      {modal?.type === "prod" && (
        <Mdl title={modal.p.name} onClose={() => setModal(null)}>
          <div style={{textAlign:"center",fontSize:52,marginBottom:10}}>{modal.p.ico}</div>
          <p style={{color:B.muted,fontSize:13,textAlign:"center",marginBottom:14,lineHeight:1.6}}>{modal.p.desc}</p>
          <div style={{textAlign:"center",marginBottom:18}}>
            {modal.p.promo ? <><span style={{fontSize:26,fontWeight:700,color:B.gold,fontFamily:FS}}>{modal.p.promo}€</span><span style={{fontSize:14,color:B.muted,textDecoration:"line-through",marginLeft:8}}>{modal.p.prix}€</span></> : <span style={{fontSize:26,fontWeight:700,color:B.gold,fontFamily:FS}}>{modal.p.prix}€</span>}
          </div>
          <div style={{display:"flex",flexDirection:"column",gap:9}}>
            <Btn v="gold" full onClick={() => {addCart(modal.p); setModal(null);}}>🛒 Ajouter au panier</Btn>
            <Btn v="ghost" full onClick={() => window.open(`https://wa.me/594694356037?text=Bonjour, je voudrais commander : ${modal.p.name}`,"_blank")}>💬 Commander via WhatsApp</Btn>
          </div>
        </Mdl>
      )}
      {modal?.type === "evt" && (
        <Mdl title={modal.e.nom} onClose={() => setModal(null)}>
          <div style={{textAlign:"center",fontSize:40,marginBottom:10}}>{modal.e.ico}</div>
          <p style={{color:B.muted,fontSize:13,textAlign:"center",marginBottom:16,lineHeight:1.6}}>{modal.e.desc}</p>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8,marginBottom:18}}>
            {[["📅 Date",fmt(modal.e.date)],["📍 Lieu",modal.e.lieu],["🎟 Prix",`${modal.e.prix}€/pers.`],["👥 Places",`${modal.e.dispo} restante${modal.e.dispo!==1?"s":""}`]].map(([l,v]) => (
              <div key={l} style={{background:B.surface,borderRadius:9,padding:"9px 11px",border:`1px solid ${B.border}`}}>
                <div style={{fontSize:9,color:B.gold,marginBottom:3,fontWeight:700}}>{l}</div>
                <div style={{fontSize:12,color:B.cream,fontWeight:600}}>{v}</div>
              </div>
            ))}
          </div>
          <Btn v="gold" full onClick={async () => {
            const id = genId();
            const cmd = {
              id,
              client: "Client web",
              produit: `Événement : ${modal.e.nom} — ${fmt(modal.e.date)}`,
              montant: modal.e.prix,
              acompte: 0,
              statut: "Demande reçue",
              date: today(),
              pmt: "À confirmer",
              notes: `Réservation événement web — ${new Date().toLocaleString("fr-FR")}`,
            };
            if (onNewCommande) await onNewCommande(cmd);
            const msg = `🌹 *RÉSERVATION ${id}*\n\nÉvénement : ${modal.e.nom}\nDate : ${fmt(modal.e.date)}\nLieu : ${modal.e.lieu}\nTarif : ${modal.e.prix}€/pers.\nDate réservation : ${new Date().toLocaleString("fr-FR")}\n\nMerci de confirmer ma réservation.`;
            setModal(null);
            window.open(`https://wa.me/594694356037?text=${encodeURIComponent(msg)}`, "_blank");
          }}>Réserver via WhatsApp →</Btn>
        </Mdl>
      )}
    </div>
  );
}

// ═══════════════════════════════════════════════════════════
// ── ESPACE CLIENT BELLA'ODYSSÉE
// ═══════════════════════════════════════════════════════════
function ClientOdyssee({rdvs, onBack}) {
  const [page, setPage] = useState("accueil");
  const [modal, setModal] = useState(null);
  const [form, setForm] = useState({prestation:PRESTATIONS_BO[0],date:today(),heure:"10h00",nom:"",tel:""});

  const PAGES = [{id:"accueil",l:"🏠"},{id:"prestations",l:"💅"},{id:"rdv",l:"📅"},{id:"galerie",l:"📸"},{id:"contact",l:"📞"}];

  return (
    <div style={{display:"flex",flexDirection:"column",height:"100vh",background:`radial-gradient(ellipse at 20% 0%,${BO.prune},${BO.fond} 65%)`,fontFamily:SA}}>
      {/* Header */}
      <div style={{padding:"10px 14px",borderBottom:`1px solid ${BO.line}`,display:"flex",justifyContent:"space-between",alignItems:"center",background:"rgba(0,0,0,0.35)",flexShrink:0}}>
        <div>
          <div style={{fontFamily:FS,fontSize:14,color:BO.or,letterSpacing:2}}>💅 Bella'Odyssée</div>
          <div style={{fontSize:8,color:BO.cremeD,letterSpacing:3}}>BEAUTÉ · SOINS · ÉLÉGANCE</div>
        </div>
        <button onClick={onBack} style={{background:"none",border:`1px solid ${BO.line}`,borderRadius:8,padding:"5px 9px",color:BO.cremeD,cursor:"pointer",fontSize:10,fontFamily:SA}}>‹ Portail</button>
      </div>

      {/* Nav */}
      <div style={{display:"flex",justifyContent:"space-around",padding:"8px 12px",borderBottom:`1px solid ${BO.line}`,background:"rgba(0,0,0,0.2)",flexShrink:0}}>
        {PAGES.map(p => (
          <button key={p.id} onClick={() => setPage(p.id)} style={{display:"flex",flexDirection:"column",alignItems:"center",gap:2,background:"none",border:"none",cursor:"pointer",padding:"4px 8px",borderBottom:page===p.id?`2px solid ${BO.or}`:"2px solid transparent"}}>
            <span style={{fontSize:18}}>{p.l}</span>
            <span style={{fontSize:8,color:page===p.id?BO.or:BO.cremeD,fontWeight:700,textTransform:"capitalize"}}>{p.id==="rdv"?"RDV":p.id}</span>
          </button>
        ))}
      </div>

      {/* Contenu */}
      <div style={{flex:1,overflowY:"auto",padding:"14px",color:BO.creme}}>

        {/* ── ACCUEIL ── */}
        {page === "accueil" && (
          <div style={{display:"flex",flexDirection:"column",gap:14}}>
            <div style={{textAlign:"center",padding:"16px 0 8px"}}>
              <div style={{fontSize:52,marginBottom:10}}>💅</div>
              <div style={{fontFamily:FS,fontSize:22,color:BO.or,letterSpacing:2,marginBottom:6}}>Bella'Odyssée</div>
              <div style={{fontSize:13,color:BO.cremeD,lineHeight:1.8}}>Studio beauté & soins à Sinnamary.<br/>Extensions de cils · Browlift · Lashlift<br/>Blanchiment · Strass dentaires</div>
            </div>
            <OCard accent style={{textAlign:"center",padding:"18px 16px"}}>
              <div style={{fontFamily:FS,fontSize:14,color:BO.or,marginBottom:8}}>Prendre rendez-vous ✦</div>
              <div style={{fontSize:12,color:BO.cremeD,marginBottom:14,lineHeight:1.7}}>Réservez votre soin en quelques secondes.<br/>Confirmation immédiate par WhatsApp.</div>
              <OBtn v="primary" sz="md" full onClick={() => setPage("rdv")}>📅 Réserver un rendez-vous</OBtn>
            </OCard>
            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:9}}>
              {[{ico:"💅",t:"Nos prestations",sub:"5 soins signature",p:"prestations"},{ico:"📸",t:"Galerie",sub:"Avant / Après",p:"galerie"}].map(c => (
                <OCard key={c.t} style={{textAlign:"center",padding:"14px 10px",cursor:"pointer"}} onClick={() => setPage(c.p)}>
                  <div style={{fontSize:26,marginBottom:5}}>{c.ico}</div>
                  <div style={{fontFamily:FS,fontSize:12,fontWeight:700,color:BO.creme}}>{c.t}</div>
                  <div style={{fontSize:10,color:BO.cremeD,marginTop:2}}>{c.sub}</div>
                </OCard>
              ))}
            </div>
          </div>
        )}

        {/* ── PRESTATIONS ── */}
        {page === "prestations" && (
          <div style={{display:"flex",flexDirection:"column",gap:11}}>
            <h2 style={{fontFamily:FS,fontSize:18,color:BO.or,margin:0}}>Nos Prestations</h2>
            {[
              {ico:"👁",nom:"Extensions de cils",desc:"Pose classique, volume russe ou mega volume. Résultat naturel à spectaculaire selon vos envies.",duree:"1h30-2h30",prix:"À partir de 45€"},
              {ico:"🦷",nom:"Blanchiment dentaire",desc:"Technique LED professionnelle. Résultat visible dès la première séance.",duree:"45min",prix:"À partir de 59€"},
              {ico:"✨",nom:"Strass dentaires",desc:"Pose de bijoux dentaires sans dommage sur l'émail. Tendance et élégant.",duree:"30min",prix:"À partir de 25€"},
              {ico:"🌿",nom:"Browlift",desc:"Restructuration et mise en forme des sourcils. Regard expressif et défini.",duree:"45min",prix:"À partir de 35€"},
              {ico:"🌟",nom:"Lashlift",desc:"Rehaussement permanent des cils naturels. Effet mascara sans mascara.",duree:"1h",prix:"À partir de 40€"},
            ].map(p => (
              <OCard key={p.nom} accent>
                <div style={{display:"flex",gap:12,alignItems:"flex-start"}}>
                  <div style={{fontSize:28,flexShrink:0,marginTop:2}}>{p.ico}</div>
                  <div style={{flex:1}}>
                    <div style={{fontFamily:FS,fontSize:14,fontWeight:700,color:BO.creme,marginBottom:4}}>{p.nom}</div>
                    <div style={{fontSize:12,color:BO.cremeD,marginBottom:9,lineHeight:1.6}}>{p.desc}</div>
                    <div style={{display:"flex",gap:7,flexWrap:"wrap",marginBottom:10}}>
                      <OTag c={BO.acc} sz={9}>⏱ {p.duree}</OTag>
                      <OTag c={BO.or} sz={9}>💰 {p.prix}</OTag>
                    </div>
                    <OBtn v="primary" sz="sm" full onClick={() => {setForm({...form,prestation:p.nom});setPage("rdv");}}>Réserver ce soin →</OBtn>
                  </div>
                </div>
              </OCard>
            ))}
          </div>
        )}

        {/* ── RÉSERVATION ── */}
        {page === "rdv" && (
          <div style={{display:"flex",flexDirection:"column",gap:14}}>
            <h2 style={{fontFamily:FS,fontSize:18,color:BO.or,margin:0}}>Prendre rendez-vous</h2>
            <OCard accent>
              <div style={{marginBottom:14}}>
                <label style={{fontSize:11,fontWeight:700,color:BO.cremeD,letterSpacing:"0.06em",textTransform:"uppercase",display:"block",marginBottom:5}}>Votre prénom</label>
                <input value={form.nom} onChange={e=>setForm({...form,nom:e.target.value})} placeholder="Votre prénom" style={{width:"100%",background:"rgba(255,255,255,.06)",border:`1px solid ${BO.line}`,borderRadius:10,padding:"9px 12px",color:BO.creme,fontSize:13,outline:"none",fontFamily:SA,boxSizing:"border-box"}}/>
              </div>
              <div style={{marginBottom:14}}>
                <label style={{fontSize:11,fontWeight:700,color:BO.cremeD,letterSpacing:"0.06em",textTransform:"uppercase",display:"block",marginBottom:5}}>Prestation souhaitée</label>
                <select value={form.prestation} onChange={e=>setForm({...form,prestation:e.target.value})} style={{width:"100%",background:"rgba(255,255,255,.06)",border:`1px solid ${BO.line}`,borderRadius:10,padding:"9px 12px",color:BO.creme,fontSize:13,outline:"none",fontFamily:SA,boxSizing:"border-box"}}>
                  {PRESTATIONS_BO.filter(p=>p!=="Autre").map(p=><option key={p} value={p}>{p}</option>)}
                </select>
              </div>
              <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10,marginBottom:14}}>
                <div>
                  <label style={{fontSize:11,fontWeight:700,color:BO.cremeD,letterSpacing:"0.06em",textTransform:"uppercase",display:"block",marginBottom:5}}>Date souhaitée</label>
                  <input type="date" value={form.date} onChange={e=>setForm({...form,date:e.target.value})} style={{width:"100%",background:"rgba(255,255,255,.06)",border:`1px solid ${BO.line}`,borderRadius:10,padding:"9px 12px",color:BO.creme,fontSize:13,outline:"none",fontFamily:SA,boxSizing:"border-box"}}/>
                </div>
                <div>
                  <label style={{fontSize:11,fontWeight:700,color:BO.cremeD,letterSpacing:"0.06em",textTransform:"uppercase",display:"block",marginBottom:5}}>Heure</label>
                  <select value={form.heure} onChange={e=>setForm({...form,heure:e.target.value})} style={{width:"100%",background:"rgba(255,255,255,.06)",border:`1px solid ${BO.line}`,borderRadius:10,padding:"9px 12px",color:BO.creme,fontSize:13,outline:"none",fontFamily:SA,boxSizing:"border-box"}}>
                    {["8h00","9h00","10h00","11h00","13h00","14h00","15h00","16h00","17h00"].map(h=><option key={h}>{h}</option>)}
                  </select>
                </div>
              </div>
              <div style={{marginBottom:16}}>
                <label style={{fontSize:11,fontWeight:700,color:BO.cremeD,letterSpacing:"0.06em",textTransform:"uppercase",display:"block",marginBottom:5}}>Téléphone / WhatsApp</label>
                <input value={form.tel} onChange={e=>setForm({...form,tel:e.target.value})} placeholder="+594..." style={{width:"100%",background:"rgba(255,255,255,.06)",border:`1px solid ${BO.line}`,borderRadius:10,padding:"9px 12px",color:BO.creme,fontSize:13,outline:"none",fontFamily:SA,boxSizing:"border-box"}}/>
              </div>
              <OBtn v="primary" sz="md" full disabled={!form.nom.trim()} onClick={() => {
                const msg=`Bonjour, je souhaite prendre rendez-vous pour : ${form.prestation}\nDate : ${fmt(form.date)} à ${form.heure}\nPrénom : ${form.nom}\nTél : ${form.tel||"À préciser"}`;
                window.open(`https://wa.me/594694356037?text=${encodeURIComponent(msg)}`,"_blank");
              }}>💬 Envoyer ma demande via WhatsApp</OBtn>
              <p style={{textAlign:"center",fontSize:10,color:BO.cremeD,marginTop:8}}>Confirmation rapide · Acompte possible</p>
            </OCard>
            <OCard style={{padding:"12px 14px"}}>
              <div style={{fontSize:12,fontWeight:700,color:BO.creme,marginBottom:6}}>📍 Nous trouver</div>
              <div style={{fontSize:11,color:BO.cremeD,lineHeight:1.8}}>12 Boulevard François Horth<br/>Bâtiment Tokoko — Appartement C3<br/>97315 Sinnamary, Guyane française</div>
            </OCard>
          </div>
        )}

        {/* ── GALERIE ── */}
        {page === "galerie" && (
          <div style={{display:"flex",flexDirection:"column",gap:11}}>
            <h2 style={{fontFamily:FS,fontSize:18,color:BO.or,margin:0}}>Galerie Avant / Après</h2>
            <p style={{fontSize:12,color:BO.cremeD,margin:0,lineHeight:1.7}}>Découvrez les transformations réalisées par Bella'Odyssée.</p>
            {[
              {presta:"Extensions de cils",avant:"Cils courts et clairsemés",apres:"Volume russe — regard magnétique"},
              {presta:"Browlift",avant:"Sourcils non dessinés",apres:"Arc parfait et regard ouvert"},
              {presta:"Blanchiment dentaire",avant:"Dents jaunies par le café",apres:"Sourire 3 teintes plus clair"},
              {presta:"Lashlift",avant:"Cils naturels tombants",apres:"Cils recourbés et allongés"},
            ].map((g,i) => (
              <OCard key={i} accent style={{padding:"12px 14px"}}>
                <div style={{fontFamily:FS,fontSize:12,fontWeight:700,color:BO.or,marginBottom:9}}>💅 {g.presta}</div>
                <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8}}>
                  {[{l:"Avant",v:g.avant,c:"rgba(180,80,80,0.2)"},{l:"Après",v:g.apres,c:"rgba(80,180,120,0.2)"}].map(x=>(
                    <div key={x.l} style={{background:x.c,borderRadius:9,padding:"10px",textAlign:"center",border:`1px solid ${x.l==="Avant"?BO.rouge||"#e84444":"rgba(80,180,120,0.3)"}`}}>
                      <div style={{fontSize:9,fontWeight:800,color:x.l==="Avant"?"#f4a0a0":"#80e0a0",marginBottom:4,letterSpacing:"0.08em"}}>{x.l.toUpperCase()}</div>
                      <div style={{fontSize:11,color:BO.creme,lineHeight:1.5}}>{x.v}</div>
                    </div>
                  ))}
                </div>
              </OCard>
            ))}
            <OBtn v="primary" sz="md" full onClick={() => setPage("rdv")}>📅 Réserver mon soin →</OBtn>
          </div>
        )}

        {/* ── CONTACT ── */}
        {page === "contact" && (
          <div style={{display:"flex",flexDirection:"column",gap:11}}>
            <h2 style={{fontFamily:FS,fontSize:18,color:BO.or,margin:0}}>Contact</h2>
            {[
              {ico:"💬",t:"WhatsApp",v:"+594 694 35 60 37",action:()=>window.open("https://wa.me/594694356037","_blank"),cta:"Envoyer un message"},
              {ico:"📧",t:"E-mail",v:"bella.studio973@hotmail.com",action:()=>window.open("mailto:bella.studio973@hotmail.com","_blank"),cta:"Envoyer un e-mail"},
              {ico:"📍",t:"Adresse",v:"12 Bd François Horth\nBât. Tokoko — Apt. C3\n97315 Sinnamary, Guyane",action:null,cta:null},
            ].map(c => (
              <OCard key={c.t} style={{padding:"14px 16px"}}>
                <div style={{display:"flex",gap:12,alignItems:"flex-start"}}>
                  <div style={{fontSize:24,flexShrink:0}}>{c.ico}</div>
                  <div style={{flex:1}}>
                    <div style={{fontFamily:FS,fontSize:12,fontWeight:700,color:BO.or,marginBottom:4}}>{c.t}</div>
                    <div style={{fontSize:12,color:BO.cremeD,lineHeight:1.7,whiteSpace:"pre-wrap",marginBottom:c.action?10:0}}>{c.v}</div>
                    {c.action && <OBtn v="primary" sz="sm" onClick={c.action}>{c.cta}</OBtn>}
                  </div>
                </div>
              </OCard>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════
// ── PLACEHOLDER UNIVERS (Events, Food, Vilo, Éditions, MTP)
// ═══════════════════════════════════════════════════════════
function PlaceholderUnivers({univers, onBack}) {
  const u = UNIVERS.find(x => x.id === univers);
  if (!u) return null;
  return (
    <div style={{display:"flex",flexDirection:"column",height:"100vh",background:`radial-gradient(ellipse at 20% 0%,${u.bg},${B.night} 65%)`,fontFamily:SA,alignItems:"center",justifyContent:"center",padding:"24px"}}>
      <div style={{textAlign:"center",maxWidth:320}}>
        <div style={{width:72,height:72,borderRadius:20,background:`${u.acc}30`,border:`1px solid ${u.acc}50`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:36,margin:"0 auto 20px"}}>{u.ico}</div>
        <div style={{fontFamily:FS,fontSize:22,color:"#fff",marginBottom:6}}>{u.nom}</div>
        <div style={{fontSize:13,color:"rgba(255,255,255,0.6)",marginBottom:8}}>{u.tag}</div>
        <div style={{background:`${u.acc}20`,border:`1px solid ${u.acc}40`,borderRadius:12,padding:"16px",marginBottom:24}}>
          <div style={{fontSize:11,color:"rgba(255,255,255,0.7)",lineHeight:1.8}}>
            ✦ Espace client en préparation<br/>
            <span style={{color:u.or,fontWeight:700}}>Prochainement disponible</span><br/>
            <br/>
            En attendant, contactez-nous<br/>directement via WhatsApp
          </div>
        </div>
        <div style={{display:"flex",flexDirection:"column",gap:10}}>
          <button onClick={() => window.open(`https://wa.me/594694356037?text=Bonjour, je suis intéressé(e) par ${u.nom}`,"_blank")} style={{background:`linear-gradient(135deg,${u.acc},${u.acc2})`,border:"none",borderRadius:12,padding:"12px 20px",color:"#fff",cursor:"pointer",fontWeight:700,fontSize:13,fontFamily:SA}}>
            💬 Nous contacter via WhatsApp
          </button>
          <button onClick={onBack} style={{background:"none",border:`1px solid rgba(255,255,255,0.2)`,borderRadius:12,padding:"10px 20px",color:"rgba(255,255,255,0.7)",cursor:"pointer",fontSize:12,fontFamily:SA}}>
            ‹ Retour au portail
          </button>
        </div>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════
// ── ESPACE FONDATRICE — DASHBOARD + PROJETS + TÂCHES + BSH + HUB + IA
// ═══════════════════════════════════════════════════════════
function DashF({projets,taches,bshCmds,bshProduits,goto}) {
  const actifs = projets.filter(p=>p.statut==="En cours");
  const retard = projets.filter(p=>p.dateCible&&new Date(p.dateCible)<new Date()&&p.statut!=="Terminé"&&p.statut!=="Archivé");
  const urgentes = taches.filter(t=>t.statut!=="Terminé"&&t.priorite==="Haute");
  const ca = bshCmds.filter(c=>c.statut==="Paiement complet reçu"||c.statut==="Terminée").reduce((s,c)=>s+(parseFloat(c.montant)||0),0);
  const stockCrit = bshProduits.filter(p=>p.stock<=p.min);

  return (
    <div style={{display:"flex",flexDirection:"column",gap:22}}>
      <div>
        <p style={{margin:0,fontSize:11,color:B.muted,letterSpacing:"0.1em",textTransform:"uppercase"}}>{new Date().toLocaleDateString("fr-FR",{weekday:"long",day:"numeric",month:"long",year:"numeric"})}</p>
        <h1 style={{margin:"4px 0 0",fontSize:24,fontWeight:900,color:B.cream,fontFamily:FS}}>Bonjour, Renée-Lise ✦</h1>
        <p style={{margin:"4px 0 0",fontSize:13,color:B.muted}}>Bellaïa prépare. Toi, tu décides.</p>
      </div>
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:9}}>
        {[
          {ico:"◉",l:"Projets actifs",v:actifs.length,s:`${projets.length} total`,m:"projets"},
          {ico:"◫",l:"Tâches urgentes",v:urgentes.length,s:"Priorité haute",m:"taches",acc:1},
          {ico:"✦",l:"Commandes BSH",v:bshCmds.filter(c=>c.statut!=="Terminée"&&c.statut!=="Annulée").length,s:"En cours",m:"bsh"},
          {ico:"€",l:"CA encaissé",v:`${ca}€`,s:"BSH confirmé",acc:1,m:"finances"},
        ].map(s=>(
          <div key={s.l} onClick={()=>goto(s.m)} style={{background:B.card,border:`1px solid ${s.acc?B.borderG:B.border}`,borderRadius:13,padding:"14px 12px",cursor:"pointer",position:"relative",overflow:"hidden"}}>
            <div style={{position:"absolute",top:-12,right:-12,width:50,height:50,borderRadius:"50%",background:s.acc?B.goldG:B.violetG,filter:"blur(14px)"}}/>
            <div style={{fontSize:18,marginBottom:5}}>{s.ico}</div>
            <div style={{fontSize:24,fontWeight:900,color:s.acc?B.gold:B.violetL,fontFamily:FS,marginBottom:2}}>{s.v}</div>
            <div style={{fontSize:11,fontWeight:700,color:B.cream}}>{s.l}</div>
            <div style={{fontSize:10,color:B.muted}}>{s.s}</div>
          </div>
        ))}
      </div>

      {(retard.length>0||stockCrit.length>0)&&(
        <div style={{background:"rgba(180,80,80,0.1)",border:"1px solid rgba(180,80,80,0.3)",borderRadius:12,padding:"12px 14px"}}>
          <div style={{fontSize:12,fontWeight:800,color:B.danger,marginBottom:8}}>⚠ Alertes</div>
          {retard.map(p=><div key={p.id} style={{fontSize:11,color:B.danger,marginBottom:4}}>📅 {p.titre} — date dépassée</div>)}
          {stockCrit.map(p=><div key={p.id} style={{fontSize:11,color:B.warning,marginBottom:4}}>📦 {p.name} — stock {p.stock}/{p.min} min.</div>)}
        </div>
      )}

      {actifs.length>0&&(
        <div>
          <div style={{display:"flex",justifyContent:"space-between",marginBottom:9}}>
            <span style={{fontSize:13,fontWeight:800,color:B.cream}}>Projets prioritaires</span>
            <span onClick={()=>goto("projets")} style={{fontSize:11,color:B.violetL,cursor:"pointer",fontWeight:700}}>Voir tout →</span>
          </div>
          {actifs.filter(p=>p.priorite==="Haute").slice(0,3).map(p=>(
            <div key={p.id} style={{background:B.card,border:`1px solid ${B.border}`,borderRadius:11,padding:"11px 13px",marginBottom:7}}>
              <div style={{display:"flex",justifyContent:"space-between",marginBottom:5}}>
                <span style={{fontSize:12,fontWeight:700,color:B.cream}}>{p.titre}</span>
                <span style={{fontSize:11,color:B.violetL,fontWeight:800}}>{p.avancement||0}%</span>
              </div>
              <PBar v={p.avancement||0}/>
              <div style={{display:"flex",justifyContent:"space-between",marginTop:4}}>
                <span style={{fontSize:10,color:B.muted}}>{p.pole}</span>
                {p.dateCible&&<span style={{fontSize:10,color:new Date(p.dateCible)<new Date()&&p.statut!=="Terminé"?B.danger:B.muted}}>📅 {fmt(p.dateCible)}</span>}
              </div>
            </div>
          ))}
        </div>
      )}

      {urgentes.length>0&&(
        <div>
          <div style={{display:"flex",justifyContent:"space-between",marginBottom:9}}>
            <span style={{fontSize:13,fontWeight:800,color:B.cream}}>À faire maintenant</span>
            <span onClick={()=>goto("taches")} style={{fontSize:11,color:B.violetL,cursor:"pointer",fontWeight:700}}>Voir tout →</span>
          </div>
          {urgentes.slice(0,3).map(t=>(
            <div key={t.id} style={{background:B.card,border:`1px solid ${B.border}`,borderRadius:11,padding:"9px 12px",display:"flex",gap:9,alignItems:"center",marginBottom:6}}>
              <div style={{width:16,height:16,borderRadius:4,border:`2px solid ${B.violet}`,flexShrink:0}}/>
              <div style={{flex:1}}>
                <div style={{fontSize:12,fontWeight:600,color:B.cream}}>{t.titre}</div>
                <div style={{fontSize:10,color:B.muted}}>{t.projetNom||"Sans projet"}</div>
              </div>
              <span style={{fontSize:10,color:B.danger,fontWeight:800}}>● Haute</span>
            </div>
          ))}
        </div>
      )}

      {projets.length===0&&(
        <div style={{textAlign:"center",padding:"40px 20px",color:B.muted}}>
          <div style={{fontSize:40,marginBottom:12}}>◎</div>
          <div style={{fontSize:14,fontWeight:700,color:B.mutedL,marginBottom:6}}>Bellaïa est prête.</div>
          <div style={{fontSize:12,marginBottom:16}}>Tes projets sont chargés. Commence à naviguer.</div>
        </div>
      )}
    </div>
  );
}

function ProjetsF({projets,setProjects}) {
  const[vue,setVue]=useState("liste");const[modal,setModal]=useState(false);const[edit,setEdit]=useState(null);const[filtre,setFiltre]=useState("Tous");
  const blank={titre:"",description:"",pole:POLES[0],priorite:"Moyenne",statut:"Idée",dateDebut:today(),dateCible:"",avancement:0,revenusEstimes:""};
  const[form,setForm]=useState(blank);
  const save=async()=>{if(!form.titre.trim())return;if(edit)await setProjects(p=>p.map(x=>x.id===edit?{...form,id:edit}:x));else await setProjects(p=>[...p,{...form,id:uid()}]);setModal(false);};
  const del=async id=>{if(confirm("Supprimer ?"))await setProjects(p=>p.filter(x=>x.id!==id));};
  const liste=filtre==="Tous"?projets:projets.filter(p=>p.statut===filtre);

  return(
    <div style={{display:"flex",flexDirection:"column",gap:16}}>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start"}}>
        <SH t="Portfolio Projets" s={`${projets.length} projets · ${projets.filter(p=>p.statut==="En cours").length} actifs`}/>
        <Btn onClick={()=>{setForm(blank);setEdit(null);setModal(true);}} sm>+ Nouveau</Btn>
      </div>
      <div style={{display:"flex",gap:5}}>{["liste","kanban"].map(v=><button key={v} onClick={()=>setVue(v)} style={{padding:"5px 12px",borderRadius:99,border:"none",cursor:"pointer",fontSize:11,fontWeight:700,background:vue===v?B.violet:B.card,color:vue===v?"#fff":B.muted}}>{v==="liste"?"Liste":"Kanban"}</button>)}</div>
      <div style={{display:"flex",gap:4,overflowX:"auto",paddingBottom:2}}>
        {["Tous",...STATUTS_PROJ].map(f=><button key={f} onClick={()=>setFiltre(f)} style={{padding:"4px 9px",borderRadius:99,border:`1px solid ${B.border}`,cursor:"pointer",fontSize:10,fontWeight:700,background:filtre===f?B.surface:"transparent",color:filtre===f?B.cream:B.muted,flexShrink:0,whiteSpace:"nowrap"}}>{f}</button>)}
      </div>
      {vue==="liste"&&<div style={{display:"flex",flexDirection:"column",gap:9}}>
        {liste.length===0&&<div style={{textAlign:"center",padding:"28px",color:B.muted,fontSize:13}}>Aucun projet</div>}
        {liste.map(p=>(
          <div key={p.id} style={{background:B.card,border:`1px solid ${B.border}`,borderRadius:13,padding:"13px 15px"}}>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",gap:8,marginBottom:3}}>
              <div style={{flex:1}}><div style={{fontSize:13,fontWeight:800,color:B.cream,fontFamily:FS}}>{p.titre}</div><div style={{fontSize:11,color:B.muted,marginTop:1}}>{p.pole} · <span style={{color:prioC(p.priorite)}}>{p.priorite}</span>{p.revenusEstimes?<span style={{color:B.gold}}> · {p.revenusEstimes}€ est.</span>:""}</div></div>
              <Bdg s={p.statut}/>
            </div>
            {p.description&&<div style={{fontSize:11,color:B.muted,marginBottom:7,lineHeight:1.5}}>{p.description}</div>}
            <PBar v={p.avancement||0}/><div style={{display:"flex",justifyContent:"space-between",marginTop:4,marginBottom:9}}><span style={{fontSize:10,color:B.violetL,fontWeight:700}}>{p.avancement||0}%</span>{p.dateCible&&<span style={{fontSize:10,color:new Date(p.dateCible)<new Date()&&p.statut!=="Terminé"?B.danger:B.muted}}>📅 {fmt(p.dateCible)}</span>}</div>
            <div style={{display:"flex",gap:5}}><Btn onClick={()=>{setForm({...p});setEdit(p.id);setModal(true);}} sm v="ghost">✏</Btn><Btn onClick={()=>del(p.id)} sm v="danger">✕</Btn></div>
          </div>
        ))}
      </div>}
      {vue==="kanban"&&<div style={{display:"flex",gap:9,overflowX:"auto",paddingBottom:8}}>
        {STATUTS_PROJ.map(s=>{const items=projets.filter(p=>p.statut===s);const c=sCo(s);return(<div key={s} style={{minWidth:175,flexShrink:0}}>
          <div style={{display:"flex",justifyContent:"space-between",marginBottom:7}}><span style={{fontSize:9,fontWeight:800,color:c.t,textTransform:"uppercase",letterSpacing:"0.07em"}}>{s}</span><span style={{background:c.bg,color:c.t,borderRadius:99,padding:"2px 7px",fontSize:9,fontWeight:700}}>{items.length}</span></div>
          {items.map(p=><div key={p.id} onClick={()=>{setForm({...p});setEdit(p.id);setModal(true);}} style={{background:B.card,border:`1px solid ${B.border}`,borderRadius:10,padding:"10px 11px",marginBottom:6,cursor:"pointer"}}><div style={{fontSize:11,fontWeight:700,color:B.cream,marginBottom:4}}>{p.titre}</div><PBar v={p.avancement||0}/><div style={{display:"flex",justifyContent:"space-between",marginTop:3}}><span style={{fontSize:9,color:B.muted}}>{p.avancement||0}%</span><span style={{fontSize:9,color:prioC(p.priorite)}}>{p.priorite}</span></div></div>)}
          {items.length===0&&<div style={{background:B.surface,border:`1px dashed ${B.border}`,borderRadius:10,padding:"12px",textAlign:"center",color:B.muted,fontSize:10}}>Vide</div>}
        </div>);})}
      </div>}
      {modal&&<Mdl title={edit?"Modifier":"Nouveau projet"} onClose={()=>setModal(false)}>
        <Fld label="Titre"><Inp value={form.titre} onChange={e=>setForm({...form,titre:e.target.value})} placeholder="Nom du projet"/></Fld>
        <Fld label="Description"><Inp value={form.description||""} onChange={e=>setForm({...form,description:e.target.value})} placeholder="Description" rows={2}/></Fld>
        <Fld label="Pôle"><Sel value={form.pole||POLES[0]} onChange={e=>setForm({...form,pole:e.target.value})} options={POLES}/></Fld>
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
          <Fld label="Priorité"><Sel value={form.priorite} onChange={e=>setForm({...form,priorite:e.target.value})} options={PRIOS}/></Fld>
          <Fld label="Statut"><Sel value={form.statut} onChange={e=>setForm({...form,statut:e.target.value})} options={STATUTS_PROJ}/></Fld>
        </div>
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
          <Fld label="Début"><Inp type="date" value={form.dateDebut||""} onChange={e=>setForm({...form,dateDebut:e.target.value})}/></Fld>
          <Fld label="Cible"><Inp type="date" value={form.dateCible||""} onChange={e=>setForm({...form,dateCible:e.target.value})}/></Fld>
        </div>
        <Fld label="Revenus estimés €"><Inp type="number" value={form.revenusEstimes||""} onChange={e=>setForm({...form,revenusEstimes:e.target.value})} placeholder="0"/></Fld>
        <Fld label={`Avancement : ${form.avancement||0}%`}><input type="range" min={0} max={100} value={form.avancement||0} onChange={e=>setForm({...form,avancement:parseInt(e.target.value)})} style={{width:"100%",accentColor:B.violet}}/></Fld>
        <div style={{display:"flex",gap:8}}><Btn onClick={save} full>Enregistrer</Btn><Btn onClick={()=>setModal(false)} v="ghost">Annuler</Btn></div>
      </Mdl>}
    </div>
  );
}

function TachesF({taches,setTaches,projets}) {
  const[modal,setModal]=useState(false);const[edit,setEdit]=useState(null);const[filtre,setFiltre]=useState("Tous");
  const blank={titre:"",description:"",projetId:"",projetNom:"",priorite:"Moyenne",statut:"À faire",echeance:""};
  const[form,setForm]=useState(blank);
  const save=async()=>{if(!form.titre.trim())return;const projetNom=projets.find(p=>p.id===form.projetId)?.titre||"";const entry={...form,projetNom};if(edit)await setTaches(p=>p.map(x=>x.id===edit?{...entry,id:edit}:x));else await setTaches(p=>[...p,{...entry,id:uid()}]);setModal(false);};
  const toggle=async id=>await setTaches(p=>p.map(t=>t.id===id?{...t,statut:t.statut==="Terminé"?"À faire":"Terminé"}:t));
  const del=async id=>{if(confirm("Supprimer ?"))await setTaches(p=>p.filter(x=>x.id!==id));};
  const liste=filtre==="Tous"?taches:taches.filter(t=>t.statut===filtre);

  return(
    <div style={{display:"flex",flexDirection:"column",gap:16}}>
      <div style={{display:"flex",justifyContent:"space-between"}}><SH t="Tâches & Travaux" s={`${taches.filter(t=>t.statut!=="Terminé").length} en cours`}/><Btn onClick={()=>{setForm(blank);setEdit(null);setModal(true);}} sm>+ Ajouter</Btn></div>
      <div style={{display:"flex",gap:4,overflowX:"auto",paddingBottom:2}}>
        {["Tous","À faire","En cours","En attente","Terminé"].map(f=><button key={f} onClick={()=>setFiltre(f)} style={{padding:"4px 9px",borderRadius:99,border:`1px solid ${B.border}`,cursor:"pointer",fontSize:10,fontWeight:700,background:filtre===f?B.surface:"transparent",color:filtre===f?B.cream:B.muted,flexShrink:0,whiteSpace:"nowrap"}}>{f} {f!=="Tous"?`(${taches.filter(t=>t.statut===f).length})`:""}</button>)}
      </div>
      <div style={{display:"flex",flexDirection:"column",gap:7}}>
        {liste.length===0&&<div style={{textAlign:"center",padding:"28px",color:B.muted,fontSize:13}}>Aucune tâche</div>}
        {liste.map(t=>(
          <div key={t.id} style={{background:B.card,border:`1px solid ${B.border}`,borderRadius:12,padding:"11px 13px",opacity:t.statut==="Terminé"?0.6:1}}>
            <div style={{display:"flex",gap:9,alignItems:"flex-start"}}>
              <div onClick={()=>toggle(t.id)} style={{width:19,height:19,borderRadius:5,border:`2px solid ${t.statut==="Terminé"?B.success:B.violet}`,background:t.statut==="Terminé"?B.success:"transparent",flexShrink:0,cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center",marginTop:1}}>{t.statut==="Terminé"&&<span style={{fontSize:10,color:B.night,fontWeight:900}}>✓</span>}</div>
              <div style={{flex:1}}><div style={{fontSize:12,fontWeight:700,color:t.statut==="Terminé"?B.muted:B.cream,textDecoration:t.statut==="Terminé"?"line-through":"none"}}>{t.titre}</div>{t.projetNom&&<div style={{fontSize:10,color:B.muted}}>📁 {t.projetNom}</div>}<div style={{display:"flex",gap:6,marginTop:5,flexWrap:"wrap"}}><Bdg s={t.statut}/><span style={{fontSize:10,color:prioC(t.priorite),fontWeight:700}}>● {t.priorite}</span>{t.echeance&&<span style={{fontSize:10,color:B.muted}}>📅 {fmt(t.echeance)}</span>}</div></div>
              <div style={{display:"flex",flexDirection:"column",gap:3}}><Btn onClick={()=>{setForm({...t});setEdit(t.id);setModal(true);}} sm v="ghost">✏</Btn><Btn onClick={()=>del(t.id)} sm v="danger">✕</Btn></div>
            </div>
          </div>
        ))}
      </div>
      {modal&&<Mdl title={edit?"Modifier":"Nouvelle tâche"} onClose={()=>setModal(false)}>
        <Fld label="Titre"><Inp value={form.titre} onChange={e=>setForm({...form,titre:e.target.value})} placeholder="Titre"/></Fld>
        <Fld label="Projet"><select value={form.projetId||""} onChange={e=>setForm({...form,projetId:e.target.value})} style={{width:"100%",background:B.surface,border:`1px solid ${B.border}`,borderRadius:10,padding:"9px 12px",color:B.cream,fontSize:13,outline:"none",fontFamily:SA}}><option value="">— Aucun —</option>{projets.map(p=><option key={p.id} value={p.id}>{p.titre}</option>)}</select></Fld>
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
          <Fld label="Priorité"><Sel value={form.priorite} onChange={e=>setForm({...form,priorite:e.target.value})} options={PRIOS}/></Fld>
          <Fld label="Statut"><Sel value={form.statut} onChange={e=>setForm({...form,statut:e.target.value})} options={STATUTS_TACHE}/></Fld>
        </div>
        <Fld label="Échéance"><Inp type="date" value={form.echeance||""} onChange={e=>setForm({...form,echeance:e.target.value})}/></Fld>
        <div style={{display:"flex",gap:8}}><Btn onClick={save} full>Enregistrer</Btn><Btn onClick={()=>setModal(false)} v="ghost">Annuler</Btn></div>
      </Mdl>}
    </div>
  );
}

function BSHF({produits,setProduits,commandes,setCommandes,clientes,setClientes,evenements,setEvenements}) {
  const[sec,setSec]=useState("dash");const[modal,setModal]=useState(null);const[form,setForm]=useState({});
  const ca=commandes.filter(c=>c.statut==="Paiement complet reçu"||c.statut==="Terminée").reduce((s,c)=>s+(parseFloat(c.montant)||0),0);
  const crit=produits.filter(p=>p.stock<=p.min);
  const SECS=[{id:"dash",l:"🏠"},{id:"cmds",l:"🧾"},{id:"crm",l:"👥"},{id:"stock",l:"📦"},{id:"evts",l:"📅"},{id:"fin",l:"€"},{id:"params",l:"⚙"}];

  return(
    <div style={{display:"flex",flexDirection:"column",minHeight:"100%",background:`radial-gradient(ellipse at 10% 0%,${BSH.prune},${BSH.fond} 60%)`}}>
      <div style={{padding:"10px 14px",borderBottom:`1px solid ${BSH.line}`,display:"flex",alignItems:"center",gap:8}}>
        <span style={{fontFamily:FS,fontSize:13,color:BSH.or,letterSpacing:2}}>✦ Bella'Secret Home</span>
        <span style={{fontSize:8,color:BSH.cremeD,letterSpacing:2}}>BACK-OFFICE</span>
      </div>
      <div style={{display:"flex",justifyContent:"space-around",padding:"7px",borderBottom:`1px solid ${BSH.line}`,background:"rgba(0,0,0,0.2)"}}>
        {SECS.map(s=><button key={s.id} onClick={()=>setSec(s.id)} style={{display:"flex",flexDirection:"column",alignItems:"center",gap:2,background:"none",border:"none",cursor:"pointer",padding:"4px 8px",borderBottom:sec===s.id?`2px solid ${BSH.or}`:"2px solid transparent"}}><span style={{fontSize:17}}>{s.l}</span></button>)}
      </div>
      <div style={{padding:"12px",color:BSH.creme,fontFamily:SA}}>
        {sec==="dash"&&<div style={{display:"flex",flexDirection:"column",gap:10}}>
          <div style={{display:"flex",gap:7,flexWrap:"wrap"}}>
            {[{ico:"€",v:`${ca}€`,l:"CA",c:BSH.or},{ico:"📦",v:commandes.length,l:"Commandes",c:BSH.rose},{ico:"👥",v:clientes.length,l:"Clientes",c:BSH.vert},{ico:"⚠",v:crit.length,l:"Critique",c:crit.length>0?BSH.rouge:BSH.vert}].map(s=>(
              <div key={s.l} style={{flex:1,minWidth:70,background:BSH.verre,border:`1px solid ${BSH.line}`,borderRadius:11,padding:"10px 8px",textAlign:"center",borderTop:`3px solid ${s.c}`}}>
                <div style={{fontSize:16,marginBottom:2}}>{s.ico}</div><div style={{fontSize:18,fontWeight:700,color:BSH.creme,fontFamily:FS}}>{s.v}</div><div style={{fontSize:9,color:BSH.cremeD,marginTop:1}}>{s.l}</div>
              </div>
            ))}
          </div>
          {crit.length>0&&<div style={{background:`${BSH.rouge}15`,border:`1px solid ${BSH.rouge}40`,borderRadius:10,padding:"10px 12px"}}><div style={{fontSize:11,fontWeight:700,color:BSH.rouge,marginBottom:6}}>⚠ Stock critique</div>{crit.map(p=><div key={p.id} style={{fontSize:11,color:BSH.creme,marginBottom:3}}>{p.name} — <span style={{color:BSH.rouge}}>{p.stock} restants</span></div>)}</div>}
          <div style={{background:BSH.verre,border:`1px solid ${BSH.line}`,borderRadius:11,padding:"12px"}}><div style={{fontSize:12,fontWeight:700,color:BSH.or,marginBottom:8}}>Dernières commandes</div>{commandes.slice(0,4).map(c=><div key={c.id} style={{display:"flex",justifyContent:"space-between",padding:"5px 0",borderBottom:`1px solid ${BSH.line}`}}><div><div style={{fontSize:11,color:BSH.creme}}>{c.client}</div><div style={{fontSize:10,color:BSH.cremeD}}>{c.produit}</div></div><div style={{textAlign:"right"}}><div style={{fontSize:12,color:BSH.or,fontWeight:700}}>{c.montant}€</div><BTag c={CMD_C[c.statut]||BSH.bord} sz={8}>{c.statut}</BTag></div></div>)}</div>
        </div>}
        {sec==="cmds"&&<div style={{display:"flex",flexDirection:"column",gap:8}}>
          <div style={{display:"flex",justifyContent:"flex-end",marginBottom:2}}><BBtn v="gold" sz="sm" onClick={()=>{setForm({statut:"Demande reçue",date:today(),montant:0,acompte:0,pmt:"WhatsApp"});setModal("cmd");}}>+ Nouvelle</BBtn></div>
          {commandes.map(c=><div key={c.id} style={{background:BSH.verre,border:`1px solid ${BSH.line}`,borderRadius:12,padding:"12px 14px"}}>
            <div style={{display:"flex",justifyContent:"space-between"}}><div><div style={{display:"flex",gap:5,marginBottom:2}}><span style={{fontSize:10,color:BSH.or,fontWeight:700}}>{c.id}</span><BTag c={CMD_C[c.statut]||BSH.bord} sz={8}>{c.statut}</BTag></div><div style={{fontSize:12,fontWeight:600}}>{c.client}</div><div style={{fontSize:10,color:BSH.cremeD}}>{c.produit} · {c.pmt}</div></div><div style={{textAlign:"right"}}><div style={{fontSize:15,fontWeight:700,color:BSH.or,fontFamily:FS}}>{c.montant}€</div>{c.acompte>0&&<div style={{fontSize:9,color:BSH.cremeD}}>Acompte {c.acompte}€</div>}<div style={{display:"flex",gap:4,marginTop:5,justifyContent:"flex-end"}}><BBtn v="ghost" sz="sm" onClick={()=>{setForm({...c,_edit:c.id});setModal("cmd");}}>✏</BBtn><BBtn v="danger" sz="sm" onClick={()=>{if(confirm("Supprimer ?"))setCommandes(p=>p.filter(x=>x.id!==c.id));}}>✕</BBtn></div></div></div>
          </div>)}
        </div>}
        {sec==="crm"&&<div style={{display:"flex",flexDirection:"column",gap:8}}>
          <div style={{display:"flex",justifyContent:"flex-end",marginBottom:2}}><BBtn v="gold" sz="sm" onClick={()=>{setForm({vip:"Bronze",canal:"WhatsApp"});setModal("cli");}}>+ Cliente</BBtn></div>
          {clientes.map(c=><div key={c.id} style={{background:BSH.verre,border:`1px solid ${BSH.line}`,borderRadius:12,padding:"12px 14px"}}>
            <div style={{display:"flex",justifyContent:"space-between"}}><div><div style={{fontSize:13,fontWeight:600}}>{c.nom}</div><div style={{fontSize:10,color:BSH.cremeD}}>{c.ville} · {c.canal}</div>{c.preferences&&<div style={{fontSize:10,color:BSH.cremeD,marginTop:2}}>💫 {c.preferences}</div>}</div><div style={{textAlign:"right"}}><BTag c={VIP_C[c.vip]||BSH.or} sz={9}>{c.vip}</BTag><div style={{fontSize:13,color:BSH.or,fontWeight:700,marginTop:4}}>{c.total||0}€</div><div style={{display:"flex",gap:4,marginTop:5,justifyContent:"flex-end"}}><BBtn v="ghost" sz="sm" onClick={()=>{setForm({...c,_edit:c.id});setModal("cli");}}>✏</BBtn><BBtn v="danger" sz="sm" onClick={()=>{if(confirm("Supprimer ?"))setClientes(p=>p.filter(x=>x.id!==c.id));}}>✕</BBtn></div></div></div>
          </div>)}
        </div>}
        {sec==="stock"&&<div style={{display:"flex",flexDirection:"column",gap:8}}>
          <div style={{display:"flex",justifyContent:"flex-end",marginBottom:2}}><BBtn v="gold" sz="sm" onClick={()=>{setForm({cat:"Lingerie",prix:0,achat:0,stock:0,min:3,ico:"✨"});setModal("prod");}}>+ Produit</BBtn></div>
          {produits.map(p=><div key={p.id} style={{background:BSH.verre,border:`1px solid ${BSH.line}`,borderRadius:12,padding:"12px 14px",borderLeft:`3px solid ${p.stock<=p.min?BSH.rouge:BSH.vert}`}}>
            <div style={{display:"flex",justifyContent:"space-between"}}><div style={{flex:1}}><div style={{fontSize:12,fontWeight:600}}>{p.name}</div><div style={{fontSize:10,color:BSH.cremeD}}>{p.cat}</div><div style={{display:"flex",gap:5,marginTop:5,flexWrap:"wrap"}}><BTag c={BSH.or} sz={8}>Vente {p.prix}€</BTag><BTag c={BSH.vert} sz={8}>Marge {p.prix>0?Math.round((p.prix-p.achat)/p.prix*100):0}%</BTag></div></div><div style={{textAlign:"right",flexShrink:0}}><div style={{fontSize:22,fontWeight:700,color:p.stock<=p.min?BSH.rouge:BSH.vert,fontFamily:FS}}>{p.stock}</div><div style={{fontSize:9,color:BSH.cremeD}}>en stock</div><div style={{display:"flex",gap:4,marginTop:5,justifyContent:"flex-end"}}><BBtn v="ghost" sz="sm" onClick={()=>{setForm({...p,_edit:p.id});setModal("prod");}}>✏</BBtn><BBtn v="danger" sz="sm" onClick={()=>{if(confirm("Supprimer ?"))setProduits(p=>p.filter(x=>x.id!==p.id));}}>✕</BBtn></div></div></div>
          </div>)}
        </div>}
        {sec==="evts"&&<div style={{display:"flex",flexDirection:"column",gap:8}}>
          <div style={{display:"flex",justifyContent:"flex-end",marginBottom:2}}><BBtn v="gold" sz="sm" onClick={()=>{setForm({ico:"✨",cap:20,dispo:20,prix:25,lieu:"Sinnamary"});setModal("evt");}}>+ Événement</BBtn></div>
          {evenements.map(e=>{const v=e.cap-e.dispo;const pct=e.cap>0?Math.round((v/e.cap)*100):0;return(<div key={e.id} style={{background:BSH.verre,border:`1px solid ${BSH.line}`,borderRadius:12,padding:"12px 14px"}}>
            <div style={{display:"flex",justifyContent:"space-between",marginBottom:7}}><div><div style={{fontSize:13,fontWeight:700}}>{e.ico} {e.nom}</div><div style={{fontSize:10,color:BSH.cremeD}}>{fmt(e.date)} · {e.lieu}</div></div><BTag c={BSH.or}>{e.prix}€</BTag></div>
            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:5,marginBottom:7}}>{[["Cap.",e.cap],["Vendus",v],["CA",`${v*e.prix}€`]].map(([l,val])=><div key={l} style={{background:"rgba(255,255,255,.04)",borderRadius:7,padding:"5px 7px",textAlign:"center"}}><div style={{fontSize:13,fontWeight:700,color:BSH.creme,fontFamily:FS}}>{val}</div><div style={{fontSize:9,color:BSH.cremeD}}>{l}</div></div>)}</div>
            <div style={{background:"rgba(255,255,255,.04)",borderRadius:3,height:4,marginBottom:5}}><div style={{background:`linear-gradient(90deg,${BSH.bord},${BSH.rose})`,height:"100%",borderRadius:3,width:`${pct}%`}}/></div>
            <div style={{display:"flex",justifyContent:"space-between"}}><span style={{fontSize:10,color:BSH.cremeD}}>{pct}% · {e.dispo} restantes</span><div style={{display:"flex",gap:4}}><BBtn v="ghost" sz="sm" onClick={()=>{setForm({...e,_edit:e.id});setModal("evt");}}>✏</BBtn><BBtn v="danger" sz="sm" onClick={()=>{if(confirm("Supprimer ?"))setEvenements(p=>p.filter(x=>x.id!==e.id));}}>✕</BBtn></div></div>
          </div>);})}
        </div>}
        {sec==="fin"&&<div style={{display:"flex",flexDirection:"column",gap:10}}>
          <div style={{display:"flex",gap:7,flexWrap:"wrap"}}>
            {[{v:`${ca}€`,l:"CA encaissé",c:BSH.or},{v:commandes.length>0?`${Math.round(ca/Math.max(commandes.filter(c=>c.statut==="Paiement complet reçu"||c.statut==="Terminée").length,1))}€`:"—",l:"Panier moyen",c:BSH.rose}].map(s=><div key={s.l} style={{flex:1,background:BSH.verre,border:`1px solid ${BSH.line}`,borderRadius:11,padding:"12px",borderTop:`3px solid ${s.c}`}}><div style={{fontSize:22,fontWeight:700,color:BSH.creme,fontFamily:FS}}>{s.v}</div><div style={{fontSize:10,color:BSH.cremeD,marginTop:2}}>{s.l}</div></div>)}
          </div>
          <div style={{background:BSH.verre,border:`1px solid ${BSH.line}`,borderRadius:11,padding:"12px"}}><div style={{fontSize:12,fontWeight:700,color:BSH.or,marginBottom:8}}>Toutes les commandes</div>{commandes.map(c=><div key={c.id} style={{display:"flex",justifyContent:"space-between",padding:"5px 0",borderBottom:`1px solid ${BSH.line}`}}><div><div style={{fontSize:11}}>{c.client}</div><div style={{fontSize:9,color:BSH.cremeD}}>{c.produit}</div></div><div style={{textAlign:"right"}}><div style={{fontSize:12,color:BSH.or,fontWeight:700}}>{c.montant}€</div><BTag c={CMD_C[c.statut]||BSH.bord} sz={7}>{c.statut}</BTag></div></div>)}</div>
        </div>}
        {sec==="params"&&<div style={{display:"flex",flexDirection:"column",gap:9}}>
          {[{t:"Coordonnées",items:[["Nom","Bella'Secret Home"],["Adresse","12 Bd François Horth, Bât. Tokoko Apt. C3"],["Ville","97315 Sinnamary — Guyane française"],["E-mail","bella.studio973@hotmail.com"],["WhatsApp","+594 694 35 60 37"]]},{t:"Paiements",items:[["SumUp","Principal — Phase 2"],["Stripe","À configurer"],["PayPal","vilosarlise972@gmail.com"]]},{t:"Données",items:[["Stockage","Artifact persistant"],["Supabase","Phase 2"],["Sécurité","Fondatrice uniquement"]]}].map(s=>(
            <div key={s.t} style={{background:BSH.verre,border:`1px solid ${BSH.line}`,borderRadius:12,padding:"12px 14px"}}><div style={{fontSize:12,fontWeight:700,color:BSH.or,marginBottom:8,fontFamily:FS}}>{s.t}</div>{s.items.map(([l,v])=><div key={l} style={{display:"flex",justifyContent:"space-between",padding:"4px 0",borderBottom:`1px solid ${BSH.line}22`,gap:8}}><span style={{fontSize:10,color:BSH.cremeD,flexShrink:0}}>{l}</span><span style={{fontSize:10,color:BSH.creme,textAlign:"right",wordBreak:"break-all"}}>{v}</span></div>)}</div>
          ))}
        </div>}
      </div>

      {/* Modals BSH */}
      {modal==="cmd"&&<Mdl title={form._edit?"Modifier":"Nouvelle commande"} onClose={()=>setModal(null)}>
        <Fld label="Cliente"><Inp value={form.client||""} onChange={e=>setForm({...form,client:e.target.value})} placeholder="Nom"/></Fld>
        <Fld label="Produit"><Inp value={form.produit||""} onChange={e=>setForm({...form,produit:e.target.value})} placeholder="Produit"/></Fld>
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
          <Fld label="Montant €"><Inp type="number" value={form.montant||0} onChange={e=>setForm({...form,montant:parseFloat(e.target.value)||0})}/></Fld>
          <Fld label="Acompte €"><Inp type="number" value={form.acompte||0} onChange={e=>setForm({...form,acompte:parseFloat(e.target.value)||0})}/></Fld>
        </div>
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
          <Fld label="Statut"><Sel value={form.statut||"Demande reçue"} onChange={e=>setForm({...form,statut:e.target.value})} options={STATUTS_CMD}/></Fld>
          <Fld label="Paiement"><Sel value={form.pmt||"WhatsApp"} onChange={e=>setForm({...form,pmt:e.target.value})} options={["WhatsApp","SumUp","Stripe","PayPal","Revolut","Espèces"]}/></Fld>
        </div>
        <Fld label="Notes"><Inp value={form.notes||""} onChange={e=>setForm({...form,notes:e.target.value})} placeholder="Notes" rows={2}/></Fld>
        <div style={{display:"flex",gap:8}}><Btn onClick={async()=>{if(!form.client?.trim())return;const id=form._edit||"BSH-"+Date.now().toString().slice(-6);if(form._edit)await setCommandes(p=>p.map(x=>x.id===form._edit?{...form,id:form._edit}:x));else await setCommandes(p=>[...p,{...form,id}]);setModal(null);}} full v="gold">Enregistrer</Btn><Btn onClick={()=>setModal(null)} v="ghost">Annuler</Btn></div>
      </Mdl>}
      {modal==="cli"&&<Mdl title={form._edit?"Modifier":"Nouvelle cliente"} onClose={()=>setModal(null)}>
        <Fld label="Nom"><Inp value={form.nom||""} onChange={e=>setForm({...form,nom:e.target.value})} placeholder="Nom complet"/></Fld>
        <Fld label="Ville"><Inp value={form.ville||""} onChange={e=>setForm({...form,ville:e.target.value})} placeholder="Ville"/></Fld>
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
          <Fld label="Canal"><Sel value={form.canal||"WhatsApp"} onChange={e=>setForm({...form,canal:e.target.value})} options={["WhatsApp","Instagram","TikTok","Événement","Recommandation"]}/></Fld>
          <Fld label="VIP"><Sel value={form.vip||"Bronze"} onChange={e=>setForm({...form,vip:e.target.value})} options={["Bronze","Argent","Or","Diamant"]}/></Fld>
        </div>
        <Fld label="Préférences"><Inp value={form.preferences||""} onChange={e=>setForm({...form,preferences:e.target.value})} placeholder="Style, taille..." rows={2}/></Fld>
        <Fld label="Notes"><Inp value={form.notes||""} onChange={e=>setForm({...form,notes:e.target.value})} placeholder="Notes internes" rows={2}/></Fld>
        <div style={{display:"flex",gap:8}}><Btn onClick={async()=>{if(!form.nom?.trim())return;if(form._edit)await setClientes(p=>p.map(x=>x.id===form._edit?{...form,id:form._edit}:x));else await setClientes(p=>[...p,{...form,id:uid(),total:0}]);setModal(null);}} full v="gold">Enregistrer</Btn><Btn onClick={()=>setModal(null)} v="ghost">Annuler</Btn></div>
      </Mdl>}
      {modal==="prod"&&<Mdl title={form._edit?"Modifier produit":"Nouveau produit"} onClose={()=>setModal(null)}>
        <Fld label="Nom"><Inp value={form.name||""} onChange={e=>setForm({...form,name:e.target.value})} placeholder="Nom"/></Fld>
        <Fld label="Catégorie"><Sel value={form.cat||"Lingerie"} onChange={e=>setForm({...form,cat:e.target.value})} options={["Lingerie","Coffrets","Bougies","Huiles","Parfums","Accessoires","Couples","Mariage","Solo"]}/></Fld>
        <Fld label="Icône emoji"><Inp value={form.ico||"✨"} onChange={e=>setForm({...form,ico:e.target.value})} placeholder="✨"/></Fld>
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:8}}>
          <Fld label="Prix vente €"><Inp type="number" value={form.prix||0} onChange={e=>setForm({...form,prix:parseFloat(e.target.value)||0})}/></Fld>
          <Fld label="Prix achat €"><Inp type="number" value={form.achat||0} onChange={e=>setForm({...form,achat:parseFloat(e.target.value)||0})}/></Fld>
          <Fld label="Stock"><Inp type="number" value={form.stock||0} onChange={e=>setForm({...form,stock:parseInt(e.target.value)||0})}/></Fld>
        </div>
        <div style={{display:"flex",gap:8}}><Btn onClick={async()=>{if(!form.name?.trim())return;if(form._edit)await setProduits(p=>p.map(x=>x.id===form._edit?{...form,id:form._edit}:x));else await setProduits(p=>[...p,{...form,id:uid()}]);setModal(null);}} full v="gold">Enregistrer</Btn><Btn onClick={()=>setModal(null)} v="ghost">Annuler</Btn></div>
      </Mdl>}
      {modal==="evt"&&<Mdl title={form._edit?"Modifier":"Nouvel événement"} onClose={()=>setModal(null)}>
        <Fld label="Nom"><Inp value={form.nom||""} onChange={e=>setForm({...form,nom:e.target.value})} placeholder="Nom"/></Fld>
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
          <Fld label="Date"><Inp type="date" value={form.date||""} onChange={e=>setForm({...form,date:e.target.value})}/></Fld>
          <Fld label="Lieu"><Inp value={form.lieu||"Sinnamary"} onChange={e=>setForm({...form,lieu:e.target.value})} placeholder="Lieu"/></Fld>
        </div>
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:8}}>
          <Fld label="Places"><Inp type="number" value={form.cap||20} onChange={e=>setForm({...form,cap:parseInt(e.target.value)||20})}/></Fld>
          <Fld label="Restantes"><Inp type="number" value={form.dispo||20} onChange={e=>setForm({...form,dispo:parseInt(e.target.value)||20})}/></Fld>
          <Fld label="Prix €"><Inp type="number" value={form.prix||25} onChange={e=>setForm({...form,prix:parseInt(e.target.value)||25})}/></Fld>
        </div>
        <div style={{display:"flex",gap:8}}><Btn onClick={async()=>{if(!form.nom?.trim())return;if(form._edit)await setEvenements(p=>p.map(x=>x.id===form._edit?{...form,id:form._edit}:x));else await setEvenements(p=>[...p,{...form,id:uid(),ico:"✨"}]);setModal(null);}} full v="gold">Enregistrer</Btn><Btn onClick={()=>setModal(null)} v="ghost">Annuler</Btn></div>
      </Mdl>}
    </div>
  );
}

function HubF({projets,taches,bshCmds,goto}) {
  const ca=bshCmds.filter(c=>c.statut==="Paiement complet reçu"||c.statut==="Terminée").reduce((s,c)=>s+(parseFloat(c.montant)||0),0);
  const rev=projets.reduce((s,p)=>s+(parseFloat(p.revenusEstimes)||0),0);
  const ALL=[{id:"bo",nom:"Bella'Odyssée",ico:"💅"},{id:"bev",nom:"Bella'Events",ico:"✨"},{id:"bfd",nom:"Bella'Food",ico:"🍃"},{id:"bsh",nom:"Bella'Secret Home",ico:"✦"},{id:"vilo",nom:"Vilo'Assistance",ico:"📋"},{id:"bse",nom:"Bella'Studio Éditions",ico:"📚"},{id:"mtp",nom:"Mo Ti-Péyi",ico:"🌺"},{id:"tp",nom:"Ti-Panier",ico:"🧺"},{id:"ped",nom:"Pédagogique",ico:"🎓"},{id:"num",nom:"Numérique",ico:"💻"}];

  return(
    <div style={{display:"flex",flexDirection:"column",gap:16}}>
      <SH t="Hub Bella'Studio" s="Vue d'ensemble de l'écosystème"/>
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:9}}>
        {[{l:"CA encaissé",v:`${ca}€`,acc:1},{l:"Revenus estimés",v:`${rev.toLocaleString("fr")}€`,acc:1},{l:"Total projets",v:projets.length},{l:"Projets actifs",v:projets.filter(p=>p.statut==="En cours").length}].map(s=>(
          <div key={s.l} style={{background:B.card,border:`1px solid ${s.acc?B.borderG:B.border}`,borderRadius:12,padding:"14px 12px"}}>
            <div style={{fontSize:22,fontWeight:900,color:s.acc?B.gold:B.violetL,fontFamily:FS}}>{s.v}</div>
            <div style={{fontSize:11,color:B.muted,marginTop:3}}>{s.l}</div>
          </div>
        ))}
      </div>
      {ALL.map(p=>{
        const pp=projets.filter(x=>x.pole===p.nom);const tt=taches.filter(x=>pp.some(pr=>pr.id===x.projetId)&&x.statut!=="Terminé");
        const actif=pp.some(x=>x.statut==="En cours");const rev=pp.reduce((s,x)=>s+(parseFloat(x.revenusEstimes)||0),0);
        return(
          <div key={p.id} style={{background:B.card,border:`1px solid ${B.border}`,borderRadius:13,padding:"12px 14px"}}>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
              <div style={{display:"flex",gap:10,alignItems:"center"}}>
                <span style={{fontSize:20}}>{p.ico}</span>
                <div><div style={{fontSize:13,fontWeight:800,color:B.cream}}>{p.nom}</div><div style={{fontSize:10,color:B.muted}}>{pp.length} projet{pp.length!==1?"s":""} · {tt.length} tâche{tt.length!==1?"s":""}</div></div>
              </div>
              <div style={{textAlign:"right"}}>{rev>0&&<div style={{fontSize:12,fontWeight:700,color:B.gold,marginBottom:3}}>{rev.toLocaleString("fr")}€</div>}<Bdg s={actif?"Actif":"Inactif"}/></div>
            </div>
            {pp.length>0&&<div style={{marginTop:8}}><PBar v={pp.length>0?(pp.filter(x=>x.statut==="Terminé").length/pp.length)*100:0}/><div style={{fontSize:9,color:B.muted,marginTop:2}}>{pp.filter(x=>x.statut==="Terminé").length}/{pp.length} terminés</div></div>}
          </div>
        );
      })}
    </div>
  );
}

function FinancesF({bshCmds,projets}) {
  const enc=bshCmds.filter(c=>c.statut==="Paiement complet reçu"||c.statut==="Terminée").reduce((s,c)=>s+(parseFloat(c.montant)||0),0);
  const acomp=bshCmds.filter(c=>c.acompte>0).reduce((s,c)=>s+(parseFloat(c.acompte)||0),0);
  const att=bshCmds.filter(c=>c.statut!=="Paiement complet reçu"&&c.statut!=="Terminée"&&c.statut!=="Annulée").reduce((s,c)=>s+(parseFloat(c.montant)||0)-(parseFloat(c.acompte)||0),0);
  const est=projets.reduce((s,p)=>s+(parseFloat(p.revenusEstimes)||0),0);
  return(
    <div style={{display:"flex",flexDirection:"column",gap:16}}>
      <SH t="Finances" s="Vue consolidée Bella'Studio"/>
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:9}}>
        {[{l:"CA encaissé",v:`${enc}€`,acc:1},{l:"Acomptes reçus",v:`${acomp}€`},{l:"Soldes en attente",v:`${Math.max(0,Math.round(att))}€`},{l:"Revenus estimés",v:`${est.toLocaleString("fr")}€`,acc:1}].map(s=>(
          <div key={s.l} style={{background:B.card,border:`1px solid ${s.acc?B.borderG:B.border}`,borderRadius:12,padding:"14px 12px"}}>
            <div style={{fontSize:22,fontWeight:900,color:s.acc?B.gold:B.violetL,fontFamily:FS}}>{s.v}</div>
            <div style={{fontSize:11,color:B.muted,marginTop:3}}>{s.l}</div>
          </div>
        ))}
      </div>
      <div style={{background:B.card,border:`1px solid ${B.border}`,borderRadius:12,padding:"13px 14px"}}>
        <div style={{fontSize:12,fontWeight:800,color:B.cream,marginBottom:9}}>Commandes BSH</div>
        {bshCmds.length===0&&<div style={{textAlign:"center",padding:"16px",color:B.muted,fontSize:13}}>Aucune commande</div>}
        {bshCmds.map(c=>(
          <div key={c.id} style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"7px 0",borderBottom:`1px solid ${B.border}`}}>
            <div><div style={{fontSize:12,fontWeight:600,color:B.cream}}>{c.client}</div><div style={{fontSize:10,color:B.muted}}>{c.produit}</div></div>
            <div style={{textAlign:"right"}}><div style={{fontSize:14,fontWeight:700,color:B.gold}}>{c.montant}€</div><Bdg s={c.statut}/></div>
          </div>
        ))}
      </div>
      <div style={{background:B.surface,border:`1px solid ${B.border}`,borderRadius:12,padding:"12px 14px"}}>
        <div style={{fontSize:11,fontWeight:700,color:B.mutedL,marginBottom:6}}>💡 Phase 2 — À venir</div>
        <div style={{fontSize:11,color:B.muted,lineHeight:1.8}}>✦ SumUp Hosted Checkout{"\n"}✦ Facturation automatique{"\n"}✦ Export comptable{"\n"}✦ Supabase synchronisé</div>
      </div>
    </div>
  );
}

function IAF({projets,taches,bshCmds,bshProduits}) {
  const[msgs,setMsgs]=useState([{role:"assistant",text:"Bonjour Renée-Lise ✦\n\nJe suis Bellaïa. Je connais tes projets, tâches, commandes BSH et stocks en temps réel.\n\nQue veux-tu savoir ?"}]);
  const[inp,setInp]=useState("");const[loading,setLoading]=useState(false);
  const sugg=["Quels projets sont en retard ?","Mes priorités aujourd'hui ?","Résumé CA BSH","Stocks critiques ?","Rapport hebdomadaire","Projets à +90% ?"];

  const send=async msg=>{
    const text=msg||inp.trim();if(!text||loading)return;
    setInp("");setMsgs(p=>[...p,{role:"user",text}]);setLoading(true);
    const retard=projets.filter(p=>p.dateCible&&new Date(p.dateCible)<new Date()&&p.statut!=="Terminé"&&p.statut!=="Archivé");
    const near90=projets.filter(p=>(p.avancement||0)>=90&&p.statut!=="Terminé");
    const ca=bshCmds.filter(c=>c.statut==="Paiement complet reçu"||c.statut==="Terminée").reduce((s,c)=>s+(parseFloat(c.montant)||0),0);
    const crit=bshProduits.filter(p=>p.stock<=p.min);
    const ctx=`Tu es Bellaïa, assistante de pilotage de l'écosystème Bella'Studio de Renée-Lise Vilosa, Sinnamary, Guyane française. Principe fondamental : Bellaïa prépare. Renée-Lise décide.

PROJETS (${projets.length}) : ${projets.map(p=>`${p.titre}|${p.statut}|${p.avancement||0}%|${p.priorite}|${p.dateCible||"—"}|${p.pole}|${p.revenusEstimes||0}€ estimés`).join(" / ")||"Aucun"}
EN RETARD : ${retard.map(p=>p.titre).join(", ")||"Aucun"}
PRÈS DE 90%+ : ${near90.map(p=>`${p.titre}(${p.avancement}%)`).join(", ")||"Aucun"}
TÂCHES (${taches.length}) : ${taches.map(t=>`${t.titre}|${t.statut}|${t.priorite}`).join(" / ")||"Aucune"}
COMMANDES BSH : ${bshCmds.map(c=>`${c.client}|${c.montant}€|${c.statut}`).join(" / ")||"Aucune"} — CA total: ${ca}€
STOCK CRITIQUE : ${crit.map(p=>`${p.name}(${p.stock}/${p.min})`).join(", ")||"Aucun"}
Réponds en français. Sois précise, synthétique, élégante. Structure les rapports. Emojis avec modération.`;
    try{
      const r=await fetch("/api/chat",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({system:ctx,messages:[...msgs.filter(m=>m.role!=="system").map(m=>({role:m.role,content:m.text})),{role:"user",content:text}]})});
      const d=await r.json();setMsgs(p=>[...p,{role:"assistant",text:d.content?.[0]?.text||"Impossible de répondre."}]);
    }catch{setMsgs(p=>[...p,{role:"assistant",text:"Connexion impossible. Réessaie."}]);}
    setLoading(false);
  };

  return(
    <div style={{display:"flex",flexDirection:"column",gap:14}}>
      <SH t="Bellaïa IA" s="Bellaïa prépare. Renée-Lise décide."/>
      <div style={{display:"flex",gap:5,flexWrap:"wrap"}}>{sugg.map(s=><button key={s} onClick={()=>send(s)} style={{padding:"4px 9px",borderRadius:99,border:`1px solid ${B.border}`,background:"transparent",color:B.mutedL,fontSize:10,cursor:"pointer",fontFamily:SA}}>{s}</button>)}</div>
      <div style={{overflowY:"auto",display:"flex",flexDirection:"column",gap:9,minHeight:260,maxHeight:380}}>
        {msgs.map((m,i)=><div key={i} style={{display:"flex",justifyContent:m.role==="user"?"flex-end":"flex-start"}}><div style={{maxWidth:"88%",padding:"10px 14px",borderRadius:m.role==="user"?"16px 16px 4px 16px":"4px 16px 16px 16px",background:m.role==="user"?B.violet:B.card,border:m.role==="assistant"?`1px solid ${B.border}`:"none",color:B.cream,fontSize:13,lineHeight:1.65,whiteSpace:"pre-wrap"}}>{m.role==="assistant"&&<span style={{color:B.gold,fontWeight:800,marginRight:6}}>✦</span>}{m.text}</div></div>)}
        {loading&&<div style={{display:"flex"}}><div style={{background:B.card,border:`1px solid ${B.border}`,borderRadius:"4px 16px 16px 16px",padding:"10px 14px",color:B.gold,fontSize:13}}>✦ <span style={{color:B.muted}}>Bellaïa analyse…</span></div></div>}
      </div>
      <div style={{display:"flex",gap:8}}>
        <input value={inp} onChange={e=>setInp(e.target.value)} onKeyDown={e=>e.key==="Enter"&&send()} placeholder="Pose ta question…" style={{flex:1,background:B.card,border:`1px solid ${B.border}`,borderRadius:12,padding:"10px 14px",color:B.cream,fontSize:13,outline:"none",fontFamily:SA}}/>
        <button onClick={()=>send()} disabled={loading||!inp.trim()} style={{padding:"10px 16px",borderRadius:12,border:"none",background:B.violet,color:"#fff",fontWeight:800,fontSize:15,cursor:"pointer",opacity:loading||!inp.trim()?0.5:1}}>↑</button>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════

// ═══════════════════════════════════════════════════════════
// ÉCRAN PIN — Authentification sécurisée via /api/auth
// ═══════════════════════════════════════════════════════════
function EcranPIN({ mode, label, couleur, ico, onSuccess, onBack }) {
  const [pin, setPin] = useState("");
  const [loading, setLoading] = useState(false);
  const [erreur, setErreur] = useState("");

  const verifier = async () => {
    if (pin.length < 4) return;
    setLoading(true);
    setErreur("");
    try {
      const r = await fetch("/api/auth", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ mode, pin }),
      });
      const d = await r.json();
      if (d.ok) {
        onSuccess();
      } else if (r.status === 500 && d.error?.includes("non configuré")) {
        setErreur("PIN non configuré dans Vercel. Contactez l'administratrice.");
      } else {
        setErreur("Code incorrect. Réessayez.");
        setPin("");
      }
    } catch {
      setErreur("Erreur réseau. Réessayez.");
    }
    setLoading(false);
  };

  const touches = ["1","2","3","4","5","6","7","8","9","","0","⌫"];

  return (
    <div style={{display:"flex",flexDirection:"column",height:"100vh",background:`radial-gradient(ellipse at 30% 0%,${couleur}40,${B.night} 65%)`,fontFamily:SA,alignItems:"center",justifyContent:"center",padding:"24px"}}>
      <div style={{textAlign:"center",maxWidth:320,width:"100%"}}>
        <div style={{width:64,height:64,borderRadius:18,background:`${couleur}30`,border:`1px solid ${couleur}50`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:30,margin:"0 auto 18px"}}>{ico}</div>
        <div style={{fontFamily:FS,fontSize:22,fontWeight:900,color:B.cream,marginBottom:4}}>{label}</div>
        <div style={{fontSize:12,color:B.muted,marginBottom:32}}>Saisissez votre code d'accès</div>

        {/* Affichage PIN */}
        <div style={{display:"flex",justifyContent:"center",gap:10,marginBottom:24}}>
          {Array.from({length:Math.max(pin.length+1,4)}).map((_,i) => (
            <div key={i} style={{width:14,height:14,borderRadius:"50%",background:i<pin.length?couleur:"rgba(255,255,255,0.15)",border:`1px solid ${i<pin.length?couleur:"rgba(255,255,255,0.3)"}`}}/>
          ))}
        </div>

        {erreur && <div style={{background:"rgba(180,80,80,0.2)",border:"1px solid rgba(180,80,80,0.4)",borderRadius:10,padding:"8px 14px",color:B.danger,fontSize:12,marginBottom:16}}>{erreur}</div>}

        {/* Clavier */}
        <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:10,marginBottom:20}}>
          {touches.map((t,i) => (
            <button key={i} onClick={() => {
              if (t === "⌫") setPin(p => p.slice(0,-1));
              else if (t === "") return;
              else if (pin.length < 8) setPin(p => p+t);
            }} style={{height:52,borderRadius:12,border:`1px solid rgba(255,255,255,0.1)`,background:t===""?"transparent":t==="⌫"?"rgba(180,80,80,0.15)":"rgba(255,255,255,0.06)",color:B.cream,fontSize:18,fontWeight:600,cursor:t===""?"default":"pointer",fontFamily:SA}}>
              {t}
            </button>
          ))}
        </div>

        <Btn onClick={verifier} full disabled={loading || pin.length < 4} v="primary">
          {loading ? "Vérification…" : "Confirmer"}
        </Btn>
        <button onClick={onBack} style={{marginTop:16,background:"none",border:"none",color:B.muted,cursor:"pointer",fontSize:12,fontFamily:SA}}>‹ Retour</button>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════
// ÉCRAN D'ENTRÉE — 4 modes, accès PIN pour 3
// ═══════════════════════════════════════════════════════════
function Entree({ onMode }) {
  const [pinMode, setPinMode] = useState(null);

  const MODES = [
    { id:"client",    ico:"🌐", label:"Portail Client",      sub:"BSH · Odyssée · Réservations · Boutique", couleur:"#6B1A2B", libre:true  },
    { id:"fondatrice",ico:"◎",  label:"Espace Fondatrice",   sub:"Dashboard · CRM · Back-office · IA",      couleur:B.violet,  libre:false },
    { id:"hote",      ico:"🎭", label:"Espace Hôte / Talent",sub:"Planning · Missions · Contrats",           couleur:"#0d9488", libre:false },
    { id:"partenaire",ico:"🤝", label:"Espace Partenaire",   sub:"Collaborations · Documents · Factures",   couleur:"#b45309", libre:false },
  ];

  if (pinMode) {
    const m = MODES.find(x => x.id === pinMode);
    return <EcranPIN mode={pinMode} label={m.label} couleur={m.couleur} ico={m.ico} onSuccess={() => { setPinMode(null); onMode(pinMode); }} onBack={() => setPinMode(null)}/>;
  }

  return (
    <div style={{display:"flex",flexDirection:"column",height:"100vh",background:`radial-gradient(ellipse at 30% 0%,rgba(124,58,237,0.3),${B.night} 65%)`,fontFamily:SA,alignItems:"center",justifyContent:"center",padding:"20px 16px"}}>
      <div style={{textAlign:"center",maxWidth:380,width:"100%"}}>
        <div style={{width:64,height:64,borderRadius:18,background:`linear-gradient(135deg,${B.violet},${B.gold})`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:30,margin:"0 auto 18px",boxShadow:`0 8px 32px rgba(124,58,237,0.3)`}}>◎</div>
        <div style={{fontFamily:FS,fontSize:30,fontWeight:900,color:B.cream,letterSpacing:"-0.03em",marginBottom:4}}>Bellaïa</div>
        <div style={{fontSize:10,color:B.muted,letterSpacing:"0.18em",textTransform:"uppercase",marginBottom:6}}>Bella'Studio Hub</div>
        <div style={{fontSize:13,color:B.muted,marginBottom:32,lineHeight:1.6}}>Bellaïa prépare. Renée-Lise décide.</div>

        <div style={{display:"flex",flexDirection:"column",gap:12}}>
          {MODES.map(m => (
            <button key={m.id} onClick={() => m.libre ? onMode(m.id) : setPinMode(m.id)}
              style={{background:`linear-gradient(135deg,${m.couleur}22,${m.couleur}10)`,border:`1px solid ${m.couleur}50`,borderRadius:16,padding:"18px 20px",cursor:"pointer",textAlign:"left",fontFamily:SA,width:"100%"}}>
              <div style={{display:"flex",alignItems:"center",gap:14}}>
                <div style={{width:44,height:44,borderRadius:12,background:`${m.couleur}25`,border:`1px solid ${m.couleur}40`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:22,flexShrink:0}}>{m.ico}</div>
                <div style={{flex:1}}>
                  <div style={{display:"flex",alignItems:"center",gap:8,marginBottom:3}}>
                    <span style={{fontSize:15,fontWeight:800,color:"#fff",fontFamily:FS}}>{m.label}</span>
                    {!m.libre && <span style={{fontSize:9,color:m.couleur,background:`${m.couleur}22`,border:`1px solid ${m.couleur}44`,borderRadius:4,padding:"1px 5px",fontWeight:700}}>🔐 PIN</span>}
                  </div>
                  <div style={{fontSize:12,color:"rgba(255,255,255,0.5)"}}>{m.sub}</div>
                </div>
                <span style={{color:`${m.couleur}88`,fontSize:20}}>›</span>
              </div>
            </button>
          ))}
        </div>
        <div style={{marginTop:24,fontSize:10,color:B.muted}}>Bella'Studio · Sinnamary, Guyane française</div>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════
// ESPACE HÔTE / TALENT
// ═══════════════════════════════════════════════════════════
function EspaceHote({ onBack }) {
  const [ong, setOng] = useState("planning");
  const ONGS = [{id:"planning",l:"📅 Planning"},{id:"missions",l:"🎯 Missions"},{id:"contrats",l:"📝 Contrats"},{id:"docs",l:"📄 Documents"},{id:"messages",l:"💬 Messages"},{id:"profil",l:"👤 Profil"}];
  const [missions] = useState([
    {id:"M001",titre:"Soirée Découverte BSH",date:"2026-07-15",lieu:"Sinnamary",statut:"Confirmée",cachet:"80€"},
    {id:"M002",titre:"Shooting Catalogue Été",date:"2026-07-20",lieu:"Sinnamary",statut:"En attente",cachet:"120€"},
    {id:"M003",titre:"VIP Night Or",date:"2026-08-05",lieu:"Cayenne",statut:"Proposée",cachet:"100€"},
  ]);
  const [contrats] = useState([
    {id:"C001",titre:"Contrat Hôtesse — Juillet 2026",date:"2026-07-01",statut:"À signer"},
    {id:"C002",titre:"Accord Confidentialité BSH",date:"2026-06-01",statut:"Signé"},
  ]);

  return (
    <div style={{display:"flex",flexDirection:"column",height:"100vh",background:`radial-gradient(ellipse at 20% 0%,#0d2420,${B.night} 65%)`,fontFamily:SA,color:B.cream}}>
      <div style={{padding:"12px 16px",borderBottom:"1px solid rgba(13,148,136,0.3)",display:"flex",justifyContent:"space-between",alignItems:"center",background:"rgba(0,0,0,0.3)",flexShrink:0}}>
        <div style={{display:"flex",alignItems:"center",gap:10}}>
          <span style={{fontSize:22}}>🎭</span>
          <div>
            <div style={{fontSize:14,fontWeight:800,color:B.cream,fontFamily:FS}}>Espace Hôte / Talent</div>
            <div style={{fontSize:9,color:"rgba(13,148,136,0.8)",letterSpacing:"0.1em",textTransform:"uppercase"}}>Bella'Studio</div>
          </div>
        </div>
        <button onClick={onBack} style={{background:"none",border:"1px solid rgba(255,255,255,0.15)",borderRadius:8,padding:"4px 10px",color:B.muted,cursor:"pointer",fontSize:10,fontFamily:SA}}>‹ Quitter</button>
      </div>

      <div style={{display:"flex",gap:0,overflowX:"auto",padding:"8px 12px",borderBottom:"1px solid rgba(13,148,136,0.2)",background:"rgba(0,0,0,0.15)",flexShrink:0}}>
        {ONGS.map(o => <button key={o.id} onClick={()=>setOng(o.id)} style={{padding:"5px 12px",borderRadius:99,border:"none",cursor:"pointer",fontSize:11,fontWeight:700,background:ong===o.id?"#0d9488":"transparent",color:ong===o.id?"#fff":"rgba(255,255,255,0.4)",whiteSpace:"nowrap",fontFamily:SA,marginRight:4}}>{o.l}</button>)}
      </div>

      <div style={{flex:1,overflowY:"auto",padding:"16px 14px 80px"}}>

        {ong==="planning"&&(
          <div style={{display:"flex",flexDirection:"column",gap:12}}>
            <SH t="Mon Planning" s="Événements à venir"/>
            {missions.filter(m=>m.statut==="Confirmée").map(m=>(
              <div key={m.id} style={{background:"rgba(13,148,136,0.1)",border:"1px solid rgba(13,148,136,0.3)",borderRadius:14,padding:"14px 16px"}}>
                <div style={{display:"flex",justifyContent:"space-between",marginBottom:6}}>
                  <div style={{fontSize:14,fontWeight:700,color:B.cream}}>{m.titre}</div>
                  <span style={{background:"rgba(80,180,120,0.2)",color:B.success,borderRadius:99,padding:"3px 10px",fontSize:10,fontWeight:700}}>{m.statut}</span>
                </div>
                <div style={{fontSize:11,color:B.muted}}>📅 {fmt(m.date)} · 📍 {m.lieu}</div>
                <div style={{fontSize:13,fontWeight:700,color:"#0d9488",marginTop:6}}>💰 {m.cachet}</div>
              </div>
            ))}
          </div>
        )}

        {ong==="missions"&&(
          <div style={{display:"flex",flexDirection:"column",gap:10}}>
            <SH t="Mes Missions" s="Toutes les propositions"/>
            {missions.map(m=>(
              <div key={m.id} style={{background:B.card,border:`1px solid ${B.border}`,borderRadius:13,padding:"13px 15px"}}>
                <div style={{display:"flex",justifyContent:"space-between",marginBottom:4}}>
                  <div style={{fontSize:13,fontWeight:700,color:B.cream}}>{m.titre}</div>
                  <Bdg s={m.statut}/>
                </div>
                <div style={{fontSize:11,color:B.muted,marginBottom:6}}>📅 {fmt(m.date)} · 📍 {m.lieu}</div>
                <div style={{display:"flex",gap:8}}>
                  <span style={{fontSize:13,fontWeight:700,color:B.gold}}>💰 {m.cachet}</span>
                  {m.statut==="Proposée"&&<Btn sm v="success">Accepter</Btn>}
                </div>
              </div>
            ))}
          </div>
        )}

        {ong==="contrats"&&(
          <div style={{display:"flex",flexDirection:"column",gap:10}}>
            <SH t="Mes Contrats" s="Documents à signer"/>
            {contrats.map(c=>(
              <div key={c.id} style={{background:B.card,border:`1px solid ${B.border}`,borderRadius:13,padding:"13px 15px"}}>
                <div style={{display:"flex",justifyContent:"space-between",marginBottom:4}}>
                  <div style={{fontSize:13,fontWeight:700,color:B.cream}}>{c.titre}</div>
                  <span style={{background:c.statut==="Signé"?"rgba(80,180,120,0.2)":"rgba(201,168,76,0.2)",color:c.statut==="Signé"?B.success:B.warning,borderRadius:99,padding:"3px 10px",fontSize:10,fontWeight:700}}>{c.statut}</span>
                </div>
                <div style={{fontSize:11,color:B.muted,marginBottom:8}}>📅 {fmt(c.date)}</div>
                {c.statut==="À signer"&&<Btn sm v="gold" onClick={()=>window.open(`https://wa.me/594694356037?text=Bonjour, je souhaite signer le contrat : ${c.titre}`,"_blank")}>Signer via WhatsApp →</Btn>}
              </div>
            ))}
          </div>
        )}

        {ong==="docs"&&(
          <div style={{display:"flex",flexDirection:"column",gap:10}}>
            <SH t="Documents Utiles"/>
            {["Manuel Hôtesse BSH","Charte Éthique","Planning Type Événement","Guide Tenues & Style","Politique Confidentialité"].map(d=>(
              <div key={d} style={{background:B.card,border:`1px solid ${B.border}`,borderRadius:12,padding:"12px 14px",display:"flex",justifyContent:"space-between",alignItems:"center"}}>
                <span style={{fontSize:13,color:B.cream}}>📄 {d}</span>
                <Btn sm v="ghost" onClick={()=>window.open("https://wa.me/594694356037","_blank")}>Demander</Btn>
              </div>
            ))}
          </div>
        )}

        {ong==="messages"&&(
          <div style={{display:"flex",flexDirection:"column",gap:10}}>
            <SH t="Messages" s="Contacter la fondatrice"/>
            <div style={{background:B.card,border:`1px solid ${B.border}`,borderRadius:14,padding:"14px"}}>
              <div style={{fontSize:12,color:B.muted,marginBottom:12,lineHeight:1.7}}>Pour toute communication avec Bella'Studio, utilisez WhatsApp. La fondatrice vous répondra dans les meilleurs délais.</div>
              <Btn v="gold" full onClick={()=>window.open("https://wa.me/594694356037","_blank")}>💬 Contacter la fondatrice</Btn>
            </div>
          </div>
        )}

        {ong==="profil"&&(
          <div style={{display:"flex",flexDirection:"column",gap:10}}>
            <SH t="Mon Profil"/>
            <div style={{background:B.card,border:`1px solid ${B.border}`,borderRadius:14,padding:"16px",textAlign:"center"}}>
              <div style={{fontSize:48,marginBottom:8}}>🎭</div>
              <div style={{fontSize:15,fontWeight:700,color:B.cream,marginBottom:4}}>Hôte / Talent</div>
              <div style={{fontSize:12,color:B.muted,marginBottom:14}}>Bella'Studio Sinnamary</div>
              <Btn v="ghost" full onClick={()=>window.open("https://wa.me/594694356037?text=Bonjour, je souhaite mettre à jour mon profil Hôte/Talent","_blank")}>Mettre à jour via WhatsApp</Btn>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════
// ESPACE PARTENAIRE
// ═══════════════════════════════════════════════════════════
function EspacePartenaire({ onBack }) {
  const [ong, setOng] = useState("collaborations");
  const ONGS = [{id:"collaborations",l:"🤝 Collaborations"},{id:"demandes",l:"📥 Demandes"},{id:"contrats",l:"📝 Contrats"},{id:"factures",l:"💰 Factures"},{id:"docs",l:"📄 Documents"},{id:"messages",l:"💬 Messages"}];
  const [collabs] = useState([
    {id:"PC001",titre:"Studio Lumière — Shooting Juillet",type:"Photographe",statut:"Confirmée",montant:"200€"},
    {id:"PC002",titre:"Bar Le Refuge — Soirée Découverte",type:"Lieu",statut:"En discussion",montant:"—"},
    {id:"PC003",titre:"Maquilleuse Élise — VIP Night",type:"Prestataire",statut:"Proposée",montant:"150€"},
  ]);
  const [factures] = useState([
    {id:"F001",titre:"Studio Lumière — Session 28/06",montant:"200€",statut:"Payée",date:"2026-06-28"},
    {id:"F002",titre:"Soirée Découverte — Juillet",montant:"250€",statut:"En attente",date:"2026-07-15"},
  ]);

  return (
    <div style={{display:"flex",flexDirection:"column",height:"100vh",background:`radial-gradient(ellipse at 20% 0%,#2d1a04,${B.night} 65%)`,fontFamily:SA,color:B.cream}}>
      <div style={{padding:"12px 16px",borderBottom:"1px solid rgba(180,83,9,0.3)",display:"flex",justifyContent:"space-between",alignItems:"center",background:"rgba(0,0,0,0.3)",flexShrink:0}}>
        <div style={{display:"flex",alignItems:"center",gap:10}}>
          <span style={{fontSize:22}}>🤝</span>
          <div>
            <div style={{fontSize:14,fontWeight:800,color:B.cream,fontFamily:FS}}>Espace Partenaire</div>
            <div style={{fontSize:9,color:"rgba(180,83,9,0.8)",letterSpacing:"0.1em",textTransform:"uppercase"}}>Bella'Studio</div>
          </div>
        </div>
        <button onClick={onBack} style={{background:"none",border:"1px solid rgba(255,255,255,0.15)",borderRadius:8,padding:"4px 10px",color:B.muted,cursor:"pointer",fontSize:10,fontFamily:SA}}>‹ Quitter</button>
      </div>

      <div style={{display:"flex",gap:0,overflowX:"auto",padding:"8px 12px",borderBottom:"1px solid rgba(180,83,9,0.2)",background:"rgba(0,0,0,0.15)",flexShrink:0}}>
        {ONGS.map(o=><button key={o.id} onClick={()=>setOng(o.id)} style={{padding:"5px 12px",borderRadius:99,border:"none",cursor:"pointer",fontSize:11,fontWeight:700,background:ong===o.id?"#b45309":"transparent",color:ong===o.id?"#fff":"rgba(255,255,255,0.4)",whiteSpace:"nowrap",fontFamily:SA,marginRight:4}}>{o.l}</button>)}
      </div>

      <div style={{flex:1,overflowY:"auto",padding:"16px 14px 80px"}}>

        {ong==="collaborations"&&(
          <div style={{display:"flex",flexDirection:"column",gap:10}}>
            <SH t="Collaborations" s="Partenariats actifs et en cours"/>
            {collabs.map(c=>(
              <div key={c.id} style={{background:B.card,border:`1px solid ${B.border}`,borderRadius:13,padding:"13px 15px"}}>
                <div style={{display:"flex",justifyContent:"space-between",marginBottom:4}}>
                  <div style={{fontSize:13,fontWeight:700,color:B.cream}}>{c.titre}</div>
                  <Bdg s={c.statut}/>
                </div>
                <div style={{fontSize:11,color:B.muted,marginBottom:6}}>🏷 {c.type}</div>
                <div style={{fontSize:14,fontWeight:700,color:B.gold}}>{c.montant}</div>
              </div>
            ))}
          </div>
        )}

        {ong==="demandes"&&(
          <div style={{display:"flex",flexDirection:"column",gap:10}}>
            <SH t="Demandes reçues"/>
            <div style={{background:B.card,border:`1px solid ${B.border}`,borderRadius:14,padding:"14px",textAlign:"center"}}>
              <div style={{fontSize:12,color:B.muted,marginBottom:12}}>Aucune demande en attente pour le moment.</div>
              <Btn v="ghost" full onClick={()=>window.open("https://wa.me/594694356037?text=Bonjour, je suis partenaire et j'ai une demande","_blank")}>Envoyer une demande →</Btn>
            </div>
          </div>
        )}

        {ong==="contrats"&&(
          <div style={{display:"flex",flexDirection:"column",gap:10}}>
            <SH t="Contrats Partenaires"/>
            {[{titre:"Contrat Partenariat Studio Lumière",statut:"Actif",date:"2026-06-01"},{titre:"Accord Confidentialité",statut:"Signé",date:"2026-05-15"}].map(c=>(
              <div key={c.titre} style={{background:B.card,border:`1px solid ${B.border}`,borderRadius:12,padding:"12px 14px"}}>
                <div style={{display:"flex",justifyContent:"space-between",marginBottom:4}}>
                  <span style={{fontSize:13,color:B.cream,fontWeight:600}}>{c.titre}</span>
                  <span style={{background:"rgba(80,180,120,0.2)",color:B.success,borderRadius:99,padding:"3px 8px",fontSize:10,fontWeight:700}}>{c.statut}</span>
                </div>
                <div style={{fontSize:11,color:B.muted}}>📅 {fmt(c.date)}</div>
              </div>
            ))}
          </div>
        )}

        {ong==="factures"&&(
          <div style={{display:"flex",flexDirection:"column",gap:10}}>
            <SH t="Factures & Paiements"/>
            {factures.map(f=>(
              <div key={f.id} style={{background:B.card,border:`1px solid ${B.border}`,borderRadius:12,padding:"12px 14px"}}>
                <div style={{display:"flex",justifyContent:"space-between",marginBottom:4}}>
                  <span style={{fontSize:13,color:B.cream,fontWeight:600}}>{f.titre}</span>
                  <span style={{background:f.statut==="Payée"?"rgba(80,180,120,0.2)":"rgba(201,168,76,0.2)",color:f.statut==="Payée"?B.success:B.warning,borderRadius:99,padding:"3px 8px",fontSize:10,fontWeight:700}}>{f.statut}</span>
                </div>
                <div style={{display:"flex",justifyContent:"space-between",marginTop:4}}>
                  <span style={{fontSize:14,fontWeight:700,color:B.gold}}>{f.montant}</span>
                  <span style={{fontSize:11,color:B.muted}}>📅 {fmt(f.date)}</span>
                </div>
              </div>
            ))}
          </div>
        )}

        {ong==="docs"&&(
          <div style={{display:"flex",flexDirection:"column",gap:8}}>
            <SH t="Documents Partenaires"/>
            {["Charte Partenariat BSH","Guide Événements","Politique Image & Communication","Tarifs Collaboration 2026"].map(d=>(
              <div key={d} style={{background:B.card,border:`1px solid ${B.border}`,borderRadius:12,padding:"12px 14px",display:"flex",justifyContent:"space-between",alignItems:"center"}}>
                <span style={{fontSize:13,color:B.cream}}>📄 {d}</span>
                <Btn sm v="ghost" onClick={()=>window.open("https://wa.me/594694356037","_blank")}>Demander</Btn>
              </div>
            ))}
          </div>
        )}

        {ong==="messages"&&(
          <div style={{display:"flex",flexDirection:"column",gap:10}}>
            <SH t="Messagerie"/>
            <div style={{background:B.card,border:`1px solid ${B.border}`,borderRadius:14,padding:"14px"}}>
              <div style={{fontSize:12,color:B.muted,marginBottom:12,lineHeight:1.7}}>Contactez directement la fondatrice via WhatsApp pour toute question relative à votre partenariat.</div>
              <Btn v="gold" full onClick={()=>window.open("https://wa.me/594694356037?text=Bonjour, je suis partenaire Bella'Studio","_blank")}>💬 Contacter la fondatrice</Btn>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════
// APP ROOT — Multi-rôles sécurisé
// ═══════════════════════════════════════════════════════════
const NAV_F = [
  {id:"dashboard",ico:"◈",l:"Accueil"},{id:"projets",ico:"◉",l:"Projets"},
  {id:"taches",ico:"◫",l:"Tâches"},{id:"bsh",ico:"✦",l:"BSH"},
  {id:"hub",ico:"⬡",l:"Hub"},{id:"finances",ico:"€",l:"Finances"},
  {id:"ia",ico:"◎",l:"IA"},
];

export default function BellaiaApp() {
  const [mode, setMode] = useState(null);
  const [activeUnivers, setActiveUnivers] = useState(null);
  const [activeF, setActiveF] = useState("dashboard");
  const [previewClient, setPreviewClient] = useState(false);

  const [projets, setProjects, r1]  = useStore("b5:projets", PROJETS_INIT);
  const [taches, setTaches, r2]     = useStore("b5:taches", []);
  const [bshProd, setBshProd, r3]   = useStore("b5:bsh:prod", PRODS_BSH_INIT);
  const [bshCmds, setBshCmds, r4]   = useStore("b5:bsh:cmds", CMDS_BSH_INIT);
  const [bshCli, setBshCli, r5]     = useStore("b5:bsh:cli", CLIENTES_BSH_INIT);
  const [bshEvts, setBshEvts, r6]   = useStore("b5:bsh:evts", EVTS_BSH_INIT);
  const ready = r1 && r2 && r3 && r4 && r5 && r6;

  // ── Écran d'entrée
  if (!mode) return <Entree onMode={setMode}/>;

  // ── Espace Hôte
  if (mode === "hote") return <EspaceHote onBack={() => setMode(null)}/>;

  // ── Espace Partenaire
  if (mode === "partenaire") return <EspacePartenaire onBack={() => setMode(null)}/>;

  // ── Portail Client (mode direct ou preview fondatrice)
  if (mode === "client" || previewClient) {
    const handleBack = () => {
      if (previewClient) { setPreviewClient(false); }
      else { setMode(null); setActiveUnivers(null); }
    };

    if (!activeUnivers) {
      return <HubClient
        onSelectUnivers={id => setActiveUnivers(id)}
        onBack={handleBack}
        isFondatrice={previewClient}
      />;
    }
    if (activeUnivers === "bsh") return <ClientBSH
      produits={bshProd} evenements={bshEvts}
      onBack={() => setActiveUnivers(null)}
      onNewCommande={async cmd => { await setBshCmds(prev => [cmd, ...prev]); }}
    />;
    if (activeUnivers === "bo") return <ClientOdyssee rdvs={[]} onBack={() => setActiveUnivers(null)}/>;
    return <PlaceholderUnivers univers={activeUnivers} onBack={() => setActiveUnivers(null)}/>;
  }

  // ── Espace Fondatrice
  const views = {
    dashboard: <DashF projets={projets} taches={taches} bshCmds={bshCmds} bshProduits={bshProd} goto={setActiveF}/>,
    projets:   <ProjetsF projets={projets} setProjects={setProjects}/>,
    taches:    <TachesF taches={taches} setTaches={setTaches} projets={projets}/>,
    bsh:       <BSHF produits={bshProd} setProduits={setBshProd} commandes={bshCmds} setCommandes={setBshCmds} clientes={bshCli} setClientes={setBshCli} evenements={bshEvts} setEvenements={setBshEvts}/>,
    hub:       <HubF projets={projets} taches={taches} bshCmds={bshCmds} goto={setActiveF}/>,
    finances:  <FinancesF bshCmds={bshCmds} projets={projets}/>,
    ia:        <IAF projets={projets} taches={taches} bshCmds={bshCmds} bshProduits={bshProd}/>,
  };

  return (
    <div style={{display:"flex",flexDirection:"column",height:"100vh",background:B.night,fontFamily:SA,color:B.cream,maxWidth:430,margin:"0 auto"}}>
      {/* Header Fondatrice */}
      <div style={{padding:"12px 16px 10px",borderBottom:`1px solid ${B.border}`,display:"flex",justifyContent:"space-between",alignItems:"center",background:B.deep,flexShrink:0}}>
        <div style={{display:"flex",alignItems:"center",gap:10}}>
          <div style={{width:32,height:32,borderRadius:9,background:`linear-gradient(135deg,${B.violet},${B.gold})`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:15}}>◎</div>
          <div>
            <div style={{fontSize:14,fontWeight:900,color:B.cream,fontFamily:FS}}>Bellaïa</div>
            <div style={{fontSize:8,color:B.muted,letterSpacing:"0.1em",textTransform:"uppercase"}}>Espace Fondatrice</div>
          </div>
        </div>
        <div style={{display:"flex",alignItems:"center",gap:7}}>
          {/* Bouton prévisualisation — visible uniquement côté Fondatrice */}
          <button onClick={() => { setActiveUnivers(null); setPreviewClient(true); }} style={{background:`rgba(107,26,43,0.2)`,border:`1px solid rgba(107,26,43,0.5)`,borderRadius:8,padding:"4px 9px",color:BSH.or,cursor:"pointer",fontSize:9,fontFamily:SA,fontWeight:700}}>
            👁 Portail client
          </button>
          <button onClick={() => { setMode(null); }} style={{background:"none",border:`1px solid ${B.border}`,borderRadius:8,padding:"4px 10px",color:B.muted,cursor:"pointer",fontSize:9,fontFamily:SA}}>
            Déconnexion
          </button>
          <div style={{width:7,height:7,borderRadius:"50%",background:ready?B.success:B.warning,boxShadow:`0 0 7px ${ready?B.success:B.warning}`}}/>
        </div>
      </div>

      {/* Contenu */}
      <div style={{flex:1,overflowY:"auto",padding:activeF==="bsh"?"0":"16px 14px 80px"}}>
        {!ready
          ? <div style={{display:"flex",alignItems:"center",justifyContent:"center",height:"60vh",flexDirection:"column",gap:12}}><div style={{fontSize:32}}>◎</div><div style={{fontSize:13,color:B.muted}}>Bellaïa se prépare…</div></div>
          : views[activeF]
        }
      </div>

      {/* Bottom nav Fondatrice */}
      <div style={{position:"fixed",bottom:0,left:"50%",transform:"translateX(-50%)",width:"100%",maxWidth:430,borderTop:`1px solid ${B.border}`,background:B.deep,padding:"5px 2px 9px",display:"flex",justifyContent:"space-around",zIndex:10}}>
        {NAV_F.map(m => (
          <button key={m.id} onClick={() => setActiveF(m.id)} style={{display:"flex",flexDirection:"column",alignItems:"center",gap:2,background:"none",border:"none",cursor:"pointer",padding:"3px",flex:1}}>
            <span style={{fontSize:16,color:activeF===m.id?B.gold:B.muted}}>{m.ico}</span>
            <span style={{fontSize:7,color:activeF===m.id?B.gold:B.muted,fontWeight:700,letterSpacing:"0.03em"}}>{m.l}</span>
          </button>
        ))}
      </div>
    </div>
  );
}
