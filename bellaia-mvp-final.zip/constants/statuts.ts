/**
 * constants/statuts.ts
 *
 * Source unique de vérité pour tous les statuts de l'application.
 * Importer depuis ce fichier uniquement — ne jamais redéfinir ailleurs.
 *
 * Règle absolue :
 * Les statuts financiers (financier: true) nécessitent
 * une validation fondatrice explicite avant tout changement.
 */

// ─────────────────────────────────────────────────────────────────────────────
// COMMANDES
// ─────────────────────────────────────────────────────────────────────────────

export const STATUTS_COMMANDE = [
  {
    key:       "demande_recue",
    label:     "Demande reçue",
    color:     "#7EB8C4",
    bg:        "rgba(126,184,196,0.12)",
    border:    "rgba(126,184,196,0.30)",
    financier: false,
    description: "La cliente a soumis sa commande. En attente d'examen.",
  },
  {
    key:       "en_attente_validation",
    label:     "En attente validation",
    color:     "#C9A84C",
    bg:        "rgba(201,168,76,0.12)",
    border:    "rgba(201,168,76,0.30)",
    financier: false,
    description: "Renée-Lise examine la commande.",
  },
  {
    key:       "lien_paiement_envoye",
    label:     "Lien paiement envoyé",
    color:     "#9B6B9E",
    bg:        "rgba(155,107,158,0.12)",
    border:    "rgba(155,107,158,0.30)",
    financier: false,
    description: "Le lien Revolut a été envoyé à la cliente.",
  },
  {
    key:       "acompte_recu",
    label:     "Acompte reçu",
    color:     "#E8A4B8",
    bg:        "rgba(232,164,184,0.12)",
    border:    "rgba(232,164,184,0.30)",
    financier: true,
    description: "L'acompte a été reçu et validé manuellement par Renée-Lise.",
  },
  {
    key:       "paiement_complet",
    label:     "Paiement complet reçu",
    color:     "#4CAF50",
    bg:        "rgba(76,175,80,0.12)",
    border:    "rgba(76,175,80,0.30)",
    financier: true,
    description: "La totalité du paiement a été reçue et validée.",
  },
  {
    key:       "solde_restant",
    label:     "Solde restant",
    color:     "#FF9800",
    bg:        "rgba(255,152,0,0.12)",
    border:    "rgba(255,152,0,0.30)",
    financier: true,
    description: "Acompte reçu, solde encore dû.",
  },
  {
    key:       "confirme",
    label:     "Confirmé",
    color:     "#4CAF50",
    bg:        "rgba(76,175,80,0.12)",
    border:    "rgba(76,175,80,0.30)",
    financier: false,
    description: "Commande confirmée, prête à préparer.",
  },
  {
    key:       "en_preparation",
    label:     "En préparation",
    color:     "#C9A84C",
    bg:        "rgba(201,168,76,0.12)",
    border:    "rgba(201,168,76,0.30)",
    financier: false,
    description: "Le colis est en cours de préparation.",
  },
  {
    key:       "livre",
    label:     "Livré",
    color:     "#4CAF50",
    bg:        "rgba(76,175,80,0.10)",
    border:    "rgba(76,175,80,0.25)",
    financier: false,
    description: "Commande livrée ou session réalisée.",
  },
  {
    key:       "annule",
    label:     "Annulé",
    color:     "#F44336",
    bg:        "rgba(244,67,54,0.10)",
    border:    "rgba(244,67,54,0.25)",
    financier: false,
    description: "Commande annulée.",
  },
] as const;

export type StatutCommande = (typeof STATUTS_COMMANDE)[number]["key"];

/** Clés dont le changement nécessite une validation fondatrice explicite */
export const STATUTS_FINANCIERS = STATUTS_COMMANDE
  .filter((s) => s.financier)
  .map((s) => s.key) satisfies StatutCommande[];

/** Toutes les clés valides pour la validation SQL */
export const STATUTS_COMMANDE_KEYS = STATUTS_COMMANDE
  .map((s) => s.key) satisfies StatutCommande[];

/** Lookup rapide par clé */
export function getStatutCommande(key: string) {
  return STATUTS_COMMANDE.find((s) => s.key === key) ?? null;
}

// ─────────────────────────────────────────────────────────────────────────────
// RÉSERVATIONS (sessions boudoirs)
// ─────────────────────────────────────────────────────────────────────────────

export const STATUTS_RESERVATION = [
  {
    key:       "demande_recue",
    label:     "Demande reçue",
    color:     "#7EB8C4",
    bg:        "rgba(126,184,196,0.12)",
    financier: false,
  },
  {
    key:       "en_attente_validation",
    label:     "En attente validation",
    color:     "#C9A84C",
    bg:        "rgba(201,168,76,0.12)",
    financier: false,
  },
  {
    key:       "lien_paiement_envoye",
    label:     "Lien paiement envoyé",
    color:     "#9B6B9E",
    bg:        "rgba(155,107,158,0.12)",
    financier: false,
  },
  {
    key:       "acompte_recu",
    label:     "Acompte reçu",
    color:     "#E8A4B8",
    bg:        "rgba(232,164,184,0.12)",
    financier: true,
  },
  {
    key:       "confirme",
    label:     "Confirmé",
    color:     "#4CAF50",
    bg:        "rgba(76,175,80,0.12)",
    financier: false,
  },
  {
    key:       "realise",
    label:     "Réalisé",
    color:     "#4CAF50",
    bg:        "rgba(76,175,80,0.10)",
    financier: false,
  },
  {
    key:       "annule",
    label:     "Annulé",
    color:     "#F44336",
    bg:        "rgba(244,67,54,0.10)",
    financier: false,
  },
] as const;

export type StatutReservation = (typeof STATUTS_RESERVATION)[number]["key"];

// ─────────────────────────────────────────────────────────────────────────────
// DOCUMENTS
// ─────────────────────────────────────────────────────────────────────────────

export const STATUTS_DOC = [
  {
    key:         "BROUILLON",
    label:       "Brouillon",
    color:       "#888888",
    bg:          "rgba(136,136,136,0.12)",
    border:      "rgba(136,136,136,0.28)",
    publiable:   false,
    description: "Créé par Bellaïa, non soumis. Modifiable.",
  },
  {
    key:         "EN_REVISION",
    label:       "En révision",
    color:       "#FF9800",
    bg:          "rgba(255,152,0,0.12)",
    border:      "rgba(255,152,0,0.28)",
    publiable:   false,
    description: "Soumis pour relecture par Renée-Lise.",
  },
  {
    key:         "VALIDE",
    label:       "Validé",
    color:       "#4CAF50",
    bg:          "rgba(76,175,80,0.12)",
    border:      "rgba(76,175,80,0.28)",
    publiable:   true,
    description: "Approuvé par Renée-Lise. Prêt à publier ou envoyer.",
  },
  {
    key:         "ARCHIVE",
    label:       "Archivé",
    color:       "#9B6B9E",
    bg:          "rgba(155,107,158,0.12)",
    border:      "rgba(155,107,158,0.28)",
    publiable:   false,
    description: "Version précédente conservée. Non modifiable.",
  },
] as const;

export type StatutDoc = (typeof STATUTS_DOC)[number]["key"];

export const STATUTS_DOC_KEYS = STATUTS_DOC
  .map((s) => s.key) satisfies StatutDoc[];

/** Workflow linéaire des statuts documents */
export const STATUTS_DOC_WORKFLOW: StatutDoc[] = [
  "BROUILLON",
  "EN_REVISION",
  "VALIDE",
  "ARCHIVE",
];

export function getStatutDoc(key: string) {
  return STATUTS_DOC.find((s) => s.key === key) ?? null;
}

// ─────────────────────────────────────────────────────────────────────────────
// FACTURES / DEVIS
// ─────────────────────────────────────────────────────────────────────────────

export const STATUTS_FACTURE = [
  {
    key:       "BROUILLON",
    label:     "Brouillon",
    color:     "#888888",
    bg:        "rgba(136,136,136,0.12)",
    financier: false,
  },
  {
    key:       "EN_REVISION",
    label:     "En révision",
    color:     "#FF9800",
    bg:        "rgba(255,152,0,0.12)",
    financier: false,
  },
  {
    key:       "VALIDE",
    label:     "Validé",
    color:     "#4CAF50",
    bg:        "rgba(76,175,80,0.12)",
    financier: false,
  },
  {
    key:       "a_payer",
    label:     "À payer",
    color:     "#FF9800",
    bg:        "rgba(255,152,0,0.12)",
    financier: true,
  },
  {
    key:       "partiellement_paye",
    label:     "Partiellement payé",
    color:     "#FFC107",
    bg:        "rgba(255,193,7,0.12)",
    financier: true,
  },
  {
    key:       "paye",
    label:     "Payé",
    color:     "#4CAF50",
    bg:        "rgba(76,175,80,0.12)",
    financier: true,
  },
  {
    key:       "annule",
    label:     "Annulé",
    color:     "#F44336",
    bg:        "rgba(244,67,54,0.10)",
    financier: false,
  },
] as const;

export type StatutFacture = (typeof STATUTS_FACTURE)[number]["key"];

export function getStatutFacture(key: string) {
  return STATUTS_FACTURE.find((s) => s.key === key) ?? null;
}

// ─────────────────────────────────────────────────────────────────────────────
// CRM CLIENTES
// ─────────────────────────────────────────────────────────────────────────────

export const STATUTS_CRM = [
  {
    key:         "prospect",
    label:       "Prospect",
    color:       "#2196F3",
    bg:          "rgba(33,150,243,0.12)",
    border:      "rgba(33,150,243,0.28)",
    description: "Contact entrant, pas encore qualifié.",
  },
  {
    key:         "prospect_qualifie",
    label:       "Prospect qualifié",
    color:       "#64B5F6",
    bg:          "rgba(100,181,246,0.12)",
    border:      "rgba(100,181,246,0.28)",
    description: "Prospect avec intention d'achat confirmée.",
  },
  {
    key:         "active",
    label:       "Cliente active",
    color:       "#4CAF50",
    bg:          "rgba(76,175,80,0.12)",
    border:      "rgba(76,175,80,0.28)",
    description: "A déjà acheté, engagement régulier.",
  },
  {
    key:         "vip",
    label:       "VIP",
    color:       "#C9A84C",
    bg:          "rgba(201,168,76,0.15)",
    border:      "rgba(201,168,76,0.40)",
    description: "Cliente haute valeur, traitement prioritaire.",
  },
  {
    key:         "inactive",
    label:       "Inactive",
    color:       "#888888",
    bg:          "rgba(136,136,136,0.10)",
    border:      "rgba(136,136,136,0.25)",
    description: "Aucune activité récente. À relancer.",
  },
] as const;

export type StatutCRM = (typeof STATUTS_CRM)[number]["key"];

export function getStatutCRM(key: string) {
  return STATUTS_CRM.find((s) => s.key === key) ?? null;
}

// ─────────────────────────────────────────────────────────────────────────────
// STOCKS
// ─────────────────────────────────────────────────────────────────────────────

export const STATUTS_STOCK = [
  {
    key:       "ok",
    label:     "Disponible",
    color:     "#4CAF50",
    bg:        "rgba(76,175,80,0.12)",
    border:    "rgba(76,175,80,0.28)",
    alerte:    false,
  },
  {
    key:       "faible",
    label:     "Stock faible",
    color:     "#FF9800",
    bg:        "rgba(255,152,0,0.12)",
    border:    "rgba(255,152,0,0.28)",
    alerte:    true,
  },
  {
    key:       "rupture",
    label:     "Rupture",
    color:     "#F44336",
    bg:        "rgba(244,67,54,0.12)",
    border:    "rgba(244,67,54,0.28)",
    alerte:    true,
  },
] as const;

export type StatutStock = (typeof STATUTS_STOCK)[number]["key"];

export function getStatutStock(key: string) {
  return STATUTS_STOCK.find((s) => s.key === key) ?? null;
}

// ─────────────────────────────────────────────────────────────────────────────
// FOURNISSEURS
// ─────────────────────────────────────────────────────────────────────────────

export const STATUTS_FOURNISSEUR = [
  {
    key:   "actif",
    label: "Actif",
    color: "#4CAF50",
    bg:    "rgba(76,175,80,0.12)",
  },
  {
    key:   "evaluation",
    label: "En évaluation",
    color: "#FF9800",
    bg:    "rgba(255,152,0,0.12)",
  },
  {
    key:   "inactif",
    label: "Inactif",
    color: "#888888",
    bg:    "rgba(136,136,136,0.10)",
  },
] as const;

export type StatutFournisseur = (typeof STATUTS_FOURNISSEUR)[number]["key"];

// ─────────────────────────────────────────────────────────────────────────────
// TYPES DE DOCUMENTS CLIENTS
// ─────────────────────────────────────────────────────────────────────────────

export const TYPES_DOCUMENT = [
  {
    key:     "questionnaire",
    label:   "Questionnaire",
    icon:    "📋",
    branches: ["odyssee", "secret_home", "events"],
  },
  {
    key:     "consentement",
    label:   "Consentement",
    icon:    "✍️",
    branches: ["odyssee", "secret_home"],
  },
  {
    key:     "cgv",
    label:   "CGV",
    icon:    "📄",
    branches: ["secret_home", "events", "academy", "structure"],
  },
  {
    key:     "autorisation",
    label:   "Autorisation",
    icon:    "🔐",
    branches: ["odyssee", "secret_home"],
  },
  {
    key:     "contrat",
    label:   "Contrat",
    icon:    "📝",
    branches: ["events", "vilo"],
  },
  {
    key:     "fiche_conseils",
    label:   "Fiche conseils",
    icon:    "💡",
    branches: ["odyssee", "food"],
  },
  {
    key:     "questionnaire_sante",
    label:   "Questionnaire santé",
    icon:    "🏥",
    branches: ["odyssee"],
  },
] as const;

export type TypeDocument = (typeof TYPES_DOCUMENT)[number]["key"];

// ─────────────────────────────────────────────────────────────────────────────
// BRANCHES
// ─────────────────────────────────────────────────────────────────────────────

export const BRANCHES = [
  {
    id:        "studio",
    label:     "Bella'Studio",
    icon:      "◈",
    accent:    "#C9A84C",
    secondary: "#5C2D5C",
    bg:        "rgba(92,45,92,0.14)",
    tagline:   "Maison mère · Pilotage global",
  },
  {
    id:        "odyssee",
    label:     "Bella'Odyssée",
    icon:      "✦",
    accent:    "#C9A84C",
    secondary: "#6B3FA0",
    bg:        "rgba(107,63,160,0.13)",
    tagline:   "Beauté du regard · Esthétique · Sourire",
  },
  {
    id:        "secret_home",
    label:     "Bella'Secret Home",
    icon:      "◆",
    accent:    "#D4A0B5",
    secondary: "#2A0A1A",
    bg:        "rgba(212,160,181,0.09)",
    tagline:   "Univers privé 18+ · Lingerie · Boudoirs",
  },
  {
    id:        "food",
    label:     "Bella'Food",
    icon:      "❋",
    accent:    "#C9A84C",
    secondary: "#1E5C3A",
    bg:        "rgba(30,92,58,0.13)",
    tagline:   "Artisanat alimentaire · Jus · Desserts",
  },
  {
    id:        "events",
    label:     "Bella'Events",
    icon:      "✿",
    accent:    "#C9A84C",
    secondary: "#1E5C3A",
    bg:        "rgba(30,92,58,0.11)",
    tagline:   "Décoration · Événementiel · Pâtisserie",
  },
  {
    id:        "invest",
    label:     "BellaInvest",
    icon:      "◐",
    accent:    "#C9A84C",
    secondary: "#0A1628",
    bg:        "rgba(10,22,40,0.28)",
    tagline:   "Veille économique · Analyses",
  },
  {
    id:        "vilo",
    label:     "Vilo'Assistance",
    icon:      "◉",
    accent:    "#C9A84C",
    secondary: "#0A1628",
    bg:        "rgba(10,22,40,0.24)",
    tagline:   "Administratif · Courriers · Classement",
  },
  {
    id:        "academy",
    label:     "Bella'Academy",
    icon:      "◇",
    accent:    "#E8B4C8",
    secondary: "#7A3050",
    bg:        "rgba(122,48,80,0.11)",
    tagline:   "Ressources pédagogiques · Collections",
  },
  {
    id:        "structure",
    label:     "Bella'Structure",
    icon:      "▲",
    accent:    "#E8B4C8",
    secondary: "#7A3050",
    bg:        "rgba(122,48,80,0.10)",
    tagline:   "Produits numériques · E-books · Templates",
  },
] as const;

export type BrancheId = (typeof BRANCHES)[number]["id"];

export function getBranche(id: string) {
  return BRANCHES.find((b) => b.id === id) ?? null;
}

// ─────────────────────────────────────────────────────────────────────────────
// RÔLES UTILISATEURS
// ─────────────────────────────────────────────────────────────────────────────

export const ROLES_UTILISATEUR = [
  {
    key:         "fondatrice",
    label:       "Fondatrice",
    description: "Accès total. Autorité finale. Renée-Lise.",
    acces_total: true,
  },
  {
    key:         "hote_boudoir",
    label:       "Hôte Boudoir",
    description: "Sessions boudoir uniquement.",
    acces_total: false,
  },
  {
    key:         "estheticienne",
    label:       "Esthéticienne",
    description: "Odyssée : RDV et fiches clientes.",
    acces_total: false,
  },
  {
    key:         "assistante_admin",
    label:       "Assistante Administrative",
    description: "Vilo'Assistance et documents clients.",
    acces_total: false,
  },
  {
    key:         "community_manager",
    label:       "Community Manager",
    description: "Publications et bibliothèque média.",
    acces_total: false,
  },
  {
    key:         "photographe",
    label:       "Photographe",
    description: "Upload médias et sessions boudoir.",
    acces_total: false,
  },
  {
    key:         "decoratrice",
    label:       "Décoratrice",
    description: "Events : plannings et checklists.",
    acces_total: false,
  },
  {
    key:         "cliente",
    label:       "Cliente",
    description: "Espace cliente : commandes, réservations.",
    acces_total: false,
  },
] as const;

export type RoleUtilisateur = (typeof ROLES_UTILISATEUR)[number]["key"];
