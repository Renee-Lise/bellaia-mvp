/**
 * types/database.ts
 *
 * Stub minimal à utiliser jusqu'à la génération automatique
 * par le CLI Supabase.
 *
 * Pour générer les types réels après avoir exécuté le SQL :
 *   npx supabase gen types typescript \
 *     --project-id VOTRE_PROJECT_ID \
 *     --schema public \
 *     > types/database.ts
 *
 * Ce stub garantit que TypeScript compile sans erreur
 * pendant le setup initial.
 */

export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[];

export interface Database {
  public: {
    Tables: {

      profiles: {
        Row: {
          id:           string;
          prenom:       string;
          nom:          string;
          telephone:    string;
          role:         UserRole;
          statut:       "actif" | "inactif" | "veille";
          age_verifie:  boolean;
          created_at:   string;
          updated_at:   string;
        };
        Insert: {
          id:           string;
          prenom?:      string;
          nom?:         string;
          telephone?:   string;
          role?:        UserRole;
          statut?:      "actif" | "inactif" | "veille";
          age_verifie?: boolean;
        };
        Update: Partial<Database["public"]["Tables"]["profiles"]["Insert"]>;
      };

      commandes: {
        Row: {
          id:               string;
          cliente_id:       string | null;
          cliente_nom:      string;
          branche:          string;
          articles:         Json;
          total:            number;
          acompte_attendu:  number;
          acompte_paye:     number;
          statut:           StatutCommande;
          lien_revolut:     string | null;
          discretion_colis: boolean;
          adresse_livraison: Json;
          notes_cliente:    string;
          notes_admin:      string;
          created_at:       string;
          updated_at:       string;
        };
        Insert: Omit<Database["public"]["Tables"]["commandes"]["Row"],
          "id" | "created_at" | "updated_at"> & { id?: string };
        Update: Partial<Database["public"]["Tables"]["commandes"]["Insert"]>;
      };

      commandes_historique: {
        Row: {
          id:             string;
          commande_id:    string;
          ancien_statut:  string | null;
          nouveau_statut: string;
          commentaire:    string;
          fait_par:       string | null;
          created_at:     string;
        };
        Insert: Omit<Database["public"]["Tables"]["commandes_historique"]["Row"],
          "id" | "created_at"> & { id?: string };
        Update: never;
      };

      paiements: {
        Row: {
          id:              string;
          commande_id:     string | null;
          montant:         number;
          type_paiement:   "acompte" | "solde" | "complet" | null;
          mode:            "revolut" | "especes" | "virement" | "autre";
          statut:          "en_attente" | "recu" | "annule";
          lien_revolut:    string | null;
          date_envoi_lien: string | null;
          date_reception:  string | null;
          valide_par:      string | null;
          notes:           string;
          created_at:      string;
        };
        Insert: Omit<Database["public"]["Tables"]["paiements"]["Row"],
          "id" | "created_at"> & { id?: string };
        Update: Partial<Database["public"]["Tables"]["paiements"]["Insert"]>;
      };

      clientes_crm: {
        Row: {
          id:             string;
          profile_id:     string | null;
          nom:            string;
          email:          string;
          telephone:      string;
          statut_crm:     StatutCRM;
          univers:        string[];
          score_fidelite: number;
          anniversaire:   string | null;
          preferences:    Json;
          nb_achats:      number;
          ca_total:       number;
          notes_admin:    string;
          created_at:     string;
          updated_at:     string;
        };
        Insert: Omit<Database["public"]["Tables"]["clientes_crm"]["Row"],
          "id" | "created_at" | "updated_at"> & { id?: string };
        Update: Partial<Database["public"]["Tables"]["clientes_crm"]["Insert"]>;
      };

      factures: {
        Row: {
          id:            string;
          numero:        string | null;
          type:          "devis" | "facture" | "avoir" | "bon_commande" | "bon_livraison";
          client_nom:    string;
          client_email:  string;
          cliente_id:    string | null;
          branche:       string;
          articles:      Json;
          total_ttc:     number;
          acompte_recu:  number;
          statut:        StatutDoc | "a_payer" | "partiellement_paye" | "paye" | "annule";
          validite_date: string | null;
          notes:         string;
          valide_par:    string | null;
          emis_le:       string | null;
          created_at:    string;
        };
        Insert: Omit<Database["public"]["Tables"]["factures"]["Row"],
          "id" | "created_at"> & { id?: string };
        Update: Partial<Database["public"]["Tables"]["factures"]["Insert"]>;
      };

      documents_clients: {
        Row: {
          id:              string;
          cliente_id:      string | null;
          type:            TypeDocument;
          univers:         string;
          contenu:         Json;
          statut:          StatutDoc;
          version:         string;
          valide_par:      string | null;
          date_validation: string | null;
          created_at:      string;
        };
        Insert: Omit<Database["public"]["Tables"]["documents_clients"]["Row"],
          "id" | "created_at"> & { id?: string };
        Update: Partial<Database["public"]["Tables"]["documents_clients"]["Insert"]>;
      };

      produits: {
        Row: {
          id:             string;
          nom:            string;
          description:    string;
          categorie:      string;
          branche:        string;
          prix_public:    number;
          prix_cout:      number;
          tailles:        string[];
          couleurs:       string[];
          photos:         string[];
          fournisseur_id: string | null;
          statut:         "actif" | "inactif" | "archive";
          version:        string;
          created_at:     string;
          updated_at:     string;
        };
        Insert: Omit<Database["public"]["Tables"]["produits"]["Row"],
          "id" | "created_at" | "updated_at"> & { id?: string };
        Update: Partial<Database["public"]["Tables"]["produits"]["Insert"]>;
      };

      stocks: {
        Row: {
          id:           string;
          produit_id:   string;
          quantite:     number;
          unite:        string;
          seuil_alerte: number;
          derniere_maj: string;
        };
        Insert: Omit<Database["public"]["Tables"]["stocks"]["Row"],
          "id" | "derniere_maj"> & { id?: string };
        Update: Partial<Database["public"]["Tables"]["stocks"]["Insert"]>;
      };

      fournisseurs: {
        Row: {
          id:         string;
          nom:        string;
          pays:       string;
          contact:    string;
          categorie:  string;
          delai:      string;
          conformite: string;
          statut:     "actif" | "evaluation" | "inactif";
          notes:      string;
          created_at: string;
        };
        Insert: Omit<Database["public"]["Tables"]["fournisseurs"]["Row"],
          "id" | "created_at"> & { id?: string };
        Update: Partial<Database["public"]["Tables"]["fournisseurs"]["Insert"]>;
      };

      sessions_boudoir: {
        Row: {
          id:               string;
          titre:            string;
          description:      string;
          date_session:     string;
          heure:            string | null;
          duree_minutes:    number;
          places_total:     number;
          places_restantes: number;
          acompte_requis:   number;
          prix_total:       number;
          statut:           "ouvert" | "complet" | "annule" | "realise";
          notes_admin:      string;
          created_at:       string;
        };
        Insert: Omit<Database["public"]["Tables"]["sessions_boudoir"]["Row"],
          "id" | "created_at"> & { id?: string };
        Update: Partial<Database["public"]["Tables"]["sessions_boudoir"]["Insert"]>;
      };

      reservations: {
        Row: {
          id:            string;
          session_id:    string;
          cliente_id:    string | null;
          cliente_nom:   string;
          statut:        "demande_recue" | "en_attente_validation" | "lien_paiement_envoye"
                       | "acompte_recu" | "confirme" | "realise" | "annule";
          acompte_paye:  number;
          solde_paye:    number;
          notes_cliente: string;
          notes_admin:   string;
          created_at:    string;
        };
        Insert: Omit<Database["public"]["Tables"]["reservations"]["Row"],
          "id" | "created_at"> & { id?: string };
        Update: Partial<Database["public"]["Tables"]["reservations"]["Insert"]>;
      };

      memoire_metier: {
        Row: {
          id:         string;
          label:      string;
          univers:    string;
          type:       "tarif" | "procedure" | "produit" | "fournisseur"
                    | "document" | "visuel" | "general";
          valeur:     string;
          statut:     "VALIDE" | "ARCHIVE";
          version:    string;
          valide_par: string | null;
          notes:      string;
          created_at: string;
        };
        Insert: Omit<Database["public"]["Tables"]["memoire_metier"]["Row"],
          "id" | "created_at"> & { id?: string };
        Update: Partial<Database["public"]["Tables"]["memoire_metier"]["Insert"]>;
      };

      audit_log: {
        Row: {
          id:           string;
          action:       string;
          entite:       string;
          entite_id:    string | null;
          fait_par:     string | null;
          valeur_avant: Json | null;
          valeur_apres: Json | null;
          ip_address:   string | null;
          created_at:   string;
        };
        // Insert uniquement — pas d'update ni delete
        Insert: Omit<Database["public"]["Tables"]["audit_log"]["Row"],
          "id" | "created_at"> & { id?: string };
        Update: never;
      };
    };

    Views: {
      stocks_avec_statut: {
        Row: {
          id:            string;
          produit_id:    string;
          produit_nom:   string;
          branche:       string;
          categorie:     string;
          quantite:      number;
          unite:         string;
          seuil_alerte:  number;
          statut_stock:  "ok" | "faible" | "rupture";
          derniere_maj:  string;
        };
      };
    };

    Functions: {
      gen_num: {
        Args:    { t: string };
        Returns: string;
      };
    };
  };
}

// ── Types dérivés ─────────────────────────────────────────────────────────────

export type UserRole =
  | "fondatrice"
  | "hote_boudoir"
  | "estheticienne"
  | "assistante_admin"
  | "community_manager"
  | "photographe"
  | "decoratrice"
  | "cliente";

export type StatutCommande =
  | "demande_recue"
  | "en_attente_validation"
  | "lien_paiement_envoye"
  | "acompte_recu"
  | "paiement_complet"
  | "solde_restant"
  | "confirme"
  | "en_preparation"
  | "livre"
  | "annule";

export type StatutCRM =
  | "prospect"
  | "prospect_qualifie"
  | "active"
  | "vip"
  | "inactive";

export type StatutDoc =
  | "BROUILLON"
  | "EN_REVISION"
  | "VALIDE"
  | "ARCHIVE";

export type TypeDocument =
  | "questionnaire"
  | "consentement"
  | "cgv"
  | "autorisation"
  | "contrat"
  | "fiche_conseils"
  | "questionnaire_sante";

// Rows raccourcis
export type Profile         = Database["public"]["Tables"]["profiles"]["Row"];
export type Commande        = Database["public"]["Tables"]["commandes"]["Row"];
export type Paiement        = Database["public"]["Tables"]["paiements"]["Row"];
export type ClienteCRM      = Database["public"]["Tables"]["clientes_crm"]["Row"];
export type Facture         = Database["public"]["Tables"]["factures"]["Row"];
export type DocumentClient  = Database["public"]["Tables"]["documents_clients"]["Row"];
export type Produit         = Database["public"]["Tables"]["produits"]["Row"];
export type Stock           = Database["public"]["Tables"]["stocks"]["Row"];
export type StockAvecStatut = Database["public"]["Views"]["stocks_avec_statut"]["Row"];
export type SessionBoudoir  = Database["public"]["Tables"]["sessions_boudoir"]["Row"];
export type Reservation     = Database["public"]["Tables"]["reservations"]["Row"];
export type MemoireMetier   = Database["public"]["Tables"]["memoire_metier"]["Row"];
export type AuditLog        = Database["public"]["Tables"]["audit_log"]["Row"];
