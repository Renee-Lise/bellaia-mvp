import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { FondatriceLayoutClient } from "./layout-client";

/**
 * app/(fondatrice)/layout.tsx
 *
 * Layout serveur : vérifie l'authentification et le rôle fondatrice.
 * Si non authentifié → /connexion
 * Si rôle insuffisant → /espace
 *
 * Rend le layout client qui gère la sidebar, le header et l'état UI.
 */
export default async function FondatriceLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const supabase = createClient();

  // ── Vérification session ────────────────────────────────────────────────────
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    redirect("/connexion");
  }

  // ── Vérification rôle ──────────────────────────────────────────────────────
  const { data: profile } = await supabase
    .from("profiles")
    .select("id, prenom, nom, role")
    .eq("id", user.id)
    .single();

  if (!profile || profile.role !== "fondatrice") {
    redirect("/espace");
  }

  return <FondatriceLayoutClient>{children}</FondatriceLayoutClient>;
}
