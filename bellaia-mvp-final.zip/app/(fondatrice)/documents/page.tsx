"use client";

import { useEffect, useState, useCallback } from "react";
import { DocumentCard }        from "@/components/documents/DocumentCard";
import { DocumentStatusBadge } from "@/components/documents/DocumentStatusBadge";
import { STATUTS_DOC, TYPES_DOCUMENT } from "@/constants/statuts";
import type { DocumentClient } from "@/types/database";

type DocWithCliente = DocumentClient & { cliente_nom?: string | null };
interface DocsResponse { documents: DocWithCliente[]; total: number; }

export default function DocumentsPage() {
  const [data,         setData]         = useState<DocsResponse | null>(null);
  const [loading,      setLoading]      = useState(true);
  const [error,        setError]        = useState<string | null>(null);
  const [filtreStatut, setFiltreStatut] = useState("");
  const [filtreType,   setFiltreType]   = useState("");

  const fetchData = useCallback(async () => {
    setLoading(true); setError(null);
    try {
      const p = new URLSearchParams({ limit: "100" });
      if (filtreStatut) p.set("statut", filtreStatut);
      if (filtreType)   p.set("type",   filtreType);
      const res = await fetch(`/api/documents?${p}`);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      setData(await res.json());
    } catch { setError("Impossible de charger les documents."); }
    finally   { setLoading(false); }
  }, [filtreStatut, filtreType]);

  useEffect(() => { fetchData(); }, [fetchData]);

  const docs     = data?.documents ?? [];
  const brouillons = docs.filter((d) => d.statut === "BROUILLON").length;
  const revision   = docs.filter((d) => d.statut === "EN_REVISION").length;
  const valides    = docs.filter((d) => d.statut === "VALIDE").length;

  const inputStyle: React.CSSProperties = {
    padding: "7px 12px", borderRadius: "8px",
    background: "rgba(255,255,255,0.04)", border: "1px solid rgba(201,168,76,0.18)",
    color: "#F0E8D8", fontSize: "12px", outline: "none", fontFamily: "Arial, sans-serif",
  };

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: "18px" }}>

      {/* En-tête */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", flexWrap: "wrap", gap: "10px" }}>
        <div>
          <h2 style={{ fontSize: "20px", fontWeight: "700", color: "#F0E8D8", fontFamily: "Georgia, serif" }}>Documents clients</h2>
          <p style={{ fontSize: "11px", color: "rgba(201,168,76,0.55)", marginTop: "2px", fontFamily: "Arial, sans-serif" }}>
            {loading ? "Chargement…" : `${data?.total ?? 0} documents · ${brouillons} brouillons · ${revision} en révision · ${valides} validés`}
          </p>
        </div>
        <button type="button" onClick={fetchData} disabled={loading}
          style={{ ...inputStyle, cursor: loading ? "not-allowed" : "pointer", color: "rgba(201,168,76,0.65)" }}>
          {loading ? "⟳" : "⟳ Actualiser"}
        </button>
      </div>

      {/* KPIs */}
      {!loading && (
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: "10px" }}>
          {[
            { label: "Total",       value: data?.total ?? 0, color: "#C9A84C" },
            { label: "Brouillons",  value: brouillons,       color: "#888888" },
            { label: "En révision", value: revision,         color: "#FF9800" },
            { label: "Validés",     value: valides,          color: "#4CAF50" },
          ].map((k) => (
            <div key={k.label} style={{ padding: "10px 13px", background: "#120A10", border: `1px solid ${k.color}22`, borderRadius: "10px" }}>
              <p style={{ fontSize: "8px", color: "rgba(240,232,216,0.35)", letterSpacing: "0.12em", textTransform: "uppercase", marginBottom: "3px", fontFamily: "Arial, sans-serif" }}>{k.label}</p>
              <p style={{ fontSize: "20px", fontWeight: "700", color: k.color, fontFamily: "Arial, sans-serif" }}>{k.value}</p>
            </div>
          ))}
        </div>
      )}

      {/* Filtres */}
      <div style={{ display: "flex", gap: "10px", flexWrap: "wrap" }}>
        <select value={filtreStatut} onChange={(e) => setFiltreStatut(e.target.value)}
          style={{ ...inputStyle, cursor: "pointer", color: filtreStatut ? "#C9A84C" : "rgba(240,232,216,0.50)" }}>
          <option value="">Tous les statuts</option>
          {STATUTS_DOC.map((s) => <option key={s.key} value={s.key}>{s.label}</option>)}
        </select>
        <select value={filtreType} onChange={(e) => setFiltreType(e.target.value)}
          style={{ ...inputStyle, cursor: "pointer", color: filtreType ? "#C9A84C" : "rgba(240,232,216,0.50)" }}>
          <option value="">Tous les types</option>
          {TYPES_DOCUMENT.map((t) => <option key={t.key} value={t.key}>{t.label}</option>)}
        </select>
        {(filtreStatut || filtreType) && (
          <button type="button" onClick={() => { setFiltreStatut(""); setFiltreType(""); }}
            style={{ ...inputStyle, cursor: "pointer", color: "rgba(240,232,216,0.45)" }}>
            ✕ Réinitialiser
          </button>
        )}
      </div>

      {/* Erreur */}
      {error && (
        <div style={{ padding: "12px 16px", background: "rgba(244,67,54,0.09)", border: "1px solid rgba(244,67,54,0.22)", borderRadius: "10px", color: "#F44336", fontSize: "13px", fontFamily: "Arial, sans-serif" }}>{error}</div>
      )}

      {/* Tableau */}
      <div style={{ background: "#120A10", border: "1px solid rgba(201,168,76,0.14)", borderRadius: "12px", overflow: "hidden" }}>
        {/* Header */}
        <div style={{ display: "grid", gridTemplateColumns: "36px 1fr 120px 110px 90px 80px 60px", gap: "10px", padding: "8px 14px", borderBottom: "1px solid rgba(201,168,76,0.10)" }}>
          {["", "Type / Cliente", "Univers", "Statut", "Version", "Date", ""].map((h) => (
            <p key={h} style={{ fontSize: "9px", color: "rgba(201,168,76,0.45)", letterSpacing: "0.14em", textTransform: "uppercase", fontFamily: "Arial, sans-serif" }}>{h}</p>
          ))}
        </div>
        {loading
          ? [0,1,2,3,4].map((i) => <div key={i} style={{ height: "44px", margin: "3px 12px", background: "rgba(255,255,255,0.04)", borderRadius: "7px", animation: "bellaia-pulse 1.4s ease-in-out infinite", animationDelay: `${i*0.1}s` }} />)
          : docs.length === 0
          ? <p style={{ textAlign: "center", color: "rgba(240,232,216,0.35)", fontSize: "13px", padding: "40px", fontFamily: "Arial, sans-serif" }}>Aucun document</p>
          : docs.map((d) => <DocumentCard key={d.id} document={d} />)}
      </div>

      <p style={{ fontSize: "10px", color: "rgba(220,100,80,0.55)", fontStyle: "italic", fontFamily: "Arial, sans-serif" }}>
        🔒 Tout envoi de document nécessite une validation fondatrice. PDF disponible en V2.
      </p>
    </div>
  );
}
