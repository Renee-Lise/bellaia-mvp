"use client";

import { useEffect, useState, useCallback } from "react";
import { useParams, useRouter }             from "next/navigation";
import { DocumentPreview }     from "@/components/documents/DocumentPreview";
import { DocumentStatusBadge } from "@/components/documents/DocumentStatusBadge";
import { ValidationModal }     from "@/components/validation/ValidationModal";
import { useValidation }       from "@/hooks/useValidation";
import type { DocumentClient } from "@/types/database";

interface DocDetail {
  document: DocumentClient;
  cliente:  { id: string; nom: string; email: string; telephone: string } | null;
}

export default function DocumentDetailPage() {
  const params = useParams();
  const router = useRouter();
  const id     = params.id as string;

  const [detail,  setDetail]  = useState<DocDetail | null>(null);
  const [loading, setLoading] = useState(true);
  const [error,   setError]   = useState<string | null>(null);

  const validation = useValidation();

  const fetchDetail = useCallback(async () => {
    setLoading(true); setError(null);
    try {
      const res = await fetch(`/api/documents/${id}`);
      if (res.status === 404) { router.push("/documents"); return; }
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      setDetail(await res.json());
    } catch { setError("Impossible de charger le document."); }
    finally   { setLoading(false); }
  }, [id, router]);

  useEffect(() => { fetchDetail(); }, [fetchDetail]);

  const changeStatut = (cible: string, titre: string, impact: string) => {
    validation.request({
      action:    "document_statut_change",
      entite:    "documents_clients",
      entite_id: id,
      titre,
      resume:    `Document ${detail?.document.type} (${detail?.document.univers}) → ${cible}`,
      impact,
      onConfirm: async () => {
        const res = await fetch(`/api/documents/${id}?action=${cible === "VALIDE" ? "valider" : "archiver"}`, {
          method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({}),
        });
        if (!res.ok) { const j = await res.json().catch(() => ({})); throw new Error(j.error ?? `HTTP ${res.status}`); }
        await fetchDetail();
      },
    });
  };

  if (loading) return (
    <div style={{ display: "flex", flexDirection: "column", gap: "14px" }}>
      {[0,1].map((i) => <div key={i} style={{ height: i===0?36:280, background: "rgba(255,255,255,0.04)", borderRadius: "12px", animation: "bellaia-pulse 1.4s ease-in-out infinite", animationDelay: `${i*0.1}s` }} />)}
    </div>
  );
  if (error || !detail) return <p style={{ color: "#F44336", fontFamily: "Arial, sans-serif" }}>{error ?? "Introuvable."}</p>;

  const { document: doc, cliente } = detail;
  const isTerminal = doc.statut === "ARCHIVE";

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: "16px" }}>

      {/* Navigation */}
      <div style={{ display: "flex", alignItems: "center", gap: "12px", flexWrap: "wrap" }}>
        <button type="button" onClick={() => router.push("/documents")}
          style={{ background: "none", border: "none", color: "rgba(201,168,76,0.60)", cursor: "pointer", fontSize: "12px", fontFamily: "Georgia, serif" }}>
          ← Documents
        </button>
        <DocumentStatusBadge statut={doc.statut} size="md" withDot />

        {/* Boutons actions */}
        {!isTerminal && (
          <div style={{ marginLeft: "auto", display: "flex", gap: "8px" }}>
            {doc.statut === "BROUILLON" && (
              <button type="button"
                onClick={() => changeStatut("EN_REVISION", "Soumettre pour révision", "Document passé en révision — visible pour relecture.")}
                style={{ padding: "6px 14px", borderRadius: "8px", fontSize: "11px", cursor: "pointer", fontFamily: "Georgia, serif", background: "rgba(255,152,0,0.10)", border: "1px solid rgba(255,152,0,0.28)", color: "#FF9800" }}>
                Soumettre en révision
              </button>
            )}
            {(doc.statut === "BROUILLON" || doc.statut === "EN_REVISION") && (
              <button type="button"
                onClick={() => changeStatut("VALIDE", "Valider le document", "Le document sera marqué VALIDÉ et prêt à être envoyé. Validation fondatrice obligatoire.")}
                style={{ padding: "6px 16px", borderRadius: "8px", fontSize: "11px", fontWeight: "700", cursor: "pointer", fontFamily: "Georgia, serif", background: "linear-gradient(135deg, #C9A84C, #5C2D5C)", border: "none", color: "#0C0810" }}>
                🔒 Valider
              </button>
            )}
            {doc.statut === "VALIDE" && (
              <button type="button"
                onClick={() => changeStatut("ARCHIVE", "Archiver le document", "Ce document sera archivé et ne pourra plus être modifié.")}
                style={{ padding: "6px 14px", borderRadius: "8px", fontSize: "11px", cursor: "pointer", fontFamily: "Georgia, serif", background: "rgba(136,136,136,0.10)", border: "1px solid rgba(136,136,136,0.25)", color: "#888888" }}>
                Archiver
              </button>
            )}
          </div>
        )}
      </div>

      {/* Grille 2 colonnes */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1.5fr", gap: "14px", alignItems: "start" }}>

        {/* Infos */}
        <div style={{ display: "flex", flexDirection: "column", gap: "14px" }}>
          <div style={{ background: "#120A10", border: "1px solid rgba(201,168,76,0.14)", borderRadius: "12px", padding: "16px 18px" }}>
            <p style={{ fontSize: "9px", color: "#C9A84C", letterSpacing: "0.18em", textTransform: "uppercase", fontWeight: "700", marginBottom: "14px", fontFamily: "Arial, sans-serif" }}>Informations</p>
            {[
              ["Type",     doc.type],
              ["Univers",  doc.univers],
              ["Version",  doc.version],
              ["Statut",   doc.statut],
              ["Créé le",  new Date(doc.created_at).toLocaleDateString("fr-FR")],
              ...(doc.date_validation ? [["Validé le", new Date(doc.date_validation).toLocaleDateString("fr-FR")]] : []),
            ].map(([l, v]) => (
              <div key={l} style={{ display: "flex", justifyContent: "space-between", padding: "6px 0", borderBottom: "1px solid rgba(255,255,255,0.04)" }}>
                <p style={{ fontSize: "11px", color: "rgba(240,232,216,0.40)", fontFamily: "Arial, sans-serif" }}>{l}</p>
                <p style={{ fontSize: "12px", color: "#F0E8D8", fontFamily: "Arial, sans-serif" }}>{v}</p>
              </div>
            ))}
          </div>

          {cliente && (
            <div style={{ background: "#120A10", border: "1px solid rgba(201,168,76,0.14)", borderRadius: "12px", padding: "16px 18px" }}>
              <p style={{ fontSize: "9px", color: "#C9A84C", letterSpacing: "0.18em", textTransform: "uppercase", fontWeight: "700", marginBottom: "14px", fontFamily: "Arial, sans-serif" }}>Cliente associée</p>
              {[["Nom", cliente.nom], ["Email", cliente.email || "—"], ["Tél.", cliente.telephone || "—"]].map(([l, v]) => (
                <div key={l} style={{ display: "flex", justifyContent: "space-between", padding: "6px 0", borderBottom: "1px solid rgba(255,255,255,0.04)" }}>
                  <p style={{ fontSize: "11px", color: "rgba(240,232,216,0.40)", fontFamily: "Arial, sans-serif" }}>{l}</p>
                  <p style={{ fontSize: "12px", color: "#F0E8D8", fontFamily: "Arial, sans-serif" }}>{v}</p>
                </div>
              ))}
            </div>
          )}

          <div style={{ padding: "10px 14px", background: "rgba(160,32,16,0.06)", border: "1px solid rgba(160,32,16,0.16)", borderRadius: "8px" }}>
            <p style={{ fontSize: "10px", color: "rgba(220,100,80,0.75)", fontStyle: "italic", fontFamily: "Arial, sans-serif" }}>
              🔒 Export PDF en V2 · Envoi email en V2 · Validation fondatrice obligatoire avant envoi
            </p>
          </div>
        </div>

        {/* Prévisualisation */}
        <DocumentPreview document={doc} />
      </div>

      <ValidationModal validation={validation} />
    </div>
  );
}
