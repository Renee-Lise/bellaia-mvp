"use client";

import { useEffect, useState, useCallback } from "react";
import { ClientCard }        from "@/components/crm/ClientCard";
import { ClientStatusBadge } from "@/components/crm/ClientStatusBadge";
import { STATUTS_CRM }       from "@/constants/statuts";
import type { ClienteCRM }   from "@/types/database";

interface CRMResponse { clientes: ClienteCRM[]; total: number; }

const UNIVERS = ["secret_home","odyssee","food","events","academy","structure"];

export default function CRMPage() {
  const [data,          setData]          = useState<CRMResponse | null>(null);
  const [loading,       setLoading]       = useState(true);
  const [error,         setError]         = useState<string | null>(null);
  const [search,        setSearch]        = useState("");
  const [searchD,       setSearchD]       = useState("");
  const [filtreStatut,  setFiltreStatut]  = useState("");
  const [filtreUnivers, setFiltreUnivers] = useState("");
  const [viewMode,      setViewMode]      = useState<"grid" | "list">("list");

  useEffect(() => {
    const t = setTimeout(() => setSearchD(search), 350);
    return () => clearTimeout(t);
  }, [search]);

  const fetchData = useCallback(async () => {
    setLoading(true); setError(null);
    try {
      const p = new URLSearchParams({ limit: "100" });
      if (filtreStatut)  p.set("statut",  filtreStatut);
      if (filtreUnivers) p.set("univers", filtreUnivers);
      if (searchD)       p.set("search",  searchD);
      const res = await fetch(`/api/crm?${p}`);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      setData(await res.json());
    } catch { setError("Impossible de charger les clientes."); }
    finally { setLoading(false); }
  }, [filtreStatut, filtreUnivers, searchD]);

  useEffect(() => { fetchData(); }, [fetchData]);

  const clientes = data?.clientes ?? [];
  const vip      = clientes.filter((c) => c.statut_crm === "vip").length;
  const actives  = clientes.filter((c) => c.statut_crm === "active").length;

  const inputStyle: React.CSSProperties = { padding: "7px 12px", borderRadius: "8px", background: "rgba(255,255,255,0.04)", border: "1px solid rgba(201,168,76,0.18)", color: "#F0E8D8", fontSize: "12px", outline: "none", fontFamily: "Arial, sans-serif" };

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: "18px" }}>

      {/* En-tête */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", flexWrap: "wrap", gap: "10px" }}>
        <div>
          <h2 style={{ fontSize: "20px", fontWeight: "700", color: "#F0E8D8", fontFamily: "Georgia, serif" }}>CRM Clientes</h2>
          <p style={{ fontSize: "11px", color: "rgba(201,168,76,0.55)", marginTop: "2px", fontFamily: "Arial, sans-serif" }}>
            {loading ? "Chargement…" : `${data?.total ?? 0} clientes · ${vip} VIP · ${actives} actives`}
          </p>
        </div>
        <div style={{ display: "flex", gap: "8px" }}>
          {/* Toggle vue */}
          {["list","grid"].map((m) => (
            <button key={m} type="button" onClick={() => setViewMode(m as "grid"|"list")}
              style={{ padding: "6px 12px", borderRadius: "8px", fontSize: "11px", cursor: "pointer", fontFamily: "Georgia, serif",
                background: viewMode === m ? "rgba(201,168,76,0.15)" : "rgba(255,255,255,0.03)",
                border: `1px solid ${viewMode === m ? "rgba(201,168,76,0.35)" : "rgba(255,255,255,0.08)"}`,
                color: viewMode === m ? "#C9A84C" : "rgba(240,232,216,0.45)" }}>
              {m === "list" ? "☰ Liste" : "⊞ Cartes"}
            </button>
          ))}
          <button type="button" onClick={fetchData} disabled={loading}
            style={{ ...inputStyle, cursor: loading ? "not-allowed" : "pointer", color: "rgba(201,168,76,0.65)" }}>
            {loading ? "⟳" : "⟳"}
          </button>
        </div>
      </div>

      {/* Filtres */}
      <div style={{ display: "flex", gap: "10px", flexWrap: "wrap" }}>
        <input type="text" value={search} onChange={(e) => setSearch(e.target.value)}
          placeholder="Rechercher par nom ou email…"
          style={{ ...inputStyle, minWidth: "220px" }} />
        <select value={filtreStatut} onChange={(e) => setFiltreStatut(e.target.value)}
          style={{ ...inputStyle, cursor: "pointer", color: filtreStatut ? "#C9A84C" : "rgba(240,232,216,0.50)" }}>
          <option value="">Tous les statuts</option>
          {STATUTS_CRM.map((s) => <option key={s.key} value={s.key}>{s.label}</option>)}
        </select>
        <select value={filtreUnivers} onChange={(e) => setFiltreUnivers(e.target.value)}
          style={{ ...inputStyle, cursor: "pointer", color: filtreUnivers ? "#C9A84C" : "rgba(240,232,216,0.50)" }}>
          <option value="">Tous les univers</option>
          {UNIVERS.map((u) => <option key={u} value={u}>{u}</option>)}
        </select>
        {(filtreStatut || filtreUnivers || search) && (
          <button type="button" onClick={() => { setFiltreStatut(""); setFiltreUnivers(""); setSearch(""); }}
            style={{ ...inputStyle, cursor: "pointer", color: "rgba(240,232,216,0.45)" }}>
            ✕ Réinitialiser
          </button>
        )}
      </div>

      {/* Répartition statuts */}
      {!loading && clientes.length > 0 && (
        <div style={{ display: "flex", gap: "8px", flexWrap: "wrap" }}>
          {STATUTS_CRM.map((s) => {
            const n = clientes.filter((c) => c.statut_crm === s.key).length;
            if (n === 0) return null;
            return (
              <button key={s.key} type="button" onClick={() => setFiltreStatut(filtreStatut === s.key ? "" : s.key)}
                style={{ display: "flex", alignItems: "center", gap: "6px", padding: "4px 11px", borderRadius: "20px", cursor: "pointer",
                  background: filtreStatut === s.key ? `${s.color}20` : "rgba(255,255,255,0.03)",
                  border: `1px solid ${filtreStatut === s.key ? `${s.color}45` : "rgba(255,255,255,0.08)"}`,
                  color: filtreStatut === s.key ? s.color : "rgba(240,232,216,0.50)",
                  fontSize: "11px", fontFamily: "Arial, sans-serif" }}>
                <ClientStatusBadge statut={s.key} size="xs" />
                <span style={{ fontWeight: "700" }}>{n}</span>
              </button>
            );
          })}
        </div>
      )}

      {/* Erreur */}
      {error && (
        <div style={{ padding: "12px 16px", background: "rgba(244,67,54,0.09)", border: "1px solid rgba(244,67,54,0.22)", borderRadius: "10px", color: "#F44336", fontSize: "13px", fontFamily: "Arial, sans-serif" }}>
          {error}
        </div>
      )}

      {/* Contenu */}
      {viewMode === "grid" ? (
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: "12px" }}>
          {loading
            ? [0,1,2,3].map((i) => <div key={i} style={{ height: "200px", background: "rgba(255,255,255,0.04)", borderRadius: "12px", animation: "bellaia-pulse 1.4s ease-in-out infinite", animationDelay: `${i*0.1}s` }} />)
            : clientes.length === 0
            ? <p style={{ gridColumn: "1/-1", textAlign: "center", color: "rgba(240,232,216,0.35)", fontSize: "13px", padding: "40px", fontFamily: "Arial, sans-serif" }}>Aucune cliente</p>
            : clientes.map((c) => <ClientCard key={c.id} cliente={c} />)}
        </div>
      ) : (
        <div style={{ background: "#120A10", border: "1px solid rgba(201,168,76,0.14)", borderRadius: "12px", overflow: "hidden" }}>
          {/* Header table */}
          <div style={{ display: "grid", gridTemplateColumns: "36px 1fr 100px 90px 80px 80px", gap: "10px", padding: "9px 14px", borderBottom: "1px solid rgba(201,168,76,0.10)" }}>
            {["", "Cliente", "Statut", "Fidélité", "CA", ""].map((h) => (
              <p key={h} style={{ fontSize: "9px", color: "rgba(201,168,76,0.45)", letterSpacing: "0.14em", textTransform: "uppercase", fontFamily: "Arial, sans-serif" }}>{h}</p>
            ))}
          </div>
          {loading
            ? [0,1,2,3,4].map((i) => <div key={i} style={{ height: "44px", margin: "3px 12px", background: "rgba(255,255,255,0.04)", borderRadius: "7px", animation: "bellaia-pulse 1.4s ease-in-out infinite", animationDelay: `${i*0.1}s` }} />)
            : clientes.length === 0
            ? <p style={{ textAlign: "center", color: "rgba(240,232,216,0.35)", fontSize: "13px", padding: "40px", fontFamily: "Arial, sans-serif" }}>Aucune cliente</p>
            : clientes.map((c) => <ClientCard key={c.id} cliente={c} compact />)}
        </div>
      )}
    </div>
  );
}
