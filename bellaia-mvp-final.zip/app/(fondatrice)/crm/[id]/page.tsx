"use client";

import { useEffect, useState, useCallback } from "react";
import { useParams, useRouter }              from "next/navigation";
import { ClientStatusBadge }  from "@/components/crm/ClientStatusBadge";
import { ClientTimeline }     from "@/components/crm/ClientTimeline";
import { STATUTS_CRM }        from "@/constants/statuts";
import type { ClienteCRM }    from "@/types/database";
import type { TimelineEvent } from "@/components/crm/ClientTimeline";

interface Commande { id: string; total: number; statut: string; branche: string; created_at: string; }
interface Document { id: string; type: string; univers: string; statut: string; version: string; created_at: string; }

interface DetailResponse {
  cliente:   ClienteCRM;
  commandes: Commande[];
  documents: Document[];
}

function formatEur(n: number) {
  return new Intl.NumberFormat("fr-FR", { style: "currency", currency: "EUR", minimumFractionDigits: 0 }).format(n);
}

const fieldStyle: React.CSSProperties = {
  width: "100%", padding: "9px 12px", borderRadius: "8px",
  background: "rgba(255,255,255,0.04)", border: "1px solid rgba(201,168,76,0.18)",
  color: "#F0E8D8", fontSize: "13px", outline: "none", fontFamily: "Arial, sans-serif",
};

const labelStyle: React.CSSProperties = {
  display: "block", fontSize: "9px", color: "rgba(240,232,216,0.40)",
  letterSpacing: "0.14em", textTransform: "uppercase", marginBottom: "5px", fontFamily: "Arial, sans-serif",
};

function Section({ titre, children }: { titre: string; children: React.ReactNode }) {
  return (
    <div style={{ background: "#120A10", border: "1px solid rgba(201,168,76,0.14)", borderRadius: "12px", padding: "16px 18px" }}>
      <p style={{ fontSize: "9px", color: "#C9A84C", letterSpacing: "0.18em", textTransform: "uppercase", fontWeight: "700", marginBottom: "14px", fontFamily: "Arial, sans-serif" }}>{titre}</p>
      {children}
    </div>
  );
}

export default function ClienteDetailPage() {
  const params = useParams();
  const router = useRouter();
  const id     = params.id as string;

  const [detail,    setDetail]    = useState<DetailResponse | null>(null);
  const [loading,   setLoading]   = useState(true);
  const [error,     setError]     = useState<string | null>(null);
  const [saving,    setSaving]    = useState(false);
  const [saveMsg,   setSaveMsg]   = useState<string | null>(null);
  const [editMode,  setEditMode]  = useState(false);

  // Champs éditables
  const [nom,          setNom]          = useState("");
  const [email,        setEmail]        = useState("");
  const [telephone,    setTelephone]    = useState("");
  const [statutCRM,    setStatutCRM]    = useState("");
  const [scoreFidelite, setScoreFidelite] = useState(0);
  const [notesAdmin,   setNotesAdmin]   = useState("");

  const fetchDetail = useCallback(async () => {
    setLoading(true); setError(null);
    try {
      const res = await fetch(`/api/crm/${id}`);
      if (res.status === 404) { router.push("/crm"); return; }
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data: DetailResponse = await res.json();
      setDetail(data);
      // Initialiser les champs
      setNom(data.cliente.nom);
      setEmail(data.cliente.email ?? "");
      setTelephone(data.cliente.telephone ?? "");
      setStatutCRM(data.cliente.statut_crm);
      setScoreFidelite(data.cliente.score_fidelite);
      setNotesAdmin(data.cliente.notes_admin ?? "");
    } catch { setError("Impossible de charger la fiche."); }
    finally   { setLoading(false); }
  }, [id, router]);

  useEffect(() => { fetchDetail(); }, [fetchDetail]);

  // Construire la timeline
  const timeline: TimelineEvent[] = [
    ...(detail?.commandes ?? []).map((c) => ({
      id: c.id, type: "commande" as const,
      titre: `Commande — ${c.branche}`,
      description: `Statut : ${c.statut}`,
      date: c.created_at, montant: c.total,
      href: `/commandes/${c.id}`,
    })),
    ...(detail?.documents ?? []).map((d) => ({
      id: d.id, type: "document" as const,
      titre: `Document — ${d.type}`,
      description: `${d.univers} · v${d.version} · ${d.statut}`,
      date: d.created_at,
    })),
  ].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  const saveChanges = async () => {
    setSaving(true); setSaveMsg(null);
    try {
      const res = await fetch(`/api/crm/${id}`, {
        method: "PUT", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ nom, email, telephone, statut_crm: statutCRM, score_fidelite: scoreFidelite, notes_admin: notesAdmin }),
      });
      if (!res.ok) throw new Error();
      setSaveMsg("Fiche sauvegardée."); setEditMode(false);
      await fetchDetail();
      setTimeout(() => setSaveMsg(null), 2500);
    } catch { setSaveMsg("Erreur lors de la sauvegarde."); }
    finally   { setSaving(false); }
  };

  if (loading) return (
    <div style={{ display: "flex", flexDirection: "column", gap: "14px" }}>
      {[0,1,2].map((i) => <div key={i} style={{ height: i===0?40:160, background: "rgba(255,255,255,0.04)", borderRadius: "12px", animation: "bellaia-pulse 1.4s ease-in-out infinite", animationDelay: `${i*0.1}s` }} />)}
    </div>
  );
  if (error || !detail) return <p style={{ color: "#F44336", fontFamily: "Arial, sans-serif" }}>{error ?? "Introuvable."}</p>;

  const { cliente } = detail;

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: "16px" }}>

      {/* En-tête */}
      <div style={{ display: "flex", alignItems: "center", gap: "12px", flexWrap: "wrap" }}>
        <button type="button" onClick={() => router.push("/crm")}
          style={{ background: "none", border: "none", color: "rgba(201,168,76,0.60)", cursor: "pointer", fontSize: "12px", fontFamily: "Georgia, serif" }}>
          ← CRM
        </button>
        <div style={{ width: "42px", height: "42px", borderRadius: "50%", background: "linear-gradient(135deg, #C9A84C, #5C2D5C)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "15px", fontWeight: "700", color: "#0C0810" }}>
          {cliente.nom.slice(0,2).toUpperCase()}
        </div>
        <div>
          <p style={{ fontSize: "18px", fontWeight: "700", color: "#F0E8D8", fontFamily: "Georgia, serif" }}>{cliente.nom}</p>
          <p style={{ fontSize: "11px", color: "rgba(240,232,216,0.40)", fontFamily: "Arial, sans-serif" }}>{cliente.email || "—"}</p>
        </div>
        <ClientStatusBadge statut={cliente.statut_crm} size="md" withDot />
        <div style={{ marginLeft: "auto", display: "flex", gap: "8px", alignItems: "center" }}>
          {saveMsg && <p style={{ fontSize: "11px", color: saveMsg.includes("Erreur") ? "#F44336" : "#4CAF50", fontFamily: "Arial, sans-serif" }}>{saveMsg}</p>}
          <button type="button" onClick={() => setEditMode(!editMode)}
            style={{ padding: "6px 14px", borderRadius: "8px", fontSize: "11px", cursor: "pointer", fontFamily: "Georgia, serif",
              background: editMode ? "rgba(244,67,54,0.10)" : "rgba(201,168,76,0.10)",
              border: `1px solid ${editMode ? "rgba(244,67,54,0.25)" : "rgba(201,168,76,0.25)"}`,
              color: editMode ? "#F44336" : "#C9A84C" }}>
            {editMode ? "Annuler" : "Modifier"}
          </button>
          {editMode && (
            <button type="button" onClick={saveChanges} disabled={saving}
              style={{ padding: "6px 16px", borderRadius: "8px", fontSize: "11px", fontWeight: "700", cursor: saving ? "not-allowed" : "pointer", fontFamily: "Georgia, serif",
                background: "linear-gradient(135deg, #C9A84C, #5C2D5C)", border: "none", color: "#0C0810" }}>
              {saving ? "Sauvegarde…" : "Sauvegarder"}
            </button>
          )}
        </div>
      </div>

      {/* Grille 2 colonnes */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "14px", alignItems: "start" }}>

        {/* Colonne gauche */}
        <div style={{ display: "flex", flexDirection: "column", gap: "14px" }}>

          <Section titre="Informations">
            {editMode ? (
              <div style={{ display: "flex", flexDirection: "column", gap: "10px" }}>
                <div><label style={labelStyle}>Nom</label><input value={nom} onChange={(e) => setNom(e.target.value)} style={fieldStyle} /></div>
                <div><label style={labelStyle}>Email</label><input type="email" value={email} onChange={(e) => setEmail(e.target.value)} style={fieldStyle} /></div>
                <div><label style={labelStyle}>Téléphone</label><input value={telephone} onChange={(e) => setTelephone(e.target.value)} style={fieldStyle} /></div>
                <div>
                  <label style={labelStyle}>Statut CRM</label>
                  <select value={statutCRM} onChange={(e) => setStatutCRM(e.target.value)} style={{ ...fieldStyle, cursor: "pointer" }}>
                    {STATUTS_CRM.map((s) => <option key={s.key} value={s.key}>{s.label}</option>)}
                  </select>
                </div>
                <div>
                  <label style={labelStyle}>Score fidélité ({scoreFidelite}/100)</label>
                  <input type="range" min={0} max={100} value={scoreFidelite} onChange={(e) => setScoreFidelite(parseInt(e.target.value))} style={{ width: "100%", accentColor: "#C9A84C" }} />
                </div>
              </div>
            ) : (
              <div style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
                {[
                  ["Email",     cliente.email || "—"],
                  ["Téléphone", cliente.telephone || "—"],
                  ["Univers",   cliente.univers?.join(", ") || "—"],
                  ["Anniversaire", cliente.anniversaire || "—"],
                  ["Inscrite le", new Date(cliente.created_at).toLocaleDateString("fr-FR")],
                ].map(([l, v]) => (
                  <div key={l} style={{ display: "flex", justifyContent: "space-between", padding: "6px 0", borderBottom: "1px solid rgba(255,255,255,0.04)" }}>
                    <p style={{ fontSize: "11px", color: "rgba(240,232,216,0.40)", fontFamily: "Arial, sans-serif" }}>{l}</p>
                    <p style={{ fontSize: "12px", color: "#F0E8D8", fontFamily: "Arial, sans-serif" }}>{v}</p>
                  </div>
                ))}
              </div>
            )}
          </Section>

          <Section titre="Statistiques">
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "10px" }}>
              {[
                ["Achats",       cliente.nb_achats.toString(), "#C9A84C"],
                ["CA total",     formatEur(cliente.ca_total),  "#C9A84C"],
                ["Score fidél.", `${cliente.score_fidelite}/100`, "#E8A4B8"],
                ["Statut CRM",  cliente.statut_crm,            "#7EB8C4"],
              ].map(([l, v, c]) => (
                <div key={l} style={{ padding: "10px 12px", background: "rgba(255,255,255,0.03)", borderRadius: "8px" }}>
                  <p style={{ fontSize: "8px", color: "rgba(240,232,216,0.35)", letterSpacing: "0.10em", textTransform: "uppercase", marginBottom: "4px", fontFamily: "Arial, sans-serif" }}>{l}</p>
                  <p style={{ fontSize: "16px", fontWeight: "700", color: c, fontFamily: "Arial, sans-serif" }}>{v}</p>
                </div>
              ))}
            </div>
          </Section>

          <Section titre="Notes internes">
            <textarea
              value={notesAdmin}
              onChange={(e) => setNotesAdmin(e.target.value)}
              disabled={!editMode}
              rows={4} placeholder="Notes internes…"
              style={{ ...fieldStyle, resize: "vertical", lineHeight: "1.5", opacity: editMode ? 1 : 0.7 }}
            />
          </Section>
        </div>

        {/* Colonne droite — timeline */}
        <Section titre={`Activité (${timeline.length} événements)`}>
          <ClientTimeline events={timeline} />
        </Section>
      </div>
    </div>
  );
}
