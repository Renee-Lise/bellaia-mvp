"use client";

import { useEffect, useState, useCallback } from "react";
import { KpiCard }           from "@/components/dashboard/KpiCard";
import { UrgenceItem, UrgenceItemSkeleton } from "@/components/dashboard/UrgenceItem";
import { AgendaWidget }      from "@/components/dashboard/AgendaWidget";
import { FinanceWidget }     from "@/components/dashboard/FinanceWidget";
import { StockAlertWidget }  from "@/components/dashboard/StockAlertWidget";
import type { DashboardSummary } from "@/app/api/dashboard/summary/route";

/**
 * app/(fondatrice)/dashboard/page.tsx
 *
 * Tableau de bord fondatrice — Vue 360° Bella'Studio.
 *
 * Structure :
 * 1. Ligne KPIs (5 cartes)
 * 2. Colonne gauche : urgences + message Bellaïa
 * 3. Colonne droite : agenda + finance + stocks
 *
 * Se rafraîchit toutes les 60 secondes.
 * Lecture seule — toutes les actions renvoient vers les modules dédiés.
 */

// ── Helpers ───────────────────────────────────────────────────────────────────

function formatEur(n: number): string {
  if (n >= 1000) {
    return (n / 1000).toFixed(1).replace(".", ",") + " k€";
  }
  return n.toFixed(0) + " €";
}

function getGreeting(): string {
  const h = new Date().getHours();
  if (h < 12) return "Bonjour";
  if (h < 18) return "Bon après-midi";
  return "Bonsoir";
}

function getTodayLabel(): string {
  return new Date().toLocaleDateString("fr-FR", {
    weekday: "long",
    day:     "numeric",
    month:   "long",
    year:    "numeric",
  });
}

// ── Page ──────────────────────────────────────────────────────────────────────

export default function DashboardPage() {
  const [data,          setData]          = useState<DashboardSummary | null>(null);
  const [loading,       setLoading]       = useState(true);
  const [error,         setError]         = useState<string | null>(null);
  const [lastRefresh,   setLastRefresh]   = useState<Date>(new Date());

  // ── Chargement des données ─────────────────────────────────────────────────
  const fetchData = useCallback(async () => {
    try {
      const res = await fetch("/api/dashboard/summary", {
        cache: "no-store",
      });

      if (!res.ok) {
        if (res.status === 401 || res.status === 403) {
          window.location.href = "/connexion";
          return;
        }
        throw new Error(`HTTP ${res.status}`);
      }

      const json: DashboardSummary = await res.json();
      setData(json);
      setError(null);
      setLastRefresh(new Date());
    } catch (err) {
      console.error("[Dashboard]", err);
      setError("Impossible de charger les données. Vérifiez votre connexion.");
    } finally {
      setLoading(false);
    }
  }, []);

  // ── Chargement initial + rafraîchissement auto ─────────────────────────────
  useEffect(() => {
    fetchData();
    const interval = setInterval(fetchData, 60_000); // toutes les 60s
    return () => clearInterval(interval);
  }, [fetchData]);

  const kpis       = data?.kpis;
  const urgences   = data?.urgences ?? [];
  const urgRouge   = urgences.filter((u) => u.niveau === "rouge");
  const urgJaune   = urgences.filter((u) => u.niveau === "jaune");
  const urgBleu    = urgences.filter((u) => u.niveau === "bleu");

  // ── Message Bellaïa du jour ───────────────────────────────────────────────
  const bellaiaMessage = loading
    ? "Chargement de votre synthèse…"
    : error
    ? "Connexion temporairement indisponible."
    : urgRouge.length > 0
    ? `${getGreeting()} Renée-Lise. Vous avez ${urgRouge.length} urgence${urgRouge.length > 1 ? "s" : ""} critique${urgRouge.length > 1 ? "s" : ""} nécessitant votre validation aujourd'hui.${kpis && kpis.ca_mois > 0 ? ` Le CA du mois est de ${formatEur(kpis.ca_mois)}.` : ""} Je suis prête à préparer vos récapitulatifs.`
    : `${getGreeting()} Renée-Lise. Tout est sous contrôle — aucune urgence critique.${kpis && kpis.ca_mois > 0 ? ` CA du mois : ${formatEur(kpis.ca_mois)}.` : ""} Bellaïa est à votre service.`;

  // ─────────────────────────────────────────────────────────────────────────
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: "20px" }}>

      {/* ── En-tête ─────────────────────────────────────────────────────────── */}
      <div
        style={{
          display:        "flex",
          justifyContent: "space-between",
          alignItems:     "flex-start",
          flexWrap:       "wrap",
          gap:            "8px",
        }}
      >
        <div>
          <h2
            style={{
              fontSize:   "20px",
              fontWeight: "700",
              color:      "#F0E8D8",
              fontFamily: "Georgia, serif",
            }}
          >
            Tableau de bord
          </h2>
          <p
            style={{
              fontSize:   "11px",
              color:      "rgba(201, 168, 76, 0.55)",
              marginTop:  "2px",
              fontFamily: "Arial, sans-serif",
              textTransform: "capitalize",
            }}
          >
            {getTodayLabel()}
          </p>
        </div>

        {/* Dernier rafraîchissement */}
        <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
          {error && (
            <span
              style={{
                fontSize:   "11px",
                color:      "#F44336",
                fontFamily: "Arial, sans-serif",
              }}
            >
              ⚠ {error}
            </span>
          )}
          <button
            type="button"
            onClick={fetchData}
            disabled={loading}
            style={{
              fontSize:     "11px",
              padding:      "5px 12px",
              borderRadius: "20px",
              background:   "rgba(201, 168, 76, 0.08)",
              border:       "1px solid rgba(201, 168, 76, 0.20)",
              color:        "rgba(201, 168, 76, 0.65)",
              cursor:       loading ? "not-allowed" : "pointer",
              fontFamily:   "Georgia, serif",
              transition:   "opacity 0.15s",
            }}
          >
            {loading ? "⟳ Chargement…" : "⟳ Actualiser"}
          </button>
          <p
            style={{
              fontSize:   "10px",
              color:      "rgba(240,232,216,0.22)",
              fontFamily: "Arial, sans-serif",
            }}
          >
            {lastRefresh.toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" })}
          </p>
        </div>
      </div>

      {/* ── Message Bellaïa ──────────────────────────────────────────────────── */}
      <div
        style={{
          padding:      "14px 18px",
          background:   "linear-gradient(135deg, rgba(92,45,92,0.12), rgba(201,168,76,0.07))",
          border:       "1px solid rgba(201, 168, 76, 0.18)",
          borderRadius: "12px",
          display:      "flex",
          alignItems:   "flex-start",
          gap:          "12px",
        }}
      >
        {/* Avatar Bellaïa */}
        <div
          style={{
            width:        "32px",
            height:       "32px",
            borderRadius: "50%",
            background:   "linear-gradient(135deg, #5C2D5C, #C9A84C)",
            display:      "flex",
            alignItems:   "center",
            justifyContent: "center",
            fontSize:     "13px",
            fontWeight:   "700",
            color:        "#0C0810",
            flexShrink:   0,
          }}
        >
          B
        </div>

        <div style={{ flex: 1 }}>
          <p
            style={{
              fontSize:      "8px",
              color:         "#C9A84C",
              letterSpacing: "0.20em",
              textTransform: "uppercase",
              fontWeight:    "700",
              fontFamily:    "Arial, sans-serif",
              marginBottom:  "5px",
            }}
          >
            Bellaïa ✦ Message du jour
          </p>
          <p
            style={{
              fontSize:   "13px",
              color:      "rgba(240, 232, 216, 0.80)",
              lineHeight: "1.65",
              fontFamily: "Georgia, serif",
              fontStyle:  "italic",
            }}
          >
            &ldquo;{bellaiaMessage}&rdquo;
          </p>
        </div>
      </div>

      {/* ── Ligne KPIs ───────────────────────────────────────────────────────── */}
      <div
        style={{
          display:             "grid",
          gridTemplateColumns: "repeat(auto-fit, minmax(150px, 1fr))",
          gap:                 "12px",
        }}
      >
        <KpiCard
          label="CA ce mois"
          value={loading ? "—" : formatEur(kpis?.ca_mois ?? 0)}
          subtext={loading ? "" : `${kpis?.commandes_actives ?? 0} commandes actives`}
          color="#C9A84C"
          icon="◈"
          loading={loading}
        />
        <KpiCard
          label="Urgences critiques"
          value={loading ? "—" : urgRouge.length}
          subtext={loading ? "" : urgRouge.length > 0 ? "Validation requise" : "Aucune urgence"}
          color={urgRouge.length > 0 ? "#F44336" : "#4CAF50"}
          icon="⚡"
          urgent={urgRouge.length > 0}
          loading={loading}
        />
        <KpiCard
          label="Paiements en attente"
          value={loading ? "—" : formatEur(kpis?.montant_en_attente ?? 0)}
          subtext={loading ? "" : `${kpis?.paiements_en_attente ?? 0} transaction${(kpis?.paiements_en_attente ?? 0) > 1 ? "s" : ""}`}
          color={( kpis?.montant_en_attente ?? 0) > 0 ? "#FF9800" : "rgba(240,232,216,0.35)"}
          icon="◐"
          loading={loading}
        />
        <KpiCard
          label="Alertes stocks"
          value={loading ? "—" : (kpis?.ruptures_stock ?? 0) + (kpis?.alertes_stock ?? 0)}
          subtext={loading ? "" : `${kpis?.ruptures_stock ?? 0} rupture${(kpis?.ruptures_stock ?? 0) > 1 ? "s" : ""} · ${kpis?.alertes_stock ?? 0} faible${(kpis?.alertes_stock ?? 0) > 1 ? "s" : ""}`}
          color={(kpis?.ruptures_stock ?? 0) > 0 ? "#F44336" : (kpis?.alertes_stock ?? 0) > 0 ? "#FF9800" : "#4CAF50"}
          icon="📦"
          urgent={(kpis?.ruptures_stock ?? 0) > 0}
          loading={loading}
        />
        <KpiCard
          label="Clientes actives"
          value={loading ? "—" : kpis?.clientes_actives ?? 0}
          subtext={loading ? "" : `${kpis?.factures_a_regler ?? 0} facture${(kpis?.factures_a_regler ?? 0) > 1 ? "s" : ""} à régler`}
          color="#E8A4B8"
          icon="✦"
          loading={loading}
        />
      </div>

      {/* ── Corps principal : 2 colonnes ─────────────────────────────────────── */}
      <div
        style={{
          display:             "grid",
          gridTemplateColumns: "1fr 1fr",
          gap:                 "16px",
          alignItems:          "start",
        }}
      >
        {/* ── Colonne gauche : urgences ─────────────────────────────────────── */}
        <div style={{ display: "flex", flexDirection: "column", gap: "14px" }}>

          {/* Urgences */}
          <div
            style={{
              background:   "#120A10",
              border:       `1px solid ${urgRouge.length > 0 ? "rgba(244,67,54,0.25)" : "rgba(201,168,76,0.15)"}`,
              borderRadius: "12px",
              padding:      "18px",
            }}
          >
            {/* Header urgences */}
            <div
              style={{
                display:        "flex",
                justifyContent: "space-between",
                alignItems:     "center",
                marginBottom:   "14px",
              }}
            >
              <p
                style={{
                  fontSize:      "9px",
                  color:         urgRouge.length > 0 ? "#F44336" : "#C9A84C",
                  letterSpacing: "0.20em",
                  textTransform: "uppercase",
                  fontWeight:    "700",
                  fontFamily:    "Arial, sans-serif",
                }}
              >
                ⚡ Actions requises ({loading ? "…" : urgences.length})
              </p>
              {!loading && urgences.length > 0 && (
                <div style={{ display: "flex", gap: "6px" }}>
                  {urgRouge.length  > 0 && <Chip n={urgRouge.length}  c="#F44336" />}
                  {urgJaune.length  > 0 && <Chip n={urgJaune.length}  c="#FF9800" />}
                  {urgBleu.length   > 0 && <Chip n={urgBleu.length}   c="#2196F3" />}
                </div>
              )}
            </div>

            {/* Liste urgences */}
            {loading ? (
              <div style={{ display: "flex", flexDirection: "column", gap: "7px" }}>
                {[0, 1, 2, 3].map((i) => (
                  <UrgenceItemSkeleton key={i} />
                ))}
              </div>
            ) : urgences.length === 0 ? (
              <div
                style={{
                  padding:      "20px",
                  textAlign:    "center",
                  borderRadius: "8px",
                  background:   "rgba(76,175,80,0.06)",
                  border:       "1px dashed rgba(76,175,80,0.20)",
                }}
              >
                <p style={{ fontSize: "18px", marginBottom: "6px" }}>✅</p>
                <p style={{ fontSize: "12px", color: "#4CAF50", fontFamily: "Arial, sans-serif" }}>
                  Aucune urgence — tout est à jour
                </p>
              </div>
            ) : (
              <div style={{ display: "flex", flexDirection: "column", gap: "7px" }}>
                {urgences.map((u, i) => (
                  <UrgenceItem key={`${u.entite}-${u.id}`} urgence={u} index={i} />
                ))}
              </div>
            )}

            {/* Note gouvernance */}
            {!loading && urgences.length > 0 && (
              <p
                style={{
                  marginTop:  "12px",
                  fontSize:   "9px",
                  color:      "rgba(220, 100, 80, 0.60)",
                  fontStyle:  "italic",
                  fontFamily: "Arial, sans-serif",
                }}
              >
                🔒 Validation fondatrice obligatoire sur toutes ces actions.
              </p>
            )}
          </div>

          {/* Finance widget */}
          <FinanceWidget data={data} loading={loading} />
        </div>

        {/* ── Colonne droite : agenda + stocks ──────────────────────────────── */}
        <div style={{ display: "flex", flexDirection: "column", gap: "14px" }}>
          <AgendaWidget />
          <StockAlertWidget data={data} loading={loading} />
        </div>
      </div>

      {/* ── Footer tableau de bord ───────────────────────────────────────────── */}
      <p
        style={{
          textAlign:  "center",
          fontSize:   "10px",
          color:      "rgba(240,232,216,0.18)",
          fontStyle:  "italic",
          fontFamily: "Arial, sans-serif",
          paddingBottom: "8px",
        }}
      >
        Bellaïa prépare · Renée-Lise décide · Aucune action financière ou stratégique sans validation fondatrice
      </p>
    </div>
  );
}

// ── Composant badge ───────────────────────────────────────────────────────────

function Chip({ n, c }: { n: number; c: string }) {
  return (
    <span
      style={{
        fontSize:     "9px",
        padding:      "2px 7px",
        borderRadius: "20px",
        background:   `${c}18`,
        color:        c,
        border:       `1px solid ${c}35`,
        fontWeight:   "700",
        fontFamily:   "Arial, sans-serif",
      }}
    >
      {n}
    </span>
  );
}
