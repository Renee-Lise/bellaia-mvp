"use client";

import { useEffect, useState, useCallback } from "react";
import { AutomationCard }        from "@/components/automations/AutomationCard";
import { AutomationBuilder }     from "@/components/automations/AutomationBuilder";
import { ValidationModal }       from "@/components/validation/ValidationModal";
import { useValidation }         from "@/hooks/useValidation";
import type { AutomationDef }    from "@/components/automations/AutomationCard";
import type { AutomationConfig } from "@/components/automations/AutomationBuilder";

export default function AutomatisationsPage() {
  const [automations, setAutomations] = useState<AutomationDef[]>([]);
  const [loading,     setLoading]     = useState(true);
  const [running,     setRunning]     = useState<string | null>(null);
  const [runResult,   setRunResult]   = useState<{ workflow: string; message: string } | null>(null);
  const [showBuilder, setShowBuilder] = useState(false);
  const [buildLoading, setBuildLoading] = useState(false);
  const [buildError,  setBuildError]  = useState<string | null>(null);

  const validation = useValidation();

  const fetchAutomations = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/automations");
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = await res.json();
      setAutomations(data.automations ?? []);
    } catch {
      // Silencieux — utiliser les workflows par défaut
      setAutomations([]);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { fetchAutomations(); }, [fetchAutomations]);

  const handleRun = (id: string) => {
    const auto = automations.find((a) => a.id === id);
    if (!auto) return;

    validation.request({
      action:    "bellaia_tool_called",
      entite:    "bellaia",
      entite_id: id,
      titre:     `Exécuter — ${auto.nom}`,
      resume:    auto.description,
      impact:    auto.requiert_validation
        ? "Ce workflow va préparer des actions. Bellaïa ne valide rien automatiquement."
        : "Ce workflow exécute des opérations de maintenance non critiques.",
      onConfirm: async () => {
        setRunning(id);
        setRunResult(null);
        try {
          const res = await fetch("/api/automations?action=run", {
            method: "POST", headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ workflow: id }),
          });
          const data = await res.json();
          if (!res.ok) throw new Error(data.error ?? `HTTP ${res.status}`);
          setRunResult({ workflow: auto.nom, message: data.result?.message ?? "Workflow exécuté." });
          await fetchAutomations();
        } finally {
          setRunning(null);
        }
      },
    });
  };

  const handleCreateAutomation = async (config: AutomationConfig) => {
    setBuildLoading(true); setBuildError(null);
    try {
      const res = await fetch("/api/automations", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify(config),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? `HTTP ${res.status}`);
      setShowBuilder(false);
      await fetchAutomations();
    } catch (err) {
      setBuildError(err instanceof Error ? err.message : "Erreur création.");
    } finally {
      setBuildLoading(false);
    }
  };

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: "18px" }}>

      {/* En-tête */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", flexWrap: "wrap", gap: "10px" }}>
        <div>
          <h2 style={{ fontSize: "20px", fontWeight: "700", color: "#F0E8D8", fontFamily: "Georgia, serif" }}>Automatisations</h2>
          <p style={{ fontSize: "11px", color: "rgba(201,168,76,0.55)", marginTop: "2px", fontFamily: "Arial, sans-serif" }}>
            Moteur d&apos;automatisation Bellaïa — {automations.length} workflow{automations.length !== 1 ? "s" : ""} disponible{automations.length !== 1 ? "s" : ""}
          </p>
        </div>
        <button type="button" onClick={() => setShowBuilder(!showBuilder)}
          style={{ padding: "7px 16px", borderRadius: "8px", fontSize: "12px", fontWeight: "700", cursor: "pointer", fontFamily: "Georgia, serif",
            background: showBuilder ? "rgba(244,67,54,0.10)" : "linear-gradient(135deg, rgba(201,168,76,0.20), rgba(92,45,92,0.20))",
            border: `1px solid ${showBuilder ? "rgba(244,67,54,0.30)" : "rgba(201,168,76,0.35)"}`,
            color: showBuilder ? "#F44336" : "#C9A84C" }}>
          {showBuilder ? "✕ Annuler" : "+ Créer automatisation"}
        </button>
      </div>

      {/* Règle gouvernance */}
      <div style={{ padding: "12px 16px", background: "rgba(92,45,92,0.08)", border: "1px solid rgba(92,45,92,0.22)", borderRadius: "10px" }}>
        <p style={{ fontSize: "11px", color: "rgba(200,160,220,0.75)", fontStyle: "italic", fontFamily: "Arial, sans-serif" }}>
          ✦ <strong>Bellaïa prépare. Renée-Lise décide.</strong> Aucune automatisation ne valide un paiement, n&apos;envoie un message, ne modifie un statut financier sans votre confirmation explicite.
        </p>
      </div>

      {/* Résultat dernière exécution */}
      {runResult && (
        <div style={{ padding: "12px 16px", background: "rgba(76,175,80,0.09)", border: "1px solid rgba(76,175,80,0.22)", borderRadius: "10px", display: "flex", justifyContent: "space-between", alignItems: "center", gap: "10px" }}>
          <div>
            <p style={{ fontSize: "12px", fontWeight: "600", color: "#4CAF50", fontFamily: "Arial, sans-serif" }}>✓ {runResult.workflow}</p>
            <p style={{ fontSize: "11px", color: "rgba(240,232,216,0.60)", marginTop: "3px", fontFamily: "Arial, sans-serif" }}>{runResult.message}</p>
          </div>
          <button type="button" onClick={() => setRunResult(null)} style={{ background: "none", border: "none", color: "rgba(240,232,216,0.40)", cursor: "pointer", fontSize: "16px" }}>✕</button>
        </div>
      )}

      {/* Builder */}
      {showBuilder && (
        <div style={{ background: "#120A10", border: "1px solid rgba(201,168,76,0.20)", borderRadius: "12px", padding: "20px" }}>
          <p style={{ fontSize: "9px", color: "#C9A84C", letterSpacing: "0.20em", textTransform: "uppercase", fontWeight: "700", marginBottom: "16px", fontFamily: "Arial, sans-serif" }}>
            ▲ Créer une automatisation personnalisée
          </p>
          <AutomationBuilder onSave={handleCreateAutomation} onCancel={() => setShowBuilder(false)} loading={buildLoading} error={buildError} />
        </div>
      )}

      {/* Grille workflows */}
      {loading ? (
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(320px, 1fr))", gap: "12px" }}>
          {[0,1,2,3,4].map((i) => <div key={i} style={{ height: "220px", background: "rgba(255,255,255,0.04)", borderRadius: "12px", animation: "bellaia-pulse 1.4s ease-in-out infinite", animationDelay: `${i*0.1}s` }} />)}
        </div>
      ) : (
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(320px, 1fr))", gap: "12px" }}>
          {automations.map((a) => (
            <AutomationCard
              key={a.id}
              automation={a}
              onRun={handleRun}
              running={running === a.id}
            />
          ))}
        </div>
      )}

      <ValidationModal validation={validation} />
    </div>
  );
}
