"use client";

import { useEffect, useState, useCallback } from "react";
import { useParams, useRouter }              from "next/navigation";
import { StatutBadge }                       from "@/components/commandes/StatutBadge";
import { StatutSelector }                    from "@/components/commandes/StatutSelector";
import { ValidationModal }                   from "@/components/validation/ValidationModal";
import { useValidation }                     from "@/hooks/useValidation";
import type { StatutCommande }               from "@/constants/statuts";

/**
 * app/(fondatrice)/commandes/[id]/page.tsx
 *
 * Fiche détaillée d'une commande.
 * - Informations commande + articles
 * - Changement de statut via StatutSelector (avec ValidationModal)
 * - Gestion du lien Revolut manuel
 * - Historique des changements de statut
 * - Liste des paiements liés
 * - Notes admin modifiables
 */

// ── Types ─────────────────────────────────────────────────────────────────────

interface Article {
  nom:           string;
  description?:  string;
  quantite:      number;
  prix_unitaire: number;
  taille?:       string;
  couleur?:      string;
}

interface HistoriqueItem {
  id:             string;
  ancien_statut:  string | null;
  nouveau_statut: string;
  commentaire:    string;
  fait_par:       string | null;
  created_at:     string;
}

interface PaiementItem {
  id:              string;
  montant:         number;
  type_paiement:   string;
  mode:            string;
  statut:          string;
  lien_revolut:    string | null;
  date_envoi_lien: string | null;
  date_reception:  string | null;
  notes:           string;
  created_at:      string;
}

interface Cliente {
  id:             string;
  nom:            string;
  email:          string;
  telephone:      string;
  statut_crm:     string;
  score_fidelite: number;
  univers:        string[];
}

interface CommandeDetail {
  id:               string;
  cliente_id:       string | null;
  cliente_nom:      string;
  branche:          string;
  articles:         Article[];
  total:            number;
  acompte_attendu:  number;
  acompte_paye:     number;
  statut:           StatutCommande;
  lien_revolut:     string | null;
  discretion_colis: boolean;
  adresse_livraison: Record<string, string>;
  notes_cliente:    string;
  notes_admin:      string;
  created_at:       string;
  updated_at:       string;
}

interface CommandeDetailResponse {
  commande:   CommandeDetail;
  historique: HistoriqueItem[];
  paiements:  PaiementItem[];
  cliente:    Cliente | null;
}

// ── Helpers ───────────────────────────────────────────────────────────────────

function formatEur(n: number) {
  return new Intl.NumberFormat("fr-FR", { style: "currency", currency: "EUR" }).format(n);
}

function formatDatetime(iso: string) {
  return new Date(iso).toLocaleString("fr-FR", {
    day: "numeric", month: "short", year: "numeric",
    hour: "2-digit", minute: "2-digit",
  });
}

function formatDate(iso: string) {
  return new Date(iso).toLocaleDateString("fr-FR", { day: "numeric", month: "long", year: "numeric" });
}

// ── Composant ─────────────────────────────────────────────────────────────────

export default function CommandeDetailPage() {
  const params   = useParams();
  const router   = useRouter();
  const id       = params.id as string;

  const [detail,        setDetail]        = useState<CommandeDetailResponse | null>(null);
  const [loading,       setLoading]       = useState(true);
  const [error,         setError]         = useState<string | null>(null);
  const [notesAdmin,    setNotesAdmin]    = useState("");
  const [lienRevolut,   setLienRevolut]   = useState("");
  const [savingNotes,   setSavingNotes]   = useState(false);
  const [savingLien,    setSavingLien]    = useState(false);
  const [saveMsg,       setSaveMsg]       = useState<string | null>(null);

  const validation = useValidation();

  // ── Chargement ────────────────────────────────────────────────────────────
  const fetchDetail = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch(`/api/commandes/${id}`);
      if (res.status === 404) { router.push("/commandes"); return; }
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data: CommandeDetailResponse = await res.json();
      setDetail(data);
      setNotesAdmin(data.commande.notes_admin ?? "");
      setLienRevolut(data.commande.lien_revolut ?? "");
    } catch (e) {
      setError("Impossible de charger la commande.");
      console.error(e);
    } finally {
      setLoading(false);
    }
  }, [id, router]);

  useEffect(() => { fetchDetail(); }, [fetchDetail]);

  // ── Sauvegarder les notes ─────────────────────────────────────────────────
  const saveNotes = async () => {
    setSavingNotes(true);
    setSaveMsg(null);
    try {
      const res = await fetch(`/api/commandes/${id}`, {
        method:  "PUT",
        headers: { "Content-Type": "application/json" },
        body:    JSON.stringify({ notes_admin: notesAdmin }),
      });
      if (!res.ok) throw new Error();
      setSaveMsg("Notes sauvegardées.");
      setTimeout(() => setSaveMsg(null), 2000);
    } catch {
      setSaveMsg("Erreur lors de la sauvegarde.");
    } finally {
      setSavingNotes(false);
    }
  };

  // ── Enregistrer le lien Revolut ───────────────────────────────────────────
  const handleSaveLienRevolut = () => {
    if (!lienRevolut.trim()) return;
    validation.request({
      action:    "commande_revolut_link_set",
      entite:    "commandes",
      entite_id: id,
      titre:     "Enregistrer le lien Revolut",
      resume:    `Commande de ${detail?.commande.cliente_nom} — lien de paiement Revolut.`,
      impact:    "Ce lien sera associé à la commande. Envoi au client à faire manuellement (WhatsApp ou email).",
      onConfirm: async () => {
        setSavingLien(true);
        const res = await fetch(`/api/commandes/${id}`, {
          method:  "PUT",
          headers: { "Content-Type": "application/json" },
          body:    JSON.stringify({ lien_revolut: lienRevolut.trim() }),
        });
        setSavingLien(false);
        if (!res.ok) throw new Error("Erreur lors de la sauvegarde du lien.");
        setSaveMsg("Lien Revolut enregistré.");
        setTimeout(() => setSaveMsg(null), 2500);
        await fetchDetail();
      },
    });
  };

  // ── Statut mis à jour ─────────────────────────────────────────────────────
  const handleStatutUpdate = (newStatut: StatutCommande) => {
    if (detail) {
      setDetail((prev) =>
        prev ? { ...prev, commande: { ...prev.commande, statut: newStatut } } : prev
      );
      fetchDetail(); // Recharger pour avoir l'historique à jour
    }
  };

  // ─────────────────────────────────────────────────────────────────────────
  if (loading) return <CommandeDetailSkeleton />;
  if (error || !detail) {
    return (
      <div style={{ padding: "40px", textAlign: "center" }}>
        <p style={{ color: "#F44336", fontSize: "14px", fontFamily: "Arial, sans-serif" }}>
          {error ?? "Commande introuvable."}
        </p>
      </div>
    );
  }

  const { commande, historique, paiements, cliente } = detail;
  const solde = commande.total - commande.acompte_paye;

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: "18px" }}>

      {/* ── Retour + titre ─────────────────────────────────────────────────── */}
      <div style={{ display: "flex", alignItems: "center", gap: "14px" }}>
        <button
          type="button"
          onClick={() => router.push("/commandes")}
          style={{ fontSize: "12px", color: "rgba(201,168,76,0.60)", background: "none", border: "none", cursor: "pointer", fontFamily: "Georgia, serif" }}
        >
          ← Commandes
        </button>
        <StatutBadge statut={commande.statut} size="md" withDot />
        {commande.discretion_colis && (
          <span style={{ fontSize: "10px", padding: "2px 9px", borderRadius: "20px", background: "rgba(155,107,158,0.12)", border: "1px solid rgba(155,107,158,0.28)", color: "#9B6B9E", fontFamily: "Arial, sans-serif" }}>
            🔒 Colis discret
          </span>
        )}
      </div>

      {/* ── Grille principale ────────────────────────────────────────────────── */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "14px", alignItems: "start" }}>

        {/* Colonne gauche */}
        <div style={{ display: "flex", flexDirection: "column", gap: "14px" }}>

          {/* Infos commande */}
          <Section titre="Informations commande">
            <Row label="Cliente"     value={commande.cliente_nom} />
            <Row label="Branche"     value={commande.branche} />
            <Row label="Créée le"    value={formatDate(commande.created_at)} />
            <Row label="Mise à jour" value={formatDatetime(commande.updated_at)} />
            <Row label="Total"       value={formatEur(commande.total)} highlight />
            {commande.acompte_attendu > 0 && (
              <Row label="Acompte attendu" value={formatEur(commande.acompte_attendu)} />
            )}
            {commande.acompte_paye > 0 && (
              <Row label="Acompte reçu" value={formatEur(commande.acompte_paye)} color="#4CAF50" />
            )}
            {solde > 0 && commande.acompte_paye > 0 && (
              <Row label="Solde restant" value={formatEur(solde)} color="#FF9800" />
            )}
          </Section>

          {/* Articles */}
          <Section titre="Articles">
            {commande.articles.map((art, i) => (
              <div
                key={i}
                style={{ padding: "10px 0", borderBottom: i < commande.articles.length - 1 ? "1px solid rgba(255,255,255,0.05)" : "none" }}
              >
                <div style={{ display: "flex", justifyContent: "space-between", gap: "8px" }}>
                  <div style={{ flex: 1 }}>
                    <p style={{ fontSize: "13px", color: "#F0E8D8", fontWeight: "500", fontFamily: "Arial, sans-serif" }}>
                      {art.nom}
                    </p>
                    {art.description && (
                      <p style={{ fontSize: "11px", color: "rgba(240,232,216,0.45)", marginTop: "2px", fontFamily: "Arial, sans-serif" }}>
                        {art.description}
                      </p>
                    )}
                    <div style={{ display: "flex", gap: "8px", marginTop: "5px", flexWrap: "wrap" }}>
                      <span style={{ fontSize: "10px", color: "rgba(240,232,216,0.45)", fontFamily: "Arial, sans-serif" }}>
                        Qté : {art.quantite}
                      </span>
                      {art.taille && (
                        <span style={{ fontSize: "10px", padding: "1px 7px", borderRadius: "10px", background: "rgba(201,168,76,0.08)", color: "#C9A84C", fontFamily: "Arial, sans-serif" }}>
                          {art.taille}
                        </span>
                      )}
                      {art.couleur && (
                        <span style={{ fontSize: "10px", padding: "1px 7px", borderRadius: "10px", background: "rgba(232,164,184,0.08)", color: "#E8A4B8", fontFamily: "Arial, sans-serif" }}>
                          {art.couleur}
                        </span>
                      )}
                    </div>
                  </div>
                  <p style={{ fontSize: "14px", fontWeight: "700", color: "#C9A84C", flexShrink: 0, fontFamily: "Arial, sans-serif" }}>
                    {formatEur(art.quantite * art.prix_unitaire)}
                  </p>
                </div>
              </div>
            ))}
            <div style={{ display: "flex", justifyContent: "flex-end", paddingTop: "10px", borderTop: "1px solid rgba(201,168,76,0.15)" }}>
              <p style={{ fontSize: "15px", fontWeight: "700", color: "#C9A84C", fontFamily: "Arial, sans-serif" }}>
                Total : {formatEur(commande.total)}
              </p>
            </div>
          </Section>

          {/* Notes cliente */}
          {commande.notes_cliente && (
            <Section titre="Note de la cliente">
              <p style={{ fontSize: "12px", color: "rgba(240,232,216,0.70)", lineHeight: "1.6", fontFamily: "Arial, sans-serif", fontStyle: "italic" }}>
                &ldquo;{commande.notes_cliente}&rdquo;
              </p>
            </Section>
          )}

          {/* Profil cliente */}
          {cliente && (
            <Section titre="Profil cliente">
              <Row label="Email"     value={cliente.email || "—"} />
              <Row label="Tél."      value={cliente.telephone || "—"} />
              <Row label="Statut CRM" value={cliente.statut_crm} />
              <Row label="Score fidélité" value={`${cliente.score_fidelite}/100`} />
            </Section>
          )}
        </div>

        {/* Colonne droite */}
        <div style={{ display: "flex", flexDirection: "column", gap: "14px" }}>

          {/* Changement de statut */}
          <Section titre="Gestion du statut">
            <StatutSelector
              commandeId={id}
              statutActuel={commande.statut}
              clienteNom={commande.cliente_nom}
              total={commande.total}
              onUpdate={handleStatutUpdate}
            />
          </Section>

          {/* Revolut */}
          <Section titre="Paiement Revolut manuel">
            <p style={{ fontSize: "10px", color: "rgba(240,232,216,0.40)", marginBottom: "10px", fontFamily: "Arial, sans-serif", fontStyle: "italic" }}>
              Envoi manuel uniquement. Aucun paiement automatique. Validation fondatrice obligatoire.
            </p>
            <div style={{ display: "flex", gap: "8px" }}>
              <input
                type="url"
                value={lienRevolut}
                onChange={(e) => setLienRevolut(e.target.value)}
                placeholder="https://revolut.me/..."
                style={{ flex: 1, padding: "8px 12px", borderRadius: "8px", background: "rgba(255,255,255,0.04)", border: "1px solid rgba(201,168,76,0.18)", color: "#F0E8D8", fontSize: "12px", outline: "none", fontFamily: "Arial, sans-serif" }}
              />
              <button
                type="button"
                onClick={handleSaveLienRevolut}
                disabled={!lienRevolut.trim() || savingLien}
                style={{ padding: "8px 14px", borderRadius: "8px", background: lienRevolut.trim() ? "rgba(201,168,76,0.15)" : "rgba(255,255,255,0.03)", border: "1px solid rgba(201,168,76,0.25)", color: lienRevolut.trim() ? "#C9A84C" : "rgba(240,232,216,0.25)", cursor: lienRevolut.trim() ? "pointer" : "not-allowed", fontSize: "11px", fontFamily: "Georgia, serif" }}
              >
                🔒 Enregistrer
              </button>
            </div>
            {commande.lien_revolut && (
              <a
                href={commande.lien_revolut}
                target="_blank"
                rel="noopener noreferrer"
                style={{ display: "inline-block", marginTop: "8px", fontSize: "11px", color: "rgba(201,168,76,0.65)", fontFamily: "Arial, sans-serif" }}
              >
                ↗ Lien actuel : {commande.lien_revolut.slice(0, 40)}…
              </a>
            )}
          </Section>

          {/* Notes admin */}
          <Section titre="Notes internes">
            <textarea
              value={notesAdmin}
              onChange={(e) => setNotesAdmin(e.target.value)}
              rows={4}
              placeholder="Notes internes sur cette commande…"
              style={{ width: "100%", padding: "10px 12px", borderRadius: "8px", background: "rgba(255,255,255,0.04)", border: "1px solid rgba(201,168,76,0.16)", color: "#F0E8D8", fontSize: "12px", resize: "vertical", outline: "none", fontFamily: "Arial, sans-serif", lineHeight: "1.5" }}
            />
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: "8px" }}>
              {saveMsg && (
                <p style={{ fontSize: "11px", color: saveMsg.includes("Erreur") ? "#F44336" : "#4CAF50", fontFamily: "Arial, sans-serif" }}>
                  {saveMsg}
                </p>
              )}
              <button
                type="button"
                onClick={saveNotes}
                disabled={savingNotes}
                style={{ marginLeft: "auto", padding: "6px 16px", borderRadius: "8px", background: "rgba(201,168,76,0.10)", border: "1px solid rgba(201,168,76,0.22)", color: "#C9A84C", cursor: savingNotes ? "not-allowed" : "pointer", fontSize: "11px", fontFamily: "Georgia, serif" }}
              >
                {savingNotes ? "Sauvegarde…" : "Sauvegarder"}
              </button>
            </div>
          </Section>

          {/* Historique */}
          {historique.length > 0 && (
            <Section titre="Historique des statuts">
              <div style={{ display: "flex", flexDirection: "column", gap: "6px" }}>
                {historique.map((h) => (
                  <div
                    key={h.id}
                    style={{ display: "flex", alignItems: "flex-start", gap: "10px", padding: "8px 10px", borderRadius: "7px", background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.06)" }}
                  >
                    <div style={{ width: "6px", height: "6px", borderRadius: "50%", background: "#C9A84C", marginTop: "5px", flexShrink: 0 }} />
                    <div style={{ flex: 1 }}>
                      <p style={{ fontSize: "11px", color: "rgba(240,232,216,0.75)", fontFamily: "Arial, sans-serif" }}>
                        {h.ancien_statut
                          ? `${h.ancien_statut}  →  ${h.nouveau_statut}`
                          : `Créée → ${h.nouveau_statut}`}
                      </p>
                      {h.commentaire && (
                        <p style={{ fontSize: "10px", color: "rgba(240,232,216,0.40)", marginTop: "2px", fontStyle: "italic", fontFamily: "Arial, sans-serif" }}>
                          {h.commentaire}
                        </p>
                      )}
                    </div>
                    <p style={{ fontSize: "9px", color: "rgba(240,232,216,0.28)", flexShrink: 0, fontFamily: "Arial, sans-serif" }}>
                      {formatDatetime(h.created_at)}
                    </p>
                  </div>
                ))}
              </div>
            </Section>
          )}

          {/* Paiements */}
          {paiements.length > 0 && (
            <Section titre="Paiements enregistrés">
              {paiements.map((p) => (
                <div
                  key={p.id}
                  style={{ padding: "10px 0", borderBottom: "1px solid rgba(255,255,255,0.05)" }}
                >
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                    <div>
                      <p style={{ fontSize: "12px", color: "#F0E8D8", fontWeight: "500", fontFamily: "Arial, sans-serif" }}>
                        {formatEur(p.montant)} — {p.type_paiement}
                      </p>
                      <p style={{ fontSize: "10px", color: "rgba(240,232,216,0.40)", marginTop: "2px", fontFamily: "Arial, sans-serif" }}>
                        {p.mode} · {formatDatetime(p.created_at)}
                      </p>
                    </div>
                    <span style={{
                      fontSize: "10px", padding: "2px 8px", borderRadius: "10px",
                      background: p.statut === "recu" ? "rgba(76,175,80,0.12)" : "rgba(255,152,0,0.12)",
                      color:      p.statut === "recu" ? "#4CAF50" : "#FF9800",
                      border:     `1px solid ${p.statut === "recu" ? "rgba(76,175,80,0.28)" : "rgba(255,152,0,0.28)"}`,
                      fontFamily: "Arial, sans-serif",
                    }}>
                      {p.statut === "recu" ? "Reçu" : "En attente"}
                    </span>
                  </div>
                </div>
              ))}
            </Section>
          )}
        </div>
      </div>

      {/* ValidationModal partagée pour le lien Revolut */}
      <ValidationModal validation={validation} />
    </div>
  );
}

// ── Sous-composants ───────────────────────────────────────────────────────────

function Section({ titre, children }: { titre: string; children: React.ReactNode }) {
  return (
    <div style={{ background: "#120A10", border: "1px solid rgba(201,168,76,0.14)", borderRadius: "12px", padding: "16px 18px" }}>
      <p style={{ fontSize: "9px", color: "#C9A84C", letterSpacing: "0.18em", textTransform: "uppercase", fontWeight: "700", marginBottom: "14px", fontFamily: "Arial, sans-serif" }}>
        {titre}
      </p>
      {children}
    </div>
  );
}

function Row({ label, value, highlight = false, color }: { label: string; value: string; highlight?: boolean; color?: string }) {
  return (
    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "6px 0", borderBottom: "1px solid rgba(255,255,255,0.04)" }}>
      <p style={{ fontSize: "11px", color: "rgba(240,232,216,0.45)", fontFamily: "Arial, sans-serif" }}>{label}</p>
      <p style={{ fontSize: highlight ? "14px" : "12px", fontWeight: highlight ? "700" : "500", color: color ?? (highlight ? "#C9A84C" : "#F0E8D8"), fontFamily: "Arial, sans-serif" }}>
        {value}
      </p>
    </div>
  );
}

function CommandeDetailSkeleton() {
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: "18px" }}>
      {[0, 1, 2].map((i) => (
        <div key={i} style={{ height: i === 0 ? "32px" : "200px", background: "rgba(255,255,255,0.04)", borderRadius: "12px", animation: "bellaia-pulse 1.4s ease-in-out infinite", animationDelay: `${i * 0.1}s` }} />
      ))}
    </div>
  );
}
