"use client";

import { useEffect, useState, useCallback } from "react";
import Link                                  from "next/link";
import { StatutBadge }                       from "@/components/commandes/StatutBadge";
import { STATUTS_COMMANDE }                  from "@/constants/statuts";
import type { StatutCommande }               from "@/constants/statuts";

/**
 * app/(fondatrice)/commandes/page.tsx
 *
 * Liste de toutes les commandes avec filtres, tri et statuts colorés.
 */

// ── Types ─────────────────────────────────────────────────────────────────────

interface CommandeRow {
  id:          string;
  cliente_nom: string;
  branche:     string;
  total:       number;
  acompte_paye: number;
  statut:      StatutCommande;
  created_at:  string;
  updated_at:  string;
}

interface CommandesResponse {
  commandes: CommandeRow[];
  total:     number;
}

// ── Helpers ───────────────────────────────────────────────────────────────────

function formatEur(n: number) {
  return new Intl.NumberFormat("fr-FR", { style: "currency", currency: "EUR", minimumFractionDigits: 0 }).format(n);
}

function formatDate(iso: string) {
  return new Date(iso).toLocaleDateString("fr-FR", { day: "numeric", month: "short", year: "numeric" });
}

const BRANCHE_LABELS: Record<string, string> = {
  secret_home: "Secret Home",
  odyssee:     "Odyssée",
  food:        "Food",
  events:      "Events",
  academy:     "Academy",
  structure:   "Structure",
};

// ── Composant ─────────────────────────────────────────────────────────────────

export default function CommandesPage() {
  const [data,           setData]           = useState<CommandesResponse | null>(null);
  const [loading,        setLoading]        = useState(true);
  const [error,          setError]          = useState<string | null>(null);
  const [filtreStatut,   setFiltreStatut]   = useState<StatutCommande | "">("");
  const [filtreBranche,  setFiltreBranche]  = useState("");
  const [searchTerm,     setSearchTerm]     = useState("");
  const [searchDebounced, setSearchDebounced] = useState("");

  // Debounce de la recherche
  useEffect(() => {
    const t = setTimeout(() => setSearchDebounced(searchTerm), 350);
    return () => clearTimeout(t);
  }, [searchTerm]);

  const fetchCommandes = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const params = new URLSearchParams({ limit: "100" });
      if (filtreStatut)  params.set("statut",  filtreStatut);
      if (filtreBranche) params.set("branche", filtreBranche);

      const res = await fetch(`/api/commandes?${params}`);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      setData(await res.json());
    } catch (e) {
      setError("Impossible de charger les commandes.");
      console.error(e);
    } finally {
      setLoading(false);
    }
  }, [filtreStatut, filtreBranche]);

  useEffect(() => { fetchCommandes(); }, [fetchCommandes]);

  // Filtrage client par recherche textuelle
  const commandes = (data?.commandes ?? []).filter((c) => {
    if (!searchDebounced) return true;
    const q = searchDebounced.toLowerCase();
    return (
      c.cliente_nom.toLowerCase().includes(q) ||
      c.id.toLowerCase().includes(q)
    );
  });

  const urgentes = commandes.filter((c) => c.statut === "demande_recue");

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: "18px" }}>

      {/* ── En-tête ─────────────────────────────────────────────────────────── */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", flexWrap: "wrap", gap: "10px" }}>
        <div>
          <h2 style={{ fontSize: "20px", fontWeight: "700", color: "#F0E8D8", fontFamily: "Georgia, serif" }}>
            Commandes
          </h2>
          <p style={{ fontSize: "11px", color: "rgba(201,168,76,0.55)", marginTop: "2px", fontFamily: "Arial, sans-serif" }}>
            {loading ? "Chargement…" : `${data?.total ?? 0} commande${(data?.total ?? 0) !== 1 ? "s" : ""} au total`}
          </p>
        </div>
        <button
          type="button"
          onClick={fetchCommandes}
          disabled={loading}
          style={{ fontSize: "11px", padding: "5px 14px", borderRadius: "20px", background: "rgba(201,168,76,0.08)", border: "1px solid rgba(201,168,76,0.20)", color: "rgba(201,168,76,0.65)", cursor: loading ? "not-allowed" : "pointer", fontFamily: "Georgia, serif" }}
        >
          {loading ? "⟳" : "⟳ Actualiser"}
        </button>
      </div>

      {/* ── Alertes urgentes ─────────────────────────────────────────────────── */}
      {urgentes.length > 0 && (
        <div style={{ padding: "12px 16px", background: "rgba(244,67,54,0.07)", border: "1px solid rgba(244,67,54,0.22)", borderRadius: "10px", display: "flex", alignItems: "center", gap: "10px" }}>
          <span style={{ fontSize: "14px" }}>🔴</span>
          <p style={{ fontSize: "12px", color: "rgba(244,67,54,0.85)", fontFamily: "Arial, sans-serif" }}>
            <strong>{urgentes.length} commande{urgentes.length > 1 ? "s" : ""}</strong> en attente de votre validation.
          </p>
        </div>
      )}

      {/* ── Filtres ──────────────────────────────────────────────────────────── */}
      <div style={{ display: "flex", gap: "10px", flexWrap: "wrap", alignItems: "center" }}>
        {/* Recherche */}
        <input
          type="text"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          placeholder="Rechercher cliente, ID…"
          style={{ padding: "7px 12px", borderRadius: "8px", background: "rgba(255,255,255,0.04)", border: "1px solid rgba(201,168,76,0.18)", color: "#F0E8D8", fontSize: "12px", outline: "none", minWidth: "200px", fontFamily: "Arial, sans-serif" }}
        />

        {/* Filtre statut */}
        <select
          value={filtreStatut}
          onChange={(e) => setFiltreStatut(e.target.value as StatutCommande | "")}
          style={{ padding: "7px 12px", borderRadius: "8px", background: "#120A10", border: "1px solid rgba(201,168,76,0.18)", color: filtreStatut ? "#C9A84C" : "rgba(240,232,216,0.50)", fontSize: "12px", outline: "none", cursor: "pointer", fontFamily: "Arial, sans-serif" }}
        >
          <option value="">Tous les statuts</option>
          {STATUTS_COMMANDE.map((s) => (
            <option key={s.key} value={s.key}>{s.label}</option>
          ))}
        </select>

        {/* Filtre branche */}
        <select
          value={filtreBranche}
          onChange={(e) => setFiltreBranche(e.target.value)}
          style={{ padding: "7px 12px", borderRadius: "8px", background: "#120A10", border: "1px solid rgba(201,168,76,0.18)", color: filtreBranche ? "#C9A84C" : "rgba(240,232,216,0.50)", fontSize: "12px", outline: "none", cursor: "pointer", fontFamily: "Arial, sans-serif" }}
        >
          <option value="">Toutes les branches</option>
          {Object.entries(BRANCHE_LABELS).map(([k, v]) => (
            <option key={k} value={k}>{v}</option>
          ))}
        </select>

        {/* Reset filtres */}
        {(filtreStatut || filtreBranche || searchTerm) && (
          <button
            type="button"
            onClick={() => { setFiltreStatut(""); setFiltreBranche(""); setSearchTerm(""); }}
            style={{ fontSize: "11px", padding: "5px 12px", borderRadius: "20px", background: "transparent", border: "1px solid rgba(255,255,255,0.10)", color: "rgba(240,232,216,0.45)", cursor: "pointer", fontFamily: "Arial, sans-serif" }}
          >
            ✕ Réinitialiser
          </button>
        )}
      </div>

      {/* ── Erreur ───────────────────────────────────────────────────────────── */}
      {error && (
        <div style={{ padding: "12px 16px", background: "rgba(244,67,54,0.09)", border: "1px solid rgba(244,67,54,0.22)", borderRadius: "10px", color: "#F44336", fontSize: "13px", fontFamily: "Arial, sans-serif" }}>
          {error}
        </div>
      )}

      {/* ── Table ────────────────────────────────────────────────────────────── */}
      <div style={{ background: "#120A10", border: "1px solid rgba(201,168,76,0.14)", borderRadius: "12px", overflow: "hidden" }}>

        {/* Header table */}
        <div
          style={{
            display:             "grid",
            gridTemplateColumns: "1fr 1.2fr 100px 110px 120px 80px",
            gap:                 "8px",
            padding:             "10px 16px",
            borderBottom:        "1px solid rgba(201,168,76,0.10)",
          }}
        >
          {["Cliente", "Branche", "Total", "Acompte", "Statut", "Date"].map((h) => (
            <p
              key={h}
              style={{ fontSize: "9px", color: "rgba(201,168,76,0.50)", letterSpacing: "0.14em", textTransform: "uppercase", fontFamily: "Arial, sans-serif" }}
            >
              {h}
            </p>
          ))}
        </div>

        {/* Lignes */}
        {loading ? (
          <div style={{ padding: "20px 16px", display: "flex", flexDirection: "column", gap: "10px" }}>
            {[0, 1, 2, 3, 4].map((i) => (
              <div key={i} style={{ height: "42px", background: "rgba(255,255,255,0.04)", borderRadius: "8px", animation: "bellaia-pulse 1.4s ease-in-out infinite", animationDelay: `${i * 0.1}s` }} />
            ))}
          </div>
        ) : commandes.length === 0 ? (
          <div style={{ padding: "40px", textAlign: "center" }}>
            <p style={{ fontSize: "18px", marginBottom: "8px" }}>◆</p>
            <p style={{ fontSize: "13px", color: "rgba(240,232,216,0.35)", fontFamily: "Arial, sans-serif" }}>
              {filtreStatut || filtreBranche || searchTerm ? "Aucune commande ne correspond aux filtres." : "Aucune commande active."}
            </p>
          </div>
        ) : (
          commandes.map((cmd, i) => {
            const solde = cmd.total - cmd.acompte_paye;
            return (
              <Link
                key={cmd.id}
                href={`/commandes/${cmd.id}`}
                style={{
                  display:             "grid",
                  gridTemplateColumns: "1fr 1.2fr 100px 110px 120px 80px",
                  gap:                 "8px",
                  padding:             "13px 16px",
                  borderBottom:        i < commandes.length - 1 ? "1px solid rgba(255,255,255,0.05)" : "none",
                  textDecoration:      "none",
                  transition:          "background 0.15s",
                  background:          cmd.statut === "demande_recue" ? "rgba(244,67,54,0.04)" : "transparent",
                  alignItems:          "center",
                }}
                onMouseEnter={(e) => {
                  (e.currentTarget as HTMLAnchorElement).style.background = "rgba(255,255,255,0.03)";
                }}
                onMouseLeave={(e) => {
                  (e.currentTarget as HTMLAnchorElement).style.background =
                    cmd.statut === "demande_recue" ? "rgba(244,67,54,0.04)" : "transparent";
                }}
              >
                {/* Cliente */}
                <div style={{ minWidth: 0 }}>
                  <p style={{ fontSize: "13px", color: "#F0E8D8", fontWeight: "500", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", fontFamily: "Arial, sans-serif" }}>
                    {cmd.cliente_nom}
                  </p>
                  <p style={{ fontSize: "10px", color: "rgba(240,232,216,0.35)", fontFamily: "Arial, sans-serif" }}>
                    {cmd.id.slice(0, 8)}…
                  </p>
                </div>

                {/* Branche */}
                <p style={{ fontSize: "11px", color: "rgba(240,232,216,0.55)", fontFamily: "Arial, sans-serif" }}>
                  {BRANCHE_LABELS[cmd.branche] ?? cmd.branche}
                </p>

                {/* Total */}
                <p style={{ fontSize: "13px", fontWeight: "600", color: "#C9A84C", fontFamily: "Arial, sans-serif" }}>
                  {formatEur(cmd.total)}
                </p>

                {/* Acompte / Solde */}
                <div>
                  <p style={{ fontSize: "11px", color: cmd.acompte_paye > 0 ? "#4CAF50" : "rgba(240,232,216,0.35)", fontFamily: "Arial, sans-serif" }}>
                    {cmd.acompte_paye > 0 ? `+${formatEur(cmd.acompte_paye)}` : "—"}
                  </p>
                  {solde > 0 && cmd.acompte_paye > 0 && (
                    <p style={{ fontSize: "10px", color: "#FF9800", fontFamily: "Arial, sans-serif" }}>
                      solde {formatEur(solde)}
                    </p>
                  )}
                </div>

                {/* Statut */}
                <StatutBadge statut={cmd.statut} size="xs" withDot />

                {/* Date */}
                <p style={{ fontSize: "10px", color: "rgba(240,232,216,0.35)", fontFamily: "Arial, sans-serif" }}>
                  {formatDate(cmd.created_at)}
                </p>
              </Link>
            );
          })
        )}
      </div>

      {/* ── Note gouvernance ─────────────────────────────────────────────────── */}
      <p style={{ fontSize: "10px", color: "rgba(220,100,80,0.55)", fontStyle: "italic", fontFamily: "Arial, sans-serif" }}>
        🔒 Tout changement de statut financier nécessite une validation fondatrice explicite.
      </p>
    </div>
  );
}
