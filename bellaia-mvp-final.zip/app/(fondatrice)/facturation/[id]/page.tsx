"use client";

import { useEffect, useState, useCallback } from "react";
import { useParams, useRouter }             from "next/navigation";
import { FactureStatusBadge }  from "@/components/facturation/FactureStatusBadge";
import { ValidationModal }     from "@/components/validation/ValidationModal";
import { useValidation }       from "@/hooks/useValidation";
import type { Facture }        from "@/types/database";

interface Article { description: string; quantite: number; prix_unitaire: number; }
interface FactureDetail { facture: Facture; cliente: { id: string; nom: string; email: string; telephone: string } | null; }

function formatEur(n: number) {
  return new Intl.NumberFormat("fr-FR", { style: "currency", currency: "EUR" }).format(n);
}
function formatDate(iso: string | null) {
  if (!iso) return "—";
  return new Date(iso).toLocaleDateString("fr-FR", { day: "numeric", month: "long", year: "numeric" });
}

function Section({ titre, children }: { titre: string; children: React.ReactNode }) {
  return (
    <div style={{ background: "#120A10", border: "1px solid rgba(201,168,76,0.14)", borderRadius: "12px", padding: "16px 18px" }}>
      <p style={{ fontSize: "9px", color: "#C9A84C", letterSpacing: "0.18em", textTransform: "uppercase", fontWeight: "700", marginBottom: "14px", fontFamily: "Arial, sans-serif" }}>{titre}</p>
      {children}
    </div>
  );
}

function Row({ label, value, highlight = false, color }: { label: string; value: string; highlight?: boolean; color?: string }) {
  return (
    <div style={{ display: "flex", justifyContent: "space-between", padding: "6px 0", borderBottom: "1px solid rgba(255,255,255,0.04)" }}>
      <p style={{ fontSize: "11px", color: "rgba(240,232,216,0.40)", fontFamily: "Arial, sans-serif" }}>{label}</p>
      <p style={{ fontSize: highlight ? "15px" : "12px", fontWeight: highlight ? "700" : "500", color: color ?? (highlight ? "#C9A84C" : "#F0E8D8"), fontFamily: "Arial, sans-serif" }}>{value}</p>
    </div>
  );
}

export default function FactureDetailPage() {
  const params = useParams();
  const router = useRouter();
  const id     = params.id as string;

  const [detail,      setDetail]      = useState<FactureDetail | null>(null);
  const [loading,     setLoading]     = useState(true);
  const [error,       setError]       = useState<string | null>(null);
  const [notes,       setNotes]       = useState("");
  const [acompte,     setAcompte]     = useState("");
  const [saving,      setSaving]      = useState(false);
  const [saveMsg,     setSaveMsg]     = useState<string | null>(null);

  const validation = useValidation();

  const fetchDetail = useCallback(async () => {
    setLoading(true); setError(null);
    try {
      const res = await fetch(`/api/factures/${id}`);
      if (res.status === 404) { router.push("/facturation"); return; }
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data: FactureDetail = await res.json();
      setDetail(data);
      setNotes(data.facture.notes ?? "");
      setAcompte(data.facture.acompte_recu?.toString() ?? "0");
    } catch { setError("Impossible de charger le document."); }
    finally   { setLoading(false); }
  }, [id, router]);

  useEffect(() => { fetchDetail(); }, [fetchDetail]);

  const saveNotes = async () => {
    setSaving(true); setSaveMsg(null);
    try {
      const res = await fetch(`/api/factures/${id}`, { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ notes }) });
      if (!res.ok) throw new Error();
      setSaveMsg("Notes sauvegardées."); setTimeout(() => setSaveMsg(null), 2000);
    } catch { setSaveMsg("Erreur."); }
    finally   { setSaving(false); }
  };

  const handleEmettre = () => {
    if (!detail) return;
    const f = detail.facture;
    validation.request({
      action: "facture_emise", entite: "factures", entite_id: id,
      titre: `Émettre ${f.type} — ${f.client_nom}`,
      resume: `${f.client_nom} · ${formatEur(f.total_ttc)}\nCe document deviendra officiel et recevra un numéro.`,
      impact: "Document émis, numéro attribué, statut → VALIDE. Action irréversible.",
      onConfirm: async () => {
        const res = await fetch(`/api/factures/${id}?action=valider`, { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({}) });
        if (!res.ok) { const j = await res.json().catch(() => ({})); throw new Error(j.error ?? `HTTP ${res.status}`); }
        await fetchDetail();
      },
    });
  };

  const handleAcompte = () => {
    const val = parseFloat(acompte);
    if (isNaN(val) || val < 0) return;
    validation.request({
      action: "paiement_marked_received", entite: "factures", entite_id: id,
      titre: "Enregistrer acompte reçu",
      resume: `Acompte de ${formatEur(val)} enregistré sur ce document.`,
      impact: "Montant acompte mis à jour. Enregistré dans le journal d'audit.",
      onConfirm: async () => {
        const res = await fetch(`/api/factures/${id}`, { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ acompte_recu: val }) });
        if (!res.ok) { const j = await res.json().catch(() => ({})); throw new Error(j.error ?? `HTTP ${res.status}`); }
        await fetchDetail();
      },
    });
  };

  if (loading) return (
    <div style={{ display: "flex", flexDirection: "column", gap: "14px" }}>
      {[0,1,2].map((i) => <div key={i} style={{ height: i===0?36:180, background: "rgba(255,255,255,0.04)", borderRadius: "12px", animation: "bellaia-pulse 1.4s ease-in-out infinite", animationDelay: `${i*0.1}s` }} />)}
    </div>
  );
  if (error || !detail) return <p style={{ color: "#F44336", fontFamily: "Arial, sans-serif" }}>{error ?? "Introuvable."}</p>;

  const { facture, cliente } = detail;
  const articles = (facture.articles ?? []) as Article[];
  const solde    = facture.total_ttc - (facture.acompte_recu ?? 0);
  const estEmis  = facture.statut !== "BROUILLON" && facture.statut !== "EN_REVISION";

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: "16px" }}>

      {/* En-tête */}
      <div style={{ display: "flex", alignItems: "center", gap: "12px", flexWrap: "wrap" }}>
        <button type="button" onClick={() => router.push("/facturation")}
          style={{ background: "none", border: "none", color: "rgba(201,168,76,0.60)", cursor: "pointer", fontSize: "12px", fontFamily: "Georgia, serif" }}>
          ← Facturation
        </button>
        <FactureStatusBadge statut={facture.statut} type={facture.type} size="md" withDot />
        {facture.numero && <span style={{ fontSize: "13px", color: "#C9A84C", fontFamily: "Georgia, serif" }}>{facture.numero}</span>}
        {!estEmis && (
          <button type="button" onClick={handleEmettre}
            style={{ marginLeft: "auto", padding: "7px 18px", borderRadius: "8px", fontWeight: "700", fontSize: "12px", cursor: "pointer", fontFamily: "Georgia, serif",
              background: "linear-gradient(135deg, #C9A84C, #5C2D5C)", border: "none", color: "#0C0810" }}>
            🔒 Émettre officiellement
          </button>
        )}
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "14px", alignItems: "start" }}>

        {/* Colonne gauche */}
        <div style={{ display: "flex", flexDirection: "column", gap: "14px" }}>
          <Section titre="Informations">
            <Row label="Client"        value={facture.client_nom} />
            <Row label="Email"         value={facture.client_email || "—"} />
            <Row label="Branche"       value={facture.branche} />
            <Row label="Créé le"       value={formatDate(facture.created_at)} />
            {facture.emis_le && <Row label="Émis le" value={formatDate(facture.emis_le)} />}
            {facture.validite_date && <Row label="Validité" value={formatDate(facture.validite_date)} />}
            <Row label="Total"         value={formatEur(facture.total_ttc)} highlight />
            {(facture.acompte_recu ?? 0) > 0 && <Row label="Acompte reçu" value={formatEur(facture.acompte_recu!)} color="#4CAF50" />}
            {solde > 0 && (facture.acompte_recu ?? 0) > 0 && <Row label="Solde restant" value={formatEur(solde)} color="#FF9800" />}
          </Section>

          {/* Acompte */}
          <Section titre="Paiement reçu">
            <p style={{ fontSize: "10px", color: "rgba(240,232,216,0.38)", marginBottom: "10px", fontStyle: "italic", fontFamily: "Arial, sans-serif" }}>
              🔒 Validation fondatrice obligatoire pour enregistrer un paiement.
            </p>
            <div style={{ display: "flex", gap: "8px" }}>
              <input type="number" min="0" step="0.01" value={acompte} onChange={(e) => setAcompte(e.target.value)}
                placeholder="Montant reçu (€)"
                style={{ flex: 1, padding: "9px 12px", borderRadius: "8px", background: "rgba(255,255,255,0.04)", border: "1px solid rgba(201,168,76,0.18)", color: "#F0E8D8", fontSize: "13px", outline: "none", fontFamily: "Arial, sans-serif" }} />
              <button type="button" onClick={handleAcompte}
                style={{ padding: "9px 14px", borderRadius: "8px", background: "rgba(201,168,76,0.12)", border: "1px solid rgba(201,168,76,0.28)", color: "#C9A84C", cursor: "pointer", fontSize: "12px", fontFamily: "Georgia, serif" }}>
                🔒 Enregistrer
              </button>
            </div>
          </Section>

          {/* Notes */}
          <Section titre="Notes">
            <textarea value={notes} onChange={(e) => setNotes(e.target.value)} rows={3}
              placeholder="Notes, conditions…"
              style={{ width: "100%", padding: "9px 12px", borderRadius: "8px", background: "rgba(255,255,255,0.04)", border: "1px solid rgba(201,168,76,0.18)", color: "#F0E8D8", fontSize: "12px", resize: "vertical", outline: "none", lineHeight: "1.5", fontFamily: "Arial, sans-serif" }} />
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: "8px" }}>
              {saveMsg && <p style={{ fontSize: "11px", color: saveMsg.includes("Erreur") ? "#F44336" : "#4CAF50", fontFamily: "Arial, sans-serif" }}>{saveMsg}</p>}
              <button type="button" onClick={saveNotes} disabled={saving}
                style={{ marginLeft: "auto", padding: "5px 14px", borderRadius: "8px", background: "rgba(201,168,76,0.10)", border: "1px solid rgba(201,168,76,0.22)", color: "#C9A84C", cursor: saving ? "not-allowed" : "pointer", fontSize: "11px", fontFamily: "Georgia, serif" }}>
                {saving ? "…" : "Sauvegarder"}
              </button>
            </div>
          </Section>
        </div>

        {/* Colonne droite — articles */}
        <Section titre={`Articles (${articles.length})`}>
          {articles.map((art, i) => (
            <div key={i} style={{ padding: "10px 0", borderBottom: i < articles.length - 1 ? "1px solid rgba(255,255,255,0.05)" : "none" }}>
              <div style={{ display: "flex", justifyContent: "space-between", gap: "8px" }}>
                <div style={{ flex: 1 }}>
                  <p style={{ fontSize: "13px", color: "#F0E8D8", fontWeight: "500", fontFamily: "Arial, sans-serif" }}>{art.description}</p>
                  <p style={{ fontSize: "10px", color: "rgba(240,232,216,0.40)", marginTop: "2px", fontFamily: "Arial, sans-serif" }}>
                    {art.quantite} × {formatEur(art.prix_unitaire)}
                  </p>
                </div>
                <p style={{ fontSize: "14px", fontWeight: "700", color: "#C9A84C", flexShrink: 0, fontFamily: "Arial, sans-serif" }}>
                  {formatEur(art.quantite * art.prix_unitaire)}
                </p>
              </div>
            </div>
          ))}
          <div style={{ display: "flex", justifyContent: "flex-end", paddingTop: "12px", borderTop: "1px solid rgba(201,168,76,0.15)" }}>
            <p style={{ fontSize: "18px", fontWeight: "700", color: "#C9A84C", fontFamily: "Arial, sans-serif" }}>
              {formatEur(facture.total_ttc)}
            </p>
          </div>
        </Section>
      </div>

      <ValidationModal validation={validation} />
    </div>
  );
}
