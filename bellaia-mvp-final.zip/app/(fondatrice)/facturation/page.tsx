"use client";

import { useEffect, useState, useCallback } from "react";
import { useRouter }              from "next/navigation";
import { FactureCard }            from "@/components/facturation/FactureCard";
import { FactureStatusBadge }     from "@/components/facturation/FactureStatusBadge";
import { DevisForm }              from "@/components/facturation/DevisForm";
import { ValidationModal }        from "@/components/validation/ValidationModal";
import { useValidation }          from "@/hooks/useValidation";
import { STATUTS_FACTURE }        from "@/constants/statuts";
import type { Facture }           from "@/types/database";
import type { DevisFormData }     from "@/components/facturation/DevisForm";

interface FacturesResponse { factures: Facture[]; total: number; }

const TYPES = [
  { key: "", label: "Tous les types" },
  { key: "devis", label: "Devis" }, { key: "facture", label: "Factures" },
  { key: "avoir", label: "Avoirs" }, { key: "bon_commande", label: "BC" }, { key: "bon_livraison", label: "BL" },
];

export default function FacturationPage() {
  const router = useRouter();
  const [data,         setData]         = useState<FacturesResponse | null>(null);
  const [loading,      setLoading]      = useState(true);
  const [error,        setError]        = useState<string | null>(null);
  const [filtreType,   setFiltreType]   = useState("");
  const [filtreStatut, setFiltreStatut] = useState("");
  const [showForm,     setShowForm]     = useState(false);
  const [formLoading,  setFormLoading]  = useState(false);
  const [formError,    setFormError]    = useState<string | null>(null);

  const validation = useValidation();

  const fetchData = useCallback(async () => {
    setLoading(true); setError(null);
    try {
      const p = new URLSearchParams({ limit: "100" });
      if (filtreType)   p.set("type",   filtreType);
      if (filtreStatut) p.set("statut", filtreStatut);
      const res = await fetch(`/api/factures?${p}`);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      setData(await res.json());
    } catch { setError("Impossible de charger les documents."); }
    finally   { setLoading(false); }
  }, [filtreType, filtreStatut]);

  useEffect(() => { fetchData(); }, [fetchData]);

  const handleCreateDevis = async (formData: DevisFormData) => {
    setFormLoading(true); setFormError(null);
    try {
      const res = await fetch("/api/factures", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ type: "devis", ...formData }),
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error ?? `HTTP ${res.status}`);
      setShowForm(false);
      await fetchData();
      router.push(`/facturation/${json.facture.id}`);
    } catch (err) {
      setFormError(err instanceof Error ? err.message : "Erreur création devis.");
    } finally {
      setFormLoading(false);
    }
  };

  const factures     = data?.factures ?? [];
  const brouillons   = factures.filter((f) => f.statut === "BROUILLON").length;
  const aRegler      = factures.filter((f) => f.statut === "a_payer" || f.statut === "partiellement_paye").length;
  const totalARegler = factures.filter((f) => f.statut === "a_payer" || f.statut === "partiellement_paye")
    .reduce((s, f) => s + (f.total_ttc - (f.acompte_recu ?? 0)), 0);

  const inputStyle: React.CSSProperties = { padding: "7px 12px", borderRadius: "8px", background: "rgba(255,255,255,0.04)", border: "1px solid rgba(201,168,76,0.18)", color: "#F0E8D8", fontSize: "12px", outline: "none", fontFamily: "Arial, sans-serif" };
  const formatEur = (n: number) => new Intl.NumberFormat("fr-FR", { style: "currency", currency: "EUR", minimumFractionDigits: 0 }).format(n);

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: "18px" }}>

      {/* En-tête */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", flexWrap: "wrap", gap: "10px" }}>
        <div>
          <h2 style={{ fontSize: "20px", fontWeight: "700", color: "#F0E8D8", fontFamily: "Georgia, serif" }}>Facturation</h2>
          <p style={{ fontSize: "11px", color: "rgba(201,168,76,0.55)", marginTop: "2px", fontFamily: "Arial, sans-serif" }}>
            {loading ? "Chargement…" : `${data?.total ?? 0} documents · ${brouillons} brouillons · ${aRegler} à régler`}
          </p>
        </div>
        <div style={{ display: "flex", gap: "8px" }}>
          <button type="button" onClick={fetchData} disabled={loading}
            style={{ ...inputStyle, cursor: loading ? "not-allowed" : "pointer", color: "rgba(201,168,76,0.65)" }}>
            ⟳
          </button>
          <button type="button" onClick={() => setShowForm(!showForm)}
            style={{ padding: "7px 16px", borderRadius: "8px", fontSize: "12px", fontWeight: "700", cursor: "pointer", fontFamily: "Georgia, serif",
              background: showForm ? "rgba(244,67,54,0.10)" : "linear-gradient(135deg, rgba(201,168,76,0.20), rgba(92,45,92,0.20))",
              border: `1px solid ${showForm ? "rgba(244,67,54,0.30)" : "rgba(201,168,76,0.35)"}`,
              color: showForm ? "#F44336" : "#C9A84C" }}>
            {showForm ? "✕ Annuler" : "+ Nouveau devis"}
          </button>
        </div>
      </div>

      {/* KPIs */}
      {!loading && (
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: "10px" }}>
          {[
            { label: "Total documents", value: data?.total ?? 0, color: "#C9A84C" },
            { label: "À régler",        value: aRegler,          color: aRegler > 0 ? "#FF9800" : "rgba(240,232,216,0.35)" },
            { label: "Montant à recouvrer", value: formatEur(totalARegler), color: totalARegler > 0 ? "#FF9800" : "rgba(240,232,216,0.35)", isText: true },
          ].map((k) => (
            <div key={k.label} style={{ padding: "12px 14px", background: "#120A10", border: `1px solid ${k.color}25`, borderRadius: "10px" }}>
              <p style={{ fontSize: "8px", color: "rgba(240,232,216,0.38)", letterSpacing: "0.12em", textTransform: "uppercase", marginBottom: "4px", fontFamily: "Arial, sans-serif" }}>{k.label}</p>
              <p style={{ fontSize: k.isText ? "17px" : "22px", fontWeight: "700", color: k.color, fontFamily: "Arial, sans-serif" }}>{k.value}</p>
            </div>
          ))}
        </div>
      )}

      {/* Formulaire devis */}
      {showForm && (
        <div style={{ background: "#120A10", border: "1px solid rgba(201,168,76,0.20)", borderRadius: "12px", padding: "20px" }}>
          <p style={{ fontSize: "9px", color: "#C9A84C", letterSpacing: "0.20em", textTransform: "uppercase", fontWeight: "700", marginBottom: "16px", fontFamily: "Arial, sans-serif" }}>
            ◇ Créer un nouveau devis
          </p>
          <DevisForm onSubmit={handleCreateDevis} onCancel={() => setShowForm(false)} loading={formLoading} error={formError} />
        </div>
      )}

      {/* Filtres */}
      <div style={{ display: "flex", gap: "10px", flexWrap: "wrap" }}>
        <select value={filtreType} onChange={(e) => setFiltreType(e.target.value)}
          style={{ ...inputStyle, cursor: "pointer", color: filtreType ? "#C9A84C" : "rgba(240,232,216,0.50)" }}>
          {TYPES.map((t) => <option key={t.key} value={t.key}>{t.label}</option>)}
        </select>
        <select value={filtreStatut} onChange={(e) => setFiltreStatut(e.target.value)}
          style={{ ...inputStyle, cursor: "pointer", color: filtreStatut ? "#C9A84C" : "rgba(240,232,216,0.50)" }}>
          <option value="">Tous les statuts</option>
          {STATUTS_FACTURE.map((s) => <option key={s.key} value={s.key}>{s.label}</option>)}
        </select>
        {(filtreType || filtreStatut) && (
          <button type="button" onClick={() => { setFiltreType(""); setFiltreStatut(""); }}
            style={{ ...inputStyle, cursor: "pointer", color: "rgba(240,232,216,0.45)" }}>
            ✕ Réinitialiser
          </button>
        )}
      </div>

      {/* Erreur */}
      {error && (
        <div style={{ padding: "12px 16px", background: "rgba(244,67,54,0.09)", border: "1px solid rgba(244,67,54,0.22)", borderRadius: "10px", color: "#F44336", fontSize: "13px", fontFamily: "Arial, sans-serif" }}>{error}</div>
      )}

      {/* Liste */}
      <div style={{ background: "#120A10", border: "1px solid rgba(201,168,76,0.14)", borderRadius: "12px", overflow: "hidden" }}>
        {/* Header table */}
        <div style={{ display: "grid", gridTemplateColumns: "32px 1fr 110px 110px 120px 100px 80px", gap: "10px", padding: "9px 14px", borderBottom: "1px solid rgba(201,168,76,0.10)" }}>
          {["", "Client", "Total", "Solde", "Statut", "Date", ""].map((h) => (
            <p key={h} style={{ fontSize: "9px", color: "rgba(201,168,76,0.45)", letterSpacing: "0.14em", textTransform: "uppercase", fontFamily: "Arial, sans-serif" }}>{h}</p>
          ))}
        </div>
        {loading
          ? [0,1,2,3,4].map((i) => <div key={i} style={{ height: "44px", margin: "3px 12px", background: "rgba(255,255,255,0.04)", borderRadius: "7px", animation: "bellaia-pulse 1.4s ease-in-out infinite", animationDelay: `${i*0.1}s` }} />)
          : factures.length === 0
          ? <p style={{ textAlign: "center", color: "rgba(240,232,216,0.35)", fontSize: "13px", padding: "40px", fontFamily: "Arial, sans-serif" }}>Aucun document</p>
          : factures.map((f) => <FactureCard key={f.id} facture={f} />)}
      </div>

      <p style={{ fontSize: "10px", color: "rgba(220,100,80,0.55)", fontStyle: "italic", fontFamily: "Arial, sans-serif" }}>
        🔒 Validation fondatrice obligatoire avant émission de tout document.
      </p>

      <ValidationModal validation={validation} />
    </div>
  );
}
