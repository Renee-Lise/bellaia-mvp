"use client";

import { useState } from "react";
import { ChatWindow }  from "@/components/bellaia/ChatWindow";
import { useAuth }     from "@/hooks/useAuth";
import { BRANCHES }    from "@/constants/statuts";

/**
 * app/(fondatrice)/bellaia/page.tsx
 *
 * Page principale du chatbot Bellaïa IA.
 * - Sélecteur de branche pour contextualiser la conversation
 * - Quick actions contextuelles par branche
 * - Interface chat complète
 */

// ── Quick actions par branche ─────────────────────────────────────────────────

const QUICK_ACTIONS_BY_BRANCH: Record<string, string[]> = {
  studio:      ["Rapport du jour", "Priorités de la semaine", "Analyse globale des branches", "Bilan mensuel"],
  odyssee:     ["Préparer un devis extensions cils", "Clientes actives Odyssée", "Alertes stocks beauté", "Script relance RDV"],
  secret_home: ["Commandes Secret Home urgentes", "Récapitulatif commande", "Créer devis boudoir", "Alertes stocks lingerie"],
  food:        ["Alertes stocks Food", "Créer fiche produit jus", "Préparer menu semaine", "Calcul marge produit"],
  events:      ["Préparer devis événement", "Réservations à venir", "Checklist décoration", "Créer devis anniversaire"],
  invest:      ["Veille marché beauté 2026", "Tendances secteur adulte", "Analyse opportunités", "Note de synthèse"],
  vilo:        ["Courrier à préparer", "Documents en attente", "Procédure administrative", "Modèle de réponse"],
  academy:     ["Nouvelle ressource pédagogique", "Collections Ti-Colibri", "Préparer mise en vente", "Stratégie pédagogique"],
  structure:   ["Idée e-book Bella'Structure", "Stratégie Ko-fi", "Fiche produit numérique", "Plan de contenu"],
};

const DEFAULT_QUICK_ACTIONS = [
  "Rapport du jour",
  "Commandes urgentes",
  "Alertes stocks",
  "Clientes VIP",
  "Créer un devis",
  "Mémoire métier",
];

// ── Composant ─────────────────────────────────────────────────────────────────

export default function BellaiaPage() {
  const { profile }        = useAuth();
  const [activeBranch, setActiveBranch] = useState("studio");

  const branchData    = BRANCHES.find((b) => b.id === activeBranch) ?? BRANCHES[0];
  const quickActions  = QUICK_ACTIONS_BY_BRANCH[activeBranch] ?? DEFAULT_QUICK_ACTIONS;

  const welcomeMessage =
    `Bonjour ${profile?.prenom ?? "Renée-Lise"}. ✦\n\n` +
    `Je suis Bellaïa, votre Executive Business Manager IA.\n\n` +
    `Branche active : **${branchData.label}**\n\n` +
    `Je peux lire vos commandes, stocks, clientes, créer des devis en brouillon, et générer votre rapport quotidien.\n\n` +
    `Commencez par une action rapide ou posez-moi votre première question.`;

  return (
    <div
      style={{
        display:       "flex",
        flexDirection: "column",
        height:        "calc(100vh - 132px)", // hauteur viewport - header - footer
        minHeight:     "500px",
        gap:           "14px",
      }}
    >
      {/* ── En-tête ─────────────────────────────────────────────────────────── */}
      <div
        style={{
          display:        "flex",
          justifyContent: "space-between",
          alignItems:     "center",
          flexWrap:       "wrap",
          gap:            "10px",
          flexShrink:     0,
        }}
      >
        <div style={{ display: "flex", alignItems: "center", gap: "12px" }}>
          {/* Avatar */}
          <div
            style={{
              width:          "38px",
              height:         "38px",
              borderRadius:   "50%",
              background:     `linear-gradient(135deg, ${branchData.secondary}, ${branchData.accent})`,
              display:        "flex",
              alignItems:     "center",
              justifyContent: "center",
              fontSize:       "16px",
              fontWeight:     "700",
              color:          "#0C0810",
              flexShrink:     0,
            }}
          >
            B
          </div>
          <div>
            <h2
              style={{
                fontSize:   "17px",
                fontWeight: "700",
                color:      "#F0E8D8",
                fontFamily: "Georgia, serif",
              }}
            >
              Bellaïa IA
            </h2>
            <p
              style={{
                fontSize:   "11px",
                color:      "rgba(201,168,76,0.55)",
                marginTop:  "1px",
                fontFamily: "Arial, sans-serif",
              }}
            >
              Executive Business Manager · {branchData.label}
            </p>
          </div>
        </div>

        {/* Statut actif */}
        <div style={{ display: "flex", alignItems: "center", gap: "7px" }}>
          <div
            style={{
              width:     "7px",
              height:    "7px",
              borderRadius: "50%",
              background: "#4CAF50",
              boxShadow: "0 0 6px #4CAF50",
            }}
          />
          <span
            style={{
              fontSize:   "11px",
              color:      "rgba(240,232,216,0.38)",
              fontFamily: "Arial, sans-serif",
            }}
          >
            Bellaïa active · claude-sonnet-4
          </span>
        </div>
      </div>

      {/* ── Sélecteur de branche ─────────────────────────────────────────────── */}
      <div
        style={{
          display:  "flex",
          gap:      "6px",
          flexWrap: "wrap",
          flexShrink: 0,
        }}
      >
        {BRANCHES.map((b) => (
          <button
            key={b.id}
            type="button"
            onClick={() => setActiveBranch(b.id)}
            style={{
              display:      "flex",
              alignItems:   "center",
              gap:          "6px",
              padding:      "5px 12px",
              borderRadius: "20px",
              border:       `1px solid ${activeBranch === b.id ? `${b.accent}50` : "rgba(255,255,255,0.08)"}`,
              background:   activeBranch === b.id ? `${b.accent}15` : "transparent",
              color:        activeBranch === b.id ? b.accent : "rgba(240,232,216,0.42)",
              fontSize:     "11px",
              cursor:       "pointer",
              fontFamily:   "Georgia, serif",
              transition:   "all 0.15s",
              whiteSpace:   "nowrap",
            }}
          >
            <span style={{ fontSize: "11px", opacity: activeBranch === b.id ? 1 : 0.5 }}>
              {b.icon}
            </span>
            <span>{b.label}</span>
          </button>
        ))}
      </div>

      {/* ── Fenêtre de chat ──────────────────────────────────────────────────── */}
      <div
        style={{
          flex:         "1 1 0",
          minHeight:    "0",
          background:   "#120A10",
          border:       "1px solid rgba(201,168,76,0.15)",
          borderRadius: "14px",
          overflow:     "hidden",
          display:      "flex",
          flexDirection: "column",
        }}
      >
        <ChatWindow
          key={activeBranch} // Réinitialise la conversation au changement de branche
          branch={activeBranch}
          prenom={profile?.prenom ?? "Renée-Lise"}
          branchAccent={branchData.accent}
          branchSecondary={branchData.secondary}
          quickActions={quickActions}
          welcomeMessage={welcomeMessage}
        />
      </div>

      {/* ── Note gouvernance ─────────────────────────────────────────────────── */}
      <p
        style={{
          textAlign:  "center",
          fontSize:   "9px",
          color:      "rgba(240,232,216,0.18)",
          fontStyle:  "italic",
          fontFamily: "Arial, sans-serif",
          flexShrink: 0,
        }}
      >
        Bellaïa prépare · Renée-Lise décide · Validation fondatrice obligatoire sur toute action sensible
      </p>
    </div>
  );
}
