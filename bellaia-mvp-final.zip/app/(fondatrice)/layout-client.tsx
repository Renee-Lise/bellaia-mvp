"use client";

import { useState, useEffect } from "react";
import { usePathname } from "next/navigation";
import { Sidebar } from "@/components/layout/Sidebar";
import { Header } from "@/components/layout/Header";

/**
 * app/(fondatrice)/layout-client.tsx
 *
 * Partie client du layout fondatrice.
 * Gère :
 * - L'état ouvert/fermé de la sidebar (desktop + mobile)
 * - Le titre dynamique du header selon la route
 * - La récupération des urgences (stub — sera connecté à /api/dashboard/summary)
 * - L'overlay mobile pour fermer la sidebar
 */

// ── Mapping route → titre / sous-titre ────────────────────────────────────────
const ROUTE_TITRES: Record<string, { titre: string; sousTitre: string }> = {
  "/dashboard":      { titre: "Tableau de bord",  sousTitre: "Vue 360° Bella'Studio" },
  "/commandes":      { titre: "Commandes",         sousTitre: "Gestion & suivi — Bella'Secret Home" },
  "/stocks":         { titre: "Stocks",            sousTitre: "Produits & alertes réassort" },
  "/crm":            { titre: "CRM Clientes",      sousTitre: "Profils, fidélité & relances" },
  "/facturation":    { titre: "Facturation",       sousTitre: "Devis, factures & avoirs" },
  "/documents":      { titre: "Documents clients", sousTitre: "Consentements, CGV & suivi" },
  "/bellaia":        { titre: "Bellaïa IA",        sousTitre: "Executive Business Manager" },
  "/audit":          { titre: "Journal d'audit",   sousTitre: "Traçabilité toutes actions" },
  "/coffre-fort":    { titre: "Coffre-fort",       sousTitre: "Documents sensibles — accès restreint" },
  "/fournisseurs":   { titre: "Fournisseurs",      sousTitre: "Analyse, comparaison & suivi" },
  "/collaborateurs": { titre: "Collaborateurs",    sousTitre: "Rôles & accès" },
};

function getRouteTitre(pathname: string) {
  // Correspondance exacte d'abord
  if (ROUTE_TITRES[pathname]) return ROUTE_TITRES[pathname];
  // Correspondance par préfixe (ex: /commandes/CMD-001)
  const prefix = Object.keys(ROUTE_TITRES).find((k) =>
    k !== "/dashboard" && pathname.startsWith(k)
  );
  return prefix
    ? ROUTE_TITRES[prefix]
    : { titre: "Bella'Studio", sousTitre: "Bellaïa Enterprise" };
}

// ── Composant ─────────────────────────────────────────────────────────────────

export function FondatriceLayoutClient({
  children,
}: {
  children: React.ReactNode;
}) {
  const pathname = usePathname();

  // Sidebar ouverte par défaut sur desktop, fermée sur mobile
  const [sidebarOpen, setSidebarOpen] = useState(true);
  // Urgences (sera chargé depuis /api/dashboard/summary)
  const [urgences, setUrgences] = useState(0);

  const { titre, sousTitre } = getRouteTitre(pathname);

  // ── Fermer la sidebar sur mobile au changement de route ──────────────────
  useEffect(() => {
    const isMobile = window.innerWidth < 768;
    if (isMobile) setSidebarOpen(false);
  }, [pathname]);

  // ── Détecter la taille d'écran au montage ────────────────────────────────
  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth >= 768) {
        setSidebarOpen(true);
      }
    };
    window.addEventListener("resize", handleResize);
    // État initial
    setSidebarOpen(window.innerWidth >= 768);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  // ── Charger les urgences ──────────────────────────────────────────────────
  useEffect(() => {
    const fetchUrgences = async () => {
      try {
        const res  = await fetch("/api/dashboard/summary");
        if (!res.ok) return;
        const data = await res.json();
        const critiques = (data.urgences ?? []).filter(
          (u: { niveau: string }) => u.niveau === "rouge"
        ).length;
        setUrgences(critiques);
      } catch {
        // Silencieux — pas critique si le dashboard n'est pas encore codé
      }
    };
    fetchUrgences();
  }, [pathname]);

  return (
    <div className="flex h-dvh overflow-hidden" style={{ background: "#0C0810" }}>

      {/* ── Overlay mobile ─────────────────────────────────────────────────── */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 z-20 md:hidden"
          style={{ background: "rgba(0, 0, 0, 0.60)" }}
          onClick={() => setSidebarOpen(false)}
          aria-hidden="true"
        />
      )}

      {/* ── Sidebar ─────────────────────────────────────────────────────────── */}
      <div
        className={[
          "fixed inset-y-0 left-0 z-30 transition-transform duration-300 md:relative md:z-auto md:translate-x-0",
          sidebarOpen ? "translate-x-0" : "-translate-x-full",
        ].join(" ")}
      >
        <Sidebar
          onClose={() => setSidebarOpen(false)}
        />
      </div>

      {/* ── Zone principale ─────────────────────────────────────────────────── */}
      <div className="flex min-w-0 flex-1 flex-col overflow-hidden">

        {/* Header */}
        <Header
          titre={titre}
          sousTitre={sousTitre}
          onToggleSidebar={() => setSidebarOpen((v) => !v)}
          urgences={urgences}
        />

        {/* Contenu de la page */}
        <main
          className="flex-1 overflow-y-auto"
          style={{ background: "#0C0810" }}
        >
          {/* Fond ambiance */}
          <div
            className="pointer-events-none fixed inset-0 z-0"
            style={{
              background: `
                radial-gradient(ellipse 55% 45% at 15% 85%, rgba(92,45,92,0.10) 0%, transparent 65%),
                radial-gradient(ellipse 40% 55% at 85% 15%, rgba(201,168,76,0.05) 0%, transparent 60%)
              `,
            }}
            aria-hidden="true"
          />

          {/* Contenu */}
          <div className="relative z-10 p-4 md:p-6">
            {children}
          </div>
        </main>

        {/* Footer */}
        <footer
          className="flex items-center justify-between px-4 py-2 md:px-6"
          style={{
            borderTop:  "1px solid rgba(201, 168, 76, 0.08)",
            background: "rgba(8, 4, 7, 0.90)",
          }}
        >
          <p
            className="text-xs"
            style={{ color: "rgba(240, 232, 216, 0.18)", letterSpacing: "0.06em" }}
          >
            Bellaïa prépare · Renée-Lise décide · Validation fondatrice obligatoire
          </p>
          <p
            className="text-xs"
            style={{ color: "rgba(240, 232, 216, 0.15)" }}
          >
            Bella&apos;Studio © 2026 · Confidentiel
          </p>
        </footer>
      </div>
    </div>
  );
}
