"use client";

import { useEffect, useState, useCallback } from "react";
import { StockTable }         from "@/components/stocks/StockTable";
import { StockMovementModal } from "@/components/stocks/StockMovementModal";
import type { StockAvecStatut } from "@/types/database";

interface StocksResponse {
  stocks:  StockAvecStatut[];
  resume:  { total: number; ok: number; faibles: number; ruptures: number };
}

const BRANCHES = ["secret_home","odyssee","food","events","academy","structure","vilo","studio"];

export default function StocksPage() {
  const [data,          setData]          = useState<StocksResponse | null>(null);
  const [loading,       setLoading]       = useState(true);
  const [error,         setError]         = useState<string | null>(null);
  const [filtreBranche, setFiltreBranche] = useState("");
  const [filtreAlerte,  setFiltreAlerte]  = useState(false);

  // Modal mouvement
  const [modalOpen,   setModalOpen]   = useState(false);
  const [modalProduit, setModalProduit] = useState<{ id: string; nom: string; qty: number; unite: string } | null>(null);

  const fetchData = useCallback(async () => {
    setLoading(true); setError(null);
    try {
      const p = new URLSearchParams();
      if (filtreBranche) p.set("branche", filtreBranche);
      if (filtreAlerte)  p.set("alerte",  "1");
      const res = await fetch(`/api/stocks?${p}`);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      setData(await res.json());
    } catch { setError("Impossible de charger les stocks."); }
    finally   { setLoading(false); }
  }, [filtreBranche, filtreAlerte]);

  useEffect(() => { fetchData(); }, [fetchData]);

  const openModal = (produitId: string, produitNom: string) => {
    const stock = data?.stocks.find((s) => s.produit_id === produitId);
    setModalProduit({ id: produitId, nom: produitNom, qty: stock?.quantite ?? 0, unite: stock?.unite ?? "unités" });
    setModalOpen(true);
  };

  const r = data?.resume;
  const inputStyle: React.CSSProperties = { padding: "7px 12px", borderRadius: "8px", background: "rgba(255,255,255,0.04)", border: "1px solid rgba(201,168,76,0.18)", color: "#F0E8D8", fontSize: "12px", outline: "none", fontFamily: "Arial, sans-serif" };

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: "18px" }}>

      {/* En-tête */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", flexWrap: "wrap", gap: "10px" }}>
        <div>
          <h2 style={{ fontSize: "20px", fontWeight: "700", color: "#F0E8D8", fontFamily: "Georgia, serif" }}>Stocks</h2>
          <p style={{ fontSize: "11px", color: "rgba(201,168,76,0.55)", marginTop: "2px", fontFamily: "Arial, sans-serif" }}>
            {loading ? "Chargement…" : `${r?.total ?? 0} produits · ${r?.ruptures ?? 0} ruptures · ${r?.faibles ?? 0} faibles`}
          </p>
        </div>
        <button type="button" onClick={fetchData} disabled={loading}
          style={{ ...inputStyle, cursor: loading ? "not-allowed" : "pointer", color: "rgba(201,168,76,0.65)" }}>
          {loading ? "⟳" : "⟳ Actualiser"}
        </button>
      </div>

      {/* KPIs stocks */}
      {r && !loading && (
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: "10px" }}>
          {[
            { label: "Total produits", value: r.total,    color: "#C9A84C" },
            { label: "Disponibles",    value: r.ok,       color: "#4CAF50" },
            { label: "Stocks faibles", value: r.faibles,  color: "#FF9800" },
            { label: "Ruptures",       value: r.ruptures, color: r.ruptures > 0 ? "#F44336" : "rgba(240,232,216,0.35)" },
          ].map((k) => (
            <div key={k.label} style={{ padding: "12px 14px", background: "#120A10", border: `1px solid ${k.color}25`, borderRadius: "10px" }}>
              <p style={{ fontSize: "8px", color: "rgba(240,232,216,0.38)", letterSpacing: "0.12em", textTransform: "uppercase", marginBottom: "4px", fontFamily: "Arial, sans-serif" }}>{k.label}</p>
              <p style={{ fontSize: "22px", fontWeight: "700", color: k.color, fontFamily: "Arial, sans-serif" }}>{k.value}</p>
            </div>
          ))}
        </div>
      )}

      {/* Alertes critiques */}
      {(r?.ruptures ?? 0) > 0 && (
        <div style={{ padding: "12px 16px", background: "rgba(244,67,54,0.07)", border: "1px solid rgba(244,67,54,0.22)", borderRadius: "10px", display: "flex", alignItems: "center", gap: "10px" }}>
          <span style={{ fontSize: "14px" }}>🔴</span>
          <p style={{ fontSize: "12px", color: "rgba(244,67,54,0.85)", fontFamily: "Arial, sans-serif" }}>
            <strong>{r?.ruptures} rupture{(r?.ruptures ?? 0) > 1 ? "s" : ""}</strong> détectée{(r?.ruptures ?? 0) > 1 ? "s" : ""}.
            Toute commande fournisseur nécessite une <strong>validation fondatrice</strong>.
          </p>
        </div>
      )}

      {/* Filtres */}
      <div style={{ display: "flex", gap: "10px", flexWrap: "wrap", alignItems: "center" }}>
        <select value={filtreBranche} onChange={(e) => setFiltreBranche(e.target.value)}
          style={{ ...inputStyle, cursor: "pointer", color: filtreBranche ? "#C9A84C" : "rgba(240,232,216,0.50)" }}>
          <option value="">Toutes les branches</option>
          {BRANCHES.map((b) => <option key={b} value={b}>{b}</option>)}
        </select>
        <button type="button" onClick={() => setFiltreAlerte(!filtreAlerte)}
          style={{ ...inputStyle, cursor: "pointer",
            background: filtreAlerte ? "rgba(244,67,54,0.10)" : "rgba(255,255,255,0.04)",
            borderColor: filtreAlerte ? "rgba(244,67,54,0.35)" : "rgba(201,168,76,0.18)",
            color: filtreAlerte ? "#F44336" : "rgba(240,232,216,0.45)" }}>
          {filtreAlerte ? "✕ Alertes seulement" : "⚠ Alertes seulement"}
        </button>
        {(filtreBranche || filtreAlerte) && (
          <button type="button" onClick={() => { setFiltreBranche(""); setFiltreAlerte(false); }}
            style={{ ...inputStyle, cursor: "pointer", color: "rgba(240,232,216,0.45)" }}>
            ✕ Réinitialiser
          </button>
        )}
      </div>

      {/* Erreur */}
      {error && (
        <div style={{ padding: "12px 16px", background: "rgba(244,67,54,0.09)", border: "1px solid rgba(244,67,54,0.22)", borderRadius: "10px", color: "#F44336", fontSize: "13px", fontFamily: "Arial, sans-serif" }}>{error}</div>
      )}

      {/* Tableau */}
      <div style={{ background: "#120A10", border: "1px solid rgba(201,168,76,0.14)", borderRadius: "12px", overflow: "hidden" }}>
        <StockTable stocks={data?.stocks ?? []} loading={loading} onMovement={openModal} />
      </div>

      {/* Note gouvernance */}
      <p style={{ fontSize: "10px", color: "rgba(220,100,80,0.55)", fontStyle: "italic", fontFamily: "Arial, sans-serif" }}>
        🔒 Tout réassort ou commande fournisseur nécessite une validation fondatrice explicite.
      </p>

      {/* Modal mouvement */}
      {modalOpen && modalProduit && (
        <StockMovementModal
          produitId={modalProduit.id}
          produitNom={modalProduit.nom}
          quantiteActuelle={modalProduit.qty}
          unite={modalProduit.unite}
          isOpen={modalOpen}
          onClose={() => setModalOpen(false)}
          onSaved={() => { setModalOpen(false); fetchData(); }}
        />
      )}
    </div>
  );
}
