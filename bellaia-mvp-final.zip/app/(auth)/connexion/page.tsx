"use client";

import { useState, useEffect } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { createClient } from "@/lib/supabase/client";

/**
 * app/(auth)/connexion/page.tsx
 *
 * Page de connexion Bellaïa.
 * - Login email + mot de passe via Supabase Auth
 * - Redirection vers /dashboard (fondatrice) ou /espace (cliente)
 * - Support du paramètre redirectTo
 * - Gestion des erreurs inline (pas de toast pour simplifier la Couche 2)
 */

export default function ConnexionPage() {
  const router       = useRouter();
  const searchParams = useSearchParams();
  const supabase     = createClient();

  const [email,      setEmail]      = useState("");
  const [password,   setPassword]   = useState("");
  const [loading,    setLoading]    = useState(false);
  const [error,      setError]      = useState<string | null>(null);
  const [showPass,   setShowPass]   = useState(false);

  // URL de redirection après connexion (optionnel)
  const redirectTo = searchParams.get("redirectTo");

  // ── Vérifier si déjà connecté ──────────────────────────────────────────────
  useEffect(() => {
    const checkSession = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) return;

      const { data: profile } = await supabase
        .from("profiles")
        .select("role")
        .eq("id", session.user.id)
        .single();

      const dest = redirectTo
        ?? (profile?.role === "fondatrice" ? "/dashboard" : "/espace");
      router.replace(dest);
    };
    checkSession();
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  // ── Soumission du formulaire ───────────────────────────────────────────────
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    // Validation basique
    if (!email.trim() || !password) {
      setError("Email et mot de passe requis.");
      setLoading(false);
      return;
    }

    try {
      const { data, error: authError } = await supabase.auth.signInWithPassword({
        email:    email.trim().toLowerCase(),
        password,
      });

      if (authError) {
        // Traduire les erreurs Supabase
        if (authError.message.includes("Invalid login credentials")) {
          setError("Email ou mot de passe incorrect.");
        } else if (authError.message.includes("Email not confirmed")) {
          setError("Votre email n'a pas été confirmé. Vérifiez votre boîte mail.");
        } else if (authError.message.includes("Too many requests")) {
          setError("Trop de tentatives. Veuillez patienter quelques minutes.");
        } else {
          setError(authError.message);
        }
        return;
      }

      if (!data.user) {
        setError("Connexion échouée. Veuillez réessayer.");
        return;
      }

      // Récupérer le rôle pour rediriger au bon endroit
      const { data: profile } = await supabase
        .from("profiles")
        .select("role")
        .eq("id", data.user.id)
        .single();

      const dest = redirectTo
        ?? (profile?.role === "fondatrice" ? "/dashboard" : "/espace");

      router.push(dest);
    } finally {
      setLoading(false);
    }
  };

  // ─────────────────────────────────────────────────────────────────────────
  return (
    <div
      className="flex min-h-dvh items-center justify-center px-4"
      style={{ background: "#0C0810" }}
    >
      {/* Fond ambiance */}
      <div
        className="pointer-events-none fixed inset-0"
        style={{
          background: `
            radial-gradient(ellipse 60% 50% at 20% 80%, rgba(92,45,92,0.14) 0%, transparent 65%),
            radial-gradient(ellipse 50% 40% at 80% 20%, rgba(201,168,76,0.07) 0%, transparent 60%)
          `,
        }}
        aria-hidden="true"
      />

      {/* Card connexion */}
      <div
        className="relative w-full max-w-sm"
        style={{
          background:   "#120A10",
          border:       "1px solid rgba(201, 168, 76, 0.22)",
          borderRadius: "20px",
          padding:      "2.5rem 2rem",
        }}
      >
        {/* Logo */}
        <div className="mb-8 text-center">
          <p
            className="font-serif text-xs tracking-widest uppercase mb-1"
            style={{ color: "#C9A84C", letterSpacing: "0.35em" }}
          >
            Bella&apos;Studio
          </p>
          <h1
            className="font-serif text-3xl font-bold"
            style={{ color: "#F0E8D8", letterSpacing: "0.06em" }}
          >
            Bellaïa
          </h1>
          <p
            className="mt-1 text-xs"
            style={{ color: "rgba(240, 232, 216, 0.35)", letterSpacing: "0.1em" }}
          >
            Executive Business Manager IA
          </p>
        </div>

        {/* Formulaire */}
        <form onSubmit={handleSubmit} noValidate className="space-y-4">

          {/* Email */}
          <div>
            <label
              htmlFor="email"
              className="block text-xs mb-1.5 font-medium"
              style={{ color: "rgba(240, 232, 216, 0.55)", letterSpacing: "0.06em" }}
            >
              EMAIL
            </label>
            <input
              id="email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              disabled={loading}
              autoComplete="email"
              autoFocus
              placeholder="renee-lise@bellastudio.fr"
              className="w-full rounded-xl px-4 py-3 text-sm transition-colors"
              style={{
                background: "rgba(255, 255, 255, 0.04)",
                border:     "1px solid rgba(201, 168, 76, 0.18)",
                color:      "#F0E8D8",
                outline:    "none",
              }}
              onFocus={(e) => {
                e.currentTarget.style.borderColor = "rgba(201, 168, 76, 0.45)";
              }}
              onBlur={(e) => {
                e.currentTarget.style.borderColor = "rgba(201, 168, 76, 0.18)";
              }}
            />
          </div>

          {/* Mot de passe */}
          <div>
            <label
              htmlFor="password"
              className="block text-xs mb-1.5 font-medium"
              style={{ color: "rgba(240, 232, 216, 0.55)", letterSpacing: "0.06em" }}
            >
              MOT DE PASSE
            </label>
            <div className="relative">
              <input
                id="password"
                type={showPass ? "text" : "password"}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                disabled={loading}
                autoComplete="current-password"
                placeholder="••••••••"
                className="w-full rounded-xl px-4 py-3 pr-11 text-sm transition-colors"
                style={{
                  background: "rgba(255, 255, 255, 0.04)",
                  border:     "1px solid rgba(201, 168, 76, 0.18)",
                  color:      "#F0E8D8",
                  outline:    "none",
                }}
                onFocus={(e) => {
                  e.currentTarget.style.borderColor = "rgba(201, 168, 76, 0.45)";
                }}
                onBlur={(e) => {
                  e.currentTarget.style.borderColor = "rgba(201, 168, 76, 0.18)";
                }}
              />
              <button
                type="button"
                onClick={() => setShowPass((v) => !v)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-sm transition-colors"
                style={{ color: "rgba(201, 168, 76, 0.45)" }}
                aria-label={showPass ? "Masquer le mot de passe" : "Afficher le mot de passe"}
              >
                {showPass ? "◉" : "◎"}
              </button>
            </div>
          </div>

          {/* Erreur */}
          {error && (
            <div
              className="rounded-lg px-4 py-3 text-sm"
              style={{
                background: "rgba(244, 67, 54, 0.10)",
                border:     "1px solid rgba(244, 67, 54, 0.25)",
                color:      "#F44336",
              }}
              role="alert"
            >
              {error}
            </div>
          )}

          {/* Bouton connexion */}
          <button
            type="submit"
            disabled={loading || !email || !password}
            className="w-full rounded-xl py-3 text-sm font-bold transition-all mt-2"
            style={{
              background: loading || !email || !password
                ? "rgba(201, 168, 76, 0.20)"
                : "linear-gradient(135deg, #C9A84C, #5C2D5C)",
              border:     "none",
              color:      loading || !email || !password
                ? "rgba(240, 232, 216, 0.35)"
                : "#0C0810",
              cursor:     loading || !email || !password ? "not-allowed" : "pointer",
            }}
          >
            {loading ? (
              <span className="flex items-center justify-center gap-2">
                <LoadingDots />
                Connexion…
              </span>
            ) : (
              "Se connecter"
            )}
          </button>
        </form>

        {/* Footer */}
        <p
          className="mt-6 text-center text-xs"
          style={{ color: "rgba(240, 232, 216, 0.22)" }}
        >
          Bellaïa prépare · Renée-Lise décide
        </p>
      </div>
    </div>
  );
}

// ── Composant interne ─────────────────────────────────────────────────────────
function LoadingDots() {
  return (
    <span className="flex gap-1">
      {[0, 1, 2].map((i) => (
        <span
          key={i}
          className="inline-block h-1.5 w-1.5 rounded-full"
          style={{
            background:     "#C9A84C",
            animation:      "bellaia-pulse 1.2s ease-in-out infinite",
            animationDelay: `${i * 0.2}s`,
          }}
        />
      ))}
    </span>
  );
}
