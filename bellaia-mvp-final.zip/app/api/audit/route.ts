import { NextResponse }     from "next/server";
import { withAuth }         from "@/lib/auth/guards";
import { auditLog }         from "@/lib/audit/logger";
import type { AuditAction } from "@/lib/audit/logger";
import type { Json }        from "@/types/database";

/**
 * POST /api/audit
 * Enregistre une action depuis le client (useValidation, actions fondatrice).
 */
export async function POST(req: Request) {
  const guard = await withAuth();
  if (!guard.ok) return guard.error;
  const { supabase, userId } = guard;

  let body: {
    action:        AuditAction;
    entite:        string;
    entite_id?:    string;
    valeur_avant?: Json;
    valeur_apres?: Json;
  };
  try { body = await req.json(); }
  catch { return NextResponse.json({ error: "Corps invalide." }, { status: 400 }); }

  if (!body.action || !body.entite)
    return NextResponse.json({ error: "action et entite sont requis." }, { status: 400 });

  await auditLog({
    supabase,
    action:       body.action,
    entite:       body.entite,
    entite_id:    body.entite_id    ?? undefined,
    fait_par:     userId,
    valeur_avant: body.valeur_avant ?? undefined,
    valeur_apres: body.valeur_apres ?? undefined,
  });

  return NextResponse.json({ success: true });
}
