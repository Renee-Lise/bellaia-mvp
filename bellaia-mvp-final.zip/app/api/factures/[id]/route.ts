import { NextResponse }   from "next/server";
import { withFondatrice } from "@/lib/auth/guards";
import { auditLog }       from "@/lib/audit/logger";

/**
 * GET /api/factures/[id]         — Détail facture/devis
 * PUT /api/factures/[id]         — Mettre à jour (notes, acompte)
 * PUT /api/factures/[id]?action=valider  — Émettre officiellement (fondatrice)
 */

export async function GET(
  _req: Request,
  { params }: { params: { id: string } }
) {
  const guard = await withFondatrice();
  if (!guard.ok) return guard.error;
  const { supabase } = guard;

  try {
    const { data, error } = await supabase
      .from("factures").select("*").eq("id", params.id).single();

    if (error || !data)
      return NextResponse.json({ error: "Document introuvable." }, { status: 404 });

    // Cliente liée si existante
    let cliente = null;
    if (data.cliente_id) {
      const { data: c } = await supabase.from("clientes_crm")
        .select("id,nom,email,telephone,statut_crm").eq("id", data.cliente_id).single();
      cliente = c;
    }

    return NextResponse.json({ facture: data, cliente });
  } catch (err) {
    console.error("[GET /api/factures/:id]", err);
    return NextResponse.json({ error: "Erreur chargement." }, { status: 500 });
  }
}

export async function PUT(
  req: Request,
  { params }: { params: { id: string } }
) {
  const guard = await withFondatrice();
  if (!guard.ok) return guard.error;
  const { supabase, userId } = guard;

  const { searchParams } = new URL(req.url);
  const action = searchParams.get("action");

  let body: Record<string, unknown>;
  try { body = await req.json(); }
  catch { return NextResponse.json({ error: "Corps invalide." }, { status: 400 }); }

  try {
    // ── Action : émettre officiellement ─────────────────────────────────────
    if (action === "valider") {
      const { data: avant } = await supabase
        .from("factures").select("statut,numero,type").eq("id", params.id).single();

      if (!avant)
        return NextResponse.json({ error: "Document introuvable." }, { status: 404 });

      if (avant.statut === "VALIDE" || avant.emis_le)
        return NextResponse.json({ error: "Document déjà émis." }, { status: 422 });

      // Générer le numéro via la fonction SQL
      const { data: numData } = await supabase
        .rpc("gen_num", { t: avant.type });

      const { data, error } = await supabase.from("factures")
        .update({
          statut:    "VALIDE",
          numero:    numData ?? avant.numero,
          valide_par: userId,
          emis_le:   new Date().toISOString(),
        })
        .eq("id", params.id).select().single();

      if (error) throw error;

      await auditLog({ supabase, action: "facture_emise", entite: "factures",
        entite_id: params.id, fait_par: userId,
        valeur_avant: { statut: avant.statut }, valeur_apres: { statut: "VALIDE", numero: data.numero } });

      return NextResponse.json({ facture: data });
    }

    // ── Mise à jour partielle ────────────────────────────────────────────────
    const ALLOWED = ["notes", "acompte_recu", "statut"];
    const updates: Record<string, unknown> = {};
    for (const k of ALLOWED) { if (body[k] !== undefined) updates[k] = body[k]; }

    if (Object.keys(updates).length === 0)
      return NextResponse.json({ error: "Aucun champ à mettre à jour." }, { status: 400 });

    const { data, error } = await supabase.from("factures")
      .update(updates).eq("id", params.id).select().single();

    if (error) throw error;

    if (updates.acompte_recu !== undefined) {
      await auditLog({ supabase, action: "paiement_marked_received", entite: "factures",
        entite_id: params.id, fait_par: userId, valeur_apres: { acompte_recu: updates.acompte_recu } });
    }

    return NextResponse.json({ facture: data });
  } catch (err) {
    console.error("[PUT /api/factures/:id]", err);
    return NextResponse.json({ error: "Erreur mise à jour." }, { status: 500 });
  }
}
