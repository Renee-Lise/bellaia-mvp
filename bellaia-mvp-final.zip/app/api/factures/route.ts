import { NextResponse }   from "next/server";
import { withFondatrice } from "@/lib/auth/guards";
import { auditLog }       from "@/lib/audit/logger";

/**
 * GET  /api/factures   — Liste devis + factures avec filtres
 * POST /api/factures   — Créer un devis (BROUILLON). Validation fondatrice pour émission.
 */

export async function GET(req: Request) {
  const guard = await withFondatrice();
  if (!guard.ok) return guard.error;
  const { supabase } = guard;

  const { searchParams } = new URL(req.url);
  const type    = searchParams.get("type");
  const statut  = searchParams.get("statut");
  const branche = searchParams.get("branche");
  const limit   = Math.min(parseInt(searchParams.get("limit") ?? "50"), 100);
  const offset  = parseInt(searchParams.get("offset") ?? "0");

  try {
    let q = supabase
      .from("factures")
      .select("id,numero,type,client_nom,client_email,branche,total_ttc,acompte_recu,statut,validite_date,emis_le,created_at", { count: "exact" })
      .order("created_at", { ascending: false })
      .range(offset, offset + limit - 1);

    if (type)    q = q.eq("type",    type);
    if (statut)  q = q.eq("statut",  statut);
    if (branche) q = q.eq("branche", branche);

    const { data, error, count } = await q;
    if (error) throw error;

    return NextResponse.json({ factures: data ?? [], total: count ?? 0, limit, offset });
  } catch (err) {
    console.error("[GET /api/factures]", err);
    return NextResponse.json({ error: "Erreur chargement factures." }, { status: 500 });
  }
}

export async function POST(req: Request) {
  const guard = await withFondatrice();
  if (!guard.ok) return guard.error;
  const { supabase, userId } = guard;

  let body: {
    type?:         string;
    client_nom:    string;
    client_email?: string;
    cliente_id?:   string;
    branche:       string;
    articles:      { description: string; quantite: number; prix_unitaire: number }[];
    notes?:        string;
    validite_jours?: number;
    acompte_recu?: number;
  };
  try { body = await req.json(); }
  catch { return NextResponse.json({ error: "Corps invalide." }, { status: 400 }); }

  if (!body.client_nom?.trim())
    return NextResponse.json({ error: "Le nom du client est requis." }, { status: 400 });
  if (!Array.isArray(body.articles) || body.articles.length === 0)
    return NextResponse.json({ error: "Au moins un article est requis." }, { status: 400 });

  // Calcul total côté serveur
  const totalTTC = body.articles.reduce((s, a) => s + a.quantite * a.prix_unitaire, 0);

  const validite = new Date();
  validite.setDate(validite.getDate() + (body.validite_jours ?? 30));

  try {
    const { data, error } = await supabase.from("factures").insert({
      type:          body.type ?? "devis",
      client_nom:    body.client_nom.trim(),
      client_email:  body.client_email?.trim() ?? "",
      cliente_id:    body.cliente_id ?? null,
      branche:       body.branche,
      articles:      body.articles,
      total_ttc:     totalTTC,
      acompte_recu:  body.acompte_recu ?? 0,
      statut:        "BROUILLON",
      validite_date: validite.toISOString().split("T")[0],
      notes:         body.notes ?? "",
      valide_par:    null,
      emis_le:       null,
    }).select().single();

    if (error) throw error;

    await auditLog({ supabase, action: "facture_created", entite: "factures",
      entite_id: data.id, fait_par: userId,
      valeur_apres: { type: data.type, client: data.client_nom, total: totalTTC, statut: "BROUILLON" } });

    return NextResponse.json({ facture: data }, { status: 201 });
  } catch (err) {
    console.error("[POST /api/factures]", err);
    return NextResponse.json({ error: "Erreur création." }, { status: 500 });
  }
}
