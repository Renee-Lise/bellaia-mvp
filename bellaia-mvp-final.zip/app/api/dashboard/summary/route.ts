import { withFondatrice } from "@/lib/auth/guards";
import { NextResponse }    from "next/server";

/**
 * GET /api/dashboard/summary
 *
 * Agrège en une seule requête tous les KPIs du tableau de bord fondatrice :
 * - Commandes actives et urgentes
 * - Stocks en alerte / rupture
 * - Paiements en attente
 * - Clientes récentes
 * - Factures ouvertes
 *
 * Toutes les données sont en lecture seule.
 * Aucune validation financière ici — Bellaïa prépare, Renée-Lise décide.
 */

// ── Types retournés ───────────────────────────────────────────────────────────

export interface Urgence {
  niveau:   "rouge" | "jaune" | "bleu";
  message:  string;
  entite:   "commande" | "stock" | "paiement" | "document" | "facture";
  id:       string;
  href:     string;
  action:   string;
}

export interface KpiSummary {
  commandes_actives:      number;
  commandes_urgentes:     number;
  ca_mois:                number;
  paiements_en_attente:   number;
  montant_en_attente:     number;
  alertes_stock:          number;
  ruptures_stock:         number;
  clientes_actives:       number;
  factures_a_regler:      number;
}

export interface DashboardSummary {
  kpis:             KpiSummary;
  urgences:         Urgence[];
  commandes_recent: RecentCommande[];
  stocks_alerte:    StockAlerte[];
  clientes_recent:  ClienteRecent[];
}

interface RecentCommande {
  id:          string;
  cliente_nom: string;
  total:       number;
  statut:      string;
  branche:     string;
  created_at:  string;
}

interface StockAlerte {
  produit_id:   string;
  produit_nom:  string;
  quantite:     number;
  unite:        string;
  statut_stock: "faible" | "rupture";
  branche:      string;
}

interface ClienteRecent {
  id:             string;
  nom:            string;
  statut_crm:     string;
  score_fidelite: number;
  ca_total:       number;
  univers:        string[];
}

// ── Handler ───────────────────────────────────────────────────────────────────

export async function GET() {
  // Vérification fondatrice
  const guard = await withFondatrice();
  if (!guard.ok) return guard.error;

  const { supabase } = guard;

  try {
    // ── Requêtes parallèles ─────────────────────────────────────────────────
    const [
      commandesRes,
      stocksRes,
      paiementsRes,
      clientesRes,
      facturesRes,
    ] = await Promise.all([

      // Commandes actives (hors livre/annule)
      supabase
        .from("commandes")
        .select("id, cliente_nom, total, statut, branche, created_at")
        .not("statut", "in", "(livre,annule)")
        .order("created_at", { ascending: false })
        .limit(20),

      // Stocks en alerte et rupture
      supabase
        .from("stocks_avec_statut")
        .select("produit_id, produit_nom, quantite, unite, statut_stock, branche")
        .in("statut_stock", ["faible", "rupture"])
        .order("statut_stock", { ascending: true }), // rupture en premier

      // Paiements en attente
      supabase
        .from("paiements")
        .select("id, montant, type_paiement, created_at")
        .eq("statut", "en_attente")
        .order("created_at", { ascending: false }),

      // Clientes récentes (5 dernières)
      supabase
        .from("clientes_crm")
        .select("id, nom, statut_crm, score_fidelite, ca_total, univers")
        .order("updated_at", { ascending: false })
        .limit(5),

      // Factures à régler
      supabase
        .from("factures")
        .select("id, client_nom, total_ttc, statut, branche")
        .in("statut", ["a_payer", "partiellement_paye"])
        .order("created_at", { ascending: false })
        .limit(10),
    ]);

    // ── CA du mois courant ──────────────────────────────────────────────────
    const debutMois = new Date();
    debutMois.setDate(1);
    debutMois.setHours(0, 0, 0, 0);

    const { data: paiementsMois } = await supabase
      .from("paiements")
      .select("montant")
      .eq("statut", "recu")
      .gte("date_reception", debutMois.toISOString());

    const caMois = (paiementsMois ?? []).reduce(
      (sum, p) => sum + (p.montant ?? 0),
      0
    );

    // ── Construction des urgences ───────────────────────────────────────────
    const urgences: Urgence[] = [];

    // Commandes demande_recue → urgence rouge
    const commandesUrgentes = (commandesRes.data ?? []).filter(
      (c) => c.statut === "demande_recue"
    );
    commandesUrgentes.forEach((c) => {
      urgences.push({
        niveau:  "rouge",
        message: `Commande ${c.cliente_nom} — validation requise`,
        entite:  "commande",
        id:      c.id,
        href:    `/commandes/${c.id}`,
        action:  "Valider la commande",
      });
    });

    // Ruptures stock → urgence rouge
    const ruptures = (stocksRes.data ?? []).filter(
      (s) => s.statut_stock === "rupture"
    );
    ruptures.forEach((s) => {
      urgences.push({
        niveau:  "rouge",
        message: `Rupture stock — ${s.produit_nom}`,
        entite:  "stock",
        id:      s.produit_id,
        href:    `/stocks`,
        action:  "Décider du réassort",
      });
    });

    // Paiements en attente → urgence jaune
    (paiementsRes.data ?? []).slice(0, 3).forEach((p) => {
      urgences.push({
        niveau:  "jaune",
        message: `Paiement ${p.montant.toFixed(2)} € en attente de validation`,
        entite:  "paiement",
        id:      p.id,
        href:    `/facturation`,
        action:  "Confirmer la réception",
      });
    });

    // Stocks faibles → urgence jaune
    const faibles = (stocksRes.data ?? []).filter(
      (s) => s.statut_stock === "faible"
    );
    faibles.slice(0, 2).forEach((s) => {
      urgences.push({
        niveau:  "jaune",
        message: `Stock faible — ${s.produit_nom} (${s.quantite} ${s.unite})`,
        entite:  "stock",
        id:      s.produit_id,
        href:    `/stocks`,
        action:  "Surveiller le stock",
      });
    });

    // Factures à régler → urgence bleu
    (facturesRes.data ?? []).slice(0, 2).forEach((f) => {
      urgences.push({
        niveau:  "bleu",
        message: `Facture ${f.client_nom} — ${f.total_ttc.toFixed(2)} € ${f.statut === "partiellement_paye" ? "(partiel)" : "à régler"}`,
        entite:  "facture",
        id:      f.id,
        href:    `/facturation/${f.id}`,
        action:  "Suivre le règlement",
      });
    });

    // ── KPIs ────────────────────────────────────────────────────────────────
    const totalPaiementsAttente = (paiementsRes.data ?? []).reduce(
      (sum, p) => sum + (p.montant ?? 0),
      0
    );

    const kpis: KpiSummary = {
      commandes_actives:    (commandesRes.data ?? []).length,
      commandes_urgentes:   commandesUrgentes.length,
      ca_mois:              caMois,
      paiements_en_attente: (paiementsRes.data ?? []).length,
      montant_en_attente:   totalPaiementsAttente,
      alertes_stock:        faibles.length,
      ruptures_stock:       ruptures.length,
      clientes_actives:     (clientesRes.data ?? []).filter(
        (c) => c.statut_crm === "active" || c.statut_crm === "vip"
      ).length,
      factures_a_regler:    (facturesRes.data ?? []).length,
    };

    // ── Réponse ─────────────────────────────────────────────────────────────
    const summary: DashboardSummary = {
      kpis,
      urgences,
      commandes_recent: (commandesRes.data ?? []).slice(0, 5) as RecentCommande[],
      stocks_alerte:    (stocksRes.data ?? []) as StockAlerte[],
      clientes_recent:  (clientesRes.data ?? []) as ClienteRecent[],
    };

    return NextResponse.json(summary);

  } catch (err) {
    console.error("[API /dashboard/summary]", err);
    return NextResponse.json(
      { error: "Erreur lors du chargement du tableau de bord." },
      { status: 500 }
    );
  }
}
