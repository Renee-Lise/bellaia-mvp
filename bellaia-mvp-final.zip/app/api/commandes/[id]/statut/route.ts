import { NextResponse }                        from "next/server";
import { withFondatrice }                      from "@/lib/auth/guards";
import { auditLog }                            from "@/lib/audit/logger";
import { STATUTS_COMMANDE_KEYS, STATUTS_FINANCIERS } from "@/constants/statuts";
import type { StatutCommande }                 from "@/constants/statuts";

/**
 * PUT /api/commandes/[id]/statut
 *
 * Change le statut d'une commande.
 * Fondatrice uniquement.
 * Chaque changement est enregistré dans commandes_historique ET audit_log.
 * Les statuts financiers déclenchent une entrée d'audit supplémentaire.
 *
 * Règle absolue :
 * Aucun statut financier (acompte_recu, paiement_complet, solde_restant)
 * ne peut être atteint sans validation fondatrice explicite côté client
 * (ValidationModal). Cette route ne vérifie pas si la modal a été affichée
 * — c'est le rôle fondatrice sur la route qui constitue la validation.
 */

// ── Transitions autorisées ────────────────────────────────────────────────────
// Empêche de revenir à un statut antérieur par erreur
// (null = toutes les transitions autorisées depuis ce statut)

const TRANSITIONS: Partial<Record<StatutCommande, StatutCommande[]>> = {
  demande_recue:          ["en_attente_validation", "annule"],
  en_attente_validation:  ["lien_paiement_envoye", "demande_recue", "annule"],
  lien_paiement_envoye:   ["acompte_recu", "paiement_complet", "en_attente_validation", "annule"],
  acompte_recu:           ["solde_restant", "paiement_complet", "confirme", "annule"],
  solde_restant:          ["paiement_complet", "annule"],
  paiement_complet:       ["confirme"],
  confirme:               ["en_preparation", "annule"],
  en_preparation:         ["livre"],
  livre:                  [], // terminal
  annule:                 [], // terminal
};

// ── Handler ───────────────────────────────────────────────────────────────────

export async function PUT(
  req: Request,
  { params }: { params: { id: string } }
) {
  // Vérification fondatrice — c'est la validation réelle
  const guard = await withFondatrice();
  if (!guard.ok) return guard.error;

  const { supabase, userId } = guard;
  const { id } = params;

  let body: { statut: string; commentaire?: string };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Corps de requête invalide." }, { status: 400 });
  }

  const nouveauStatut = body.statut as StatutCommande;
  const commentaire   = body.commentaire?.trim() ?? "";

  // Validation du statut cible
  if (!STATUTS_COMMANDE_KEYS.includes(nouveauStatut)) {
    return NextResponse.json(
      { error: `Statut invalide : "${nouveauStatut}".` },
      { status: 400 }
    );
  }

  // Récupérer la commande actuelle
  const { data: commande, error: fetchError } = await supabase
    .from("commandes")
    .select("id, statut, cliente_nom, total, acompte_paye, branche")
    .eq("id", id)
    .single();

  if (fetchError || !commande) {
    return NextResponse.json({ error: "Commande introuvable." }, { status: 404 });
  }

  const ancienStatut = commande.statut as StatutCommande;

  // Vérifier que la transition est autorisée
  const transitionsAutorisees = TRANSITIONS[ancienStatut];
  if (transitionsAutorisees !== undefined && transitionsAutorisees.length > 0) {
    if (!transitionsAutorisees.includes(nouveauStatut)) {
      return NextResponse.json(
        {
          error: `Transition non autorisée : "${ancienStatut}" → "${nouveauStatut}".`,
          transitions_autorisees: transitionsAutorisees,
        },
        { status: 422 }
      );
    }
  }

  // Bloquer si déjà dans un état terminal
  if (ancienStatut === "livre" || ancienStatut === "annule") {
    return NextResponse.json(
      { error: `La commande est "${ancienStatut}" et ne peut plus être modifiée.` },
      { status: 422 }
    );
  }

  // Pas de changement inutile
  if (ancienStatut === nouveauStatut) {
    return NextResponse.json(
      { error: "Le statut est déjà à cette valeur." },
      { status: 400 }
    );
  }

  try {
    // Mise à jour de la commande + historique + audit en parallèle
    const [updateRes] = await Promise.all([

      // 1. Mettre à jour le statut
      supabase
        .from("commandes")
        .update({
          statut:     nouveauStatut,
          updated_at: new Date().toISOString(),
        })
        .eq("id", id)
        .select()
        .single(),

      // 2. Enregistrer dans l'historique
      supabase
        .from("commandes_historique")
        .insert({
          commande_id:    id,
          ancien_statut:  ancienStatut,
          nouveau_statut: nouveauStatut,
          commentaire,
          fait_par:       userId,
        }),

      // 3. Audit log — une seule entrée par mutation
      auditLog({
        supabase,
        action:    "commande_statut_change",
        entite:    "commandes",
        entite_id: id,
        fait_par:  userId,
        valeur_avant: { statut: ancienStatut },
        valeur_apres: {
          statut:     nouveauStatut,
          commentaire: commentaire || null,
          financier:  STATUTS_FINANCIERS.includes(nouveauStatut),
          cliente_nom: commande.cliente_nom,
          total:       commande.total,
        },
      }),
    ]);

    const { data: commandeMaj, error: updateError } = updateRes;
    if (updateError) throw updateError;

    // Si statut financier : log supplémentaire pour la traçabilité comptable
    if (STATUTS_FINANCIERS.includes(nouveauStatut)) {
      await auditLog({
        supabase,
        action:    "paiement_marked_received",
        entite:    "commandes",
        entite_id: id,
        fait_par:  userId,
        valeur_apres: {
          statut:     nouveauStatut,
          total:      commande.total,
          acompte_paye: commande.acompte_paye,
          validee_par: "fondatrice",
        },
      });
    }

    return NextResponse.json({
      success:    true,
      commande:   commandeMaj,
      transition: { de: ancienStatut, vers: nouveauStatut },
    });

  } catch (err) {
    console.error("[PUT /api/commandes/:id/statut]", err);
    return NextResponse.json(
      { error: "Erreur lors du changement de statut." },
      { status: 500 }
    );
  }
}
