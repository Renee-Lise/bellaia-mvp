import { NextResponse }   from "next/server";
import { withFondatrice } from "@/lib/auth/guards";
import { auditLog }       from "@/lib/audit/logger";

/**
 * GET  /api/commandes/[id]   — Détail commande + historique
 * PUT  /api/commandes/[id]   — Mise à jour notes/lien Revolut (fondatrice)
 */

// ── GET — Détail ──────────────────────────────────────────────────────────────

export async function GET(
  _req: Request,
  { params }: { params: { id: string } }
) {
  const guard = await withFondatrice();
  if (!guard.ok) return guard.error;

  const { supabase } = guard;
  const { id } = params;

  try {
    // Commande principale
    const { data: commande, error } = await supabase
      .from("commandes")
      .select(`
        id,
        cliente_id,
        cliente_nom,
        branche,
        articles,
        total,
        acompte_attendu,
        acompte_paye,
        statut,
        lien_revolut,
        discretion_colis,
        adresse_livraison,
        notes_cliente,
        notes_admin,
        created_at,
        updated_at
      `)
      .eq("id", id)
      .single();

    if (error || !commande) {
      return NextResponse.json(
        { error: "Commande introuvable." },
        { status: 404 }
      );
    }

    // Historique des changements de statut
    const { data: historique } = await supabase
      .from("commandes_historique")
      .select("id, ancien_statut, nouveau_statut, commentaire, fait_par, created_at")
      .eq("commande_id", id)
      .order("created_at", { ascending: true });

    // Paiements liés
    const { data: paiements } = await supabase
      .from("paiements")
      .select("id, montant, type_paiement, mode, statut, lien_revolut, date_envoi_lien, date_reception, notes, created_at")
      .eq("commande_id", id)
      .order("created_at", { ascending: false });

    // Profil cliente (si lié)
    let cliente = null;
    if (commande.cliente_id) {
      const { data } = await supabase
        .from("clientes_crm")
        .select("id, nom, email, telephone, statut_crm, score_fidelite, univers")
        .eq("profile_id", commande.cliente_id)
        .single();
      cliente = data;
    }

    return NextResponse.json({
      commande,
      historique: historique ?? [],
      paiements:  paiements  ?? [],
      cliente,
    });
  } catch (err) {
    console.error("[GET /api/commandes/:id]", err);
    return NextResponse.json(
      { error: "Erreur lors du chargement de la commande." },
      { status: 500 }
    );
  }
}

// ── PUT — Mise à jour (notes / lien Revolut) ──────────────────────────────────

export async function PUT(
  req: Request,
  { params }: { params: { id: string } }
) {
  const guard = await withFondatrice();
  if (!guard.ok) return guard.error;

  const { supabase, userId } = guard;
  const { id } = params;

  let body: {
    notes_admin?:   string;
    lien_revolut?:  string;
    acompte_paye?:  number;
  };

  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Corps de requête invalide." }, { status: 400 });
  }

  // Vérifier que la commande existe
  const { data: avant, error: fetchError } = await supabase
    .from("commandes")
    .select("id, statut, notes_admin, lien_revolut, acompte_paye")
    .eq("id", id)
    .single();

  if (fetchError || !avant) {
    return NextResponse.json({ error: "Commande introuvable." }, { status: 404 });
  }

  // Construire les champs à mettre à jour
  const updates: Record<string, unknown> = {
    updated_at: new Date().toISOString(),
  };

  if (body.notes_admin  !== undefined) updates.notes_admin  = body.notes_admin;
  if (body.lien_revolut !== undefined) updates.lien_revolut = body.lien_revolut;
  if (body.acompte_paye !== undefined) {
    if (body.acompte_paye < 0) {
      return NextResponse.json({ error: "L'acompte ne peut pas être négatif." }, { status: 400 });
    }
    updates.acompte_paye = body.acompte_paye;
  }

  if (Object.keys(updates).length === 1) {
    return NextResponse.json({ error: "Aucun champ à mettre à jour." }, { status: 400 });
  }

  try {
    const { data, error } = await supabase
      .from("commandes")
      .update(updates)
      .eq("id", id)
      .select()
      .single();

    if (error) throw error;

    // Log si le lien Revolut a été défini
    if (body.lien_revolut && body.lien_revolut !== avant.lien_revolut) {
      await auditLog({
        supabase,
        action:    "commande_revolut_link_set",
        entite:    "commandes",
        entite_id: id,
        fait_par:  userId,
        valeur_apres: { lien_revolut: body.lien_revolut },
      });
    }

    return NextResponse.json({ commande: data });
  } catch (err) {
    console.error("[PUT /api/commandes/:id]", err);
    return NextResponse.json(
      { error: "Erreur lors de la mise à jour." },
      { status: 500 }
    );
  }
}
