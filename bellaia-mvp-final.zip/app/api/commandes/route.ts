import { NextResponse }      from "next/server";
import { withFondatrice }    from "@/lib/auth/guards";
import { withAuth }          from "@/lib/auth/guards";
import { auditLog }          from "@/lib/audit/logger";
import { createAdminClient } from "@/lib/supabase/server";
import type { StatutCommande } from "@/constants/statuts";

/**
 * GET  /api/commandes   — Liste toutes les commandes (fondatrice)
 * POST /api/commandes   — Crée une nouvelle commande (cliente ou fondatrice)
 */

// ── Types ─────────────────────────────────────────────────────────────────────

export interface ArticleCommande {
  produit_id:    string | null;
  nom:           string;
  description?:  string;
  quantite:      number;
  prix_unitaire: number;
  taille?:       string;
  couleur?:      string;
}

export interface CommandeCreateBody {
  cliente_nom:       string;
  branche?:          string;
  articles:          ArticleCommande[];
  total:             number;
  acompte_attendu?:  number;
  discretion_colis?: boolean;
  adresse_livraison?: {
    ligne1:    string;
    ligne2?:   string;
    ville:     string;
    code_postal: string;
    pays?:     string;
  };
  notes_cliente?: string;
}

// ── GET — Liste commandes ─────────────────────────────────────────────────────

export async function GET(req: Request) {
  const guard = await withFondatrice();
  if (!guard.ok) return guard.error;

  const { supabase } = guard;
  const { searchParams } = new URL(req.url);

  const statut  = searchParams.get("statut");
  const branche = searchParams.get("branche");
  const limit   = Math.min(parseInt(searchParams.get("limit") ?? "50"), 100);
  const offset  = parseInt(searchParams.get("offset") ?? "0");

  try {
    let query = supabase
      .from("commandes")
      .select(`
        id,
        cliente_id,
        cliente_nom,
        branche,
        articles,
        total,
        acompte_attendu,
        acompte_paye,
        statut,
        lien_revolut,
        discretion_colis,
        notes_cliente,
        notes_admin,
        created_at,
        updated_at
      `, { count: "exact" })
      .order("created_at", { ascending: false })
      .range(offset, offset + limit - 1);

    if (statut)  query = query.eq("statut",  statut);
    if (branche) query = query.eq("branche", branche);

    const { data, error, count } = await query;

    if (error) throw error;

    return NextResponse.json({
      commandes: data ?? [],
      total:     count ?? 0,
      limit,
      offset,
    });
  } catch (err) {
    console.error("[GET /api/commandes]", err);
    return NextResponse.json(
      { error: "Erreur lors du chargement des commandes." },
      { status: 500 }
    );
  }
}

// ── POST — Créer commande ─────────────────────────────────────────────────────

export async function POST(req: Request) {
  // La création peut venir d'une cliente authentifiée ou de la fondatrice
  const guard = await withAuth();
  if (!guard.ok) return guard.error;

  const { userId } = guard;

  let body: CommandeCreateBody;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Corps de requête invalide." }, { status: 400 });
  }

  // Validation minimale
  if (!body.cliente_nom?.trim()) {
    return NextResponse.json({ error: "Le nom de la cliente est requis." }, { status: 400 });
  }
  if (!Array.isArray(body.articles) || body.articles.length === 0) {
    return NextResponse.json({ error: "Au moins un article est requis." }, { status: 400 });
  }
  if (typeof body.total !== "number" || body.total <= 0) {
    return NextResponse.json({ error: "Le total doit être un nombre positif." }, { status: 400 });
  }

  // Recalcul du total côté serveur (sécurité)
  const totalServeur = body.articles.reduce(
    (sum, a) => sum + a.quantite * a.prix_unitaire,
    0
  );
  // Tolérance de 1 centime pour les arrondis
  if (Math.abs(totalServeur - body.total) > 0.01) {
    return NextResponse.json(
      { error: `Total incohérent : attendu ${totalServeur.toFixed(2)} €, reçu ${body.total.toFixed(2)} €.` },
      { status: 400 }
    );
  }

  // Utiliser le client admin pour bypasser RLS sur l'insertion
  // (une cliente insère sa propre commande)
  const admin = createAdminClient();

  try {
    const { data, error } = await admin
      .from("commandes")
      .insert({
        cliente_id:        userId,
        cliente_nom:       body.cliente_nom.trim(),
        branche:           body.branche ?? "secret_home",
        articles:          body.articles,
        total:             totalServeur,
        acompte_attendu:   body.acompte_attendu ?? 0,
        acompte_paye:      0,
        statut:            "demande_recue" as StatutCommande,
        discretion_colis:  body.discretion_colis ?? false,
        adresse_livraison: body.adresse_livraison ?? {},
        notes_cliente:     body.notes_cliente ?? "",
        notes_admin:       "",
      })
      .select()
      .single();

    if (error) throw error;

    // Audit
    await auditLog({
      supabase: admin,
      action:   "commande_created",
      entite:   "commandes",
      entite_id: data.id,
      fait_par:  userId,
      valeur_apres: {
        cliente_nom: data.cliente_nom,
        total:       data.total,
        statut:      data.statut,
      },
    });

    return NextResponse.json({ commande: data }, { status: 201 });
  } catch (err) {
    console.error("[POST /api/commandes]", err);
    return NextResponse.json(
      { error: "Erreur lors de la création de la commande." },
      { status: 500 }
    );
  }
}
