import { NextResponse }   from "next/server";
import { withFondatrice } from "@/lib/auth/guards";
import { auditLog }       from "@/lib/audit/logger";

/**
 * GET /api/automations/[id]             — Détail automation (workflow ou config)
 * PUT /api/automations/[id]?action=mark_read — Marquer notification lue (MVP: no-op)
 * PUT /api/automations/[id]?action=toggle    — Activer/désactiver
 */

export async function GET(
  _req: Request,
  { params }: { params: { id: string } }
) {
  const guard = await withFondatrice();
  if (!guard.ok) return guard.error;
  const { supabase } = guard;

  try {
    // Chercher dans memoire_metier si c'est une config d'automatisation créée manuellement
    const { data: config } = await supabase
      .from("memoire_metier")
      .select("id, label, valeur, created_at")
      .eq("id", params.id)
      .single();

    if (config) {
      let parsed: Record<string, unknown> = {};
      try { parsed = JSON.parse(config.valeur ?? "{}"); } catch {}
      return NextResponse.json({ automation: { id: config.id, ...parsed, created_at: config.created_at } });
    }

    return NextResponse.json({ error: "Automatisation introuvable." }, { status: 404 });
  } catch (err) {
    console.error("[GET /api/automations/:id]", err);
    return NextResponse.json({ error: "Erreur chargement." }, { status: 500 });
  }
}

export async function PUT(
  req: Request,
  { params }: { params: { id: string } }
) {
  const guard = await withFondatrice();
  if (!guard.ok) return guard.error;
  const { supabase, userId } = guard;

  const { searchParams } = new URL(req.url);
  const action = searchParams.get("action");

  // MVP : mark_read = no-op (pas de table notifications dédiée)
  if (action === "mark_read") {
    return NextResponse.json({ success: true });
  }

  // Toggle actif/inactif d'une config
  if (action === "toggle") {
    let body: { actif: boolean };
    try { body = await req.json(); }
    catch { return NextResponse.json({ error: "Corps invalide." }, { status: 400 }); }

    try {
      const { data: config } = await supabase
        .from("memoire_metier").select("valeur").eq("id", params.id).single();

      if (!config) return NextResponse.json({ error: "Introuvable." }, { status: 404 });

      let parsed: Record<string, unknown> = {};
      try { parsed = JSON.parse(config.valeur ?? "{}"); } catch {}
      parsed.actif = body.actif;

      const { error } = await supabase
        .from("memoire_metier")
        .update({ valeur: JSON.stringify(parsed) })
        .eq("id", params.id);

      if (error) throw error;

      await auditLog({ supabase, action: "memoire_added", entite: "memoire_metier",
        entite_id: params.id, fait_par: userId,
        valeur_apres: { toggle: body.actif ? "activated" : "deactivated" } });

      return NextResponse.json({ success: true, actif: body.actif });
    } catch (err) {
      console.error("[PUT /api/automations/:id toggle]", err);
      return NextResponse.json({ error: "Erreur toggle." }, { status: 500 });
    }
  }

  return NextResponse.json({ error: "Action non reconnue." }, { status: 400 });
}
