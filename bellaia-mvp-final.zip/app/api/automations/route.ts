import { NextResponse }   from "next/server";
import { withFondatrice } from "@/lib/auth/guards";
import { auditLog }       from "@/lib/audit/logger";
import { workflowCheckStockAlerts }        from "@/lib/workflows/check-stock-alerts";
import { workflowSendClientDocuments }     from "@/lib/workflows/send-client-documents";
import { workflowGenerateFollowupReminders } from "@/lib/workflows/generate-followup-reminders";
import { workflowProcessOrderStatus }      from "@/lib/workflows/process-order-status";
import { workflowAutoArchiveDocuments }    from "@/lib/workflows/auto-archive-documents";

/**
 * GET  /api/automations               — Liste automatisations + notifications
 * POST /api/automations               — Créer une automatisation
 * POST /api/automations?action=run    — Exécuter un workflow
 * PUT  /api/automations?action=mark_all_read — Marquer tout lu
 */

// Registre des workflows disponibles
const WORKFLOWS = {
  check_stock_alerts:          workflowCheckStockAlerts,
  send_client_documents:       workflowSendClientDocuments,
  generate_followup_reminders: workflowGenerateFollowupReminders,
  process_order_status:        workflowProcessOrderStatus,
  auto_archive_documents:      workflowAutoArchiveDocuments,
} as const;

type WorkflowKey = keyof typeof WORKFLOWS;

export async function GET(req: Request) {
  const guard = await withFondatrice();
  if (!guard.ok) return guard.error;
  const { supabase } = guard;

  const { searchParams } = new URL(req.url);
  const type = searchParams.get("type");

  try {
    // Mode notifications : retourner les entrées audit_log récentes comme notifications
    if (type === "notifications") {
      const limit = parseInt(searchParams.get("limit") ?? "50");

      const { data: logs } = await supabase
        .from("audit_log")
        .select("id, action, entite, entite_id, valeur_apres, created_at")
        .in("action", [
          "stock_alerte_triggered",
          "bellaia_rapport_generated",
          "commande_created",
          "paiement_marked_received",
        ])
        .order("created_at", { ascending: false })
        .limit(limit);

      // Transformer les logs en notifications
      const notifications = (logs ?? []).map((log) => {
        const va = log.valeur_apres as Record<string, unknown> | null;
        const niveau = log.action === "stock_alerte_triggered" ? "critique" :
                       log.action === "paiement_marked_received" ? "haute" : "normale";

        return {
          id:         log.id,
          niveau,
          entite:     log.entite === "stocks" ? "stock" : log.entite === "commandes" ? "commande" : "system",
          titre:      formatLogTitle(log.action),
          message:    (va as Record<string, unknown>)?.message_fondatrice as string
                      ?? (va as Record<string, unknown>)?.message as string
                      ?? formatLogTitle(log.action),
          href:       getLogHref(log.action, log.entite_id),
          lue:        false, // MVP : pas de persistance lu/non-lu
          created_at: log.created_at,
        };
      });

      return NextResponse.json({ notifications });
    }

    // Mode liste automatisations : retourner la liste des workflows disponibles
    const automations = Object.entries(WORKFLOWS).map(([key]) => ({
      id:            key,
      nom:           getWorkflowLabel(key as WorkflowKey),
      description:   getWorkflowDescription(key as WorkflowKey),
      icon:          getWorkflowIcon(key as WorkflowKey),
      categorie:     getWorkflowCategorie(key as WorkflowKey),
      status:        "active",
      derniere_exec: null,
      nb_executions: 0,
      nb_erreurs:    0,
      requiert_validation: key !== "auto_archive_documents",
    }));

    return NextResponse.json({ automations });
  } catch (err) {
    console.error("[GET /api/automations]", err);
    return NextResponse.json({ error: "Erreur chargement." }, { status: 500 });
  }
}

export async function POST(req: Request) {
  const guard = await withFondatrice();
  if (!guard.ok) return guard.error;
  const { supabase, userId } = guard;

  const { searchParams } = new URL(req.url);
  const action = searchParams.get("action");

  // Exécuter un workflow
  if (action === "run") {
    let body: { workflow: string };
    try { body = await req.json(); }
    catch { return NextResponse.json({ error: "Corps invalide." }, { status: 400 }); }

    const workflowFn = WORKFLOWS[body.workflow as WorkflowKey];
    if (!workflowFn)
      return NextResponse.json({ error: `Workflow inconnu : ${body.workflow}.` }, { status: 400 });

    try {
      const result = await workflowFn(userId);

      await auditLog({ supabase, action: "bellaia_tool_called", entite: "bellaia",
        fait_par: userId, valeur_apres: { workflow: body.workflow, success: true } });

      return NextResponse.json({ success: true, result, workflow: body.workflow });
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err);
      console.error(`[POST /api/automations run ${body.workflow}]`, message);
      return NextResponse.json({ error: message }, { status: 500 });
    }
  }

  // Créer une nouvelle config d'automatisation (sauvegardée en mémoire métier)
  let body: {
    nom: string; description: string; trigger: string;
    trigger_params: Record<string, unknown>; action: string;
    action_params: Record<string, unknown>; actif: boolean;
    requiert_validation: boolean;
  };
  try { body = await req.json(); }
  catch { return NextResponse.json({ error: "Corps invalide." }, { status: 400 }); }

  if (!body.nom?.trim())
    return NextResponse.json({ error: "Le nom est requis." }, { status: 400 });

  try {
    const { data, error } = await supabase
      .from("memoire_metier")
      .insert({
        label:      `AUTO: ${body.nom}`,
        univers:    "Automatisations",
        type:       "procedure",
        valeur:     JSON.stringify({
          nom: body.nom, description: body.description,
          trigger: body.trigger, trigger_params: body.trigger_params,
          action: body.action, action_params: body.action_params,
          actif: body.actif, requiert_validation: body.requiert_validation,
        }),
        statut:     "VALIDE",
        version:    "v1.0",
        valide_par: userId,
      })
      .select().single();

    if (error) throw error;

    await auditLog({ supabase, action: "memoire_added", entite: "memoire_metier",
      entite_id: data.id, fait_par: userId,
      valeur_apres: { type: "automatisation", nom: body.nom } });

    return NextResponse.json({ automation: { id: data.id, ...body } }, { status: 201 });
  } catch (err) {
    console.error("[POST /api/automations]", err);
    return NextResponse.json({ error: "Erreur création." }, { status: 500 });
  }
}

export async function PUT(req: Request) {
  const guard = await withFondatrice();
  if (!guard.ok) return guard.error;
  // mark_all_read : MVP no-op (pas de table dédiée)
  return NextResponse.json({ success: true });
}

// ── Helpers ───────────────────────────────────────────────────────────────────

function formatLogTitle(action: string): string {
  const map: Record<string, string> = {
    stock_alerte_triggered:    "Alertes stocks détectées",
    bellaia_rapport_generated: "Rapport Bellaïa généré",
    commande_created:          "Nouvelle commande reçue",
    paiement_marked_received:  "Paiement enregistré",
  };
  return map[action] ?? action;
}

function getLogHref(action: string, entityId: string | null): string | undefined {
  if (action === "commande_created" && entityId) return `/commandes/${entityId}`;
  if (action === "stock_alerte_triggered") return "/stocks";
  return undefined;
}

function getWorkflowLabel(key: WorkflowKey): string {
  const labels: Record<WorkflowKey, string> = {
    check_stock_alerts:          "Surveillance stocks",
    send_client_documents:       "Envoi documents clients",
    generate_followup_reminders: "Rappels de suivi",
    process_order_status:        "Analyse des commandes",
    auto_archive_documents:      "Archivage automatique",
  };
  return labels[key];
}

function getWorkflowDescription(key: WorkflowKey): string {
  const desc: Record<WorkflowKey, string> = {
    check_stock_alerts:          "Détecte les ruptures et stocks faibles, prépare les recommandations de réassort",
    send_client_documents:       "Identifie les documents validés prêts à envoyer, évite les doublons",
    generate_followup_reminders: "Génère les rappels clientes inactives, paiements en attente, sessions J-3, anniversaires",
    process_order_status:        "Analyse les commandes bloquées et prépare les actions prioritaires",
    auto_archive_documents:      "Archive les brouillons anciens et les doublons de documents",
  };
  return desc[key];
}

function getWorkflowIcon(key: WorkflowKey): string {
  const icons: Record<WorkflowKey, string> = {
    check_stock_alerts:          "📦",
    send_client_documents:       "📤",
    generate_followup_reminders: "🔔",
    process_order_status:        "◆",
    auto_archive_documents:      "📁",
  };
  return icons[key];
}

function getWorkflowCategorie(key: WorkflowKey): string {
  const cats: Record<WorkflowKey, string> = {
    check_stock_alerts:          "stocks",
    send_client_documents:       "documents",
    generate_followup_reminders: "crm",
    process_order_status:        "commandes",
    auto_archive_documents:      "archivage",
  };
  return cats[key];
}
