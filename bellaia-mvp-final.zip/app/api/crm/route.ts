import { NextResponse }   from "next/server";
import { withFondatrice } from "@/lib/auth/guards";
import { auditLog }       from "@/lib/audit/logger";

/**
 * GET  /api/crm   — Liste clientes avec filtres
 * POST /api/crm   — Créer une fiche cliente
 */

export async function GET(req: Request) {
  const guard = await withFondatrice();
  if (!guard.ok) return guard.error;
  const { supabase } = guard;

  const { searchParams } = new URL(req.url);
  const statut  = searchParams.get("statut");
  const search  = searchParams.get("search");
  const univers = searchParams.get("univers");
  const limit   = Math.min(parseInt(searchParams.get("limit") ?? "50"), 100);
  const offset  = parseInt(searchParams.get("offset") ?? "0");

  try {
    let q = supabase
      .from("clientes_crm")
      .select("id,nom,email,telephone,statut_crm,univers,score_fidelite,anniversaire,nb_achats,ca_total,notes_admin,updated_at,created_at", { count: "exact" })
      .order("updated_at", { ascending: false })
      .range(offset, offset + limit - 1);

    if (statut)  q = q.eq("statut_crm", statut);
    if (univers) q = q.contains("univers", [univers]);
    if (search)  q = q.or(`nom.ilike.%${search}%,email.ilike.%${search}%`);

    const { data, error, count } = await q;
    if (error) throw error;

    return NextResponse.json({ clientes: data ?? [], total: count ?? 0, limit, offset });
  } catch (err) {
    console.error("[GET /api/crm]", err);
    return NextResponse.json({ error: "Erreur chargement CRM." }, { status: 500 });
  }
}

export async function POST(req: Request) {
  const guard = await withFondatrice();
  if (!guard.ok) return guard.error;
  const { supabase, userId } = guard;

  let body: {
    nom: string; email?: string; telephone?: string;
    statut_crm?: string; univers?: string[];
    anniversaire?: string; preferences?: Record<string, unknown>;
    notes_admin?: string;
  };
  try { body = await req.json(); }
  catch { return NextResponse.json({ error: "Corps invalide." }, { status: 400 }); }

  if (!body.nom?.trim())
    return NextResponse.json({ error: "Le nom est requis." }, { status: 400 });

  try {
    const { data, error } = await supabase
      .from("clientes_crm")
      .insert({
        nom:           body.nom.trim(),
        email:         body.email?.trim()     ?? "",
        telephone:     body.telephone?.trim() ?? "",
        statut_crm:    body.statut_crm        ?? "prospect",
        univers:       body.univers           ?? [],
        score_fidelite: 0,
        anniversaire:  body.anniversaire      ?? null,
        preferences:   body.preferences      ?? {},
        nb_achats:     0,
        ca_total:      0,
        notes_admin:   body.notes_admin       ?? "",
      })
      .select().single();

    if (error) throw error;

    await auditLog({ supabase, action: "cliente_created", entite: "clientes_crm",
      entite_id: data.id, fait_par: userId, valeur_apres: { nom: data.nom, statut_crm: data.statut_crm } });

    return NextResponse.json({ cliente: data }, { status: 201 });
  } catch (err) {
    console.error("[POST /api/crm]", err);
    return NextResponse.json({ error: "Erreur création cliente." }, { status: 500 });
  }
}
