import { NextResponse }   from "next/server";
import { withFondatrice } from "@/lib/auth/guards";
import { auditLog }       from "@/lib/audit/logger";

/**
 * GET /api/crm/[id]   — Fiche cliente + commandes + documents
 * PUT /api/crm/[id]   — Mettre à jour fiche cliente
 */

export async function GET(
  _req: Request,
  { params }: { params: { id: string } }
) {
  const guard = await withFondatrice();
  if (!guard.ok) return guard.error;
  const { supabase } = guard;

  try {
    const [clienteRes, commandesRes, documentsRes] = await Promise.all([
      supabase.from("clientes_crm")
        .select("*").eq("id", params.id).single(),

      supabase.from("commandes")
        .select("id,total,statut,branche,created_at")
        .eq("cliente_id", params.id)
        .order("created_at", { ascending: false }).limit(20),

      supabase.from("documents_clients")
        .select("id,type,univers,statut,version,created_at")
        .eq("cliente_id", params.id)
        .order("created_at", { ascending: false }),
    ]);

    if (clienteRes.error || !clienteRes.data)
      return NextResponse.json({ error: "Cliente introuvable." }, { status: 404 });

    return NextResponse.json({
      cliente:   clienteRes.data,
      commandes: commandesRes.data  ?? [],
      documents: documentsRes.data  ?? [],
    });
  } catch (err) {
    console.error("[GET /api/crm/:id]", err);
    return NextResponse.json({ error: "Erreur chargement fiche." }, { status: 500 });
  }
}

export async function PUT(
  req: Request,
  { params }: { params: { id: string } }
) {
  const guard = await withFondatrice();
  if (!guard.ok) return guard.error;
  const { supabase, userId } = guard;

  let body: Record<string, unknown>;
  try { body = await req.json(); }
  catch { return NextResponse.json({ error: "Corps invalide." }, { status: 400 }); }

  const ALLOWED = ["nom","email","telephone","statut_crm","univers","score_fidelite","anniversaire","preferences","notes_admin"];
  const updates: Record<string, unknown> = { updated_at: new Date().toISOString() };
  for (const k of ALLOWED) { if (body[k] !== undefined) updates[k] = body[k]; }

  if (Object.keys(updates).length === 1)
    return NextResponse.json({ error: "Aucun champ à mettre à jour." }, { status: 400 });

  try {
    const { data: avant } = await supabase.from("clientes_crm").select("statut_crm,score_fidelite").eq("id", params.id).single();
    const { data, error } = await supabase.from("clientes_crm").update(updates).eq("id", params.id).select().single();
    if (error) throw error;

    await auditLog({ supabase, action: "cliente_updated", entite: "clientes_crm",
      entite_id: params.id, fait_par: userId,
      valeur_avant: avant ?? undefined, valeur_apres: updates });

    return NextResponse.json({ cliente: data });
  } catch (err) {
    console.error("[PUT /api/crm/:id]", err);
    return NextResponse.json({ error: "Erreur mise à jour." }, { status: 500 });
  }
}
