import { NextResponse }   from "next/server";
import { withFondatrice } from "@/lib/auth/guards";
import { auditLog }       from "@/lib/audit/logger";
import { STATUTS_DOC_KEYS } from "@/constants/statuts";
import type { StatutDoc }   from "@/constants/statuts";

/**
 * GET /api/documents/[id]           — Détail document
 * PUT /api/documents/[id]           — Mettre à jour contenu
 * PUT /api/documents/[id]?action=valider — Valider (BROUILLON → VALIDE)
 * PUT /api/documents/[id]?action=archiver — Archiver
 */

// Transitions autorisées
const TRANSITIONS: Partial<Record<StatutDoc, StatutDoc[]>> = {
  BROUILLON:  ["EN_REVISION", "VALIDE", "ARCHIVE"],
  EN_REVISION: ["VALIDE", "BROUILLON", "ARCHIVE"],
  VALIDE:     ["ARCHIVE"],
  ARCHIVE:    [], // terminal
};

export async function GET(
  _req: Request,
  { params }: { params: { id: string } }
) {
  const guard = await withFondatrice();
  if (!guard.ok) return guard.error;
  const { supabase } = guard;

  try {
    const { data: doc, error } = await supabase
      .from("documents_clients")
      .select("*")
      .eq("id", params.id)
      .single();

    if (error || !doc)
      return NextResponse.json({ error: "Document introuvable." }, { status: 404 });

    // Profil cliente si lié
    let cliente = null;
    if (doc.cliente_id) {
      const { data: c } = await supabase
        .from("clientes_crm")
        .select("id, nom, email, telephone, statut_crm")
        .eq("id", doc.cliente_id)
        .single();
      cliente = c;
    }

    return NextResponse.json({ document: doc, cliente });
  } catch (err) {
    console.error("[GET /api/documents/:id]", err);
    return NextResponse.json({ error: "Erreur chargement." }, { status: 500 });
  }
}

export async function PUT(
  req: Request,
  { params }: { params: { id: string } }
) {
  const guard = await withFondatrice();
  if (!guard.ok) return guard.error;
  const { supabase, userId } = guard;

  const { searchParams } = new URL(req.url);
  const action = searchParams.get("action");

  let body: Record<string, unknown>;
  try { body = await req.json(); }
  catch { return NextResponse.json({ error: "Corps invalide." }, { status: 400 }); }

  // Récupérer le document actuel
  const { data: docActuel, error: fetchErr } = await supabase
    .from("documents_clients")
    .select("id, statut, type, univers")
    .eq("id", params.id)
    .single();

  if (fetchErr || !docActuel)
    return NextResponse.json({ error: "Document introuvable." }, { status: 404 });

  try {
    // ── Changement de statut ──────────────────────────────────────────────
    if (action === "valider" || action === "archiver" || body.statut) {
      const cible = (action === "valider"  ? "VALIDE" :
                     action === "archiver" ? "ARCHIVE" :
                     body.statut as StatutDoc);

      if (!STATUTS_DOC_KEYS.includes(cible as StatutDoc))
        return NextResponse.json({ error: `Statut invalide : ${cible}.` }, { status: 400 });

      const transitionsOk = TRANSITIONS[docActuel.statut as StatutDoc] ?? [];
      if (!transitionsOk.includes(cible as StatutDoc))
        return NextResponse.json({
          error: `Transition non autorisée : ${docActuel.statut} → ${cible}.`,
          transitions_autorisees: transitionsOk,
        }, { status: 422 });

      const updates: Record<string, unknown> = { statut: cible };
      if (cible === "VALIDE") {
        updates.valide_par       = userId;
        updates.date_validation  = new Date().toISOString();
      }

      const { data, error } = await supabase
        .from("documents_clients")
        .update(updates)
        .eq("id", params.id)
        .select().single();

      if (error) throw error;

      await auditLog({ supabase, action: "document_statut_change", entite: "documents_clients",
        entite_id: params.id, fait_par: userId,
        valeur_avant:  { statut: docActuel.statut },
        valeur_apres:  { statut: cible } });

      return NextResponse.json({ document: data });
    }

    // ── Mise à jour du contenu ─────────────────────────────────────────────
    if (docActuel.statut === "ARCHIVE")
      return NextResponse.json({ error: "Un document archivé ne peut pas être modifié." }, { status: 422 });

    const ALLOWED_FIELDS = ["contenu", "version"];
    const updates: Record<string, unknown> = {};
    for (const k of ALLOWED_FIELDS) { if (body[k] !== undefined) updates[k] = body[k]; }

    if (Object.keys(updates).length === 0)
      return NextResponse.json({ error: "Aucun champ à mettre à jour." }, { status: 400 });

    const { data, error } = await supabase
      .from("documents_clients")
      .update(updates)
      .eq("id", params.id)
      .select().single();

    if (error) throw error;

    return NextResponse.json({ document: data });
  } catch (err) {
    console.error("[PUT /api/documents/:id]", err);
    return NextResponse.json({ error: "Erreur mise à jour." }, { status: 500 });
  }
}
