import { NextResponse }   from "next/server";
import { withFondatrice } from "@/lib/auth/guards";
import { auditLog }       from "@/lib/audit/logger";
import { STATUTS_DOC_KEYS, TYPES_DOCUMENT } from "@/constants/statuts";

/**
 * GET  /api/documents   — Liste documents clients avec filtres
 * POST /api/documents   — Créer un document (statut BROUILLON)
 */

const TYPES_VALIDES = TYPES_DOCUMENT.map((t) => t.key);

export async function GET(req: Request) {
  const guard = await withFondatrice();
  if (!guard.ok) return guard.error;
  const { supabase } = guard;

  const { searchParams } = new URL(req.url);
  const statut   = searchParams.get("statut");
  const type     = searchParams.get("type");
  const univers  = searchParams.get("univers");
  const clienteId = searchParams.get("cliente_id");
  const limit    = Math.min(parseInt(searchParams.get("limit") ?? "50"), 100);
  const offset   = parseInt(searchParams.get("offset") ?? "0");

  try {
    let q = supabase
      .from("documents_clients")
      .select(`
        id, type, univers, statut, version,
        cliente_id, valide_par, date_validation, created_at,
        clientes_crm!left(nom)
      `, { count: "exact" })
      .order("created_at", { ascending: false })
      .range(offset, offset + limit - 1);

    if (statut)    q = q.eq("statut",    statut);
    if (type)      q = q.eq("type",      type);
    if (univers)   q = q.eq("univers",   univers);
    if (clienteId) q = q.eq("cliente_id", clienteId);

    const { data, error, count } = await q;
    if (error) throw error;

    // Aplatir le nom de la cliente
    const documents = (data ?? []).map((d) => ({
      ...d,
      cliente_nom: (d as unknown as { clientes_crm: { nom: string } | null }).clientes_crm?.nom ?? null,
    }));

    return NextResponse.json({ documents, total: count ?? 0, limit, offset });
  } catch (err) {
    console.error("[GET /api/documents]", err);
    return NextResponse.json({ error: "Erreur chargement documents." }, { status: 500 });
  }
}

export async function POST(req: Request) {
  const guard = await withFondatrice();
  if (!guard.ok) return guard.error;
  const { supabase, userId } = guard;

  let body: {
    type:       string;
    univers:    string;
    cliente_id?: string;
    contenu?:   Record<string, unknown>;
    version?:   string;
  };
  try { body = await req.json(); }
  catch { return NextResponse.json({ error: "Corps invalide." }, { status: 400 }); }

  if (!TYPES_VALIDES.includes(body.type as typeof TYPES_VALIDES[number]))
    return NextResponse.json({ error: `Type invalide : ${body.type}.` }, { status: 400 });

  if (!body.univers?.trim())
    return NextResponse.json({ error: "L'univers est requis." }, { status: 400 });

  try {
    const { data, error } = await supabase
      .from("documents_clients")
      .insert({
        type:       body.type,
        univers:    body.univers.trim(),
        cliente_id: body.cliente_id ?? null,
        contenu:    body.contenu    ?? {},
        statut:     "BROUILLON",
        version:    body.version    ?? "v1.0",
      })
      .select().single();

    if (error) throw error;

    await auditLog({ supabase, action: "document_created", entite: "documents_clients",
      entite_id: data.id, fait_par: userId,
      valeur_apres: { type: data.type, univers: data.univers, statut: "BROUILLON" } });

    return NextResponse.json({ document: data }, { status: 201 });
  } catch (err) {
    console.error("[POST /api/documents]", err);
    return NextResponse.json({ error: "Erreur création document." }, { status: 500 });
  }
}
