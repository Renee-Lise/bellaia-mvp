import { NextResponse }   from "next/server";
import { withFondatrice } from "@/lib/auth/guards";
import { auditLog }       from "@/lib/audit/logger";

/**
 * PUT /api/stocks/[produit_id]
 * Enregistre un mouvement de stock et met à jour la quantité.
 * Fondatrice uniquement. Audit log systématique.
 */

const TYPES_VALIDES = ["vente", "retour", "ajustement", "reception"] as const;
type MouvType = typeof TYPES_VALIDES[number];

export async function PUT(
  req: Request,
  { params }: { params: { id: string } }
) {
  const guard = await withFondatrice();
  if (!guard.ok) return guard.error;
  const { supabase, userId } = guard;

  let body: { type: MouvType; quantite: number; raison?: string };
  try { body = await req.json(); }
  catch { return NextResponse.json({ error: "Corps invalide." }, { status: 400 }); }

  if (!TYPES_VALIDES.includes(body.type as MouvType))
    return NextResponse.json({ error: `Type invalide : ${body.type}.` }, { status: 400 });

  const qty = Number(body.quantite);
  if (isNaN(qty) || qty <= 0)
    return NextResponse.json({ error: "La quantité doit être un nombre positif." }, { status: 400 });

  try {
    // Récupérer le stock actuel
    const { data: stock, error: fetchErr } = await supabase
      .from("stocks").select("id,quantite,unite").eq("produit_id", params.id).single();

    if (fetchErr || !stock)
      return NextResponse.json({ error: "Stock introuvable." }, { status: 404 });

    // Calculer nouvelle quantité
    const delta = body.type === "vente" ? -qty : qty;
    const nouvelleQty = Math.max(0, stock.quantite + delta);

    // Mettre à jour le stock
    const { data: updated, error: updateErr } = await supabase
      .from("stocks")
      .update({ quantite: nouvelleQty, derniere_maj: new Date().toISOString() })
      .eq("id", stock.id)
      .select().single();

    if (updateErr) throw updateErr;

    // Enregistrer le mouvement dans l'historique
    await supabase.from("mouvements_stock").insert({
      produit_id: params.id,
      type:       body.type,
      quantite:   qty,
      raison:     body.raison ?? null,
      fait_par:   userId,
    });

    // Audit log — une seule entrée
    await auditLog({
      supabase, action: "stock_updated", entite: "stocks",
      entite_id: params.id, fait_par: userId,
      valeur_avant:  { quantite: stock.quantite },
      valeur_apres:  { quantite: nouvelleQty, type: body.type, delta },
    });

    return NextResponse.json({ success: true, stock: updated, nouvelle_quantite: nouvelleQty });
  } catch (err) {
    console.error("[PUT /api/stocks/:id]", err);
    return NextResponse.json({ error: "Erreur mise à jour stock." }, { status: 500 });
  }
}
