import { NextResponse }   from "next/server";
import { withFondatrice } from "@/lib/auth/guards";

/**
 * GET /api/stocks   — Vue complète stocks avec statuts calculés
 */

export async function GET(req: Request) {
  const guard = await withFondatrice();
  if (!guard.ok) return guard.error;
  const { supabase } = guard;

  const { searchParams } = new URL(req.url);
  const branche          = searchParams.get("branche");
  const alerteSeulement  = searchParams.get("alerte") === "1";

  try {
    let q = supabase
      .from("stocks_avec_statut")
      .select("produit_id,produit_nom,branche,categorie,quantite,unite,seuil_alerte,statut_stock,derniere_maj")
      .order("statut_stock", { ascending: true })   // rupture → faible → ok
      .order("produit_nom",  { ascending: true });

    if (branche)         q = q.eq("branche", branche);
    if (alerteSeulement) q = q.in("statut_stock", ["faible", "rupture"]);

    const { data, error } = await q;
    if (error) throw error;

    const stocks = data ?? [];
    return NextResponse.json({
      stocks,
      resume: {
        total:    stocks.length,
        ok:       stocks.filter((s) => s.statut_stock === "ok").length,
        faibles:  stocks.filter((s) => s.statut_stock === "faible").length,
        ruptures: stocks.filter((s) => s.statut_stock === "rupture").length,
      },
    });
  } catch (err) {
    console.error("[GET /api/stocks]", err);
    return NextResponse.json({ error: "Erreur chargement stocks." }, { status: 500 });
  }
}
