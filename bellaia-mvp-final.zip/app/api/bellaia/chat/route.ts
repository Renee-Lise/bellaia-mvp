import Anthropic          from "@anthropic-ai/sdk";
import { NextResponse }   from "next/server";
import { withFondatrice } from "@/lib/auth/guards";
import { auditLog }       from "@/lib/audit/logger";
import { buildPrompt }    from "@/lib/bellaia/system-prompt";
import { BELLAIA_TOOLS }  from "@/lib/bellaia/tools";
import { executeTool }    from "@/lib/bellaia/executor";

/**
 * POST /api/bellaia/chat
 *
 * Route principale du chatbot Bellaïa.
 * Gère la conversation multi-tours avec tool calling Anthropic.
 *
 * Corps de la requête :
 *   messages  — historique de la conversation (format Anthropic)
 *   branch    — branche active (optionnel)
 *   prenom    — prénom de la fondatrice (optionnel)
 *
 * La route boucle jusqu'à ce qu'Anthropic arrête d'appeler des outils
 * (stop_reason === "end_turn") ou atteigne MAX_TOOL_ITERATIONS.
 */

// ── Configuration ─────────────────────────────────────────────────────────────

const MAX_TOOL_ITERATIONS = 5; // Limite de tours d'outils par requête
const MAX_TOKENS          = 1500;
const MODEL               = "claude-sonnet-4-20250514";

// ── Types ─────────────────────────────────────────────────────────────────────

interface ChatRequestBody {
  messages: Anthropic.MessageParam[];
  branch?:  string;
  prenom?:  string;
}

// ── Handler ───────────────────────────────────────────────────────────────────

export async function POST(req: Request) {
  // Vérification fondatrice
  const guard = await withFondatrice();
  if (!guard.ok) return guard.error;

  const { userId, supabase } = guard;

  // Récupérer le profil pour le prénom
  const { data: profile } = await supabase
    .from("profiles")
    .select("prenom")
    .eq("id", userId)
    .single();

  // Parser le corps
  let body: ChatRequestBody;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Corps de requête invalide." }, { status: 400 });
  }

  const { messages, branch, prenom } = body;

  if (!Array.isArray(messages) || messages.length === 0) {
    return NextResponse.json({ error: "messages[] est requis." }, { status: 400 });
  }

  // Instancier le client Anthropic
  const anthropic = new Anthropic({
    apiKey: process.env.ANTHROPIC_API_KEY,
  });

  // Construire le system prompt avec le contexte
  const systemPrompt = buildPrompt({
    branch: branch ?? "Bella'Studio (global)",
    prenom: prenom ?? profile?.prenom ?? "Renée-Lise",
  });

  // Historique de travail (copie pour ne pas muter l'original)
  let workingMessages: Anthropic.MessageParam[] = [...messages];

  // ── Boucle tool calling ────────────────────────────────────────────────────
  let finalResponse: Anthropic.Message | null = null;
  let toolIterations = 0;

  while (toolIterations < MAX_TOOL_ITERATIONS) {
    // Appel Anthropic
    const response = await anthropic.messages.create({
      model:      MODEL,
      max_tokens: MAX_TOKENS,
      system:     systemPrompt,
      tools:      BELLAIA_TOOLS,
      messages:   workingMessages,
    });

    finalResponse = response;

    // Si Anthropic a terminé sa réponse sans appeler d'outil
    if (response.stop_reason === "end_turn") {
      break;
    }

    // Si Anthropic a demandé l'utilisation d'un ou plusieurs outils
    if (response.stop_reason === "tool_use") {
      toolIterations++;

      // Extraire tous les blocs tool_use de la réponse
      const toolUseBlocks = response.content.filter(
        (b): b is Anthropic.ToolUseBlock => b.type === "tool_use"
      );

      if (toolUseBlocks.length === 0) break;

      // Ajouter la réponse Anthropic à l'historique de travail
      workingMessages.push({
        role:    "assistant",
        content: response.content,
      });

      // Exécuter tous les outils en parallèle
      const toolResults = await Promise.all(
        toolUseBlocks.map(async (block) => {
          const result = await executeTool(
            block.name,
            block.input as Record<string, unknown>,
            userId
          );

          return {
            type:       "tool_result" as const,
            tool_use_id: block.id,
            content:     JSON.stringify(result.data),
            // Si l'outil a échoué, le signaler à Anthropic
            ...(result.success ? {} : { is_error: true }),
          };
        })
      );

      // Ajouter les résultats des outils à l'historique
      workingMessages.push({
        role:    "user",
        content: toolResults,
      });

      // Log de l'utilisation des outils
      await auditLog({
        supabase,
        action:    "bellaia_tool_called",
        entite:    "bellaia",
        fait_par:  userId,
        valeur_apres: {
          outils:     toolUseBlocks.map((b) => b.name),
          iteration:  toolIterations,
          branch:     branch ?? "global",
        },
      });

      continue; // Reprendre la boucle avec les résultats
    }

    // stop_reason inattendu — sortir de la boucle
    break;
  }

  if (!finalResponse) {
    return NextResponse.json(
      { error: "Aucune réponse générée." },
      { status: 500 }
    );
  }

  // ── Extraire le texte final ────────────────────────────────────────────────
  const textBlocks = finalResponse.content.filter(
    (b): b is Anthropic.TextBlock => b.type === "text"
  );

  const responseText = textBlocks.map((b) => b.text).join("\n").trim();

  if (!responseText) {
    return NextResponse.json(
      { error: "Réponse vide d'Anthropic." },
      { status: 500 }
    );
  }

  // ── Réponse au client ──────────────────────────────────────────────────────
  return NextResponse.json({
    response:        responseText,
    tool_iterations: toolIterations,
    // Retourner les messages de travail pour que le client puisse continuer
    // la conversation (sans les messages user tool_result internes)
    updated_messages: workingMessages,
    usage: {
      input_tokens:  finalResponse.usage.input_tokens,
      output_tokens: finalResponse.usage.output_tokens,
    },
  });
}
