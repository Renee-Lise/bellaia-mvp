import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title:       "Bellaïa Enterprise",
  description: "Executive Business Manager IA — Bella'Studio",
  robots:      "noindex, nofollow", // App privée
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="fr">
      <body>{children}</body>
    </html>
  );
}
