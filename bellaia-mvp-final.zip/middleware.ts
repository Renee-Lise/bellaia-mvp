import { createServerClient } from "@supabase/ssr";
import { NextResponse, type NextRequest } from "next/server";

/**
 * middleware.ts — racine du projet
 *
 * Protège toutes les routes authentifiées.
 * Exécuté sur chaque requête AVANT le rendu de la page.
 *
 * Logique :
 * 1. Rafraîchit la session Supabase (obligatoire avec SSR)
 * 2. Redirige vers /connexion si non authentifié sur route protégée
 * 3. Vérifie le rôle fondatrice sur les routes /dashboard, /commandes, etc.
 * 4. Redirige vers /espace si une cliente tente d'accéder aux routes fondatrice
 */

// ── Routes qui nécessitent le rôle "fondatrice" ───────────────────────────────
const FONDATRICE_PREFIXES = [
  "/dashboard",
  "/commandes",
  "/stocks",
  "/crm",
  "/facturation",
  "/documents",
  "/bellaia",
  "/audit",
  "/coffre-fort",
  "/fournisseurs",
  "/collaborateurs",
  "/brand-center",
  "/media",
  "/marketing",
];

// ── Routes qui nécessitent uniquement d'être authentifié (clientes) ───────────
const CLIENTE_PREFIXES = ["/espace"];

// ── Routes publiques (pas de vérification) ────────────────────────────────────
// /connexion, /inscription, /cgv, /mentions-legales, /confidentialite
// /api/auth/callback, /_next/*, /favicon.ico

export async function middleware(request: NextRequest) {
  let response = NextResponse.next({
    request,
  });

  // ── Initialiser le client Supabase SSR ──────────────────────────────────────
  const supabase = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        getAll() {
          return request.cookies.getAll();
        },
        setAll(cookiesToSet) {
          // Appliquer les cookies à la requête entrante
          cookiesToSet.forEach(({ name, value }) =>
            request.cookies.set(name, value)
          );
          // Recréer la réponse avec les nouveaux cookies
          response = NextResponse.next({ request });
          cookiesToSet.forEach(({ name, value, options }) =>
            response.cookies.set(name, value, options)
          );
        },
      },
    }
  );

  // ── Rafraîchir la session (obligatoire — ne pas supprimer) ──────────────────
  // getUser() valide le JWT côté serveur et rafraîchit le token si nécessaire.
  const {
    data: { user },
  } = await supabase.auth.getUser();

  const { pathname } = request.nextUrl;

  // ── Vérifier si la route nécessite le rôle fondatrice ──────────────────────
  const isFondatriceRoute = FONDATRICE_PREFIXES.some((prefix) =>
    pathname.startsWith(prefix)
  );

  // ── Vérifier si la route nécessite d'être authentifié (cliente) ────────────
  const isClienteRoute = CLIENTE_PREFIXES.some((prefix) =>
    pathname.startsWith(prefix)
  );

  // ── Cas 1 : Route protégée — utilisateur non connecté ──────────────────────
  if ((isFondatriceRoute || isClienteRoute) && !user) {
    const redirectUrl = request.nextUrl.clone();
    redirectUrl.pathname = "/connexion";
    redirectUrl.searchParams.set("redirectTo", pathname);
    return NextResponse.redirect(redirectUrl);
  }

  // ── Cas 2 : Route fondatrice — vérifier le rôle ────────────────────────────
  if (isFondatriceRoute && user) {
    const { data: profile } = await supabase
      .from("profiles")
      .select("role")
      .eq("id", user.id)
      .single();

    if (!profile || profile.role !== "fondatrice") {
      // Rediriger les clientes vers leur espace
      const redirectUrl = request.nextUrl.clone();
      redirectUrl.pathname = "/espace";
      return NextResponse.redirect(redirectUrl);
    }
  }

  // ── Cas 3 : Utilisateur connecté tente d'accéder à /connexion ──────────────
  if (pathname === "/connexion" && user) {
    const { data: profile } = await supabase
      .from("profiles")
      .select("role")
      .eq("id", user.id)
      .single();

    const redirectUrl = request.nextUrl.clone();
    redirectUrl.pathname =
      profile?.role === "fondatrice" ? "/dashboard" : "/espace";
    return NextResponse.redirect(redirectUrl);
  }

  return response;
}

// ── Matcher : exclure les fichiers statiques et l'API auth ───────────────────
export const config = {
  matcher: [
    /*
     * Appliquer le middleware sur toutes les routes sauf :
     * - _next/static  (fichiers statiques Next.js)
     * - _next/image   (optimisation images)
     * - favicon.ico
     * - api/auth      (callbacks Supabase auth)
     * - fichiers avec extension (.png, .jpg, .svg, etc.)
     */
    "/((?!_next/static|_next/image|favicon\\.ico|api/auth|.*\\.(?:svg|png|jpg|jpeg|gif|webp|ico|css|js)$).*)",
  ],
};
