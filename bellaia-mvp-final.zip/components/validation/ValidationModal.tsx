"use client";

import { useEffect, useRef } from "react";
import type { ValidationControls } from "@/hooks/useValidation";

/**
 * components/validation/ValidationModal.tsx
 *
 * Modal de confirmation pour toutes les actions fondatrice critiques.
 * Affiche le résumé de l'action, son impact, et demande confirmation.
 *
 * Usage :
 *   const validation = useValidation();
 *   return (
 *     <>
 *       <button onClick={() => validation.request({ ... })}>Valider</button>
 *       <ValidationModal validation={validation} />
 *     </>
 *   );
 */

interface Props {
  validation: Pick<
    ValidationControls,
    "pending" | "isLoading" | "error" | "motif" | "setMotif" | "confirm" | "cancel"
  >;
}

export function ValidationModal({ validation }: Props) {
  const { pending, isLoading, error, motif, setMotif, confirm, cancel } =
    validation;

  const confirmBtnRef = useRef<HTMLButtonElement>(null);
  const textareaRef   = useRef<HTMLTextAreaElement>(null);

  // ── Focus automatique à l'ouverture ────────────────────────────────────────
  useEffect(() => {
    if (pending) {
      setTimeout(() => textareaRef.current?.focus(), 50);
    }
  }, [pending]);

  // ── Fermer avec Escape ─────────────────────────────────────────────────────
  useEffect(() => {
    if (!pending) return;
    const handler = (e: KeyboardEvent) => {
      if (e.key === "Escape" && !isLoading) cancel();
    };
    document.addEventListener("keydown", handler);
    return () => document.removeEventListener("keydown", handler);
  }, [pending, isLoading, cancel]);

  // ── Bloquer le scroll du body quand la modal est ouverte ───────────────────
  useEffect(() => {
    if (pending) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "";
    }
    return () => {
      document.body.style.overflow = "";
    };
  }, [pending]);

  if (!pending) return null;

  return (
    // ── Overlay ──────────────────────────────────────────────────────────────
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      style={{ backgroundColor: "rgba(0, 0, 0, 0.72)" }}
      onClick={(e) => {
        // Fermer en cliquant sur l'overlay (pas sur la modal)
        if (e.target === e.currentTarget && !isLoading) cancel();
      }}
    >
      {/* ── Modal ──────────────────────────────────────────────────────────── */}
      <div
        className="relative w-full max-w-md animate-bellaia-fade-in"
        style={{
          background:   "#120A10",
          border:       "1px solid rgba(201, 168, 76, 0.30)",
          borderRadius: "16px",
          boxShadow:    "0 24px 64px rgba(0, 0, 0, 0.6)",
        }}
        role="dialog"
        aria-modal="true"
        aria-labelledby="validation-title"
      >
        {/* ── Header ────────────────────────────────────────────────────────── */}
        <div
          className="flex items-center gap-3 px-6 py-5"
          style={{ borderBottom: "1px solid rgba(201, 168, 76, 0.12)" }}
        >
          <div
            className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full text-base"
            style={{ background: "rgba(160, 32, 16, 0.18)" }}
          >
            🔒
          </div>
          <div>
            <p
              id="validation-title"
              className="font-semibold text-sm"
              style={{ color: "#C9A84C", letterSpacing: "0.04em" }}
            >
              Validation Fondatrice Obligatoire
            </p>
            <p className="text-xs mt-0.5" style={{ color: "rgba(240, 232, 216, 0.45)" }}>
              {pending.titre}
            </p>
          </div>
        </div>

        {/* ── Corps ─────────────────────────────────────────────────────────── */}
        <div className="px-6 py-5 space-y-4">

          {/* Résumé de l'action */}
          <div
            className="rounded-xl p-4 text-sm leading-relaxed"
            style={{
              background: "rgba(240, 232, 216, 0.04)",
              border:     "1px solid rgba(240, 232, 216, 0.08)",
              color:      "rgba(240, 232, 216, 0.85)",
            }}
          >
            {pending.resume}
          </div>

          {/* Impact */}
          <div
            className="rounded-lg px-4 py-3 text-xs leading-relaxed"
            style={{
              background: "rgba(255, 152, 0, 0.08)",
              border:     "1px solid rgba(255, 152, 0, 0.20)",
              color:      "rgba(255, 190, 80, 0.90)",
            }}
          >
            <span className="font-semibold">Impact : </span>
            {pending.impact}
          </div>

          {/* Motif optionnel */}
          <div>
            <label
              htmlFor="validation-motif"
              className="block text-xs mb-2"
              style={{ color: "rgba(240, 232, 216, 0.45)", letterSpacing: "0.06em" }}
            >
              MOTIF (optionnel)
            </label>
            <textarea
              id="validation-motif"
              ref={textareaRef}
              value={motif}
              onChange={(e) => setMotif(e.target.value)}
              disabled={isLoading}
              rows={2}
              placeholder="Ajouter un motif ou une note…"
              className="w-full resize-none rounded-lg px-3 py-2.5 text-sm transition-colors"
              style={{
                background:  "rgba(255, 255, 255, 0.04)",
                border:      "1px solid rgba(201, 168, 76, 0.18)",
                color:       "rgba(240, 232, 216, 0.85)",
                outline:     "none",
              }}
              onFocus={(e) => {
                e.currentTarget.style.borderColor = "rgba(201, 168, 76, 0.45)";
              }}
              onBlur={(e) => {
                e.currentTarget.style.borderColor = "rgba(201, 168, 76, 0.18)";
              }}
            />
          </div>

          {/* Erreur */}
          {error && (
            <div
              className="rounded-lg px-4 py-3 text-xs"
              style={{
                background: "rgba(244, 67, 54, 0.10)",
                border:     "1px solid rgba(244, 67, 54, 0.25)",
                color:      "#F44336",
              }}
            >
              {error}
            </div>
          )}

          {/* Avertissement audit */}
          <p
            className="text-center text-xs"
            style={{ color: "rgba(240, 232, 216, 0.25)" }}
          >
            Cette action sera enregistrée dans le journal d&apos;audit Bellaïa.
          </p>
        </div>

        {/* ── Boutons ────────────────────────────────────────────────────────── */}
        <div
          className="flex gap-3 px-6 pb-6"
        >
          {/* Annuler */}
          <button
            type="button"
            onClick={cancel}
            disabled={isLoading}
            className="flex-1 rounded-xl py-3 text-sm font-medium transition-all"
            style={{
              background: "rgba(255, 255, 255, 0.04)",
              border:     "1px solid rgba(255, 255, 255, 0.10)",
              color:      "rgba(240, 232, 216, 0.50)",
              cursor:     isLoading ? "not-allowed" : "pointer",
            }}
            onMouseEnter={(e) => {
              if (!isLoading)
                e.currentTarget.style.background = "rgba(255, 255, 255, 0.07)";
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.background = "rgba(255, 255, 255, 0.04)";
            }}
          >
            Annuler
          </button>

          {/* Confirmer */}
          <button
            type="button"
            ref={confirmBtnRef}
            onClick={confirm}
            disabled={isLoading}
            className="flex-1 rounded-xl py-3 text-sm font-bold transition-all"
            style={{
              background: isLoading
                ? "rgba(201, 168, 76, 0.30)"
                : "linear-gradient(135deg, #C9A84C, #5C2D5C)",
              border:     "none",
              color:      isLoading ? "rgba(240, 232, 216, 0.40)" : "#0C0810",
              cursor:     isLoading ? "not-allowed" : "pointer",
            }}
          >
            {isLoading ? (
              <span className="flex items-center justify-center gap-2">
                <LoadingDots />
                Validation…
              </span>
            ) : (
              "Je valide — Renée-Lise"
            )}
          </button>
        </div>
      </div>
    </div>
  );
}

// ── Composant interne : points de chargement ──────────────────────────────────
function LoadingDots() {
  return (
    <span className="flex gap-1">
      {[0, 1, 2].map((i) => (
        <span
          key={i}
          className="inline-block h-1.5 w-1.5 rounded-full"
          style={{
            background:      "#C9A84C",
            animation:       "bellaia-pulse 1.2s ease-in-out infinite",
            animationDelay:  `${i * 0.2}s`,
          }}
        />
      ))}
    </span>
  );
}
