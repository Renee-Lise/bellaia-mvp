/**
 * components/dashboard/KpiCard.tsx
 *
 * Carte d'indicateur clé (KPI).
 * Affiche une valeur principale, un libellé, un sous-texte,
 * et un indicateur de tendance optionnel.
 */

interface KpiCardProps {
  /** Libellé de l'indicateur */
  label:       string;
  /** Valeur principale (string pour gérer €, %, nombres) */
  value:       string | number;
  /** Sous-texte informatif */
  subtext?:    string;
  /** Couleur de la valeur principale */
  color?:      string;
  /** Icône ou emoji affiché en haut à droite */
  icon?:       string;
  /** Tendance : positive (vert), negative (rouge), neutre (gris) */
  trend?:      "up" | "down" | "neutral";
  /** Valeur de la tendance ex: "+12%" */
  trendValue?: string;
  /** Rendre la carte cliquable */
  href?:       string;
  /** Highlight de bordure (urgence) */
  urgent?:     boolean;
  /** État de chargement */
  loading?:    boolean;
}

export function KpiCard({
  label,
  value,
  subtext,
  color    = "#C9A84C",
  icon,
  trend,
  trendValue,
  urgent   = false,
  loading  = false,
}: KpiCardProps) {
  // Couleurs tendance
  const trendColor =
    trend === "up"   ? "#4CAF50" :
    trend === "down" ? "#F44336" :
    "rgba(240,232,216,0.35)";

  const trendSymbol =
    trend === "up"   ? "↑" :
    trend === "down" ? "↓" :
    "→";

  return (
    <div
      style={{
        background:   "#120A10",
        border:       `1px solid ${urgent
          ? "rgba(244, 67, 54, 0.35)"
          : `${color}28`}`,
        borderRadius: "12px",
        padding:      "16px 18px",
        transition:   "border-color 0.2s",
        position:     "relative",
        overflow:     "hidden",
      }}
    >
      {/* Fond ambiance couleur */}
      <div
        style={{
          position:   "absolute",
          inset:      0,
          background: `radial-gradient(ellipse 80% 60% at 80% 20%, ${color}0A 0%, transparent 70%)`,
          pointerEvents: "none",
        }}
      />

      {/* Contenu */}
      <div style={{ position: "relative" }}>
        {/* Header : label + icône */}
        <div
          style={{
            display:        "flex",
            justifyContent: "space-between",
            alignItems:     "flex-start",
            marginBottom:   "8px",
          }}
        >
          <p
            style={{
              fontSize:      "9px",
              color:         "rgba(240,232,216,0.38)",
              letterSpacing: "0.16em",
              textTransform: "uppercase",
              fontFamily:    "Arial, sans-serif",
            }}
          >
            {label}
          </p>
          {icon && (
            <span
              style={{
                fontSize: "14px",
                opacity:  0.55,
              }}
            >
              {icon}
            </span>
          )}
        </div>

        {/* Valeur principale */}
        {loading ? (
          <div
            style={{
              height:       "32px",
              width:        "60%",
              background:   "rgba(255,255,255,0.06)",
              borderRadius: "6px",
              animation:    "bellaia-pulse 1.4s ease-in-out infinite",
            }}
          />
        ) : (
          <p
            style={{
              fontSize:   "26px",
              fontWeight: "700",
              color:      urgent ? "#F44336" : color,
              lineHeight: "1.15",
              fontFamily: "Arial, sans-serif",
            }}
          >
            {value}
          </p>
        )}

        {/* Sous-texte et tendance */}
        {(subtext || trendValue) && (
          <div
            style={{
              display:    "flex",
              alignItems: "center",
              gap:        "8px",
              marginTop:  "6px",
            }}
          >
            {subtext && (
              <p
                style={{
                  fontSize:   "11px",
                  color:      "rgba(240,232,216,0.38)",
                  flex:       1,
                  fontFamily: "Arial, sans-serif",
                }}
              >
                {subtext}
              </p>
            )}
            {trendValue && (
              <span
                style={{
                  fontSize:   "10px",
                  color:      trendColor,
                  fontWeight: "600",
                  fontFamily: "Arial, sans-serif",
                }}
              >
                {trendSymbol} {trendValue}
              </span>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
