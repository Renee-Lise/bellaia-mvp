"use client";

import Link from "next/link";
import type { DashboardSummary } from "@/app/api/dashboard/summary/route";

/**
 * components/dashboard/FinanceWidget.tsx
 *
 * Widget finance du tableau de bord fondatrice.
 * Affiche CA du mois, paiements en attente, et commandes récentes.
 *
 * Règle absolue :
 * Ce widget est en LECTURE SEULE.
 * Toute validation de paiement se fait sur /facturation ou /commandes,
 * avec confirmation fondatrice explicite via ValidationModal.
 */

interface FinanceWidgetProps {
  data:    DashboardSummary | null;
  loading: boolean;
}

// ── Helpers ───────────────────────────────────────────────────────────────────

function formatEur(value: number): string {
  return new Intl.NumberFormat("fr-FR", {
    style:                 "currency",
    currency:              "EUR",
    minimumFractionDigits: 0,
    maximumFractionDigits: 2,
  }).format(value);
}

function formatDate(isoStr: string): string {
  return new Date(isoStr).toLocaleDateString("fr-FR", {
    day:   "numeric",
    month: "short",
  });
}

// Config couleur par statut commande
const STATUT_COLORS: Record<string, string> = {
  demande_recue:          "#7EB8C4",
  en_attente_validation:  "#C9A84C",
  lien_paiement_envoye:   "#9B6B9E",
  acompte_recu:           "#E8A4B8",
  paiement_complet:       "#4CAF50",
  solde_restant:          "#FF9800",
  confirme:               "#4CAF50",
  en_preparation:         "#C9A84C",
  livre:                  "#4CAF50",
  annule:                 "#F44336",
};

const STATUT_LABELS: Record<string, string> = {
  demande_recue:          "Demande reçue",
  en_attente_validation:  "En attente",
  lien_paiement_envoye:   "Lien envoyé",
  acompte_recu:           "Acompte reçu",
  paiement_complet:       "Payé",
  solde_restant:          "Solde restant",
  confirme:               "Confirmé",
  en_preparation:         "En préparation",
  livre:                  "Livré",
  annule:                 "Annulé",
};

// ── Composant ─────────────────────────────────────────────────────────────────

export function FinanceWidget({ data, loading }: FinanceWidgetProps) {
  const kpis      = data?.kpis;
  const commandes = data?.commandes_recent ?? [];

  return (
    <div
      style={{
        background:   "#120A10",
        border:       "1px solid rgba(201, 168, 76, 0.15)",
        borderRadius: "12px",
        padding:      "18px",
        height:       "100%",
        display:      "flex",
        flexDirection: "column",
        gap:          "16px",
      }}
    >
      {/* ── Header ─────────────────────────────────────────────────────────── */}
      <p
        style={{
          fontSize:      "9px",
          color:         "#C9A84C",
          letterSpacing: "0.20em",
          textTransform: "uppercase",
          fontWeight:    "700",
          fontFamily:    "Arial, sans-serif",
        }}
      >
        ◉ Finance — Vue du mois
      </p>

      {/* ── Métriques financières ──────────────────────────────────────────── */}
      <div
        style={{
          display:             "grid",
          gridTemplateColumns: "1fr 1fr",
          gap:                 "10px",
        }}
      >
        {/* CA du mois */}
        <div
          style={{
            padding:      "12px",
            background:   "rgba(201, 168, 76, 0.07)",
            borderRadius: "9px",
            border:       "1px solid rgba(201, 168, 76, 0.15)",
          }}
        >
          <p
            style={{
              fontSize:      "8px",
              color:         "rgba(240,232,216,0.38)",
              letterSpacing: "0.12em",
              textTransform: "uppercase",
              marginBottom:  "4px",
              fontFamily:    "Arial, sans-serif",
            }}
          >
            CA ce mois
          </p>
          {loading ? (
            <Skeleton w="70%" h="22px" />
          ) : (
            <p
              style={{
                fontSize:   "20px",
                fontWeight: "700",
                color:      "#C9A84C",
                fontFamily: "Arial, sans-serif",
              }}
            >
              {formatEur(kpis?.ca_mois ?? 0)}
            </p>
          )}
        </div>

        {/* Paiements en attente */}
        <div
          style={{
            padding:      "12px",
            background:   (kpis?.montant_en_attente ?? 0) > 0
              ? "rgba(255, 152, 0, 0.07)"
              : "rgba(255,255,255,0.03)",
            borderRadius: "9px",
            border:       `1px solid ${
              (kpis?.montant_en_attente ?? 0) > 0
                ? "rgba(255, 152, 0, 0.20)"
                : "rgba(255,255,255,0.06)"
            }`,
          }}
        >
          <p
            style={{
              fontSize:      "8px",
              color:         "rgba(240,232,216,0.38)",
              letterSpacing: "0.12em",
              textTransform: "uppercase",
              marginBottom:  "4px",
              fontFamily:    "Arial, sans-serif",
            }}
          >
            En attente
          </p>
          {loading ? (
            <Skeleton w="60%" h="22px" />
          ) : (
            <p
              style={{
                fontSize:   "20px",
                fontWeight: "700",
                color:      (kpis?.montant_en_attente ?? 0) > 0 ? "#FF9800" : "rgba(240,232,216,0.35)",
                fontFamily: "Arial, sans-serif",
              }}
            >
              {formatEur(kpis?.montant_en_attente ?? 0)}
            </p>
          )}
        </div>
      </div>

      {/* Note gouvernance */}
      <div
        style={{
          padding:      "8px 12px",
          background:   "rgba(160, 32, 16, 0.06)",
          borderRadius: "7px",
          border:       "1px solid rgba(160, 32, 16, 0.15)",
        }}
      >
        <p
          style={{
            fontSize:   "10px",
            color:      "rgba(220, 100, 80, 0.75)",
            fontStyle:  "italic",
            fontFamily: "Arial, sans-serif",
          }}
        >
          🔒 Toute validation de paiement nécessite une confirmation fondatrice.
        </p>
      </div>

      {/* ── Commandes récentes ────────────────────────────────────────────── */}
      <div style={{ flex: 1 }}>
        <div
          style={{
            display:        "flex",
            justifyContent: "space-between",
            alignItems:     "center",
            marginBottom:   "10px",
          }}
        >
          <p
            style={{
              fontSize:      "9px",
              color:         "rgba(240,232,216,0.38)",
              letterSpacing: "0.12em",
              textTransform: "uppercase",
              fontFamily:    "Arial, sans-serif",
            }}
          >
            Commandes récentes
          </p>
          <Link
            href="/commandes"
            style={{
              fontSize:   "10px",
              color:      "rgba(201,168,76,0.60)",
              textDecoration: "none",
              fontFamily: "Georgia, serif",
            }}
          >
            Voir tout →
          </Link>
        </div>

        {loading ? (
          <div style={{ display: "flex", flexDirection: "column", gap: "6px" }}>
            {[0, 1, 2].map((i) => (
              <Skeleton key={i} w="100%" h="36px" delay={i * 0.1} />
            ))}
          </div>
        ) : commandes.length === 0 ? (
          <p
            style={{
              fontSize:   "12px",
              color:      "rgba(240,232,216,0.30)",
              textAlign:  "center",
              padding:    "12px 0",
              fontFamily: "Arial, sans-serif",
            }}
          >
            Aucune commande active
          </p>
        ) : (
          <div style={{ display: "flex", flexDirection: "column", gap: "5px" }}>
            {commandes.map((cmd) => {
              const sColor = STATUT_COLORS[cmd.statut]  ?? "#888";
              const sLabel = STATUT_LABELS[cmd.statut]  ?? cmd.statut;

              return (
                <Link
                  key={cmd.id}
                  href={`/commandes/${cmd.id}`}
                  style={{
                    display:        "flex",
                    alignItems:     "center",
                    gap:            "10px",
                    padding:        "8px 10px",
                    borderRadius:   "7px",
                    background:     "rgba(255,255,255,0.03)",
                    border:         "1px solid rgba(255,255,255,0.06)",
                    textDecoration: "none",
                    transition:     "background 0.15s",
                  }}
                  onMouseEnter={(e) => {
                    (e.currentTarget as HTMLAnchorElement).style.background =
                      "rgba(255,255,255,0.06)";
                  }}
                  onMouseLeave={(e) => {
                    (e.currentTarget as HTMLAnchorElement).style.background =
                      "rgba(255,255,255,0.03)";
                  }}
                >
                  {/* Dot statut */}
                  <div
                    style={{
                      width:        "6px",
                      height:       "6px",
                      borderRadius: "50%",
                      background:   sColor,
                      flexShrink:   0,
                    }}
                  />

                  {/* Nom cliente */}
                  <p
                    style={{
                      flex:         1,
                      fontSize:     "11px",
                      color:        "rgba(240,232,216,0.80)",
                      overflow:     "hidden",
                      textOverflow: "ellipsis",
                      whiteSpace:   "nowrap",
                      fontFamily:   "Arial, sans-serif",
                    }}
                  >
                    {cmd.cliente_nom}
                  </p>

                  {/* Montant */}
                  <p
                    style={{
                      fontSize:   "11px",
                      fontWeight: "600",
                      color:      "#C9A84C",
                      flexShrink: 0,
                      fontFamily: "Arial, sans-serif",
                    }}
                  >
                    {formatEur(cmd.total)}
                  </p>

                  {/* Badge statut */}
                  <span
                    style={{
                      fontSize:     "9px",
                      padding:      "2px 7px",
                      borderRadius: "10px",
                      background:   `${sColor}18`,
                      color:        sColor,
                      flexShrink:   0,
                      fontFamily:   "Arial, sans-serif",
                    }}
                  >
                    {sLabel}
                  </span>

                  {/* Date */}
                  <p
                    style={{
                      fontSize:   "9px",
                      color:      "rgba(240,232,216,0.28)",
                      flexShrink: 0,
                      fontFamily: "Arial, sans-serif",
                    }}
                  >
                    {formatDate(cmd.created_at)}
                  </p>
                </Link>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}

// ── Skeleton helper ────────────────────────────────────────────────────────────

function Skeleton({
  w, h, delay = 0,
}: { w: string; h: string; delay?: number }) {
  return (
    <div
      style={{
        width:          w,
        height:         h,
        background:     "rgba(255,255,255,0.06)",
        borderRadius:   "6px",
        animation:      "bellaia-pulse 1.4s ease-in-out infinite",
        animationDelay: `${delay}s`,
      }}
    />
  );
}
