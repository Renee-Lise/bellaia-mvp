"use client";

import { useEffect, useState } from "react";
import { createClient }        from "@/lib/supabase/client";

/**
 * components/dashboard/AgendaWidget.tsx
 *
 * Widget agenda du tableau de bord fondatrice.
 * Affiche les sessions boudoirs à venir (source : sessions_boudoir).
 * Les rendez-vous Odyssée seront ajoutés en Couche 5 (module agenda).
 */

interface SessionItem {
  id:               string;
  titre:            string;
  date_session:     string;
  heure:            string | null;
  places_restantes: number;
  places_total:     number;
  prix_total:       number;
  statut:           string;
}

// ── Helpers ───────────────────────────────────────────────────────────────────

function formatDate(dateStr: string): string {
  const d = new Date(dateStr + "T00:00:00");
  return d.toLocaleDateString("fr-FR", {
    weekday: "short",
    day:     "numeric",
    month:   "short",
  });
}

function formatHeure(heure: string | null): string {
  if (!heure) return "";
  return heure.slice(0, 5); // "HH:MM"
}

function isToday(dateStr: string): boolean {
  const today = new Date().toISOString().split("T")[0];
  return dateStr === today;
}

function isTomorrow(dateStr: string): boolean {
  const tomorrow = new Date();
  tomorrow.setDate(tomorrow.getDate() + 1);
  return dateStr === tomorrow.toISOString().split("T")[0];
}

function getDateLabel(dateStr: string): string {
  if (isToday(dateStr))    return "Aujourd'hui";
  if (isTomorrow(dateStr)) return "Demain";
  return formatDate(dateStr);
}

// ── Composant ─────────────────────────────────────────────────────────────────

export function AgendaWidget() {
  const [sessions, setSessions] = useState<SessionItem[]>([]);
  const [loading,  setLoading]  = useState(true);
  const [error,    setError]    = useState<string | null>(null);

  const supabase = createClient();

  useEffect(() => {
    const fetchSessions = async () => {
      try {
        const today = new Date().toISOString().split("T")[0];

        const { data, error: sbError } = await supabase
          .from("sessions_boudoir")
          .select("id, titre, date_session, heure, places_restantes, places_total, prix_total, statut")
          .gte("date_session", today)
          .in("statut", ["ouvert", "complet"])
          .order("date_session", { ascending: true })
          .limit(5);

        if (sbError) throw sbError;
        setSessions(data ?? []);
      } catch (err) {
        console.error("[AgendaWidget]", err);
        setError("Impossible de charger les sessions.");
      } finally {
        setLoading(false);
      }
    };

    fetchSessions();
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  return (
    <div
      style={{
        background:   "#120A10",
        border:       "1px solid rgba(201, 168, 76, 0.15)",
        borderRadius: "12px",
        padding:      "18px",
        height:       "100%",
      }}
    >
      {/* Header */}
      <div
        style={{
          display:        "flex",
          justifyContent: "space-between",
          alignItems:     "center",
          marginBottom:   "16px",
        }}
      >
        <p
          style={{
            fontSize:      "9px",
            color:         "#C9A84C",
            letterSpacing: "0.20em",
            textTransform: "uppercase",
            fontWeight:    "700",
            fontFamily:    "Arial, sans-serif",
          }}
        >
          📅 Agenda — Sessions à venir
        </p>
      </div>

      {/* Contenu */}
      {loading ? (
        <AgendaSkeleton />
      ) : error ? (
        <p style={{ fontSize: "12px", color: "rgba(244,67,54,0.70)", fontFamily: "Arial, sans-serif" }}>
          {error}
        </p>
      ) : sessions.length === 0 ? (
        <div
          style={{
            padding:      "20px",
            textAlign:    "center",
            borderRadius: "8px",
            background:   "rgba(255,255,255,0.03)",
            border:       "1px dashed rgba(201,168,76,0.15)",
          }}
        >
          <p style={{ fontSize: "20px", marginBottom: "8px" }}>📅</p>
          <p style={{ fontSize: "12px", color: "rgba(240,232,216,0.35)", fontFamily: "Arial, sans-serif" }}>
            Aucune session à venir
          </p>
        </div>
      ) : (
        <div style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
          {sessions.map((session) => {
            const placesPct = (session.places_restantes / session.places_total) * 100;
            const complet   = session.places_restantes === 0;

            return (
              <div
                key={session.id}
                style={{
                  display:      "flex",
                  gap:          "12px",
                  padding:      "11px 13px",
                  borderRadius: "9px",
                  background:   isToday(session.date_session)
                    ? "rgba(201, 168, 76, 0.08)"
                    : "rgba(255, 255, 255, 0.03)",
                  border:       `1px solid ${
                    isToday(session.date_session)
                      ? "rgba(201, 168, 76, 0.25)"
                      : "rgba(255, 255, 255, 0.06)"
                  }`,
                }}
              >
                {/* Date */}
                <div
                  style={{
                    flexShrink:   0,
                    width:        "44px",
                    textAlign:    "center",
                    background:   "rgba(201,168,76,0.08)",
                    borderRadius: "7px",
                    padding:      "6px 4px",
                    display:      "flex",
                    flexDirection: "column",
                    alignItems:   "center",
                    justifyContent: "center",
                  }}
                >
                  <p
                    style={{
                      fontSize:   "8px",
                      color:      "#C9A84C",
                      fontWeight: "700",
                      letterSpacing: "0.05em",
                      fontFamily: "Arial, sans-serif",
                    }}
                  >
                    {getDateLabel(session.date_session).split(" ")[0].toUpperCase()}
                  </p>
                  <p
                    style={{
                      fontSize:   "18px",
                      fontWeight: "700",
                      color:      "#C9A84C",
                      lineHeight: "1.1",
                      fontFamily: "Arial, sans-serif",
                    }}
                  >
                    {new Date(session.date_session + "T00:00:00").getDate()}
                  </p>
                </div>

                {/* Infos */}
                <div style={{ flex: 1, minWidth: 0 }}>
                  <p
                    style={{
                      fontSize:     "12px",
                      fontWeight:   "600",
                      color:        "#F0E8D8",
                      overflow:     "hidden",
                      textOverflow: "ellipsis",
                      whiteSpace:   "nowrap",
                      fontFamily:   "Georgia, serif",
                    }}
                  >
                    {session.titre}
                  </p>

                  <div
                    style={{
                      display:    "flex",
                      alignItems: "center",
                      gap:        "8px",
                      marginTop:  "4px",
                    }}
                  >
                    {session.heure && (
                      <span
                        style={{
                          fontSize:   "10px",
                          color:      "rgba(240,232,216,0.45)",
                          fontFamily: "Arial, sans-serif",
                        }}
                      >
                        {formatHeure(session.heure)}
                      </span>
                    )}

                    {/* Places */}
                    <span
                      style={{
                        fontSize:      "10px",
                        padding:       "1px 7px",
                        borderRadius:  "10px",
                        background:    complet
                          ? "rgba(244,67,54,0.12)"
                          : placesPct <= 25
                          ? "rgba(255,152,0,0.12)"
                          : "rgba(76,175,80,0.10)",
                        color: complet
                          ? "#F44336"
                          : placesPct <= 25
                          ? "#FF9800"
                          : "#4CAF50",
                        fontFamily: "Arial, sans-serif",
                      }}
                    >
                      {complet
                        ? "Complet"
                        : `${session.places_restantes}/${session.places_total} places`}
                    </span>

                    <span
                      style={{
                        fontSize:   "10px",
                        color:      "#C9A84C",
                        fontFamily: "Arial, sans-serif",
                      }}
                    >
                      {session.prix_total.toFixed(0)} €
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

// ── Squelette ─────────────────────────────────────────────────────────────────

function AgendaSkeleton() {
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
      {[0, 1, 2].map((i) => (
        <div
          key={i}
          style={{
            display:      "flex",
            gap:          "12px",
            padding:      "11px 13px",
            borderRadius: "9px",
            background:   "rgba(255,255,255,0.03)",
            border:       "1px solid rgba(255,255,255,0.06)",
          }}
        >
          <div
            style={{
              width:        "44px",
              height:       "48px",
              background:   "rgba(255,255,255,0.06)",
              borderRadius: "7px",
              animation:    "bellaia-pulse 1.4s ease-in-out infinite",
              animationDelay: `${i * 0.15}s`,
            }}
          />
          <div style={{ flex: 1, display: "flex", flexDirection: "column", gap: "6px", justifyContent: "center" }}>
            <div
              style={{
                height:       "12px",
                width:        "70%",
                background:   "rgba(255,255,255,0.06)",
                borderRadius: "4px",
                animation:    "bellaia-pulse 1.4s ease-in-out infinite",
                animationDelay: `${i * 0.15}s`,
              }}
            />
            <div
              style={{
                height:       "10px",
                width:        "40%",
                background:   "rgba(255,255,255,0.04)",
                borderRadius: "4px",
                animation:    "bellaia-pulse 1.4s ease-in-out infinite",
                animationDelay: `${i * 0.15 + 0.1}s`,
              }}
            />
          </div>
        </div>
      ))}
    </div>
  );
}
