import Link from "next/link";
import type { Urgence } from "@/app/api/dashboard/summary/route";

/**
 * components/dashboard/UrgenceItem.tsx
 *
 * Ligne d'urgence dans le tableau de bord fondatrice.
 * Chaque urgence indique le niveau, le message, l'action à faire
 * et un lien vers l'entité concernée.
 *
 * Rappel gouvernance :
 * Toute action financière nécessite une validation fondatrice explicite.
 */

interface UrgenceItemProps {
  urgence: Urgence;
  /** Index pour l'animation décalée */
  index?:  number;
}

// ── Config visuelle par niveau ────────────────────────────────────────────────

const NIVEAU_CONFIG = {
  rouge: {
    bg:          "rgba(244, 67, 54, 0.07)",
    border:      "rgba(244, 67, 54, 0.22)",
    dotColor:    "#F44336",
    dotShadow:   "0 0 6px rgba(244, 67, 54, 0.7)",
    labelColor:  "rgba(244, 67, 54, 0.85)",
    label:       "CRITIQUE",
    emoji:       "🔴",
  },
  jaune: {
    bg:          "rgba(255, 152, 0, 0.06)",
    border:      "rgba(255, 152, 0, 0.20)",
    dotColor:    "#FF9800",
    dotShadow:   "0 0 6px rgba(255, 152, 0, 0.6)",
    labelColor:  "rgba(255, 152, 0, 0.80)",
    label:       "IMPORTANT",
    emoji:       "🟡",
  },
  bleu: {
    bg:          "rgba(33, 150, 243, 0.06)",
    border:      "rgba(33, 150, 243, 0.18)",
    dotColor:    "#2196F3",
    dotShadow:   "0 0 6px rgba(33, 150, 243, 0.5)",
    labelColor:  "rgba(33, 150, 243, 0.75)",
    label:       "INFO",
    emoji:       "🔵",
  },
} as const;

// ── Icônes par type d'entité ──────────────────────────────────────────────────

const ENTITE_ICON: Record<Urgence["entite"], string> = {
  commande:  "◆",
  stock:     "▣",
  paiement:  "◐",
  document:  "◇",
  facture:   "◉",
};

// ── Composant ─────────────────────────────────────────────────────────────────

export function UrgenceItem({ urgence, index = 0 }: UrgenceItemProps) {
  const cfg  = NIVEAU_CONFIG[urgence.niveau];
  const icon = ENTITE_ICON[urgence.entite];

  return (
    <Link
      href={urgence.href}
      style={{
        display:       "flex",
        alignItems:    "center",
        gap:           "12px",
        padding:       "11px 14px",
        borderRadius:  "9px",
        background:    cfg.bg,
        border:        `1px solid ${cfg.border}`,
        textDecoration: "none",
        transition:    "background 0.15s, border-color 0.15s",
        animationDelay: `${index * 60}ms`,
      }}
      onMouseEnter={(e) => {
        (e.currentTarget as HTMLAnchorElement).style.background =
          urgence.niveau === "rouge"
            ? "rgba(244, 67, 54, 0.11)"
            : urgence.niveau === "jaune"
            ? "rgba(255, 152, 0, 0.09)"
            : "rgba(33, 150, 243, 0.09)";
      }}
      onMouseLeave={(e) => {
        (e.currentTarget as HTMLAnchorElement).style.background = cfg.bg;
      }}
    >
      {/* Indicateur niveau */}
      <div
        style={{
          width:        "7px",
          height:       "7px",
          borderRadius: "50%",
          background:   cfg.dotColor,
          boxShadow:    cfg.dotShadow,
          flexShrink:   0,
        }}
      />

      {/* Icône entité */}
      <span
        style={{
          fontSize:   "13px",
          color:      cfg.labelColor,
          flexShrink: 0,
          opacity:    0.7,
        }}
      >
        {icon}
      </span>

      {/* Texte */}
      <div style={{ flex: 1, minWidth: 0 }}>
        <p
          style={{
            fontSize:   "12px",
            color:      "rgba(240, 232, 216, 0.85)",
            fontFamily: "Arial, sans-serif",
            overflow:   "hidden",
            textOverflow: "ellipsis",
            whiteSpace:  "nowrap",
          }}
        >
          {urgence.message}
        </p>
        <p
          style={{
            fontSize:   "10px",
            color:      cfg.labelColor,
            fontFamily: "Arial, sans-serif",
            marginTop:  "2px",
          }}
        >
          {urgence.action} →
        </p>
      </div>

      {/* Badge niveau */}
      <span
        style={{
          fontSize:      "8px",
          padding:       "2px 7px",
          borderRadius:  "20px",
          background:    `${cfg.dotColor}18`,
          color:         cfg.dotColor,
          border:        `1px solid ${cfg.dotColor}35`,
          fontWeight:    "700",
          letterSpacing: "0.08em",
          flexShrink:    0,
          fontFamily:    "Arial, sans-serif",
        }}
      >
        {cfg.label}
      </span>
    </Link>
  );
}

// ── Squelette chargement ──────────────────────────────────────────────────────

export function UrgenceItemSkeleton() {
  return (
    <div
      style={{
        display:      "flex",
        alignItems:   "center",
        gap:          "12px",
        padding:      "11px 14px",
        borderRadius: "9px",
        background:   "rgba(255,255,255,0.03)",
        border:       "1px solid rgba(255,255,255,0.06)",
      }}
    >
      <div
        style={{
          width:        "7px",
          height:       "7px",
          borderRadius: "50%",
          background:   "rgba(255,255,255,0.10)",
        }}
      />
      <div
        style={{
          flex:         1,
          height:       "12px",
          background:   "rgba(255,255,255,0.06)",
          borderRadius: "4px",
          animation:    "bellaia-pulse 1.4s ease-in-out infinite",
        }}
      />
      <div
        style={{
          width:        "52px",
          height:       "18px",
          background:   "rgba(255,255,255,0.06)",
          borderRadius: "20px",
          animation:    "bellaia-pulse 1.4s ease-in-out infinite",
          animationDelay: "0.2s",
        }}
      />
    </div>
  );
}
