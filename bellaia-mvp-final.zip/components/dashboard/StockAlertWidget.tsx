"use client";

import Link from "next/link";
import type { DashboardSummary } from "@/app/api/dashboard/summary/route";

/**
 * components/dashboard/StockAlertWidget.tsx
 *
 * Widget alertes stocks du tableau de bord fondatrice.
 * Affiche les produits en rupture et stock faible.
 *
 * Règle absolue :
 * Toute décision de réassort nécessite une validation fondatrice.
 * Ce widget est en lecture seule — le lien renvoie vers /stocks.
 */

interface StockAlertWidgetProps {
  data:    DashboardSummary | null;
  loading: boolean;
}

// ── Config visuelle par statut ────────────────────────────────────────────────

const STATUT_CFG = {
  rupture: {
    bg:     "rgba(244, 67, 54, 0.09)",
    border: "rgba(244, 67, 54, 0.22)",
    color:  "#F44336",
    label:  "Rupture",
    icon:   "🔴",
    dot:    "#F44336",
  },
  faible: {
    bg:     "rgba(255, 152, 0, 0.07)",
    border: "rgba(255, 152, 0, 0.18)",
    color:  "#FF9800",
    label:  "Faible",
    icon:   "🟡",
    dot:    "#FF9800",
  },
} as const;

// ── Icônes par branche ────────────────────────────────────────────────────────

const BRANCHE_ICONS: Record<string, string> = {
  odyssee:     "✦",
  secret_home: "◆",
  food:        "❋",
  events:      "✿",
  academy:     "◇",
  structure:   "▲",
  invest:      "◐",
  vilo:        "◉",
  studio:      "◈",
};

// ── Composant ─────────────────────────────────────────────────────────────────

export function StockAlertWidget({ data, loading }: StockAlertWidgetProps) {
  const stocks = data?.stocks_alerte ?? [];

  const ruptures = stocks.filter((s) => s.statut_stock === "rupture");
  const faibles  = stocks.filter((s) => s.statut_stock === "faible");

  const hasAlerts = stocks.length > 0;

  return (
    <div
      style={{
        background:   "#120A10",
        border:       `1px solid ${
          ruptures.length > 0
            ? "rgba(244, 67, 54, 0.28)"
            : hasAlerts
            ? "rgba(255, 152, 0, 0.22)"
            : "rgba(201, 168, 76, 0.15)"
        }`,
        borderRadius: "12px",
        padding:      "18px",
        height:       "100%",
        display:      "flex",
        flexDirection: "column",
        gap:          "14px",
      }}
    >
      {/* ── Header ─────────────────────────────────────────────────────────── */}
      <div
        style={{
          display:        "flex",
          justifyContent: "space-between",
          alignItems:     "center",
        }}
      >
        <p
          style={{
            fontSize:      "9px",
            color:         ruptures.length > 0 ? "#F44336" : "#C9A84C",
            letterSpacing: "0.20em",
            textTransform: "uppercase",
            fontWeight:    "700",
            fontFamily:    "Arial, sans-serif",
          }}
        >
          📦 Alertes stocks
        </p>

        <Link
          href="/stocks"
          style={{
            fontSize:       "10px",
            color:          "rgba(201,168,76,0.60)",
            textDecoration: "none",
            fontFamily:     "Georgia, serif",
          }}
        >
          Gérer →
        </Link>
      </div>

      {/* ── Compteurs ──────────────────────────────────────────────────────── */}
      <div
        style={{
          display:             "grid",
          gridTemplateColumns: "1fr 1fr",
          gap:                 "8px",
        }}
      >
        <div
          style={{
            padding:      "10px 12px",
            borderRadius: "8px",
            background:   ruptures.length > 0
              ? "rgba(244,67,54,0.09)"
              : "rgba(255,255,255,0.03)",
            border:       ruptures.length > 0
              ? "1px solid rgba(244,67,54,0.22)"
              : "1px solid rgba(255,255,255,0.06)",
          }}
        >
          <p style={{ fontSize: "8px", color: "rgba(240,232,216,0.38)", letterSpacing: "0.10em", textTransform: "uppercase", fontFamily: "Arial, sans-serif" }}>
            Ruptures
          </p>
          <p style={{ fontSize: "22px", fontWeight: "700", color: ruptures.length > 0 ? "#F44336" : "rgba(240,232,216,0.30)", fontFamily: "Arial, sans-serif" }}>
            {loading ? "—" : ruptures.length}
          </p>
        </div>

        <div
          style={{
            padding:      "10px 12px",
            borderRadius: "8px",
            background:   faibles.length > 0
              ? "rgba(255,152,0,0.07)"
              : "rgba(255,255,255,0.03)",
            border:       faibles.length > 0
              ? "1px solid rgba(255,152,0,0.18)"
              : "1px solid rgba(255,255,255,0.06)",
          }}
        >
          <p style={{ fontSize: "8px", color: "rgba(240,232,216,0.38)", letterSpacing: "0.10em", textTransform: "uppercase", fontFamily: "Arial, sans-serif" }}>
            Stocks faibles
          </p>
          <p style={{ fontSize: "22px", fontWeight: "700", color: faibles.length > 0 ? "#FF9800" : "rgba(240,232,216,0.30)", fontFamily: "Arial, sans-serif" }}>
            {loading ? "—" : faibles.length}
          </p>
        </div>
      </div>

      {/* ── Liste produits ─────────────────────────────────────────────────── */}
      <div style={{ flex: 1 }}>
        {loading ? (
          <div style={{ display: "flex", flexDirection: "column", gap: "6px" }}>
            {[0, 1, 2].map((i) => (
              <div
                key={i}
                style={{
                  height:       "36px",
                  background:   "rgba(255,255,255,0.04)",
                  borderRadius: "7px",
                  animation:    "bellaia-pulse 1.4s ease-in-out infinite",
                  animationDelay: `${i * 0.12}s`,
                }}
              />
            ))}
          </div>
        ) : stocks.length === 0 ? (
          <div
            style={{
              padding:      "20px",
              textAlign:    "center",
              borderRadius: "8px",
              background:   "rgba(76,175,80,0.06)",
              border:       "1px dashed rgba(76,175,80,0.20)",
            }}
          >
            <p style={{ fontSize: "18px", marginBottom: "6px" }}>✅</p>
            <p style={{ fontSize: "12px", color: "#4CAF50", fontFamily: "Arial, sans-serif" }}>
              Tous les stocks sont OK
            </p>
          </div>
        ) : (
          <div style={{ display: "flex", flexDirection: "column", gap: "6px" }}>
            {/* Ruptures en premier */}
            {[...ruptures, ...faibles].map((stock) => {
              const cfg         = STATUT_CFG[stock.statut_stock];
              const brancheIcon = BRANCHE_ICONS[stock.branche] ?? "◈";

              return (
                <Link
                  key={stock.produit_id}
                  href="/stocks"
                  style={{
                    display:        "flex",
                    alignItems:     "center",
                    gap:            "10px",
                    padding:        "9px 11px",
                    borderRadius:   "7px",
                    background:     cfg.bg,
                    border:         `1px solid ${cfg.border}`,
                    textDecoration: "none",
                    transition:     "opacity 0.15s",
                  }}
                  onMouseEnter={(e) => {
                    (e.currentTarget as HTMLAnchorElement).style.opacity = "0.80";
                  }}
                  onMouseLeave={(e) => {
                    (e.currentTarget as HTMLAnchorElement).style.opacity = "1";
                  }}
                >
                  {/* Dot */}
                  <div
                    style={{
                      width:        "6px",
                      height:       "6px",
                      borderRadius: "50%",
                      background:   cfg.dot,
                      boxShadow:    `0 0 5px ${cfg.dot}AA`,
                      flexShrink:   0,
                    }}
                  />

                  {/* Icône branche */}
                  <span
                    style={{
                      fontSize:   "11px",
                      color:      "rgba(201,168,76,0.45)",
                      flexShrink: 0,
                    }}
                  >
                    {brancheIcon}
                  </span>

                  {/* Nom produit */}
                  <p
                    style={{
                      flex:         1,
                      fontSize:     "11px",
                      color:        "rgba(240,232,216,0.82)",
                      overflow:     "hidden",
                      textOverflow: "ellipsis",
                      whiteSpace:   "nowrap",
                      fontFamily:   "Arial, sans-serif",
                    }}
                  >
                    {stock.produit_nom}
                  </p>

                  {/* Quantité */}
                  <p
                    style={{
                      fontSize:   "10px",
                      color:      cfg.color,
                      flexShrink: 0,
                      fontWeight: "600",
                      fontFamily: "Arial, sans-serif",
                    }}
                  >
                    {stock.statut_stock === "rupture"
                      ? "0"
                      : stock.quantite}{" "}
                    {stock.unite}
                  </p>

                  {/* Badge */}
                  <span
                    style={{
                      fontSize:     "9px",
                      padding:      "2px 7px",
                      borderRadius: "10px",
                      background:   `${cfg.dot}18`,
                      color:        cfg.color,
                      flexShrink:   0,
                      fontFamily:   "Arial, sans-serif",
                    }}
                  >
                    {cfg.label}
                  </span>
                </Link>
              );
            })}
          </div>
        )}
      </div>

      {/* Note gouvernance */}
      {hasAlerts && !loading && (
        <p
          style={{
            fontSize:   "9px",
            color:      "rgba(220, 100, 80, 0.65)",
            fontStyle:  "italic",
            fontFamily: "Arial, sans-serif",
          }}
        >
          🔒 Tout réassort nécessite une validation fondatrice avant commande.
        </p>
      )}
    </div>
  );
}
