import { getStatutCRM } from "@/constants/statuts";
import type { StatutCRM } from "@/constants/statuts";

/**
 * components/crm/ClientStatusBadge.tsx
 * Badge visuel pour le statut CRM d'une cliente.
 */

interface Props {
  statut:   StatutCRM | string;
  size?:    "xs" | "sm" | "md";
  withDot?: boolean;
}

const SIZES = {
  xs: { fontSize: "9px",  padding: "1px 7px",  dot: "5px" },
  sm: { fontSize: "10px", padding: "2px 9px",  dot: "6px" },
  md: { fontSize: "12px", padding: "4px 13px", dot: "7px" },
} as const;

export function ClientStatusBadge({ statut, size = "sm", withDot = false }: Props) {
  const cfg  = getStatutCRM(statut);
  const sz   = SIZES[size];
  const color = cfg?.color ?? "#888";
  const label = cfg?.label ?? statut;

  return (
    <span
      style={{
        display:       "inline-flex",
        alignItems:    "center",
        gap:           withDot ? "5px" : 0,
        padding:       sz.padding,
        borderRadius:  "20px",
        fontSize:      sz.fontSize,
        fontWeight:    "600",
        letterSpacing: "0.03em",
        background:    `${color}18`,
        color,
        border:        `1px solid ${color}40`,
        whiteSpace:    "nowrap",
        fontFamily:    "Arial, sans-serif",
      }}
    >
      {withDot && (
        <span
          style={{
            width:        sz.dot,
            height:       sz.dot,
            borderRadius: "50%",
            background:   color,
            boxShadow:    `0 0 4px ${color}BB`,
            flexShrink:   0,
            display:      "inline-block",
          }}
        />
      )}
      {label}
    </span>
  );
}
