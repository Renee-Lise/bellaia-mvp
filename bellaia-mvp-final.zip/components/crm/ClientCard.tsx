import Link                   from "next/link";
import { ClientStatusBadge } from "@/components/crm/ClientStatusBadge";
import type { ClienteCRM }   from "@/types/database";

/**
 * components/crm/ClientCard.tsx
 * Carte cliente pour la grille CRM.
 */

interface Props {
  cliente:     ClienteCRM;
  /** Compact = ligne table, false = carte */
  compact?:    boolean;
}

function ScoreBar({ score }: { score: number }) {
  const color =
    score >= 80 ? "#C9A84C" :
    score >= 50 ? "#4CAF50" :
    score >= 25 ? "#FF9800" :
    "#888";
  return (
    <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
      <div
        style={{
          flex:         1,
          height:       "4px",
          background:   "rgba(255,255,255,0.08)",
          borderRadius: "2px",
          overflow:     "hidden",
        }}
      >
        <div
          style={{
            width:        `${score}%`,
            height:       "100%",
            background:   color,
            borderRadius: "2px",
            transition:   "width 0.4s ease",
          }}
        />
      </div>
      <span style={{ fontSize: "10px", color, fontWeight: "600", minWidth: "28px", fontFamily: "Arial, sans-serif" }}>
        {score}
      </span>
    </div>
  );
}

function Initials({ nom }: { nom: string }) {
  const parts = nom.trim().split(" ");
  const init  = parts.length >= 2
    ? (parts[0][0] + parts[1][0]).toUpperCase()
    : nom.slice(0, 2).toUpperCase();
  return <>{init}</>;
}

export function ClientCard({ cliente, compact = false }: Props) {
  if (compact) {
    return (
      <Link
        href={`/crm/${cliente.id}`}
        style={{
          display:        "grid",
          gridTemplateColumns: "36px 1fr 100px 90px 80px 80px",
          gap:            "10px",
          alignItems:     "center",
          padding:        "11px 14px",
          textDecoration: "none",
          transition:     "background 0.15s",
          borderBottom:   "1px solid rgba(255,255,255,0.05)",
        }}
        onMouseEnter={(e) => { (e.currentTarget as HTMLAnchorElement).style.background = "rgba(255,255,255,0.03)"; }}
        onMouseLeave={(e) => { (e.currentTarget as HTMLAnchorElement).style.background = "transparent"; }}
      >
        {/* Avatar */}
        <div
          style={{
            width:          "32px",
            height:         "32px",
            borderRadius:   "50%",
            background:     "linear-gradient(135deg, #C9A84C, #5C2D5C)",
            display:        "flex",
            alignItems:     "center",
            justifyContent: "center",
            fontSize:       "11px",
            fontWeight:     "700",
            color:          "#0C0810",
            flexShrink:     0,
          }}
        >
          <Initials nom={cliente.nom} />
        </div>

        {/* Nom + email */}
        <div style={{ minWidth: 0 }}>
          <p style={{ fontSize: "13px", fontWeight: "500", color: "#F0E8D8", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", fontFamily: "Arial, sans-serif" }}>
            {cliente.nom}
          </p>
          <p style={{ fontSize: "10px", color: "rgba(240,232,216,0.38)", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", fontFamily: "Arial, sans-serif" }}>
            {cliente.email || "—"}
          </p>
        </div>

        {/* Statut */}
        <ClientStatusBadge statut={cliente.statut_crm} size="xs" withDot />

        {/* Score fidélité */}
        <div style={{ minWidth: 0 }}>
          <ScoreBar score={cliente.score_fidelite} />
        </div>

        {/* Achats */}
        <p style={{ fontSize: "12px", color: "#C9A84C", fontWeight: "600", textAlign: "right", fontFamily: "Arial, sans-serif" }}>
          {new Intl.NumberFormat("fr-FR", { style: "currency", currency: "EUR", minimumFractionDigits: 0 }).format(cliente.ca_total)}
        </p>

        {/* Flèche */}
        <p style={{ fontSize: "16px", color: "rgba(201,168,76,0.30)", textAlign: "right" }}>›</p>
      </Link>
    );
  }

  // Mode carte (grille)
  return (
    <Link
      href={`/crm/${cliente.id}`}
      style={{
        display:        "flex",
        flexDirection:  "column",
        gap:            "12px",
        padding:        "16px",
        background:     "#120A10",
        border:         "1px solid rgba(201,168,76,0.14)",
        borderRadius:   "12px",
        textDecoration: "none",
        transition:     "border-color 0.2s, background 0.2s",
      }}
      onMouseEnter={(e) => {
        (e.currentTarget as HTMLAnchorElement).style.borderColor = "rgba(201,168,76,0.30)";
        (e.currentTarget as HTMLAnchorElement).style.background  = "rgba(18,10,15,0.95)";
      }}
      onMouseLeave={(e) => {
        (e.currentTarget as HTMLAnchorElement).style.borderColor = "rgba(201,168,76,0.14)";
        (e.currentTarget as HTMLAnchorElement).style.background  = "#120A10";
      }}
    >
      {/* Header */}
      <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
        <div
          style={{
            width:          "40px",
            height:         "40px",
            borderRadius:   "50%",
            background:     "linear-gradient(135deg, #C9A84C, #5C2D5C)",
            display:        "flex",
            alignItems:     "center",
            justifyContent: "center",
            fontSize:       "14px",
            fontWeight:     "700",
            color:          "#0C0810",
            flexShrink:     0,
          }}
        >
          <Initials nom={cliente.nom} />
        </div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <p style={{ fontSize: "14px", fontWeight: "600", color: "#F0E8D8", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", fontFamily: "Georgia, serif" }}>
            {cliente.nom}
          </p>
          <p style={{ fontSize: "10px", color: "rgba(240,232,216,0.40)", marginTop: "1px", fontFamily: "Arial, sans-serif" }}>
            {cliente.telephone || cliente.email || "—"}
          </p>
        </div>
        <ClientStatusBadge statut={cliente.statut_crm} size="xs" />
      </div>

      {/* Score fidélité */}
      <div>
        <p style={{ fontSize: "8px", color: "rgba(240,232,216,0.38)", letterSpacing: "0.12em", textTransform: "uppercase", marginBottom: "5px", fontFamily: "Arial, sans-serif" }}>
          Fidélité
        </p>
        <ScoreBar score={cliente.score_fidelite} />
      </div>

      {/* Stats */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "8px" }}>
        <div style={{ padding: "8px 10px", background: "rgba(255,255,255,0.03)", borderRadius: "7px" }}>
          <p style={{ fontSize: "8px", color: "rgba(240,232,216,0.35)", letterSpacing: "0.10em", marginBottom: "3px", fontFamily: "Arial, sans-serif" }}>ACHATS</p>
          <p style={{ fontSize: "14px", fontWeight: "700", color: "#C9A84C", fontFamily: "Arial, sans-serif" }}>
            {cliente.nb_achats}
          </p>
        </div>
        <div style={{ padding: "8px 10px", background: "rgba(255,255,255,0.03)", borderRadius: "7px" }}>
          <p style={{ fontSize: "8px", color: "rgba(240,232,216,0.35)", letterSpacing: "0.10em", marginBottom: "3px", fontFamily: "Arial, sans-serif" }}>CA TOTAL</p>
          <p style={{ fontSize: "14px", fontWeight: "700", color: "#C9A84C", fontFamily: "Arial, sans-serif" }}>
            {new Intl.NumberFormat("fr-FR", { style: "currency", currency: "EUR", minimumFractionDigits: 0 }).format(cliente.ca_total)}
          </p>
        </div>
      </div>

      {/* Univers */}
      {cliente.univers?.length > 0 && (
        <div style={{ display: "flex", gap: "5px", flexWrap: "wrap" }}>
          {cliente.univers.slice(0, 3).map((u) => (
            <span
              key={u}
              style={{ fontSize: "9px", padding: "2px 8px", borderRadius: "10px", background: "rgba(201,168,76,0.08)", border: "1px solid rgba(201,168,76,0.18)", color: "rgba(201,168,76,0.70)", fontFamily: "Arial, sans-serif" }}
            >
              {u}
            </span>
          ))}
        </div>
      )}
    </Link>
  );
}
