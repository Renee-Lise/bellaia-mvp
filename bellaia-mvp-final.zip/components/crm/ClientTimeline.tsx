/**
 * components/crm/ClientTimeline.tsx
 * Timeline des activités d'une cliente : commandes, documents, paiements.
 */

export interface TimelineEvent {
  id:          string;
  type:        "commande" | "paiement" | "document" | "note" | "statut";
  titre:       string;
  description: string;
  date:        string;
  montant?:    number;
  statut?:     string;
  href?:       string;
}

interface Props {
  events:   TimelineEvent[];
  loading?: boolean;
}

const TYPE_CONFIG = {
  commande:  { icon: "◆", color: "#D4A0B5" },
  paiement:  { icon: "◐", color: "#4CAF50" },
  document:  { icon: "◇", color: "#C9A84C" },
  note:      { icon: "◉", color: "#9B6B9E" },
  statut:    { icon: "◈", color: "#7EB8C4" },
} as const;

function formatDate(iso: string) {
  return new Date(iso).toLocaleDateString("fr-FR", {
    day: "numeric", month: "short", year: "numeric",
  });
}

export function ClientTimeline({ events, loading = false }: Props) {
  if (loading) {
    return (
      <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
        {[0, 1, 2].map((i) => (
          <div key={i} style={{ display: "flex", gap: "12px" }}>
            <div style={{ width: "28px", height: "28px", borderRadius: "50%", background: "rgba(255,255,255,0.06)", animation: "bellaia-pulse 1.4s ease-in-out infinite", animationDelay: `${i * 0.12}s`, flexShrink: 0 }} />
            <div style={{ flex: 1, height: "44px", background: "rgba(255,255,255,0.04)", borderRadius: "8px", animation: "bellaia-pulse 1.4s ease-in-out infinite", animationDelay: `${i * 0.12}s` }} />
          </div>
        ))}
      </div>
    );
  }

  if (events.length === 0) {
    return (
      <div style={{ padding: "20px", textAlign: "center", borderRadius: "8px", background: "rgba(255,255,255,0.03)", border: "1px dashed rgba(201,168,76,0.15)" }}>
        <p style={{ fontSize: "13px", color: "rgba(240,232,216,0.30)", fontFamily: "Arial, sans-serif" }}>
          Aucune activité enregistrée
        </p>
      </div>
    );
  }

  return (
    <div style={{ position: "relative" }}>
      {/* Ligne verticale */}
      <div
        style={{
          position:   "absolute",
          left:       "13px",
          top:        "14px",
          bottom:     "14px",
          width:      "1px",
          background: "rgba(201,168,76,0.12)",
        }}
      />

      <div style={{ display: "flex", flexDirection: "column", gap: "10px" }}>
        {events.map((ev, i) => {
          const cfg = TYPE_CONFIG[ev.type];

          const inner = (
            <div
              style={{
                display:    "flex",
                gap:        "12px",
                alignItems: "flex-start",
                animation:  "bellaia-fade-in 0.2s ease-out",
                animationDelay: `${i * 40}ms`,
              }}
            >
              {/* Dot */}
              <div
                style={{
                  width:          "28px",
                  height:         "28px",
                  borderRadius:   "50%",
                  background:     `${cfg.color}18`,
                  border:         `1px solid ${cfg.color}40`,
                  display:        "flex",
                  alignItems:     "center",
                  justifyContent: "center",
                  fontSize:       "11px",
                  color:          cfg.color,
                  flexShrink:     0,
                  zIndex:         1,
                  position:       "relative",
                }}
              >
                {cfg.icon}
              </div>

              {/* Contenu */}
              <div
                style={{
                  flex:         1,
                  padding:      "9px 12px",
                  background:   "rgba(255,255,255,0.03)",
                  border:       "1px solid rgba(255,255,255,0.06)",
                  borderRadius: "8px",
                }}
              >
                <div style={{ display: "flex", justifyContent: "space-between", gap: "8px", marginBottom: "3px" }}>
                  <p style={{ fontSize: "12px", fontWeight: "500", color: "#F0E8D8", fontFamily: "Arial, sans-serif" }}>
                    {ev.titre}
                  </p>
                  <div style={{ display: "flex", alignItems: "center", gap: "8px", flexShrink: 0 }}>
                    {ev.montant !== undefined && (
                      <span style={{ fontSize: "11px", fontWeight: "600", color: "#C9A84C", fontFamily: "Arial, sans-serif" }}>
                        {new Intl.NumberFormat("fr-FR", { style: "currency", currency: "EUR" }).format(ev.montant)}
                      </span>
                    )}
                    <span style={{ fontSize: "10px", color: "rgba(240,232,216,0.28)", fontFamily: "Arial, sans-serif" }}>
                      {formatDate(ev.date)}
                    </span>
                  </div>
                </div>
                {ev.description && (
                  <p style={{ fontSize: "11px", color: "rgba(240,232,216,0.50)", fontFamily: "Arial, sans-serif", lineHeight: "1.45" }}>
                    {ev.description}
                  </p>
                )}
              </div>
            </div>
          );

          return (
            <div key={ev.id}>
              {ev.href ? (
                <a href={ev.href} style={{ textDecoration: "none", display: "block" }}>
                  {inner}
                </a>
              ) : (
                inner
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
