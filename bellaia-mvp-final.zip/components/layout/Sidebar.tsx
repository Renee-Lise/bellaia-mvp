"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useAuth } from "@/hooks/useAuth";

/**
 * components/layout/Sidebar.tsx
 *
 * Sidebar de navigation principale pour l'espace fondatrice.
 * - Sections : pilotage, branches, outils
 * - Badge alertes sur les sections avec urgences
 * - Indicateur branche active
 * - Responsive : masqué sur mobile (toggle géré par le layout)
 */

// ── Types ─────────────────────────────────────────────────────────────────────

interface NavItem {
  href:      string;
  label:     string;
  icon:      string;
  badge?:    number;
  externe?:  boolean;
}

interface NavSection {
  titre:    string;
  items:    NavItem[];
}

// ── Navigation ────────────────────────────────────────────────────────────────

const NAV_SECTIONS: NavSection[] = [
  {
    titre: "Pilotage",
    items: [
      { href: "/dashboard",  label: "Tableau de bord", icon: "◈" },
      { href: "/bellaia",    label: "Bellaïa IA",       icon: "✦" },
      { href: "/audit",      label: "Journal d'audit",  icon: "◉" },
    ],
  },
  {
    titre: "Opérations",
    items: [
      { href: "/commandes",    label: "Commandes",     icon: "◆" },
      { href: "/stocks",       label: "Stocks",        icon: "▣" },
      { href: "/facturation",  label: "Facturation",   icon: "◐" },
      { href: "/fournisseurs", label: "Fournisseurs",  icon: "◎" },
    ],
  },
  {
    titre: "Clientes",
    items: [
      { href: "/crm",       label: "CRM Clientes", icon: "✿" },
      { href: "/documents", label: "Documents",    icon: "◇" },
    ],
  },
  {
    titre: "Branches",
    items: [
      { href: "/dashboard?branch=odyssee",     label: "Bella'Odyssée",      icon: "✦" },
      { href: "/dashboard?branch=secret_home", label: "Bella'Secret Home",  icon: "◆" },
      { href: "/dashboard?branch=food",        label: "Bella'Food",         icon: "❋" },
      { href: "/dashboard?branch=events",      label: "Bella'Events",       icon: "✿" },
      { href: "/dashboard?branch=invest",      label: "BellaInvest",        icon: "◐" },
      { href: "/dashboard?branch=vilo",        label: "Vilo'Assistance",    icon: "◉" },
      { href: "/dashboard?branch=academy",     label: "Bella'Academy",      icon: "◇" },
      { href: "/dashboard?branch=structure",   label: "Bella'Structure",    icon: "▲" },
    ],
  },
  {
    titre: "Administration",
    items: [
      { href: "/collaborateurs", label: "Collaborateurs", icon: "◈" },
      { href: "/coffre-fort",    label: "Coffre-fort",    icon: "🔒" },
    ],
  },
];

// ── Props ─────────────────────────────────────────────────────────────────────

interface SidebarProps {
  /** Badges d'alerte par chemin de route */
  alertes?: Record<string, number>;
  /** Callback fermeture sur mobile */
  onClose?: () => void;
}

// ── Composant ─────────────────────────────────────────────────────────────────

export function Sidebar({ alertes = {}, onClose }: SidebarProps) {
  const pathname  = usePathname();
  const { profile } = useAuth();

  const isActive = (href: string) => {
    const path = href.split("?")[0];
    if (path === "/dashboard") return pathname === "/dashboard";
    return pathname.startsWith(path);
  };

  return (
    <aside
      className="flex h-full flex-col"
      style={{
        background:   "rgba(8, 4, 7, 0.98)",
        borderRight:  "1px solid rgba(201, 168, 76, 0.14)",
        width:        "260px",
        minWidth:     "260px",
      }}
    >
      {/* ── Logo ─────────────────────────────────────────────────────────── */}
      <div
        className="flex flex-col px-5 py-6"
        style={{ borderBottom: "1px solid rgba(201, 168, 76, 0.10)" }}
      >
        <span
          className="font-serif text-xs tracking-widest uppercase"
          style={{ color: "#C9A84C", letterSpacing: "0.35em" }}
        >
          Bella&apos;Studio
        </span>
        <span
          className="font-serif mt-1 text-2xl font-bold tracking-wide"
          style={{ color: "#F0E8D8", letterSpacing: "0.08em" }}
        >
          Bellaïa
        </span>
        <span
          className="mt-0.5 text-xs"
          style={{ color: "rgba(240, 232, 216, 0.28)", letterSpacing: "0.12em" }}
        >
          Executive Business Manager IA
        </span>
      </div>

      {/* ── Navigation ───────────────────────────────────────────────────── */}
      <nav className="flex-1 overflow-y-auto px-3 py-4">
        {NAV_SECTIONS.map((section) => (
          <div key={section.titre} className="mb-5">
            {/* Titre de section */}
            <p
              className="mb-2 px-3 text-xs font-semibold uppercase tracking-widest"
              style={{ color: "rgba(201, 168, 76, 0.40)", letterSpacing: "0.22em" }}
            >
              {section.titre}
            </p>

            {/* Items */}
            <ul className="space-y-0.5">
              {section.items.map((item) => {
                const active  = isActive(item.href);
                const badgeCount = alertes[item.href.split("?")[0]] ?? 0;

                return (
                  <li key={item.href}>
                    <Link
                      href={item.href}
                      onClick={onClose}
                      className="flex items-center gap-3 rounded-lg px-3 py-2 text-sm transition-all"
                      style={{
                        background:  active ? "rgba(201, 168, 76, 0.12)" : "transparent",
                        border:      active
                          ? "1px solid rgba(201, 168, 76, 0.22)"
                          : "1px solid transparent",
                        color: active
                          ? "#C9A84C"
                          : "rgba(240, 232, 216, 0.50)",
                      }}
                      onMouseEnter={(e) => {
                        if (!active) {
                          e.currentTarget.style.background = "rgba(255, 255, 255, 0.04)";
                          e.currentTarget.style.color      = "rgba(240, 232, 216, 0.75)";
                        }
                      }}
                      onMouseLeave={(e) => {
                        if (!active) {
                          e.currentTarget.style.background = "transparent";
                          e.currentTarget.style.color      = "rgba(240, 232, 216, 0.50)";
                        }
                      }}
                    >
                      {/* Icône */}
                      <span
                        className="shrink-0 text-base"
                        style={{
                          color:   active ? "#C9A84C" : "rgba(201, 168, 76, 0.35)",
                          opacity: active ? 1 : 0.8,
                        }}
                      >
                        {item.icon}
                      </span>

                      {/* Label */}
                      <span className="flex-1 truncate font-serif">
                        {item.label}
                      </span>

                      {/* Badge alerte */}
                      {badgeCount > 0 && (
                        <span
                          className="flex h-4 min-w-4 items-center justify-center rounded-full px-1 text-xs font-bold"
                          style={{
                            background: "#F44336",
                            color:      "#FFFFFF",
                          }}
                        >
                          {badgeCount > 99 ? "99+" : badgeCount}
                        </span>
                      )}
                    </Link>
                  </li>
                );
              })}
            </ul>
          </div>
        ))}
      </nav>

      {/* ── Footer profil ────────────────────────────────────────────────── */}
      <div
        className="px-5 py-4"
        style={{ borderTop: "1px solid rgba(201, 168, 76, 0.10)" }}
      >
        {/* Indicateur statut */}
        <div className="mb-2 flex items-center gap-2">
          <div
            className="h-2 w-2 rounded-full"
            style={{
              background:  "#4CAF50",
              boxShadow:   "0 0 6px #4CAF50",
            }}
          />
          <span
            className="text-xs"
            style={{ color: "rgba(240, 232, 216, 0.32)", letterSpacing: "0.08em" }}
          >
            Bellaïa active
          </span>
        </div>

        {/* Nom fondatrice */}
        {profile && (
          <p
            className="text-xs"
            style={{ color: "rgba(240, 232, 216, 0.28)", fontStyle: "italic" }}
          >
            {profile.prenom} {profile.nom}
          </p>
        )}

        {/* Règle gouvernance */}
        <p
          className="mt-1 text-xs"
          style={{ color: "rgba(201, 168, 76, 0.35)", fontStyle: "italic" }}
        >
          Bellaïa prépare. Renée-Lise décide.
        </p>
      </div>
    </aside>
  );
}
