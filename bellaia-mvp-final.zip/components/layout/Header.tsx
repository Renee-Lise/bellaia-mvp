"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { createClient } from "@/lib/supabase/client";
import { useAuth } from "@/hooks/useAuth";

/**
 * components/layout/Header.tsx
 *
 * Header de l'espace fondatrice.
 * - Bouton toggle sidebar (mobile)
 * - Titre de la section active
 * - Recherche globale (stub — route /recherche)
 * - Bouton accès rapide Bellaïa IA
 * - Menu profil avec déconnexion
 */

// ── Props ─────────────────────────────────────────────────────────────────────

interface HeaderProps {
  /** Titre de la page courante */
  titre:         string;
  /** Sous-titre ou tagline */
  sousTitre?:    string;
  /** Callback toggle sidebar sur mobile */
  onToggleSidebar: () => void;
  /** Nombre d'urgences critiques (badge rouge) */
  urgences?:     number;
}

// ── Composant ─────────────────────────────────────────────────────────────────

export function Header({
  titre,
  sousTitre,
  onToggleSidebar,
  urgences = 0,
}: HeaderProps) {
  const router = useRouter();
  const { profile } = useAuth();
  const [search,      setSearch]      = useState("");
  const [profileOpen, setProfileOpen] = useState(false);
  const [isSigningOut, setIsSigningOut] = useState(false);

  const supabase = createClient();

  // ── Déconnexion ────────────────────────────────────────────────────────────
  const handleSignOut = async () => {
    setIsSigningOut(true);
    await supabase.auth.signOut();
    router.push("/connexion");
  };

  // ── Recherche ──────────────────────────────────────────────────────────────
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (search.trim()) {
      router.push(`/recherche?q=${encodeURIComponent(search.trim())}`);
      setSearch("");
    }
  };

  return (
    <header
      className="flex items-center gap-3 px-4 py-3 md:px-6"
      style={{
        background:   "rgba(8, 4, 7, 0.94)",
        backdropFilter: "blur(12px)",
        borderBottom: "1px solid rgba(201, 168, 76, 0.12)",
        minHeight:    "60px",
      }}
    >
      {/* ── Bouton sidebar mobile ────────────────────────────────────────── */}
      <button
        type="button"
        onClick={onToggleSidebar}
        className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg transition-colors md:hidden"
        style={{ color: "#C9A84C" }}
        aria-label="Ouvrir le menu"
      >
        <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
          <rect x="2" y="4"  width="14" height="1.5" rx="0.75" fill="currentColor" />
          <rect x="2" y="8"  width="14" height="1.5" rx="0.75" fill="currentColor" />
          <rect x="2" y="12" width="14" height="1.5" rx="0.75" fill="currentColor" />
        </svg>
      </button>

      {/* ── Titre section ────────────────────────────────────────────────── */}
      <div className="min-w-0 flex-1">
        <h1
          className="truncate font-serif text-sm font-bold md:text-base"
          style={{ color: "#F0E8D8" }}
        >
          {titre}
        </h1>
        {sousTitre && (
          <p
            className="truncate text-xs"
            style={{ color: "rgba(201, 168, 76, 0.55)", letterSpacing: "0.1em" }}
          >
            {sousTitre}
          </p>
        )}
      </div>

      {/* ── Actions droite ───────────────────────────────────────────────── */}
      <div className="flex items-center gap-2">

        {/* Recherche globale */}
        <form
          onSubmit={handleSearch}
          className="hidden items-center gap-2 md:flex"
        >
          <div
            className="flex items-center gap-2 rounded-lg px-3 py-1.5"
            style={{
              background: "rgba(255, 255, 255, 0.04)",
              border:     "1px solid rgba(201, 168, 76, 0.16)",
            }}
          >
            <svg
              width="13" height="13" viewBox="0 0 13 13" fill="none"
              style={{ color: "rgba(201, 168, 76, 0.45)", flexShrink: 0 }}
            >
              <circle cx="5.5" cy="5.5" r="4" stroke="currentColor" strokeWidth="1.5" />
              <path d="M9 9L11.5 11.5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
            </svg>
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Rechercher…"
              className="w-36 bg-transparent text-xs outline-none"
              style={{
                color:       "rgba(240, 232, 216, 0.75)",
              }}
            />
          </div>
        </form>

        {/* Urgences */}
        {urgences > 0 && (
          <Link
            href="/dashboard"
            className="relative flex h-8 w-8 items-center justify-center rounded-lg transition-colors"
            style={{
              background: "rgba(244, 67, 54, 0.12)",
              border:     "1px solid rgba(244, 67, 54, 0.25)",
            }}
            title={`${urgences} urgence${urgences > 1 ? "s" : ""} en attente`}
          >
            <span style={{ fontSize: "14px" }}>⚡</span>
            <span
              className="absolute -right-1 -top-1 flex h-4 min-w-4 items-center justify-center rounded-full px-1 text-xs font-bold"
              style={{ background: "#F44336", color: "#FFFFFF" }}
            >
              {urgences > 9 ? "9+" : urgences}
            </span>
          </Link>
        )}

        {/* Bouton Bellaïa IA */}
        <Link
          href="/bellaia"
          className="hidden items-center gap-2 rounded-lg px-3 py-1.5 text-xs font-semibold transition-all md:flex"
          style={{
            background: "linear-gradient(135deg, rgba(201,168,76,0.18), rgba(92,45,92,0.18))",
            border:     "1px solid rgba(201, 168, 76, 0.28)",
            color:      "#C9A84C",
          }}
        >
          <span>✦</span>
          <span className="font-serif">Bellaïa IA</span>
        </Link>

        {/* Menu profil */}
        <div className="relative">
          <button
            type="button"
            onClick={() => setProfileOpen((v) => !v)}
            className="flex h-8 w-8 items-center justify-center rounded-full text-xs font-bold transition-all"
            style={{
              background: "linear-gradient(135deg, #C9A84C, #5C2D5C)",
              color:      "#0C0810",
              flexShrink: 0,
            }}
            aria-label="Menu profil"
            aria-expanded={profileOpen}
          >
            {profile?.prenom?.[0]?.toUpperCase() ?? "R"}
          </button>

          {/* Dropdown */}
          {profileOpen && (
            <>
              {/* Overlay pour fermer */}
              <div
                className="fixed inset-0 z-10"
                onClick={() => setProfileOpen(false)}
              />

              <div
                className="absolute right-0 top-full z-20 mt-2 w-52 overflow-hidden rounded-xl py-2"
                style={{
                  background: "#120A10",
                  border:     "1px solid rgba(201, 168, 76, 0.20)",
                  boxShadow:  "0 8px 32px rgba(0, 0, 0, 0.50)",
                }}
              >
                {/* Infos profil */}
                {profile && (
                  <div
                    className="px-4 pb-3 pt-2"
                    style={{ borderBottom: "1px solid rgba(255, 255, 255, 0.06)" }}
                  >
                    <p
                      className="font-serif font-semibold text-sm"
                      style={{ color: "#F0E8D8" }}
                    >
                      {profile.prenom} {profile.nom}
                    </p>
                    <p
                      className="text-xs mt-0.5"
                      style={{ color: "rgba(201, 168, 76, 0.60)" }}
                    >
                      Fondatrice · Bella&apos;Studio
                    </p>
                  </div>
                )}

                {/* Liens */}
                {[
                  { href: "/dashboard",  label: "Tableau de bord", icon: "◈" },
                  { href: "/bellaia",    label: "Bellaïa IA",       icon: "✦" },
                  { href: "/audit",      label: "Journal d'audit",  icon: "◉" },
                ].map((item) => (
                  <Link
                    key={item.href}
                    href={item.href}
                    onClick={() => setProfileOpen(false)}
                    className="flex items-center gap-3 px-4 py-2 text-sm transition-colors"
                    style={{ color: "rgba(240, 232, 216, 0.65)" }}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.background = "rgba(255, 255, 255, 0.04)";
                      e.currentTarget.style.color      = "#F0E8D8";
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.background = "transparent";
                      e.currentTarget.style.color      = "rgba(240, 232, 216, 0.65)";
                    }}
                  >
                    <span style={{ color: "rgba(201, 168, 76, 0.50)" }}>{item.icon}</span>
                    <span className="font-serif">{item.label}</span>
                  </Link>
                ))}

                {/* Séparateur */}
                <div
                  className="my-2"
                  style={{ borderTop: "1px solid rgba(255, 255, 255, 0.06)" }}
                />

                {/* Déconnexion */}
                <button
                  type="button"
                  onClick={handleSignOut}
                  disabled={isSigningOut}
                  className="flex w-full items-center gap-3 px-4 py-2 text-sm transition-colors"
                  style={{
                    color:   "rgba(244, 67, 54, 0.75)",
                    cursor:  isSigningOut ? "not-allowed" : "pointer",
                  }}
                  onMouseEnter={(e) => {
                    if (!isSigningOut) {
                      e.currentTarget.style.background = "rgba(244, 67, 54, 0.08)";
                      e.currentTarget.style.color      = "#F44336";
                    }
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.background = "transparent";
                    e.currentTarget.style.color      = "rgba(244, 67, 54, 0.75)";
                  }}
                >
                  <span>↪</span>
                  <span className="font-serif">
                    {isSigningOut ? "Déconnexion…" : "Se déconnecter"}
                  </span>
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    </header>
  );
}
