import { getStatutFacture } from "@/constants/statuts";
import type { StatutFacture } from "@/constants/statuts";

/**
 * components/facturation/FactureStatusBadge.tsx
 * Badge visuel pour le statut d'une facture ou d'un devis.
 */

interface Props {
  statut:   StatutFacture | string;
  type?:    "devis" | "facture" | "avoir" | "bon_commande" | "bon_livraison";
  size?:    "xs" | "sm" | "md";
  withDot?: boolean;
}

const SIZES = {
  xs: { fontSize: "9px",  padding: "1px 7px" },
  sm: { fontSize: "10px", padding: "2px 9px" },
  md: { fontSize: "12px", padding: "4px 13px" },
} as const;

const TYPE_LABELS: Record<string, string> = {
  devis: "Devis", facture: "Facture", avoir: "Avoir",
  bon_commande: "BC", bon_livraison: "BL",
};

export function FactureStatusBadge({ statut, type, size = "sm", withDot = false }: Props) {
  const cfg   = getStatutFacture(statut);
  const sz    = SIZES[size];
  const color = cfg?.color ?? "#888";
  const label = cfg?.label ?? statut;

  return (
    <span
      style={{
        display:       "inline-flex",
        alignItems:    "center",
        gap:           withDot ? "5px" : "0",
        padding:       sz.padding,
        borderRadius:  "20px",
        fontSize:      sz.fontSize,
        fontWeight:    "600",
        letterSpacing: "0.02em",
        background:    `${color}18`,
        color,
        border:        `1px solid ${color}40`,
        whiteSpace:    "nowrap",
        fontFamily:    "Arial, sans-serif",
      }}
    >
      {withDot && (
        <span style={{ width: "5px", height: "5px", borderRadius: "50%", background: color, flexShrink: 0, display: "inline-block" }} />
      )}
      {type ? `${TYPE_LABELS[type] ?? type} — ${label}` : label}
    </span>
  );
}
