import Link                   from "next/link";
import { FactureStatusBadge } from "@/components/facturation/FactureStatusBadge";
import type { Facture }       from "@/types/database";

/**
 * components/facturation/FactureCard.tsx
 * Carte/ligne pour un devis ou une facture dans la liste.
 */

interface Props {
  facture: Facture;
}

const TYPE_ICONS: Record<string, string> = {
  devis: "◇", facture: "◉", avoir: "◐",
  bon_commande: "◆", bon_livraison: "▣",
};

function formatEur(n: number) {
  return new Intl.NumberFormat("fr-FR", { style: "currency", currency: "EUR", minimumFractionDigits: 0 }).format(n);
}
function formatDate(iso: string | null) {
  if (!iso) return "—";
  return new Date(iso).toLocaleDateString("fr-FR", { day: "numeric", month: "short", year: "numeric" });
}

export function FactureCard({ facture }: Props) {
  const solde  = facture.total_ttc - (facture.acompte_recu ?? 0);
  const typeIcon = TYPE_ICONS[facture.type] ?? "◇";

  return (
    <Link
      href={`/facturation/${facture.id}`}
      style={{
        display:             "grid",
        gridTemplateColumns: "32px 1fr 110px 110px 120px 100px 80px",
        gap:                 "10px",
        padding:             "12px 14px",
        alignItems:          "center",
        textDecoration:      "none",
        borderBottom:        "1px solid rgba(255,255,255,0.05)",
        transition:          "background 0.15s",
      }}
      onMouseEnter={(e) => { (e.currentTarget as HTMLAnchorElement).style.background = "rgba(255,255,255,0.03)"; }}
      onMouseLeave={(e) => { (e.currentTarget as HTMLAnchorElement).style.background = "transparent"; }}
    >
      {/* Icône type */}
      <span style={{ fontSize: "15px", color: "rgba(201,168,76,0.50)", textAlign: "center" }}>
        {typeIcon}
      </span>

      {/* Client + numéro */}
      <div style={{ minWidth: 0 }}>
        <p style={{ fontSize: "13px", fontWeight: "500", color: "#F0E8D8", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", fontFamily: "Arial, sans-serif" }}>
          {facture.client_nom}
        </p>
        <p style={{ fontSize: "9px", color: "rgba(240,232,216,0.35)", marginTop: "1px", fontFamily: "Arial, sans-serif" }}>
          {facture.numero ?? "Brouillon"} · {facture.branche}
        </p>
      </div>

      {/* Total */}
      <p style={{ fontSize: "13px", fontWeight: "700", color: "#C9A84C", fontFamily: "Arial, sans-serif" }}>
        {formatEur(facture.total_ttc)}
      </p>

      {/* Solde */}
      <p style={{ fontSize: "12px", color: solde > 0 ? "#FF9800" : "rgba(240,232,216,0.35)", fontFamily: "Arial, sans-serif" }}>
        {solde > 0 ? `Solde ${formatEur(solde)}` : "—"}
      </p>

      {/* Statut */}
      <FactureStatusBadge statut={facture.statut} type={facture.type} size="xs" withDot />

      {/* Date */}
      <p style={{ fontSize: "10px", color: "rgba(240,232,216,0.35)", fontFamily: "Arial, sans-serif" }}>
        {formatDate(facture.emis_le ?? facture.created_at)}
      </p>

      {/* Flèche */}
      <p style={{ fontSize: "16px", color: "rgba(201,168,76,0.30)", textAlign: "right" }}>›</p>
    </Link>
  );
}
