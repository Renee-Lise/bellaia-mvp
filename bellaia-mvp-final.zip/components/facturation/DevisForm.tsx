"use client";

import { useState } from "react";

/**
 * components/facturation/DevisForm.tsx
 * Formulaire de création d'un devis (statut BROUILLON).
 * Validation fondatrice obligatoire avant émission.
 */

export interface ArticleDevis {
  description:   string;
  quantite:      number;
  prix_unitaire: number;
}

export interface DevisFormData {
  client_nom:      string;
  client_email:    string;
  branche:         string;
  articles:        ArticleDevis[];
  notes:           string;
  validite_jours:  number;
}

interface Props {
  onSubmit:  (data: DevisFormData) => Promise<void>;
  onCancel?: () => void;
  loading?:  boolean;
  error?:    string | null;
}

const BRANCHES = [
  { id: "secret_home", label: "Bella'Secret Home" },
  { id: "odyssee",     label: "Bella'Odyssée" },
  { id: "food",        label: "Bella'Food" },
  { id: "events",      label: "Bella'Events" },
  { id: "academy",     label: "Bella'Academy" },
  { id: "structure",   label: "Bella'Structure" },
  { id: "vilo",        label: "Vilo'Assistance" },
];

const emptyArticle = (): ArticleDevis => ({ description: "", quantite: 1, prix_unitaire: 0 });

function formatEur(n: number) {
  return new Intl.NumberFormat("fr-FR", { style: "currency", currency: "EUR" }).format(n);
}

const fieldStyle: React.CSSProperties = {
  width: "100%", padding: "9px 12px", borderRadius: "8px",
  background: "rgba(255,255,255,0.04)", border: "1px solid rgba(201,168,76,0.18)",
  color: "#F0E8D8", fontSize: "13px", outline: "none", fontFamily: "Arial, sans-serif",
};

const labelStyle: React.CSSProperties = {
  display: "block", fontSize: "9px", color: "rgba(240,232,216,0.42)",
  letterSpacing: "0.14em", textTransform: "uppercase" as const,
  marginBottom: "6px", fontFamily: "Arial, sans-serif",
};

export function DevisForm({ onSubmit, onCancel, loading = false, error }: Props) {
  const [clientNom,     setClientNom]     = useState("");
  const [clientEmail,   setClientEmail]   = useState("");
  const [branche,       setBranche]       = useState("secret_home");
  const [articles,      setArticles]      = useState<ArticleDevis[]>([emptyArticle()]);
  const [notes,         setNotes]         = useState("");
  const [validiteJours, setValiditeJours] = useState(30);

  // Calcul total
  const total = articles.reduce((s, a) => s + a.quantite * a.prix_unitaire, 0);

  // Gérer les articles
  const updateArticle = (i: number, field: keyof ArticleDevis, value: string | number) => {
    setArticles((prev) => prev.map((a, idx) => idx === i ? { ...a, [field]: value } : a));
  };
  const addArticle    = () => setArticles((prev) => [...prev, emptyArticle()]);
  const removeArticle = (i: number) => {
    if (articles.length === 1) return;
    setArticles((prev) => prev.filter((_, idx) => idx !== i));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!clientNom.trim() || articles.some((a) => !a.description.trim() || a.prix_unitaire <= 0)) return;
    await onSubmit({ client_nom: clientNom.trim(), client_email: clientEmail.trim(), branche, articles, notes, validite_jours: validiteJours });
  };

  return (
    <form onSubmit={handleSubmit} style={{ display: "flex", flexDirection: "column", gap: "18px" }}>

      {/* Infos client */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "12px" }}>
        <div>
          <label style={labelStyle}>Nom du client *</label>
          <input
            type="text" required value={clientNom}
            onChange={(e) => setClientNom(e.target.value)}
            placeholder="Nom de la cliente"
            style={fieldStyle}
          />
        </div>
        <div>
          <label style={labelStyle}>Email (optionnel)</label>
          <input
            type="email" value={clientEmail}
            onChange={(e) => setClientEmail(e.target.value)}
            placeholder="email@exemple.fr"
            style={fieldStyle}
          />
        </div>
      </div>

      {/* Branche + validité */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 140px", gap: "12px" }}>
        <div>
          <label style={labelStyle}>Branche</label>
          <select
            value={branche} onChange={(e) => setBranche(e.target.value)}
            style={{ ...fieldStyle, cursor: "pointer" }}
          >
            {BRANCHES.map((b) => <option key={b.id} value={b.id}>{b.label}</option>)}
          </select>
        </div>
        <div>
          <label style={labelStyle}>Validité (jours)</label>
          <input
            type="number" min={1} max={365}
            value={validiteJours}
            onChange={(e) => setValiditeJours(parseInt(e.target.value) || 30)}
            style={fieldStyle}
          />
        </div>
      </div>

      {/* Articles */}
      <div>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "10px" }}>
          <label style={{ ...labelStyle, marginBottom: 0 }}>Articles *</label>
          <button
            type="button" onClick={addArticle}
            style={{ fontSize: "11px", padding: "4px 12px", borderRadius: "20px", background: "rgba(201,168,76,0.08)", border: "1px solid rgba(201,168,76,0.22)", color: "#C9A84C", cursor: "pointer", fontFamily: "Georgia, serif" }}
          >
            + Ajouter article
          </button>
        </div>

        <div style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
          {/* Header colonnes */}
          <div style={{ display: "grid", gridTemplateColumns: "1fr 80px 110px 90px 28px", gap: "8px" }}>
            {["Description", "Qté", "Prix unitaire", "Total", ""].map((h) => (
              <p key={h} style={{ fontSize: "8px", color: "rgba(240,232,216,0.35)", letterSpacing: "0.12em", textTransform: "uppercase", fontFamily: "Arial, sans-serif" }}>{h}</p>
            ))}
          </div>

          {articles.map((art, i) => (
            <div key={i} style={{ display: "grid", gridTemplateColumns: "1fr 80px 110px 90px 28px", gap: "8px", alignItems: "center" }}>
              <input
                type="text" required
                value={art.description}
                onChange={(e) => updateArticle(i, "description", e.target.value)}
                placeholder="Description…"
                style={{ ...fieldStyle, fontSize: "12px" }}
              />
              <input
                type="number" min="0.01" step="0.01" required
                value={art.quantite}
                onChange={(e) => updateArticle(i, "quantite", parseFloat(e.target.value) || 0)}
                style={{ ...fieldStyle, fontSize: "12px", textAlign: "center" }}
              />
              <input
                type="number" min="0" step="0.01" required
                value={art.prix_unitaire}
                onChange={(e) => updateArticle(i, "prix_unitaire", parseFloat(e.target.value) || 0)}
                placeholder="0.00"
                style={{ ...fieldStyle, fontSize: "12px", textAlign: "right" }}
              />
              <p style={{ fontSize: "12px", fontWeight: "600", color: "#C9A84C", textAlign: "right", fontFamily: "Arial, sans-serif" }}>
                {formatEur(art.quantite * art.prix_unitaire)}
              </p>
              <button
                type="button"
                onClick={() => removeArticle(i)}
                disabled={articles.length === 1}
                style={{ background: "none", border: "none", color: articles.length === 1 ? "rgba(255,255,255,0.10)" : "rgba(244,67,54,0.60)", cursor: articles.length === 1 ? "not-allowed" : "pointer", fontSize: "14px" }}
              >
                ✕
              </button>
            </div>
          ))}
        </div>

        {/* Total */}
        <div style={{ display: "flex", justifyContent: "flex-end", padding: "12px 0 0", borderTop: "1px solid rgba(201,168,76,0.12)", marginTop: "10px" }}>
          <div style={{ textAlign: "right" }}>
            <p style={{ fontSize: "9px", color: "rgba(240,232,216,0.38)", letterSpacing: "0.12em", textTransform: "uppercase", marginBottom: "3px", fontFamily: "Arial, sans-serif" }}>TOTAL HT</p>
            <p style={{ fontSize: "22px", fontWeight: "700", color: "#C9A84C", fontFamily: "Arial, sans-serif" }}>
              {formatEur(total)}
            </p>
          </div>
        </div>
      </div>

      {/* Notes */}
      <div>
        <label style={labelStyle}>Notes / Conditions (optionnel)</label>
        <textarea
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          rows={3} placeholder="Conditions particulières, délai, modalités de paiement…"
          style={{ ...fieldStyle, resize: "vertical", lineHeight: "1.5" }}
        />
      </div>

      {/* Erreur */}
      {error && (
        <div style={{ padding: "10px 14px", background: "rgba(244,67,54,0.10)", border: "1px solid rgba(244,67,54,0.25)", borderRadius: "8px", fontSize: "13px", color: "#F44336", fontFamily: "Arial, sans-serif" }}>
          {error}
        </div>
      )}

      {/* Note gouvernance */}
      <div style={{ padding: "9px 13px", background: "rgba(160,32,16,0.07)", border: "1px solid rgba(160,32,16,0.18)", borderRadius: "8px" }}>
        <p style={{ fontSize: "10px", color: "rgba(220,100,80,0.75)", fontStyle: "italic", fontFamily: "Arial, sans-serif" }}>
          🔒 Ce devis sera créé en statut BROUILLON. Validation fondatrice obligatoire avant toute émission ou envoi au client.
        </p>
      </div>

      {/* Boutons */}
      <div style={{ display: "flex", gap: "10px", paddingTop: "4px" }}>
        {onCancel && (
          <button
            type="button" onClick={onCancel}
            style={{ flex: 1, padding: "11px", borderRadius: "10px", background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.10)", color: "rgba(240,232,216,0.50)", cursor: "pointer", fontSize: "13px", fontFamily: "Georgia, serif" }}
          >
            Annuler
          </button>
        )}
        <button
          type="submit"
          disabled={loading || !clientNom.trim() || total === 0}
          style={{
            flex: 2, padding: "11px", borderRadius: "10px", fontWeight: "700", fontSize: "13px",
            background: loading || !clientNom.trim() || total === 0 ? "rgba(201,168,76,0.10)" : "linear-gradient(135deg, #C9A84C, #5C2D5C)",
            border: "none",
            color: loading || !clientNom.trim() || total === 0 ? "rgba(240,232,216,0.25)" : "#0C0810",
            cursor: loading || !clientNom.trim() || total === 0 ? "not-allowed" : "pointer",
            fontFamily: "Georgia, serif",
          }}
        >
          {loading ? "Création…" : `Créer le devis — ${formatEur(total)}`}
        </button>
      </div>
    </form>
  );
}
