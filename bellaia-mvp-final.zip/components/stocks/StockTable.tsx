import Link                  from "next/link";
import { StockAlertBadge }  from "@/components/stocks/StockAlertBadge";
import type { StockAvecStatut } from "@/types/database";

/**
 * components/stocks/StockTable.tsx
 * Tableau des stocks avec statuts, alertes et lien vers fiche produit.
 */

interface Props {
  stocks:   StockAvecStatut[];
  loading?: boolean;
  onMovement?: (produitId: string, produitNom: string) => void;
}

const BRANCHE_ICONS: Record<string, string> = {
  odyssee: "✦", secret_home: "◆", food: "❋",
  events: "✿", academy: "◇", structure: "▲",
  invest: "◐", vilo: "◉", studio: "◈",
};

function formatDate(iso: string) {
  return new Date(iso).toLocaleDateString("fr-FR", { day: "numeric", month: "short" });
}

function Skeleton() {
  return (
    <div style={{ display: "flex", flexDirection: "column" }}>
      {[0, 1, 2, 3, 4].map((i) => (
        <div
          key={i}
          style={{
            height: "46px", margin: "3px 12px",
            background: "rgba(255,255,255,0.04)", borderRadius: "7px",
            animation: "bellaia-pulse 1.4s ease-in-out infinite",
            animationDelay: `${i * 0.1}s`,
          }}
        />
      ))}
    </div>
  );
}

export function StockTable({ stocks, loading = false, onMovement }: Props) {
  if (loading) return <Skeleton />;

  if (stocks.length === 0) {
    return (
      <div style={{ padding: "40px", textAlign: "center" }}>
        <p style={{ fontSize: "18px", marginBottom: "8px" }}>📦</p>
        <p style={{ fontSize: "13px", color: "rgba(240,232,216,0.35)", fontFamily: "Arial, sans-serif" }}>
          Aucun produit en stock
        </p>
      </div>
    );
  }

  return (
    <div>
      {/* Header */}
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "28px 1fr 120px 100px 90px 100px 80px",
          gap: "8px", padding: "8px 14px",
          borderBottom: "1px solid rgba(201,168,76,0.10)",
        }}
      >
        {["", "Produit", "Branche", "Quantité", "Seuil", "Statut", "Màj"].map((h) => (
          <p key={h} style={{ fontSize: "9px", color: "rgba(201,168,76,0.45)", letterSpacing: "0.14em", textTransform: "uppercase", fontFamily: "Arial, sans-serif" }}>
            {h}
          </p>
        ))}
      </div>

      {/* Lignes */}
      {stocks.map((s, i) => {
        const isAlerte = s.statut_stock !== "ok";
        const brancheIcon = BRANCHE_ICONS[s.branche] ?? "◈";

        return (
          <div
            key={s.produit_id}
            style={{
              display: "grid",
              gridTemplateColumns: "28px 1fr 120px 100px 90px 100px 80px",
              gap: "8px", padding: "11px 14px", alignItems: "center",
              borderBottom: i < stocks.length - 1 ? "1px solid rgba(255,255,255,0.04)" : "none",
              background: isAlerte ? "rgba(244,67,54,0.03)" : "transparent",
            }}
          >
            {/* Icône branche */}
            <span style={{ fontSize: "12px", color: "rgba(201,168,76,0.40)", textAlign: "center" }}>
              {brancheIcon}
            </span>

            {/* Nom produit */}
            <p style={{ fontSize: "12px", color: "#F0E8D8", fontWeight: "500", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", fontFamily: "Arial, sans-serif" }}>
              {s.produit_nom}
            </p>

            {/* Branche */}
            <p style={{ fontSize: "10px", color: "rgba(240,232,216,0.45)", fontFamily: "Arial, sans-serif" }}>
              {s.branche}
            </p>

            {/* Quantité */}
            <p style={{ fontSize: "13px", fontWeight: "700", color: s.statut_stock === "rupture" ? "#F44336" : s.statut_stock === "faible" ? "#FF9800" : "#C9A84C", fontFamily: "Arial, sans-serif" }}>
              {s.quantite} <span style={{ fontSize: "10px", fontWeight: "400", color: "rgba(240,232,216,0.40)" }}>{s.unite}</span>
            </p>

            {/* Seuil alerte */}
            <p style={{ fontSize: "11px", color: "rgba(240,232,216,0.38)", fontFamily: "Arial, sans-serif" }}>
              ≤ {s.seuil_alerte} {s.unite}
            </p>

            {/* Statut */}
            <StockAlertBadge statut={s.statut_stock} size="xs" />

            {/* Date + bouton mouvement */}
            <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", gap: "3px" }}>
              <p style={{ fontSize: "9px", color: "rgba(240,232,216,0.25)", fontFamily: "Arial, sans-serif" }}>
                {formatDate(s.derniere_maj)}
              </p>
              {onMovement && (
                <button
                  type="button"
                  onClick={() => onMovement(s.produit_id, s.produit_nom)}
                  style={{
                    fontSize: "9px", padding: "2px 7px", borderRadius: "6px",
                    background: "rgba(201,168,76,0.08)", border: "1px solid rgba(201,168,76,0.18)",
                    color: "rgba(201,168,76,0.60)", cursor: "pointer", fontFamily: "Georgia, serif",
                  }}
                >
                  ± Mouvement
                </button>
              )}
            </div>
          </div>
        );
      })}
    </div>
  );
}
