"use client";

import { useState } from "react";
import { ValidationModal }  from "@/components/validation/ValidationModal";
import { useValidation }    from "@/hooks/useValidation";

/**
 * components/stocks/StockMovementModal.tsx
 * Modal d'enregistrement de mouvement de stock.
 * Lecture seule sur les ajustements — validation fondatrice via useValidation.
 */

export type MouvementType = "vente" | "retour" | "ajustement" | "reception";

interface Props {
  produitId:   string;
  produitNom:  string;
  quantiteActuelle: number;
  unite:       string;
  isOpen:      boolean;
  onClose:     () => void;
  onSaved:     () => void;
}

const MOUVEMENT_CFG: Record<MouvementType, { label: string; color: string; sign: "+" | "-" }> = {
  reception:   { label: "Réception fournisseur", color: "#4CAF50", sign: "+" },
  retour:      { label: "Retour cliente",        color: "#7EB8C4", sign: "+" },
  vente:       { label: "Vente / sortie",        color: "#FF9800", sign: "-" },
  ajustement:  { label: "Ajustement inventaire", color: "#9B6B9E", sign: "+" },
};

export function StockMovementModal({
  produitId, produitNom, quantiteActuelle, unite,
  isOpen, onClose, onSaved,
}: Props) {
  const [type,       setType]       = useState<MouvementType>("reception");
  const [quantite,   setQuantite]   = useState("");
  const [raison,     setRaison]     = useState("");

  const validation = useValidation();

  if (!isOpen) return null;

  const qty = parseFloat(quantite);
  const cfg = MOUVEMENT_CFG[type];

  const newQty = isNaN(qty) ? quantiteActuelle :
    type === "vente" ? quantiteActuelle - qty : quantiteActuelle + qty;

  const handleSubmit = () => {
    if (!quantite || isNaN(qty) || qty <= 0) return;

    validation.request({
      action:    "stock_updated",
      entite:    "stocks",
      entite_id: produitId,
      titre:     `Mouvement stock — ${produitNom}`,
      resume:    `${cfg.label} · ${cfg.sign}${qty} ${unite}\nStock actuel : ${quantiteActuelle} → Nouveau : ${newQty.toFixed(3)} ${unite}`,
      impact:    newQty < 0
        ? "⚠ La quantité résultante serait négative. Vérifier avant de confirmer."
        : newQty <= 2
        ? "Stock résultant très faible — alerte sera déclenchée."
        : "Mise à jour du stock et enregistrement dans l'historique.",
      onConfirm: async () => {
        const res = await fetch(`/api/stocks/${produitId}`, {
          method:  "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ type, quantite: qty, raison: raison || undefined }),
        });
        if (!res.ok) {
          const j = await res.json().catch(() => ({}));
          throw new Error(j.error ?? `HTTP ${res.status}`);
        }
        onSaved();
        onClose();
        setQuantite("");
        setRaison("");
        setType("reception");
      },
    });
  };

  return (
    <>
      {/* Overlay */}
      <div
        onClick={onClose}
        style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.65)", zIndex: 40 }}
      />

      {/* Modal */}
      <div
        style={{
          position: "fixed", top: "50%", left: "50%",
          transform: "translate(-50%,-50%)", zIndex: 50,
          width: "100%", maxWidth: "420px", padding: "0 16px",
        }}
      >
        <div
          style={{
            background: "#120A10", border: "1px solid rgba(201,168,76,0.25)",
            borderRadius: "16px", padding: "24px",
          }}
        >
          {/* Header */}
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: "20px" }}>
            <div>
              <p style={{ fontSize: "9px", color: "#C9A84C", letterSpacing: "0.20em", textTransform: "uppercase", fontFamily: "Arial, sans-serif", marginBottom: "4px" }}>
                📦 Mouvement de stock
              </p>
              <p style={{ fontSize: "15px", fontWeight: "700", color: "#F0E8D8", fontFamily: "Georgia, serif" }}>
                {produitNom}
              </p>
              <p style={{ fontSize: "11px", color: "rgba(240,232,216,0.45)", marginTop: "2px", fontFamily: "Arial, sans-serif" }}>
                Stock actuel : <strong style={{ color: "#C9A84C" }}>{quantiteActuelle} {unite}</strong>
              </p>
            </div>
            <button type="button" onClick={onClose} style={{ background: "none", border: "none", color: "rgba(240,232,216,0.40)", cursor: "pointer", fontSize: "18px" }}>✕</button>
          </div>

          {/* Type de mouvement */}
          <div style={{ marginBottom: "14px" }}>
            <p style={{ fontSize: "9px", color: "rgba(240,232,216,0.40)", letterSpacing: "0.12em", textTransform: "uppercase", marginBottom: "8px", fontFamily: "Arial, sans-serif" }}>
              Type de mouvement
            </p>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "6px" }}>
              {(Object.entries(MOUVEMENT_CFG) as [MouvementType, typeof MOUVEMENT_CFG[MouvementType]][]).map(([k, v]) => (
                <button
                  key={k} type="button"
                  onClick={() => setType(k)}
                  style={{
                    padding: "8px 10px", borderRadius: "8px", textAlign: "left", cursor: "pointer",
                    background: type === k ? `${v.color}18` : "rgba(255,255,255,0.03)",
                    border: `1px solid ${type === k ? `${v.color}45` : "rgba(255,255,255,0.08)"}`,
                    color: type === k ? v.color : "rgba(240,232,216,0.55)",
                    fontSize: "11px", fontFamily: "Arial, sans-serif",
                    transition: "all 0.15s",
                  }}
                >
                  <span style={{ marginRight: "5px" }}>{v.sign}</span>{v.label}
                </button>
              ))}
            </div>
          </div>

          {/* Quantité */}
          <div style={{ marginBottom: "12px" }}>
            <label style={{ display: "block", fontSize: "9px", color: "rgba(240,232,216,0.40)", letterSpacing: "0.12em", textTransform: "uppercase", marginBottom: "6px", fontFamily: "Arial, sans-serif" }}>
              Quantité ({unite})
            </label>
            <input
              type="number"
              min="0.001"
              step="0.001"
              value={quantite}
              onChange={(e) => setQuantite(e.target.value)}
              placeholder={`Ex : 5`}
              style={{
                width: "100%", padding: "9px 12px", borderRadius: "8px",
                background: "rgba(255,255,255,0.04)", border: "1px solid rgba(201,168,76,0.18)",
                color: "#F0E8D8", fontSize: "14px", outline: "none", fontFamily: "Arial, sans-serif",
              }}
            />
            {/* Nouveau stock estimé */}
            {!isNaN(qty) && qty > 0 && (
              <p style={{ fontSize: "10px", color: newQty < 0 ? "#F44336" : "rgba(240,232,216,0.40)", marginTop: "5px", fontFamily: "Arial, sans-serif" }}>
                Nouveau stock estimé : <strong style={{ color: newQty < 0 ? "#F44336" : "#C9A84C" }}>{newQty.toFixed(2)} {unite}</strong>
                {newQty < 0 && " ⚠ Négatif"}
              </p>
            )}
          </div>

          {/* Raison */}
          <div style={{ marginBottom: "20px" }}>
            <label style={{ display: "block", fontSize: "9px", color: "rgba(240,232,216,0.40)", letterSpacing: "0.12em", textTransform: "uppercase", marginBottom: "6px", fontFamily: "Arial, sans-serif" }}>
              Raison / Référence (optionnel)
            </label>
            <input
              type="text"
              value={raison}
              onChange={(e) => setRaison(e.target.value)}
              placeholder="Ex : Fournisseur X, Réf. BL-001"
              style={{
                width: "100%", padding: "9px 12px", borderRadius: "8px",
                background: "rgba(255,255,255,0.04)", border: "1px solid rgba(201,168,76,0.18)",
                color: "#F0E8D8", fontSize: "12px", outline: "none", fontFamily: "Arial, sans-serif",
              }}
            />
          </div>

          {/* Boutons */}
          <div style={{ display: "flex", gap: "10px" }}>
            <button
              type="button" onClick={onClose}
              style={{ flex: 1, padding: "10px", borderRadius: "10px", background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.10)", color: "rgba(240,232,216,0.45)", cursor: "pointer", fontSize: "13px", fontFamily: "Georgia, serif" }}
            >
              Annuler
            </button>
            <button
              type="button" onClick={handleSubmit}
              disabled={!quantite || isNaN(qty) || qty <= 0}
              style={{
                flex: 1, padding: "10px", borderRadius: "10px",
                background: (!quantite || isNaN(qty) || qty <= 0) ? "rgba(201,168,76,0.10)" : "linear-gradient(135deg, #C9A84C, #5C2D5C)",
                border: "none",
                color: (!quantite || isNaN(qty) || qty <= 0) ? "rgba(240,232,216,0.25)" : "#0C0810",
                cursor: (!quantite || isNaN(qty) || qty <= 0) ? "not-allowed" : "pointer",
                fontSize: "13px", fontWeight: "700", fontFamily: "Georgia, serif",
              }}
            >
              🔒 Enregistrer
            </button>
          </div>
        </div>
      </div>

      <ValidationModal validation={validation} />
    </>
  );
}
