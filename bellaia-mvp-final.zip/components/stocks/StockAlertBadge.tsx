import { getStatutStock } from "@/constants/statuts";
import type { StatutStock } from "@/constants/statuts";

/**
 * components/stocks/StockAlertBadge.tsx
 * Badge visuel pour le statut de stock d'un produit.
 */

interface Props {
  statut:   StatutStock | string;
  quantite?: number;
  unite?:    string;
  size?:    "xs" | "sm" | "md";
}

const SIZES = {
  xs: { fontSize: "9px",  padding: "1px 7px" },
  sm: { fontSize: "10px", padding: "2px 9px" },
  md: { fontSize: "12px", padding: "4px 13px" },
} as const;

export function StockAlertBadge({ statut, quantite, unite, size = "sm" }: Props) {
  const cfg   = getStatutStock(statut);
  const sz    = SIZES[size];
  const color = cfg?.color ?? "#888";
  const label = cfg?.label ?? statut;

  return (
    <span
      style={{
        display:       "inline-flex",
        alignItems:    "center",
        gap:           "5px",
        padding:       sz.padding,
        borderRadius:  "20px",
        fontSize:      sz.fontSize,
        fontWeight:    "600",
        letterSpacing: "0.02em",
        background:    `${color}18`,
        color,
        border:        `1px solid ${color}40`,
        whiteSpace:    "nowrap",
        fontFamily:    "Arial, sans-serif",
      }}
    >
      <span
        style={{
          width:        "5px",
          height:       "5px",
          borderRadius: "50%",
          background:   color,
          boxShadow:    cfg?.alerte ? `0 0 5px ${color}AA` : "none",
          flexShrink:   0,
          display:      "inline-block",
        }}
      />
      {quantite !== undefined
        ? `${quantite} ${unite ?? ""} — ${label}`.trim()
        : label}
    </span>
  );
}
