/**
 * components/bellaia/ChatWindow.types.ts
 *
 * Ré-export des types partagés entre ChatWindow et MessageBubble.
 * Évite les imports circulaires.
 */
export { MessageBubble } from "@/components/bellaia/MessageBubble";
export type { ChatMessage, MessageRole } from "@/components/bellaia/MessageBubble";
