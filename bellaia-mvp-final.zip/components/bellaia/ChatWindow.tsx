"use client";

import {
  useEffect,
  useRef,
  useState,
  useCallback,
  useId,
} from "react";
import {
  MessageBubble,
  type ChatMessage,
} from "@/components/bellaia/ChatWindow.types";
import type Anthropic from "@anthropic-ai/sdk";

/**
 * components/bellaia/ChatWindow.tsx
 *
 * Fenêtre de chat complète pour Bellaïa IA.
 * Gère :
 * - L'historique de conversation multi-tours
 * - L'envoi de messages avec gestion du loading
 * - Le scroll automatique vers le bas
 * - Les actions rapides (quick actions)
 * - Le retry en cas d'erreur
 */

// ── Types ─────────────────────────────────────────────────────────────────────

interface ChatWindowProps {
  /** Branche active — contextualisée le prompt */
  branch?:         string;
  /** Prénom fondatrice — pour l'avatar et le prompt */
  prenom?:         string;
  /** Couleur accent de la branche */
  branchAccent?:   string;
  /** Couleur secondaire de la branche */
  branchSecondary?: string;
  /** Actions rapides affichées au-dessus de l'input */
  quickActions?:   string[];
  /** Message d'accueil initial */
  welcomeMessage?: string;
}

type InternalMessage = ChatMessage & {
  /** Messages internes Anthropic pour le multi-tour (non affichés) */
  _anthropicContent?: Anthropic.MessageParam["content"];
};

// ── Quick actions par défaut ──────────────────────────────────────────────────

const DEFAULT_QUICK_ACTIONS = [
  "Rapport du jour",
  "Commandes urgentes",
  "Alertes stocks",
  "Clientes VIP",
  "Créer un devis",
];

// ── Composant ─────────────────────────────────────────────────────────────────

export function ChatWindow({
  branch          = "studio",
  prenom          = "Renée-Lise",
  branchAccent    = "#C9A84C",
  branchSecondary = "#5C2D5C",
  quickActions    = DEFAULT_QUICK_ACTIONS,
  welcomeMessage,
}: ChatWindowProps) {
  const idPrefix = useId();

  const [messages,  setMessages]  = useState<InternalMessage[]>([]);
  const [input,     setInput]     = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [error,     setError]     = useState<string | null>(null);

  // Historique Anthropic (format API — inclut les tool_result internes)
  const anthropicHistory = useRef<Anthropic.MessageParam[]>([]);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef       = useRef<HTMLTextAreaElement>(null);
  const abortRef       = useRef<AbortController | null>(null);

  // ── Message d'accueil ──────────────────────────────────────────────────────
  useEffect(() => {
    const welcome = welcomeMessage ??
      `Bonjour ${prenom}. ✦\n\nJe suis prête à vous accompagner.\n\nVous pouvez me demander un rapport du jour, l'état de vos commandes, vos stocks, ou créer un devis. Je suis à votre service.`;

    setMessages([{
      id:        `${idPrefix}-welcome`,
      role:      "assistant",
      content:   welcome,
      timestamp: new Date(),
    }]);
    // Réinitialiser l'historique Anthropic à chaque changement de branche
    anthropicHistory.current = [];
  }, [branch]); // eslint-disable-line react-hooks/exhaustive-deps

  // ── Auto-scroll ────────────────────────────────────────────────────────────
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  // ── Envoyer un message ─────────────────────────────────────────────────────
  const sendMessage = useCallback(async (text: string) => {
    const userText = text.trim();
    if (!userText || isLoading) return;

    setInput("");
    setError(null);

    // Ajouter le message utilisateur à l'UI
    const userMsg: InternalMessage = {
      id:        `${idPrefix}-user-${Date.now()}`,
      role:      "user",
      content:   userText,
      timestamp: new Date(),
    };

    // Ajouter le message de loading Bellaïa
    const loadingId = `${idPrefix}-loading-${Date.now()}`;
    setMessages((prev) => [
      ...prev,
      userMsg,
      { id: loadingId, role: "assistant", content: "", timestamp: new Date(), isLoading: true },
    ]);

    setIsLoading(true);

    // Construire l'historique Anthropic avec le nouveau message
    const newHistory: Anthropic.MessageParam[] = [
      ...anthropicHistory.current,
      { role: "user", content: userText },
    ];

    // Annuler toute requête précédente
    abortRef.current?.abort();
    abortRef.current = new AbortController();

    try {
      const res = await fetch("/api/bellaia/chat", {
        method:  "POST",
        headers: { "Content-Type": "application/json" },
        signal:  abortRef.current.signal,
        body:    JSON.stringify({
          messages: newHistory,
          branch,
          prenom,
        }),
      });

      if (!res.ok) {
        const json = await res.json().catch(() => ({}));
        throw new Error(json.error ?? `HTTP ${res.status}`);
      }

      const data = await res.json();

      // Mettre à jour l'historique Anthropic avec les messages de travail
      // (inclut les tool_result internes pour le multi-tour)
      if (data.updated_messages) {
        anthropicHistory.current = data.updated_messages;
      } else {
        // Fallback : ajouter user + assistant manuellement
        anthropicHistory.current = [
          ...newHistory,
          { role: "assistant" as const, content: data.response },
        ];
      }

      // Remplacer le message de loading par la vraie réponse
      setMessages((prev) =>
        prev.map((m) =>
          m.id === loadingId
            ? { ...m, content: data.response, isLoading: false, timestamp: new Date() }
            : m
        )
      );

    } catch (err) {
      if ((err as Error).name === "AbortError") return;

      const message = err instanceof Error ? err.message : "Erreur de connexion.";
      setError(message);

      // Supprimer le message de loading
      setMessages((prev) => prev.filter((m) => m.id !== loadingId));
    } finally {
      setIsLoading(false);
    }
  }, [isLoading, branch, prenom, idPrefix]);

  // ── Gestion de la touche Entrée ────────────────────────────────────────────
  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage(input);
    }
  };

  // ── Auto-resize textarea ───────────────────────────────────────────────────
  const handleInputChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setInput(e.target.value);
    // Réinitialiser puis recalculer la hauteur
    e.target.style.height = "auto";
    e.target.style.height = Math.min(e.target.scrollHeight, 120) + "px";
  };

  // ── Vider la conversation ──────────────────────────────────────────────────
  const clearChat = () => {
    anthropicHistory.current = [];
    setMessages([{
      id:        `${idPrefix}-clear-${Date.now()}`,
      role:      "assistant",
      content:   "Conversation réinitialisée. Comment puis-je vous aider ?",
      timestamp: new Date(),
    }]);
    setError(null);
  };

  // ─────────────────────────────────────────────────────────────────────────
  return (
    <div
      style={{
        display:       "flex",
        flexDirection: "column",
        height:        "100%",
        minHeight:     "0",
      }}
    >
      {/* ── Messages ────────────────────────────────────────────────────────── */}
      <div
        style={{
          flex:          "1 1 0",
          overflowY:     "auto",
          padding:       "16px",
          display:       "flex",
          flexDirection: "column",
          gap:           "14px",
        }}
      >
        {messages.map((msg) => (
          <MessageBubble
            key={msg.id}
            message={msg}
            branchAccent={branchAccent}
            branchSecondary={branchSecondary}
            prenom={prenom}
          />
        ))}
        <div ref={messagesEndRef} />
      </div>

      {/* ── Erreur ─────────────────────────────────────────────────────────── */}
      {error && (
        <div
          style={{
            margin:       "0 16px 8px",
            padding:      "9px 13px",
            borderRadius: "8px",
            background:   "rgba(244,67,54,0.10)",
            border:       "1px solid rgba(244,67,54,0.25)",
            display:      "flex",
            alignItems:   "center",
            gap:          "10px",
          }}
        >
          <p style={{ flex: 1, fontSize: "12px", color: "#F44336", fontFamily: "Arial, sans-serif" }}>
            {error}
          </p>
          <button
            type="button"
            onClick={() => setError(null)}
            style={{ fontSize: "14px", color: "rgba(244,67,54,0.65)", background: "none", border: "none", cursor: "pointer" }}
          >
            ✕
          </button>
        </div>
      )}

      {/* ── Quick actions ───────────────────────────────────────────────────── */}
      {!isLoading && (
        <div
          style={{
            padding:    "0 16px 8px",
            display:    "flex",
            gap:        "6px",
            flexWrap:   "wrap",
          }}
        >
          {quickActions.map((action) => (
            <button
              key={action}
              type="button"
              onClick={() => sendMessage(action)}
              disabled={isLoading}
              style={{
                padding:      "4px 12px",
                borderRadius: "20px",
                background:   "rgba(201,168,76,0.07)",
                border:       "1px solid rgba(201,168,76,0.18)",
                color:        "rgba(201,168,76,0.68)",
                fontSize:     "10px",
                cursor:       "pointer",
                fontFamily:   "Georgia, serif",
                whiteSpace:   "nowrap",
                transition:   "background 0.15s",
              }}
              onMouseEnter={(e) => {
                (e.currentTarget).style.background = "rgba(201,168,76,0.13)";
              }}
              onMouseLeave={(e) => {
                (e.currentTarget).style.background = "rgba(201,168,76,0.07)";
              }}
            >
              {action}
            </button>
          ))}
        </div>
      )}

      {/* ── Zone de saisie ──────────────────────────────────────────────────── */}
      <div
        style={{
          padding:    "8px 16px 16px",
          borderTop:  "1px solid rgba(201,168,76,0.10)",
          background: "rgba(8,4,7,0.95)",
        }}
      >
        <div
          style={{
            display:      "flex",
            gap:          "8px",
            background:   "rgba(14,8,12,0.97)",
            border:       "1px solid rgba(201,168,76,0.18)",
            borderRadius: "12px",
            padding:      "4px 4px 4px 14px",
            alignItems:   "flex-end",
          }}
        >
          {/* Textarea */}
          <textarea
            ref={inputRef}
            value={input}
            onChange={handleInputChange}
            onKeyDown={handleKeyDown}
            disabled={isLoading}
            placeholder={`Message à Bellaïa…`}
            rows={1}
            style={{
              flex:        1,
              background:  "transparent",
              border:      "none",
              outline:     "none",
              color:       "#F0E8D8",
              fontSize:    "12.5px",
              fontFamily:  "Arial, sans-serif",
              resize:      "none",
              lineHeight:  "1.55",
              padding:     "9px 0",
              maxHeight:   "120px",
              overflowY:   "auto",
              minHeight:   "36px",
            }}
          />

          {/* Bouton clear */}
          {messages.length > 1 && (
            <button
              type="button"
              onClick={clearChat}
              disabled={isLoading}
              title="Nouvelle conversation"
              style={{
                width:          "32px",
                height:         "32px",
                borderRadius:   "8px",
                flexShrink:     0,
                border:         "none",
                background:     "rgba(255,255,255,0.04)",
                color:          "rgba(240,232,216,0.28)",
                cursor:         isLoading ? "not-allowed" : "pointer",
                fontSize:       "13px",
                display:        "flex",
                alignItems:     "center",
                justifyContent: "center",
                marginBottom:   "4px",
              }}
            >
              ↺
            </button>
          )}

          {/* Bouton envoyer */}
          <button
            type="button"
            onClick={() => sendMessage(input)}
            disabled={isLoading || !input.trim()}
            style={{
              width:          "36px",
              height:         "36px",
              borderRadius:   "9px",
              flexShrink:     0,
              border:         "none",
              background:     input.trim() && !isLoading
                ? `linear-gradient(135deg, ${branchAccent}, ${branchSecondary})`
                : "rgba(201,168,76,0.07)",
              cursor:         input.trim() && !isLoading ? "pointer" : "not-allowed",
              color:          input.trim() && !isLoading ? "#0C0810" : "rgba(201,168,76,0.22)",
              fontSize:       "15px",
              display:        "flex",
              alignItems:     "center",
              justifyContent: "center",
              marginBottom:   "4px",
              transition:     "background 0.15s",
            }}
            aria-label="Envoyer"
          >
            ➤
          </button>
        </div>

        {/* Note gouvernance */}
        <p
          style={{
            textAlign:  "center",
            fontSize:   "8.5px",
            color:      "rgba(240,232,216,0.15)",
            marginTop:  "6px",
            fontFamily: "Arial, sans-serif",
          }}
        >
          Bellaïa prépare · Renée-Lise décide · Aucune action financière sans validation fondatrice
        </p>
      </div>
    </div>
  );
}
