/**
 * components/bellaia/MessageBubble.tsx
 *
 * Bulle de message pour le chatbot Bellaïa.
 * Supporte les messages texte avec rendu Markdown basique
 * (gras, italique, listes, séparateurs).
 */

export type MessageRole = "user" | "assistant" | "system";

export interface ChatMessage {
  id:        string;
  role:      MessageRole;
  content:   string;
  timestamp: Date;
  isLoading?: boolean;
}

interface MessageBubbleProps {
  message:       ChatMessage;
  branchAccent?: string;
  branchSecondary?: string;
  /** Prénom de la fondatrice (initiale pour l'avatar) */
  prenom?:       string;
}

// ── Rendu Markdown minimaliste ────────────────────────────────────────────────

function renderText(text: string): React.ReactNode[] {
  const lines = text.split("\n");
  const nodes: React.ReactNode[] = [];

  lines.forEach((line, lineIdx) => {
    if (line === "" || line === "\n") {
      nodes.push(<br key={`br-${lineIdx}`} />);
      return;
    }

    // Séparateur horizontal
    if (line.match(/^[-─═]{3,}$/)) {
      nodes.push(
        <hr key={`hr-${lineIdx}`} style={{ border: "none", borderTop: "1px solid rgba(201,168,76,0.18)", margin: "8px 0" }} />
      );
      return;
    }

    // Titre H2 (##)
    if (line.startsWith("## ")) {
      nodes.push(
        <p key={`h2-${lineIdx}`} style={{ fontSize: "13px", fontWeight: "700", color: "#C9A84C", marginBottom: "4px", fontFamily: "Georgia, serif" }}>
          {line.slice(3)}
        </p>
      );
      return;
    }

    // Titre H3 (###)
    if (line.startsWith("### ")) {
      nodes.push(
        <p key={`h3-${lineIdx}`} style={{ fontSize: "12px", fontWeight: "700", color: "rgba(240,232,216,0.85)", marginBottom: "3px", fontFamily: "Georgia, serif" }}>
          {line.slice(4)}
        </p>
      );
      return;
    }

    // Liste à puces (- ou *)
    if (line.match(/^[-*•▸]\s/)) {
      nodes.push(
        <div key={`li-${lineIdx}`} style={{ display: "flex", gap: "7px", marginBottom: "2px" }}>
          <span style={{ color: "#C9A84C", fontSize: "12px", flexShrink: 0, marginTop: "1px" }}>▸</span>
          <span style={{ fontSize: "12.5px", color: "rgba(240,232,216,0.82)", lineHeight: "1.55", fontFamily: "Arial, sans-serif" }}>
            {renderInline(line.slice(2))}
          </span>
        </div>
      );
      return;
    }

    // Liste numérotée (1. 2. etc.)
    if (line.match(/^\d+\.\s/)) {
      const match = line.match(/^(\d+)\.\s(.*)$/);
      if (match) {
        nodes.push(
          <div key={`ol-${lineIdx}`} style={{ display: "flex", gap: "7px", marginBottom: "2px" }}>
            <span style={{ color: "#C9A84C", fontSize: "11px", flexShrink: 0, minWidth: "16px", textAlign: "right", fontFamily: "Arial, sans-serif" }}>
              {match[1]}.
            </span>
            <span style={{ fontSize: "12.5px", color: "rgba(240,232,216,0.82)", lineHeight: "1.55", fontFamily: "Arial, sans-serif" }}>
              {renderInline(match[2])}
            </span>
          </div>
        );
        return;
      }
    }

    // Ligne standard
    nodes.push(
      <p key={`p-${lineIdx}`} style={{ fontSize: "12.5px", color: "rgba(240,232,216,0.82)", lineHeight: "1.60", marginBottom: "2px", fontFamily: "Arial, sans-serif" }}>
        {renderInline(line)}
      </p>
    );
  });

  return nodes;
}

// Rendu inline : **gras**, *italique*, `code`, 🔒
function renderInline(text: string): React.ReactNode {
  const parts: React.ReactNode[] = [];
  let remaining = text;
  let key = 0;

  while (remaining.length > 0) {
    // Gras : **text**
    const boldMatch = remaining.match(/^(.*?)\*\*(.+?)\*\*(.*)/s);
    if (boldMatch) {
      if (boldMatch[1]) parts.push(<span key={key++}>{boldMatch[1]}</span>);
      parts.push(<strong key={key++} style={{ color: "#F0E8D8", fontWeight: "700" }}>{boldMatch[2]}</strong>);
      remaining = boldMatch[3];
      continue;
    }
    // Italique : *text*
    const italicMatch = remaining.match(/^(.*?)\*(.+?)\*(.*)/s);
    if (italicMatch) {
      if (italicMatch[1]) parts.push(<span key={key++}>{italicMatch[1]}</span>);
      parts.push(<em key={key++} style={{ color: "rgba(240,232,216,0.70)" }}>{italicMatch[2]}</em>);
      remaining = italicMatch[3];
      continue;
    }
    // Code inline : `text`
    const codeMatch = remaining.match(/^(.*?)`(.+?)`(.*)/s);
    if (codeMatch) {
      if (codeMatch[1]) parts.push(<span key={key++}>{codeMatch[1]}</span>);
      parts.push(
        <code key={key++} style={{ fontSize: "11px", padding: "1px 5px", borderRadius: "4px", background: "rgba(201,168,76,0.12)", color: "#C9A84C", fontFamily: "Courier New, monospace" }}>
          {codeMatch[2]}
        </code>
      );
      remaining = codeMatch[3];
      continue;
    }
    // Pas de pattern trouvé — afficher tel quel
    parts.push(<span key={key++}>{remaining}</span>);
    break;
  }

  return parts.length === 1 ? parts[0] : <>{parts}</>;
}

// ── Composant principal ───────────────────────────────────────────────────────

export function MessageBubble({
  message,
  branchAccent   = "#C9A84C",
  branchSecondary = "#5C2D5C",
  prenom         = "R",
}: MessageBubbleProps) {
  const isUser      = message.role === "user";
  const isAssistant = message.role === "assistant";

  return (
    <div
      style={{
        display:       "flex",
        justifyContent: isUser ? "flex-end" : "flex-start",
        gap:           "10px",
        alignItems:    "flex-start",
      }}
    >
      {/* Avatar Bellaïa */}
      {isAssistant && (
        <div
          style={{
            width:          "30px",
            height:         "30px",
            borderRadius:   "50%",
            background:     `linear-gradient(135deg, ${branchSecondary}, ${branchAccent})`,
            display:        "flex",
            alignItems:     "center",
            justifyContent: "center",
            fontSize:       "11px",
            fontWeight:     "700",
            color:          "#0C0810",
            flexShrink:     0,
            marginTop:      "2px",
          }}
        >
          B
        </div>
      )}

      {/* Bulle */}
      <div
        style={{
          maxWidth:     "78%",
          padding:      "11px 15px",
          borderRadius: isUser
            ? "15px 15px 4px 15px"
            : "15px 15px 15px 4px",
          background:   isUser
            ? `linear-gradient(135deg, rgba(201,168,76,0.18), rgba(92,45,92,0.15))`
            : "rgba(14,8,12,0.92)",
          border:       isUser
            ? "1px solid rgba(201,168,76,0.22)"
            : "1px solid rgba(240,232,216,0.07)",
        }}
      >
        {/* Label Bellaïa */}
        {isAssistant && !message.isLoading && (
          <p
            style={{
              fontSize:      "7.5px",
              color:         branchAccent,
              letterSpacing: "0.22em",
              textTransform: "uppercase",
              fontWeight:    "700",
              marginBottom:  "7px",
              fontFamily:    "Arial, sans-serif",
            }}
          >
            Bellaïa ✦
          </p>
        )}

        {/* Contenu */}
        {message.isLoading ? (
          <LoadingDots color={branchAccent} />
        ) : (
          <div>{renderText(message.content)}</div>
        )}

        {/* Timestamp */}
        <p
          style={{
            fontSize:   "9px",
            color:      "rgba(240,232,216,0.20)",
            marginTop:  "6px",
            textAlign:  isUser ? "right" : "left",
            fontFamily: "Arial, sans-serif",
          }}
        >
          {message.timestamp.toLocaleTimeString("fr-FR", {
            hour: "2-digit", minute: "2-digit",
          })}
        </p>
      </div>

      {/* Avatar fondatrice */}
      {isUser && (
        <div
          style={{
            width:          "30px",
            height:         "30px",
            borderRadius:   "50%",
            background:     `linear-gradient(135deg, ${branchAccent}, ${branchSecondary})`,
            display:        "flex",
            alignItems:     "center",
            justifyContent: "center",
            fontSize:       "11px",
            fontWeight:     "700",
            color:          "#0C0810",
            flexShrink:     0,
            marginTop:      "2px",
          }}
        >
          {prenom[0]?.toUpperCase() ?? "R"}
        </div>
      )}
    </div>
  );
}

// ── Loading dots ──────────────────────────────────────────────────────────────

function LoadingDots({ color }: { color: string }) {
  return (
    <div style={{ display: "flex", gap: "5px", alignItems: "center", padding: "2px 0" }}>
      {[0, 1, 2].map((i) => (
        <span
          key={i}
          style={{
            width:          "6px",
            height:         "6px",
            borderRadius:   "50%",
            background:     color,
            display:        "inline-block",
            animation:      "bellaia-pulse 1.2s ease-in-out infinite",
            animationDelay: `${i * 0.2}s`,
          }}
        />
      ))}
    </div>
  );
}
