import { DocumentStatusBadge } from "@/components/documents/DocumentStatusBadge";
import type { DocumentClient } from "@/types/database";
import type { Json } from "@/types/database";

/**
 * components/documents/DocumentPreview.tsx
 *
 * Prévisualisation du contenu d'un document client.
 * MVP : rendu JSON structuré. PDF en V2.
 */

interface Props {
  document: DocumentClient;
}

const TYPE_LABELS: Record<string, string> = {
  questionnaire:       "Questionnaire",
  consentement:        "Consentement",
  cgv:                 "Conditions Générales de Vente",
  autorisation:        "Autorisation",
  contrat:             "Contrat",
  fiche_conseils:      "Fiche conseils",
  questionnaire_sante: "Questionnaire santé",
};

// Affiche les paires clé/valeur d'un objet JSON de façon lisible
function renderJsonContent(content: Json): React.ReactNode {
  if (!content || typeof content !== "object" || Array.isArray(content)) {
    return (
      <p style={{ fontSize: "12px", color: "rgba(240,232,216,0.50)", fontFamily: "Arial, sans-serif" }}>
        {String(content ?? "—")}
      </p>
    );
  }

  const entries = Object.entries(content as Record<string, Json>).filter(
    ([k]) => !k.startsWith("_") && k !== "genere_par" && k !== "date_generation"
  );

  if (entries.length === 0) {
    return (
      <p style={{ fontSize: "12px", color: "rgba(240,232,216,0.35)", fontStyle: "italic", fontFamily: "Arial, sans-serif" }}>
        Aucun contenu structuré
      </p>
    );
  }

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
      {entries.map(([key, value]) => {
        const label = key.replace(/_/g, " ").replace(/\b\w/g, (c) => c.toUpperCase());
        const displayValue =
          typeof value === "boolean"
            ? value ? "Oui" : "Non"
            : Array.isArray(value)
            ? value.join(", ")
            : typeof value === "object" && value !== null
            ? JSON.stringify(value, null, 2)
            : String(value ?? "—");

        return (
          <div
            key={key}
            style={{
              display:      "flex",
              gap:          "12px",
              padding:      "8px 0",
              borderBottom: "1px solid rgba(255,255,255,0.04)",
            }}
          >
            <p
              style={{
                fontSize:   "10px",
                color:      "rgba(240,232,216,0.40)",
                minWidth:   "140px",
                flexShrink: 0,
                fontFamily: "Arial, sans-serif",
                paddingTop: "1px",
              }}
            >
              {label}
            </p>
            <p
              style={{
                fontSize:   "12px",
                color:      "#F0E8D8",
                flex:       1,
                lineHeight: "1.5",
                fontFamily: "Arial, sans-serif",
                whiteSpace: typeof value === "object" ? "pre-wrap" : "normal",
              }}
            >
              {displayValue}
            </p>
          </div>
        );
      })}
    </div>
  );
}

function formatDate(iso: string) {
  return new Date(iso).toLocaleDateString("fr-FR", {
    weekday: "long", day: "numeric", month: "long", year: "numeric",
  });
}

export function DocumentPreview({ document: doc }: Props) {
  const typeLabel = TYPE_LABELS[doc.type] ?? doc.type;

  return (
    <div
      style={{
        background:   "#120A10",
        border:       "1px solid rgba(201,168,76,0.16)",
        borderRadius: "14px",
        overflow:     "hidden",
      }}
    >
      {/* En-tête document */}
      <div
        style={{
          padding:      "16px 20px",
          borderBottom: "1px solid rgba(201,168,76,0.10)",
          background:   "linear-gradient(135deg, rgba(92,45,92,0.10), rgba(201,168,76,0.06))",
        }}
      >
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: "12px" }}>
          <div>
            <p
              style={{
                fontSize:      "8px",
                color:         "#C9A84C",
                letterSpacing: "0.22em",
                textTransform: "uppercase",
                fontFamily:    "Arial, sans-serif",
                marginBottom:  "4px",
              }}
            >
              BELLA&apos;STUDIO · {doc.univers.toUpperCase()}
            </p>
            <p
              style={{
                fontSize:   "18px",
                fontWeight: "700",
                color:      "#F0E8D8",
                fontFamily: "Georgia, serif",
              }}
            >
              {typeLabel}
            </p>
            <p
              style={{
                fontSize:   "11px",
                color:      "rgba(240,232,216,0.40)",
                marginTop:  "3px",
                fontFamily: "Arial, sans-serif",
              }}
            >
              Version {doc.version} · Créé le {formatDate(doc.created_at)}
            </p>
          </div>
          <DocumentStatusBadge statut={doc.statut} size="md" withDot />
        </div>

        {/* Règle gouvernance si brouillon */}
        {(doc.statut === "BROUILLON" || doc.statut === "EN_REVISION") && (
          <div
            style={{
              marginTop:    "12px",
              padding:      "7px 12px",
              background:   "rgba(160,32,16,0.08)",
              border:       "1px solid rgba(160,32,16,0.20)",
              borderRadius: "7px",
            }}
          >
            <p
              style={{
                fontSize:   "10px",
                color:      "rgba(220,100,80,0.80)",
                fontStyle:  "italic",
                fontFamily: "Arial, sans-serif",
              }}
            >
              🔒 Document en {doc.statut.toLowerCase().replace("_", " ")} — Validation fondatrice obligatoire avant envoi.
            </p>
          </div>
        )}

        {doc.date_validation && (
          <p
            style={{
              fontSize:   "10px",
              color:      "rgba(76,175,80,0.75)",
              marginTop:  "8px",
              fontFamily: "Arial, sans-serif",
            }}
          >
            ✓ Validé le {formatDate(doc.date_validation)}
          </p>
        )}
      </div>

      {/* Contenu */}
      <div style={{ padding: "18px 20px" }}>
        <p
          style={{
            fontSize:      "8px",
            color:         "rgba(240,232,216,0.35)",
            letterSpacing: "0.16em",
            textTransform: "uppercase",
            marginBottom:  "14px",
            fontFamily:    "Arial, sans-serif",
          }}
        >
          CONTENU DU DOCUMENT
        </p>
        {renderJsonContent(doc.contenu)}
      </div>

      {/* Pied MVP */}
      <div
        style={{
          padding:    "10px 20px",
          borderTop:  "1px solid rgba(255,255,255,0.05)",
          background: "rgba(0,0,0,0.20)",
        }}
      >
        <p
          style={{
            fontSize:   "9px",
            color:      "rgba(240,232,216,0.20)",
            fontFamily: "Arial, sans-serif",
          }}
        >
          Export PDF disponible en V2 · Bella&apos;Studio © 2026
        </p>
      </div>
    </div>
  );
}
