import Link                    from "next/link";
import { DocumentStatusBadge } from "@/components/documents/DocumentStatusBadge";
import type { DocumentClient } from "@/types/database";

/**
 * components/documents/DocumentCard.tsx
 * Ligne/carte pour un document client dans la liste.
 */

interface Props {
  document: DocumentClient & { cliente_nom?: string };
}

const TYPE_ICONS: Record<string, string> = {
  questionnaire:       "📋",
  consentement:        "✍️",
  cgv:                 "📄",
  autorisation:        "🔐",
  contrat:             "📝",
  fiche_conseils:      "💡",
  questionnaire_sante: "🏥",
};

const TYPE_LABELS: Record<string, string> = {
  questionnaire:       "Questionnaire",
  consentement:        "Consentement",
  cgv:                 "CGV",
  autorisation:        "Autorisation",
  contrat:             "Contrat",
  fiche_conseils:      "Fiche conseils",
  questionnaire_sante: "Questionnaire santé",
};

function formatDate(iso: string) {
  return new Date(iso).toLocaleDateString("fr-FR", {
    day: "numeric", month: "short", year: "numeric",
  });
}

export function DocumentCard({ document: doc }: Props) {
  const icon  = TYPE_ICONS[doc.type]  ?? "📄";
  const label = TYPE_LABELS[doc.type] ?? doc.type;

  return (
    <Link
      href={`/documents/${doc.id}`}
      style={{
        display:             "grid",
        gridTemplateColumns: "36px 1fr 120px 110px 90px 80px 60px",
        gap:                 "10px",
        padding:             "11px 14px",
        alignItems:          "center",
        textDecoration:      "none",
        borderBottom:        "1px solid rgba(255,255,255,0.05)",
        transition:          "background 0.15s",
      }}
      onMouseEnter={(e) => { (e.currentTarget as HTMLAnchorElement).style.background = "rgba(255,255,255,0.03)"; }}
      onMouseLeave={(e) => { (e.currentTarget as HTMLAnchorElement).style.background = "transparent"; }}
    >
      {/* Icône type */}
      <span style={{ fontSize: "16px", textAlign: "center" }}>{icon}</span>

      {/* Type + cliente */}
      <div style={{ minWidth: 0 }}>
        <p style={{ fontSize: "12px", fontWeight: "500", color: "#F0E8D8", fontFamily: "Arial, sans-serif" }}>
          {label}
        </p>
        {doc.cliente_nom && (
          <p style={{ fontSize: "10px", color: "rgba(240,232,216,0.40)", marginTop: "1px", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", fontFamily: "Arial, sans-serif" }}>
            {doc.cliente_nom}
          </p>
        )}
      </div>

      {/* Univers */}
      <p style={{ fontSize: "10px", color: "rgba(240,232,216,0.45)", fontFamily: "Arial, sans-serif" }}>
        {doc.univers}
      </p>

      {/* Statut */}
      <DocumentStatusBadge statut={doc.statut} size="xs" withDot />

      {/* Version */}
      <p style={{ fontSize: "10px", color: "rgba(240,232,216,0.35)", fontFamily: "Arial, sans-serif" }}>
        {doc.version}
      </p>

      {/* Date */}
      <p style={{ fontSize: "10px", color: "rgba(240,232,216,0.28)", fontFamily: "Arial, sans-serif" }}>
        {formatDate(doc.created_at)}
      </p>

      {/* Flèche */}
      <p style={{ fontSize: "15px", color: "rgba(201,168,76,0.30)", textAlign: "right" }}>›</p>
    </Link>
  );
}
