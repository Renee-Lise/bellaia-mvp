import { getStatutDoc } from "@/constants/statuts";
import type { StatutDoc } from "@/constants/statuts";

/**
 * components/documents/DocumentStatusBadge.tsx
 * Badge visuel pour le statut d'un document client.
 */

interface Props {
  statut:   StatutDoc | string;
  size?:    "xs" | "sm" | "md";
  withDot?: boolean;
}

const SIZES = {
  xs: { fontSize: "9px",  padding: "1px 7px"  },
  sm: { fontSize: "10px", padding: "2px 9px"  },
  md: { fontSize: "12px", padding: "4px 13px" },
} as const;

export function DocumentStatusBadge({ statut, size = "sm", withDot = false }: Props) {
  const cfg   = getStatutDoc(statut);
  const sz    = SIZES[size];
  const color = cfg?.color  ?? "#888";
  const label = cfg?.label  ?? statut;

  return (
    <span
      style={{
        display:       "inline-flex",
        alignItems:    "center",
        gap:           withDot ? "5px" : "0",
        padding:       sz.padding,
        borderRadius:  "20px",
        fontSize:      sz.fontSize,
        fontWeight:    "600",
        letterSpacing: "0.02em",
        background:    `${color}18`,
        color,
        border:        `1px solid ${color}40`,
        whiteSpace:    "nowrap",
        fontFamily:    "Arial, sans-serif",
      }}
    >
      {withDot && (
        <span
          style={{
            width: "5px", height: "5px", borderRadius: "50%",
            background: color, flexShrink: 0, display: "inline-block",
          }}
        />
      )}
      {label}
    </span>
  );
}
