"use client";

import { useEffect, useState, useCallback } from "react";
import { NotificationItem }     from "@/components/notifications/NotificationItem";
import type { Notification }    from "@/components/notifications/NotificationItem";

/**
 * components/notifications/NotificationCenter.tsx
 *
 * Panneau de notifications glissant depuis le header.
 * Charge les alertes depuis /api/automations/notifications.
 * Toutes les actions critiques pointent vers la page dédiée.
 */

interface Props {
  isOpen:   boolean;
  onClose:  () => void;
  /** Callback pour mettre à jour le badge dans le Header */
  onCountChange?: (n: number) => void;
}

export function NotificationCenter({ isOpen, onClose, onCountChange }: Props) {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [loading,       setLoading]       = useState(false);
  const [filter,        setFilter]        = useState<"all" | "unread">("unread");

  const fetchNotifications = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/automations?type=notifications&limit=50");
      if (!res.ok) return;
      const data = await res.json();
      const notifs: Notification[] = data.notifications ?? [];
      setNotifications(notifs);
      const unread = notifs.filter((n) => !n.lue).length;
      onCountChange?.(unread);
    } catch {
      // Silencieux — ne pas bloquer l'UI si l'API n'est pas encore disponible
    } finally {
      setLoading(false);
    }
  }, [onCountChange]);

  useEffect(() => {
    if (isOpen) fetchNotifications();
  }, [isOpen, fetchNotifications]);

  const markRead = async (id: string) => {
    setNotifications((prev) =>
      prev.map((n) => n.id === id ? { ...n, lue: true } : n)
    );
    const unread = notifications.filter((n) => !n.lue && n.id !== id).length;
    onCountChange?.(unread);

    await fetch(`/api/automations/${id}?action=mark_read`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({}),
    }).catch(() => {});
  };

  const markAllRead = async () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, lue: true })));
    onCountChange?.(0);
    await fetch("/api/automations?action=mark_all_read", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({}),
    }).catch(() => {});
  };

  const displayed = filter === "unread"
    ? notifications.filter((n) => !n.lue)
    : notifications;

  const unreadCount = notifications.filter((n) => !n.lue).length;

  if (!isOpen) return null;

  return (
    <>
      {/* Overlay */}
      <div
        onClick={onClose}
        style={{ position: "fixed", inset: 0, zIndex: 30 }}
      />

      {/* Panneau */}
      <div
        style={{
          position:   "fixed",
          top:        "60px",
          right:      "16px",
          width:      "380px",
          maxWidth:   "calc(100vw - 32px)",
          maxHeight:  "calc(100vh - 80px)",
          zIndex:     40,
          background: "#120A10",
          border:     "1px solid rgba(201,168,76,0.22)",
          borderRadius: "14px",
          boxShadow:  "0 12px 40px rgba(0,0,0,0.55)",
          display:    "flex",
          flexDirection: "column",
          overflow:   "hidden",
          animation:  "bellaia-fade-in 0.2s ease-out",
        }}
      >
        {/* Header */}
        <div
          style={{
            display:        "flex",
            justifyContent: "space-between",
            alignItems:     "center",
            padding:        "14px 16px",
            borderBottom:   "1px solid rgba(201,168,76,0.10)",
            flexShrink:     0,
          }}
        >
          <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
            <p style={{ fontSize: "13px", fontWeight: "700", color: "#F0E8D8", fontFamily: "Georgia, serif" }}>
              Notifications
            </p>
            {unreadCount > 0 && (
              <span
                style={{
                  fontSize:     "10px",
                  padding:      "1px 7px",
                  borderRadius: "20px",
                  background:   "#F44336",
                  color:        "#FFFFFF",
                  fontWeight:   "700",
                  fontFamily:   "Arial, sans-serif",
                }}
              >
                {unreadCount}
              </span>
            )}
          </div>
          <div style={{ display: "flex", gap: "8px", alignItems: "center" }}>
            {unreadCount > 0 && (
              <button
                type="button"
                onClick={markAllRead}
                style={{ fontSize: "10px", color: "rgba(201,168,76,0.60)", background: "none", border: "none", cursor: "pointer", fontFamily: "Georgia, serif" }}
              >
                Tout marquer lu
              </button>
            )}
            <button
              type="button"
              onClick={onClose}
              style={{ fontSize: "16px", color: "rgba(240,232,216,0.40)", background: "none", border: "none", cursor: "pointer" }}
            >
              ✕
            </button>
          </div>
        </div>

        {/* Filtres */}
        <div
          style={{
            display:    "flex",
            gap:        "6px",
            padding:    "10px 16px",
            borderBottom: "1px solid rgba(255,255,255,0.05)",
            flexShrink: 0,
          }}
        >
          {([
            { key: "unread", label: `Non lues${unreadCount > 0 ? ` (${unreadCount})` : ""}` },
            { key: "all",    label: "Toutes" },
          ] as const).map((f) => (
            <button
              key={f.key}
              type="button"
              onClick={() => setFilter(f.key)}
              style={{
                padding:      "4px 12px",
                borderRadius: "20px",
                fontSize:     "10px",
                cursor:       "pointer",
                fontFamily:   "Georgia, serif",
                background:   filter === f.key ? "rgba(201,168,76,0.15)" : "transparent",
                border:       `1px solid ${filter === f.key ? "rgba(201,168,76,0.35)" : "rgba(255,255,255,0.08)"}`,
                color:        filter === f.key ? "#C9A84C" : "rgba(240,232,216,0.45)",
              }}
            >
              {f.label}
            </button>
          ))}
        </div>

        {/* Liste */}
        <div style={{ flex: 1, overflowY: "auto", padding: "10px 12px" }}>
          {loading ? (
            <div style={{ display: "flex", flexDirection: "column", gap: "6px" }}>
              {[0, 1, 2].map((i) => (
                <div
                  key={i}
                  style={{
                    height: "58px", borderRadius: "9px",
                    background: "rgba(255,255,255,0.04)",
                    animation: "bellaia-pulse 1.4s ease-in-out infinite",
                    animationDelay: `${i * 0.1}s`,
                  }}
                />
              ))}
            </div>
          ) : displayed.length === 0 ? (
            <div style={{ padding: "30px", textAlign: "center" }}>
              <p style={{ fontSize: "20px", marginBottom: "8px" }}>✅</p>
              <p style={{ fontSize: "12px", color: "rgba(240,232,216,0.35)", fontFamily: "Arial, sans-serif" }}>
                {filter === "unread" ? "Aucune notification non lue" : "Aucune notification"}
              </p>
            </div>
          ) : (
            <div style={{ display: "flex", flexDirection: "column", gap: "5px" }}>
              {displayed.map((n) => (
                <NotificationItem
                  key={n.id}
                  notification={n}
                  onMarkRead={markRead}
                />
              ))}
            </div>
          )}
        </div>

        {/* Footer */}
        <div
          style={{
            padding:    "8px 16px",
            borderTop:  "1px solid rgba(255,255,255,0.05)",
            flexShrink: 0,
          }}
        >
          <p style={{ fontSize: "9px", color: "rgba(240,232,216,0.20)", textAlign: "center", fontStyle: "italic", fontFamily: "Arial, sans-serif" }}>
            Bellaïa prépare · Renée-Lise décide · Toute action critique nécessite votre validation
          </p>
        </div>
      </div>
    </>
  );
}
