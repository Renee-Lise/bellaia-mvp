import Link from "next/link";

/**
 * components/notifications/NotificationItem.tsx
 * Ligne de notification dans le centre de notifications.
 */

export type NotificationLevel = "critique" | "haute" | "normale" | "info";
export type NotificationEntite = "commande" | "stock" | "paiement" | "document" | "cliente" | "session" | "system";

export interface Notification {
  id:       string;
  niveau:   NotificationLevel;
  entite:   NotificationEntite;
  titre:    string;
  message:  string;
  href?:    string;
  lue:      boolean;
  created_at: string;
}

interface Props {
  notification: Notification;
  onMarkRead?: (id: string) => void;
}

const NIVEAU_CFG: Record<NotificationLevel, { color: string; bg: string; border: string }> = {
  critique: { color: "#F44336", bg: "rgba(244,67,54,0.07)",  border: "rgba(244,67,54,0.20)"  },
  haute:    { color: "#FF9800", bg: "rgba(255,152,0,0.06)",  border: "rgba(255,152,0,0.18)"  },
  normale:  { color: "#C9A84C", bg: "rgba(201,168,76,0.06)", border: "rgba(201,168,76,0.16)" },
  info:     { color: "#7EB8C4", bg: "rgba(126,184,196,0.05)",border: "rgba(126,184,196,0.14)"},
};

const ENTITE_ICON: Record<NotificationEntite, string> = {
  commande:  "◆",
  stock:     "▣",
  paiement:  "◐",
  document:  "◇",
  cliente:   "✦",
  session:   "🗓️",
  system:    "◈",
};

function timeAgo(iso: string): string {
  const diff = Date.now() - new Date(iso).getTime();
  if (diff < 60000)    return "À l'instant";
  if (diff < 3600000)  return `Il y a ${Math.round(diff / 60000)} min`;
  if (diff < 86400000) return `Il y a ${Math.round(diff / 3600000)} h`;
  const d = new Date(iso);
  return d.toLocaleDateString("fr-FR", { day: "numeric", month: "short" });
}

export function NotificationItem({ notification: n, onMarkRead }: Props) {
  const cfg  = NIVEAU_CFG[n.niveau];
  const icon = ENTITE_ICON[n.entite];

  const inner = (
    <div
      style={{
        display:    "flex",
        gap:        "10px",
        padding:    "10px 13px",
        background: n.lue ? "transparent" : cfg.bg,
        border:     `1px solid ${n.lue ? "rgba(255,255,255,0.05)" : cfg.border}`,
        borderRadius: "9px",
        transition: "background 0.15s",
        cursor:     n.href ? "pointer" : "default",
      }}
    >
      {/* Indicateur non-lu */}
      <div
        style={{
          width:        "7px",
          height:       "7px",
          borderRadius: "50%",
          background:   n.lue ? "rgba(255,255,255,0.10)" : cfg.color,
          boxShadow:    n.lue ? "none" : `0 0 5px ${cfg.color}AA`,
          flexShrink:   0,
          marginTop:    "5px",
        }}
      />

      {/* Icône entité */}
      <span style={{ fontSize: "12px", color: cfg.color, flexShrink: 0, opacity: n.lue ? 0.45 : 0.80 }}>
        {icon}
      </span>

      {/* Texte */}
      <div style={{ flex: 1, minWidth: 0 }}>
        <p style={{ fontSize: "12px", fontWeight: n.lue ? "400" : "600", color: n.lue ? "rgba(240,232,216,0.55)" : "#F0E8D8", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", fontFamily: "Arial, sans-serif" }}>
          {n.titre}
        </p>
        <p style={{ fontSize: "10px", color: "rgba(240,232,216,0.42)", marginTop: "2px", lineHeight: "1.4", fontFamily: "Arial, sans-serif" }}>
          {n.message}
        </p>
      </div>

      {/* Droite : temps + bouton lu */}
      <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", gap: "4px", flexShrink: 0 }}>
        <p style={{ fontSize: "9px", color: "rgba(240,232,216,0.25)", fontFamily: "Arial, sans-serif" }}>
          {timeAgo(n.created_at)}
        </p>
        {!n.lue && onMarkRead && (
          <button
            type="button"
            onClick={(e) => { e.preventDefault(); e.stopPropagation(); onMarkRead(n.id); }}
            style={{ fontSize: "9px", padding: "1px 7px", borderRadius: "10px", background: "rgba(201,168,76,0.08)", border: "1px solid rgba(201,168,76,0.20)", color: "rgba(201,168,76,0.60)", cursor: "pointer", fontFamily: "Arial, sans-serif" }}
          >
            Lu
          </button>
        )}
      </div>
    </div>
  );

  if (n.href) {
    return (
      <Link href={n.href} style={{ textDecoration: "none", display: "block" }}>
        {inner}
      </Link>
    );
  }
  return inner;
}
