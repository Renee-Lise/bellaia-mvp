import { getStatutCommande } from "@/constants/statuts";
import type { StatutCommande } from "@/constants/statuts";

/**
 * components/commandes/StatutBadge.tsx
 *
 * Badge visuel pour un statut de commande.
 * Utilise la config centralisée de constants/statuts.ts.
 */

interface StatutBadgeProps {
  statut:  StatutCommande | string;
  size?:   "xs" | "sm" | "md";
  /** Afficher un point lumineux à gauche */
  withDot?: boolean;
}

const SIZE_CONFIG = {
  xs: { fontSize: "9px",  padding: "1px 7px",  dotSize: "5px" },
  sm: { fontSize: "10px", padding: "2px 9px",  dotSize: "6px" },
  md: { fontSize: "12px", padding: "4px 12px", dotSize: "7px" },
} as const;

export function StatutBadge({
  statut,
  size    = "sm",
  withDot = false,
}: StatutBadgeProps) {
  const cfg  = getStatutCommande(statut);
  const sz   = SIZE_CONFIG[size];

  const color  = cfg?.color  ?? "#888888";
  const label  = cfg?.label  ?? statut;

  return (
    <span
      style={{
        display:       "inline-flex",
        alignItems:    "center",
        gap:           withDot ? "5px" : 0,
        padding:       sz.padding,
        borderRadius:  "20px",
        fontSize:      sz.fontSize,
        fontWeight:    "600",
        letterSpacing: "0.03em",
        background:    `${color}18`,
        color,
        border:        `1px solid ${color}40`,
        whiteSpace:    "nowrap",
        fontFamily:    "Arial, sans-serif",
      }}
    >
      {withDot && (
        <span
          style={{
            width:        sz.dotSize,
            height:       sz.dotSize,
            borderRadius: "50%",
            background:   color,
            boxShadow:    `0 0 4px ${color}AA`,
            flexShrink:   0,
            display:      "inline-block",
          }}
        />
      )}
      {label}
    </span>
  );
}
