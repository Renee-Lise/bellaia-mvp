"use client";

import { useState } from "react";
import { ValidationModal }           from "@/components/validation/ValidationModal";
import { useValidation }             from "@/hooks/useValidation";
import { StatutBadge }               from "@/components/commandes/StatutBadge";
import {
  STATUTS_COMMANDE,
  STATUTS_FINANCIERS,
  getStatutCommande,
} from "@/constants/statuts";
import type { StatutCommande } from "@/constants/statuts";

/**
 * components/commandes/StatutSelector.tsx
 *
 * Sélecteur de statut pour une commande.
 * - Affiche tous les statuts disponibles
 * - Met en évidence le statut actuel
 * - Pour les statuts financiers : ouvre ValidationModal avant d'appeler l'API
 * - Pour les autres statuts : demande confirmation simple
 * - Appelle PUT /api/commandes/[id]/statut après confirmation
 */

interface StatutSelectorProps {
  commandeId:    string;
  statutActuel:  StatutCommande;
  clienteNom:    string;
  total:         number;
  /** Callback appelé après mise à jour réussie */
  onUpdate:      (nouveauStatut: StatutCommande) => void;
  /** Désactiver le sélecteur (ex: pendant une autre opération) */
  disabled?:     boolean;
}

export function StatutSelector({
  commandeId,
  statutActuel,
  clienteNom,
  total,
  onUpdate,
  disabled = false,
}: StatutSelectorProps) {
  const validation        = useValidation();
  const [error, setError] = useState<string | null>(null);

  const statutActuelCfg = getStatutCommande(statutActuel);

  // ── Sélection d'un nouveau statut ─────────────────────────────────────────
  const handleSelect = (cible: StatutCommande) => {
    if (disabled || cible === statutActuel) return;
    setError(null);

    const cibleCfg    = getStatutCommande(cible);
    const estFinancier = STATUTS_FINANCIERS.includes(cible);

    validation.request({
      action:    estFinancier ? "paiement_marked_received" : "commande_statut_change",
      entite:    "commandes",
      entite_id: commandeId,
      titre:     estFinancier
        ? `Valider un statut financier — ${cibleCfg?.label}`
        : `Changer le statut — ${cibleCfg?.label}`,
      resume:    `Commande de ${clienteNom} (${total.toFixed(2)} €)\n${statutActuelCfg?.label ?? statutActuel}  →  ${cibleCfg?.label ?? cible}`,
      impact:    estFinancier
        ? `Statut financier — implique la réception ou validation d'un paiement. Enregistré dans le journal d'audit avec mention "fondatrice".`
        : `Changement de statut opérationnel. Enregistré dans le journal d'audit.`,
      onConfirm: async () => {
        const res = await fetch(`/api/commandes/${commandeId}/statut`, {
          method:  "PUT",
          headers: { "Content-Type": "application/json" },
          body:    JSON.stringify({
            statut:      cible,
            commentaire: validation.motif || undefined,
          }),
        });

        if (!res.ok) {
          const json = await res.json().catch(() => ({}));
          throw new Error(json.error ?? `HTTP ${res.status}`);
        }

        const json = await res.json();
        onUpdate(json.commande.statut as StatutCommande);
      },
    });
  };

  // ── Statuts terminaux — affichage readonly ─────────────────────────────────
  const estTerminal = statutActuel === "livre" || statutActuel === "annule";

  return (
    <div>
      {/* Statut actuel */}
      <div
        style={{
          display:     "flex",
          alignItems:  "center",
          gap:         "10px",
          marginBottom: "14px",
        }}
      >
        <p
          style={{
            fontSize:      "9px",
            color:         "rgba(240,232,216,0.40)",
            letterSpacing: "0.14em",
            textTransform: "uppercase",
            fontFamily:    "Arial, sans-serif",
          }}
        >
          Statut actuel
        </p>
        <StatutBadge statut={statutActuel} size="md" withDot />
        {estTerminal && (
          <span
            style={{
              fontSize:   "10px",
              color:      "rgba(240,232,216,0.35)",
              fontStyle:  "italic",
              fontFamily: "Arial, sans-serif",
            }}
          >
            (état final — non modifiable)
          </span>
        )}
      </div>

      {/* Grille des statuts */}
      {!estTerminal && (
        <>
          <p
            style={{
              fontSize:      "9px",
              color:         "rgba(240,232,216,0.38)",
              letterSpacing: "0.14em",
              textTransform: "uppercase",
              marginBottom:  "10px",
              fontFamily:    "Arial, sans-serif",
            }}
          >
            Changer vers
          </p>

          <div
            style={{
              display:             "grid",
              gridTemplateColumns: "repeat(auto-fill, minmax(160px, 1fr))",
              gap:                 "7px",
            }}
          >
            {STATUTS_COMMANDE.map((s) => {
              const isCurrent   = s.key === statutActuel;
              const isFinancier = STATUTS_FINANCIERS.includes(s.key);

              return (
                <button
                  key={s.key}
                  type="button"
                  onClick={() => handleSelect(s.key)}
                  disabled={disabled || isCurrent}
                  title={
                    isCurrent
                      ? "Statut actuel"
                      : isFinancier
                      ? "⚠ Statut financier — validation fondatrice requise"
                      : s.description ?? ""
                  }
                  style={{
                    display:       "flex",
                    alignItems:    "center",
                    gap:           "8px",
                    padding:       "8px 11px",
                    borderRadius:  "8px",
                    border:        `1px solid ${isCurrent ? `${s.color}55` : `${s.color}22`}`,
                    background:    isCurrent
                      ? `${s.color}20`
                      : disabled
                      ? "rgba(255,255,255,0.02)"
                      : "rgba(255,255,255,0.03)",
                    cursor:        isCurrent || disabled ? "default" : "pointer",
                    opacity:       disabled && !isCurrent ? 0.45 : 1,
                    transition:    "background 0.15s, border-color 0.15s",
                    textAlign:     "left",
                  }}
                  onMouseEnter={(e) => {
                    if (!isCurrent && !disabled) {
                      (e.currentTarget).style.background     = `${s.color}18`;
                      (e.currentTarget).style.borderColor    = `${s.color}45`;
                    }
                  }}
                  onMouseLeave={(e) => {
                    if (!isCurrent && !disabled) {
                      (e.currentTarget).style.background     = "rgba(255,255,255,0.03)";
                      (e.currentTarget).style.borderColor    = `${s.color}22`;
                    }
                  }}
                >
                  {/* Dot */}
                  <span
                    style={{
                      width:        "7px",
                      height:       "7px",
                      borderRadius: "50%",
                      background:   s.color,
                      flexShrink:   0,
                      boxShadow:    isCurrent ? `0 0 5px ${s.color}AA` : "none",
                    }}
                  />

                  {/* Label */}
                  <span
                    style={{
                      fontSize:   "11px",
                      color:      isCurrent ? s.color : "rgba(240,232,216,0.72)",
                      fontWeight: isCurrent ? "600" : "400",
                      flex:       1,
                      fontFamily: "Arial, sans-serif",
                    }}
                  >
                    {s.label}
                  </span>

                  {/* Icône financier */}
                  {isFinancier && !isCurrent && (
                    <span
                      style={{
                        fontSize:   "10px",
                        opacity:    0.55,
                        flexShrink: 0,
                      }}
                      title="Validation fondatrice requise"
                    >
                      🔒
                    </span>
                  )}

                  {/* Indicateur courant */}
                  {isCurrent && (
                    <span
                      style={{
                        fontSize:   "9px",
                        color:      s.color,
                        fontStyle:  "italic",
                        flexShrink: 0,
                        fontFamily: "Arial, sans-serif",
                      }}
                    >
                      actuel
                    </span>
                  )}
                </button>
              );
            })}
          </div>

          {/* Note gouvernance */}
          <p
            style={{
              marginTop:  "12px",
              fontSize:   "10px",
              color:      "rgba(220, 100, 80, 0.65)",
              fontStyle:  "italic",
              fontFamily: "Arial, sans-serif",
            }}
          >
            🔒 Les statuts financiers nécessitent une validation fondatrice explicite.
          </p>
        </>
      )}

      {/* Erreur */}
      {error && (
        <div
          style={{
            marginTop:    "10px",
            padding:      "9px 12px",
            borderRadius: "8px",
            background:   "rgba(244,67,54,0.10)",
            border:       "1px solid rgba(244,67,54,0.25)",
            fontSize:     "12px",
            color:        "#F44336",
            fontFamily:   "Arial, sans-serif",
          }}
        >
          {error}
        </div>
      )}

      {/* Modal de validation fondatrice */}
      <ValidationModal validation={validation} />
    </div>
  );
}
