"use client";

import { useState } from "react";

/**
 * components/automations/AutomationBuilder.tsx
 *
 * Constructeur visuel d'une nouvelle automatisation.
 * MVP : définit déclencheur + action + condition.
 * Architecture extensible : chaque step est sérialisé en JSON pour Supabase.
 */

export type TriggerType =
  | "stock_faible"
  | "commande_recue"
  | "paiement_en_attente"
  | "document_en_revision"
  | "cliente_inactive"
  | "document_expire"
  | "session_j_moins_3"
  | "manuel";

export type ActionType =
  | "notifier_fondatrice"
  | "preparer_relance"
  | "preparer_document"
  | "archiver_document"
  | "preparer_rapport"
  | "marquer_traite";

export interface AutomationConfig {
  nom:            string;
  description:    string;
  trigger:        TriggerType;
  trigger_params: Record<string, unknown>;
  action:         ActionType;
  action_params:  Record<string, unknown>;
  actif:          boolean;
  requiert_validation: boolean;
}

interface Props {
  onSave:   (config: AutomationConfig) => Promise<void>;
  onCancel: () => void;
  loading?: boolean;
  error?:   string | null;
}

const TRIGGERS: { key: TriggerType; label: string; icon: string; description: string }[] = [
  { key: "stock_faible",            label: "Stock faible / rupture",       icon: "📦", description: "Déclenché quand un stock passe sous son seuil d'alerte" },
  { key: "commande_recue",          label: "Nouvelle commande",             icon: "◆",  description: "Déclenché à la réception d'une nouvelle commande" },
  { key: "paiement_en_attente",     label: "Paiement en attente > N jours", icon: "◐",  description: "Déclenché si un paiement n'est pas reçu après N jours" },
  { key: "document_en_revision",    label: "Document en révision > N jours",icon: "◇",  description: "Déclenché si un document reste en révision trop longtemps" },
  { key: "cliente_inactive",        label: "Cliente inactive > N jours",    icon: "✦",  description: "Déclenché si une cliente n'a pas d'activité depuis N jours" },
  { key: "document_expire",         label: "Document arrivant à expiration", icon: "📄", description: "Déclenché X jours avant l'expiration d'un document" },
  { key: "session_j_moins_3",       label: "Session boudoir dans 3 jours",  icon: "🗓️", description: "Rappel automatique 3 jours avant une session" },
  { key: "manuel",                  label: "Déclenchement manuel",          icon: "▶",  description: "Exécuté uniquement à la demande de la fondatrice" },
];

const ACTIONS: { key: ActionType; label: string; icon: string; description: string; needs_validation: boolean }[] = [
  { key: "notifier_fondatrice",  label: "Notifier la fondatrice",    icon: "🔔", description: "Crée une notification dans le dashboard",    needs_validation: false },
  { key: "preparer_relance",     label: "Préparer un message relance", icon: "✉️", description: "Rédige le message, fondatrice valide avant envoi", needs_validation: true },
  { key: "preparer_document",    label: "Préparer un document",      icon: "📝", description: "Génère un brouillon, fondatrice valide avant envoi", needs_validation: true },
  { key: "archiver_document",    label: "Archiver un document",      icon: "📁", description: "Archive automatiquement les documents expirés",  needs_validation: false },
  { key: "preparer_rapport",     label: "Préparer un rapport",       icon: "📊", description: "Génère un rapport de synthèse",                 needs_validation: false },
  { key: "marquer_traite",       label: "Marquer comme traité",      icon: "✅", description: "Marque l'élément comme traité dans le système",  needs_validation: false },
];

const inputStyle: React.CSSProperties = {
  width: "100%", padding: "9px 12px", borderRadius: "8px",
  background: "rgba(255,255,255,0.04)", border: "1px solid rgba(201,168,76,0.18)",
  color: "#F0E8D8", fontSize: "13px", outline: "none", fontFamily: "Arial, sans-serif",
};

const labelStyle: React.CSSProperties = {
  display: "block", fontSize: "9px", color: "rgba(240,232,216,0.40)",
  letterSpacing: "0.14em", textTransform: "uppercase", marginBottom: "6px",
  fontFamily: "Arial, sans-serif",
};

export function AutomationBuilder({ onSave, onCancel, loading = false, error }: Props) {
  const [nom,           setNom]           = useState("");
  const [description,   setDescription]   = useState("");
  const [trigger,       setTrigger]       = useState<TriggerType>("commande_recue");
  const [action,        setAction]        = useState<ActionType>("notifier_fondatrice");
  const [joursParam,    setJoursParam]    = useState(3);
  const [brancheParam,  setBrancheParam]  = useState("");
  const [actif,         setActif]         = useState(true);

  const selectedAction  = ACTIONS.find((a) => a.key === action);
  const selectedTrigger = TRIGGERS.find((t) => t.key === trigger);
  const needsValidation = selectedAction?.needs_validation ?? false;

  const showJoursParam = ["paiement_en_attente", "document_en_revision", "cliente_inactive", "document_expire"].includes(trigger);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!nom.trim()) return;

    const triggerParams: Record<string, unknown> = {};
    if (showJoursParam) triggerParams.jours = joursParam;
    if (brancheParam)   triggerParams.branche = brancheParam;

    await onSave({
      nom:            nom.trim(),
      description:    description.trim() || selectedTrigger?.description ?? "",
      trigger,
      trigger_params: triggerParams,
      action,
      action_params:  {},
      actif,
      requiert_validation: needsValidation,
    });
  };

  return (
    <form onSubmit={handleSubmit} style={{ display: "flex", flexDirection: "column", gap: "20px" }}>

      {/* Nom et description */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "12px" }}>
        <div>
          <label style={labelStyle}>Nom de l&apos;automatisation *</label>
          <input
            type="text" required value={nom}
            onChange={(e) => setNom(e.target.value)}
            placeholder="Ex : Alerte stock lingerie"
            style={inputStyle}
          />
        </div>
        <div>
          <label style={labelStyle}>Description (optionnel)</label>
          <input
            type="text" value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="Ce que fait cette automatisation…"
            style={inputStyle}
          />
        </div>
      </div>

      {/* Déclencheur */}
      <div>
        <label style={labelStyle}>Déclencheur</label>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(200px, 1fr))", gap: "7px" }}>
          {TRIGGERS.map((t) => (
            <button
              key={t.key} type="button"
              onClick={() => setTrigger(t.key)}
              style={{
                padding: "9px 12px", borderRadius: "8px", textAlign: "left", cursor: "pointer",
                background: trigger === t.key ? "rgba(201,168,76,0.12)" : "rgba(255,255,255,0.03)",
                border: `1px solid ${trigger === t.key ? "rgba(201,168,76,0.40)" : "rgba(255,255,255,0.08)"}`,
                color: trigger === t.key ? "#C9A84C" : "rgba(240,232,216,0.55)",
                transition: "all 0.15s",
              }}
            >
              <div style={{ display: "flex", alignItems: "center", gap: "7px", marginBottom: "3px" }}>
                <span style={{ fontSize: "13px" }}>{t.icon}</span>
                <span style={{ fontSize: "11px", fontWeight: "600", fontFamily: "Arial, sans-serif" }}>{t.label}</span>
              </div>
              <p style={{ fontSize: "9px", color: "rgba(240,232,216,0.35)", fontFamily: "Arial, sans-serif", lineHeight: "1.3" }}>
                {t.description}
              </p>
            </button>
          ))}
        </div>
      </div>

      {/* Paramètre jours si applicable */}
      {showJoursParam && (
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "12px" }}>
          <div>
            <label style={labelStyle}>Délai de déclenchement (jours)</label>
            <input
              type="number" min={1} max={365} value={joursParam}
              onChange={(e) => setJoursParam(parseInt(e.target.value) || 3)}
              style={inputStyle}
            />
          </div>
          <div>
            <label style={labelStyle}>Branche (optionnel)</label>
            <input
              type="text" value={brancheParam}
              onChange={(e) => setBrancheParam(e.target.value)}
              placeholder="Ex : secret_home"
              style={inputStyle}
            />
          </div>
        </div>
      )}

      {/* Action */}
      <div>
        <label style={labelStyle}>Action à exécuter</label>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(200px, 1fr))", gap: "7px" }}>
          {ACTIONS.map((a) => (
            <button
              key={a.key} type="button"
              onClick={() => setAction(a.key)}
              style={{
                padding: "9px 12px", borderRadius: "8px", textAlign: "left", cursor: "pointer",
                background: action === a.key ? "rgba(92,45,92,0.18)" : "rgba(255,255,255,0.03)",
                border: `1px solid ${action === a.key ? "rgba(92,45,92,0.45)" : "rgba(255,255,255,0.08)"}`,
                color: action === a.key ? "#D4A0B5" : "rgba(240,232,216,0.55)",
                transition: "all 0.15s",
              }}
            >
              <div style={{ display: "flex", alignItems: "center", gap: "7px", marginBottom: "3px" }}>
                <span style={{ fontSize: "13px" }}>{a.icon}</span>
                <span style={{ fontSize: "11px", fontWeight: "600", fontFamily: "Arial, sans-serif" }}>{a.label}</span>
                {a.needs_validation && (
                  <span style={{ fontSize: "9px", color: "rgba(220,100,80,0.70)" }}>🔒</span>
                )}
              </div>
              <p style={{ fontSize: "9px", color: "rgba(240,232,216,0.35)", fontFamily: "Arial, sans-serif", lineHeight: "1.3" }}>
                {a.description}
              </p>
            </button>
          ))}
        </div>
      </div>

      {/* Options */}
      <div style={{ display: "flex", alignItems: "center", gap: "12px" }}>
        <label style={{ display: "flex", alignItems: "center", gap: "8px", cursor: "pointer" }}>
          <input
            type="checkbox" checked={actif}
            onChange={(e) => setActif(e.target.checked)}
            style={{ accentColor: "#C9A84C", width: "14px", height: "14px" }}
          />
          <span style={{ fontSize: "12px", color: "rgba(240,232,216,0.65)", fontFamily: "Arial, sans-serif" }}>
            Activer immédiatement
          </span>
        </label>
      </div>

      {/* Info validation */}
      {needsValidation && (
        <div style={{ padding: "9px 13px", background: "rgba(160,32,16,0.07)", border: "1px solid rgba(160,32,16,0.18)", borderRadius: "8px" }}>
          <p style={{ fontSize: "10px", color: "rgba(220,100,80,0.80)", fontStyle: "italic", fontFamily: "Arial, sans-serif" }}>
            🔒 Cette action prépare uniquement — validation fondatrice obligatoire avant toute exécution réelle.
          </p>
        </div>
      )}

      {/* Erreur */}
      {error && (
        <div style={{ padding: "10px 14px", background: "rgba(244,67,54,0.10)", border: "1px solid rgba(244,67,54,0.25)", borderRadius: "8px", fontSize: "13px", color: "#F44336", fontFamily: "Arial, sans-serif" }}>
          {error}
        </div>
      )}

      {/* Boutons */}
      <div style={{ display: "flex", gap: "10px" }}>
        <button type="button" onClick={onCancel}
          style={{ flex: 1, padding: "11px", borderRadius: "10px", background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.10)", color: "rgba(240,232,216,0.50)", cursor: "pointer", fontSize: "13px", fontFamily: "Georgia, serif" }}>
          Annuler
        </button>
        <button type="submit" disabled={loading || !nom.trim()}
          style={{
            flex: 2, padding: "11px", borderRadius: "10px", fontWeight: "700", fontSize: "13px",
            background: loading || !nom.trim() ? "rgba(201,168,76,0.10)" : "linear-gradient(135deg, #C9A84C, #5C2D5C)",
            border: "none",
            color: loading || !nom.trim() ? "rgba(240,232,216,0.25)" : "#0C0810",
            cursor: loading || !nom.trim() ? "not-allowed" : "pointer",
            fontFamily: "Georgia, serif",
          }}>
          {loading ? "Création…" : "Créer l'automatisation"}
        </button>
      </div>
    </form>
  );
}
