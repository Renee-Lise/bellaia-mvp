import { AutomationStatusBadge } from "@/components/automations/AutomationStatusBadge";
import type { AutomationStatus }   from "@/components/automations/AutomationStatusBadge";

/**
 * components/automations/AutomationCard.tsx
 * Carte d'une automatisation dans le tableau de bord.
 */

export interface AutomationDef {
  id:            string;
  nom:           string;
  description:   string;
  icon:          string;
  categorie:     "documents" | "stocks" | "commandes" | "crm" | "notifications" | "archivage";
  status:        AutomationStatus;
  derniere_exec: string | null;
  prochaine_exec?: string | null;
  nb_executions: number;
  nb_erreurs:    number;
  requiert_validation: boolean;
  /** Dernière erreur si status === "error" */
  derniere_erreur?: string | null;
}

interface Props {
  automation:   AutomationDef;
  onRun?:       (id: string) => void;
  onToggle?:    (id: string, active: boolean) => void;
  running?:     boolean;
}

const CATEGORIE_CONFIG = {
  documents:     { color: "#C9A84C", label: "Documents"     },
  stocks:        { color: "#FF9800", label: "Stocks"        },
  commandes:     { color: "#D4A0B5", label: "Commandes"     },
  crm:           { color: "#7EB8C4", label: "CRM"           },
  notifications: { color: "#9B6B9E", label: "Notifications" },
  archivage:     { color: "#888888", label: "Archivage"     },
} as const;

function formatDate(iso: string | null | undefined) {
  if (!iso) return "Jamais";
  const d = new Date(iso);
  const now = new Date();
  const diff = now.getTime() - d.getTime();
  if (diff < 60000)   return "À l'instant";
  if (diff < 3600000) return `Il y a ${Math.round(diff / 60000)} min`;
  if (diff < 86400000) return `Il y a ${Math.round(diff / 3600000)} h`;
  return d.toLocaleDateString("fr-FR", { day: "numeric", month: "short" });
}

export function AutomationCard({ automation: a, onRun, onToggle, running = false }: Props) {
  const catCfg = CATEGORIE_CONFIG[a.categorie];
  const isActive = a.status === "active" || a.status === "running";

  return (
    <div
      style={{
        background:   "#120A10",
        border:       `1px solid ${a.status === "error" ? "rgba(244,67,54,0.28)" : a.status === "running" ? "rgba(201,168,76,0.28)" : "rgba(201,168,76,0.14)"}`,
        borderRadius: "12px",
        padding:      "16px",
        display:      "flex",
        flexDirection: "column",
        gap:          "12px",
        transition:   "border-color 0.2s",
      }}
    >
      {/* Header */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: "10px" }}>
        <div style={{ display: "flex", gap: "10px", alignItems: "flex-start", flex: 1, minWidth: 0 }}>
          <span style={{ fontSize: "20px", flexShrink: 0 }}>{a.icon}</span>
          <div style={{ minWidth: 0 }}>
            <p style={{ fontSize: "13px", fontWeight: "600", color: "#F0E8D8", fontFamily: "Georgia, serif", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
              {a.nom}
            </p>
            <p style={{ fontSize: "10px", color: "rgba(240,232,216,0.45)", marginTop: "2px", fontFamily: "Arial, sans-serif", lineHeight: "1.4" }}>
              {a.description}
            </p>
          </div>
        </div>
        <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", gap: "4px", flexShrink: 0 }}>
          <AutomationStatusBadge status={a.status} size="xs" pulse={a.status === "running"} />
          <span
            style={{
              fontSize:   "9px",
              padding:    "1px 7px",
              borderRadius: "10px",
              background: `${catCfg.color}12`,
              color:      catCfg.color,
              fontFamily: "Arial, sans-serif",
              border:     `1px solid ${catCfg.color}30`,
            }}
          >
            {catCfg.label}
          </span>
        </div>
      </div>

      {/* Erreur */}
      {a.status === "error" && a.derniere_erreur && (
        <div style={{ padding: "7px 10px", background: "rgba(244,67,54,0.09)", border: "1px solid rgba(244,67,54,0.20)", borderRadius: "7px" }}>
          <p style={{ fontSize: "10px", color: "#F44336", fontFamily: "Arial, sans-serif" }}>
            ⚠ {a.derniere_erreur}
          </p>
        </div>
      )}

      {/* Stats */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: "6px" }}>
        {[
          { label: "Exécutions",  value: a.nb_executions.toString(), color: "#C9A84C" },
          { label: "Erreurs",     value: a.nb_erreurs.toString(),    color: a.nb_erreurs > 0 ? "#F44336" : "rgba(240,232,216,0.35)" },
          { label: "Dernière",    value: formatDate(a.derniere_exec), color: "rgba(240,232,216,0.50)", small: true },
        ].map((s) => (
          <div key={s.label} style={{ padding: "6px 8px", background: "rgba(255,255,255,0.03)", borderRadius: "7px" }}>
            <p style={{ fontSize: "7px", color: "rgba(240,232,216,0.32)", letterSpacing: "0.10em", textTransform: "uppercase", marginBottom: "2px", fontFamily: "Arial, sans-serif" }}>{s.label}</p>
            <p style={{ fontSize: s.small ? "10px" : "14px", fontWeight: "700", color: s.color, fontFamily: "Arial, sans-serif" }}>{s.value}</p>
          </div>
        ))}
      </div>

      {/* Validation requise */}
      {a.requiert_validation && (
        <div style={{ padding: "6px 10px", background: "rgba(160,32,16,0.07)", border: "1px solid rgba(160,32,16,0.18)", borderRadius: "6px" }}>
          <p style={{ fontSize: "9px", color: "rgba(220,100,80,0.75)", fontStyle: "italic", fontFamily: "Arial, sans-serif" }}>
            🔒 Cette automatisation prépare et propose — validation fondatrice avant action
          </p>
        </div>
      )}

      {/* Boutons */}
      <div style={{ display: "flex", gap: "8px" }}>
        {onToggle && (
          <button
            type="button"
            onClick={() => onToggle(a.id, !isActive)}
            style={{
              flex: 1, padding: "7px 0", borderRadius: "8px", fontSize: "11px",
              cursor: "pointer", fontFamily: "Georgia, serif",
              background: isActive ? "rgba(244,67,54,0.09)" : "rgba(76,175,80,0.09)",
              border: `1px solid ${isActive ? "rgba(244,67,54,0.25)" : "rgba(76,175,80,0.25)"}`,
              color: isActive ? "#F44336" : "#4CAF50",
            }}
          >
            {isActive ? "Désactiver" : "Activer"}
          </button>
        )}
        {onRun && (
          <button
            type="button"
            onClick={() => onRun(a.id)}
            disabled={running || a.status === "running"}
            style={{
              flex: 2, padding: "7px 0", borderRadius: "8px", fontSize: "11px",
              fontWeight: "700", cursor: running ? "not-allowed" : "pointer",
              fontFamily: "Georgia, serif",
              background: running ? "rgba(201,168,76,0.08)" : "rgba(201,168,76,0.12)",
              border: "1px solid rgba(201,168,76,0.28)",
              color: running ? "rgba(201,168,76,0.30)" : "#C9A84C",
            }}
          >
            {running ? "⟳ En cours…" : "▶ Exécuter maintenant"}
          </button>
        )}
      </div>
    </div>
  );
}
