/**
 * components/automations/AutomationStatusBadge.tsx
 * Badge visuel pour le statut d'une automatisation.
 */

export type AutomationStatus =
  | "active"
  | "inactive"
  | "running"
  | "error"
  | "completed"
  | "pending_validation";

const STATUS_CONFIG: Record<AutomationStatus, { label: string; color: string; dot?: boolean }> = {
  active:               { label: "Active",                color: "#4CAF50", dot: true  },
  inactive:             { label: "Inactive",              color: "#888888", dot: false },
  running:              { label: "En cours",              color: "#C9A84C", dot: true  },
  error:                { label: "Erreur",                color: "#F44336", dot: true  },
  completed:            { label: "Terminée",              color: "#7EB8C4", dot: false },
  pending_validation:   { label: "Attend validation",     color: "#FF9800", dot: true  },
};

interface Props {
  status:   AutomationStatus | string;
  size?:    "xs" | "sm" | "md";
  pulse?:   boolean;
}

const SIZES = {
  xs: { fontSize: "9px",  padding: "1px 7px"  },
  sm: { fontSize: "10px", padding: "2px 9px"  },
  md: { fontSize: "12px", padding: "4px 13px" },
} as const;

export function AutomationStatusBadge({ status, size = "sm", pulse = false }: Props) {
  const cfg   = STATUS_CONFIG[status as AutomationStatus];
  const sz    = SIZES[size];
  const color = cfg?.color ?? "#888";
  const label = cfg?.label ?? status;

  return (
    <span
      style={{
        display:       "inline-flex",
        alignItems:    "center",
        gap:           "5px",
        padding:       sz.padding,
        borderRadius:  "20px",
        fontSize:      sz.fontSize,
        fontWeight:    "600",
        background:    `${color}18`,
        color,
        border:        `1px solid ${color}40`,
        whiteSpace:    "nowrap",
        fontFamily:    "Arial, sans-serif",
      }}
    >
      <span
        style={{
          width:        "5px",
          height:       "5px",
          borderRadius: "50%",
          background:   color,
          boxShadow:    cfg?.dot ? `0 0 5px ${color}AA` : "none",
          flexShrink:   0,
          display:      "inline-block",
          animation:    (pulse && cfg?.dot) ? "bellaia-pulse 1.2s ease-in-out infinite" : "none",
        }}
      />
      {label}
    </span>
  );
}
