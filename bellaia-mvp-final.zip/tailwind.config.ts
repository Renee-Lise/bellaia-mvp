import type { Config } from "tailwindcss";

const config: Config = {
  // Seuls les fichiers listés ici seront scannés pour les classes Tailwind
  content: [
    "./app/**/*.{ts,tsx}",
    "./components/**/*.{ts,tsx}",
    "./lib/**/*.{ts,tsx}",
    "./hooks/**/*.{ts,tsx}",
  ],

  theme: {
    extend: {
      // ── Palette Bella'Studio ──────────────────────────────────────────
      colors: {
        // Base
        background: "#0C0810",
        surface:    "#120A10",
        border:     "rgba(201,168,76,0.18)",

        // Or — couleur principale
        or: {
          DEFAULT: "#C9A84C",
          light:   "#D4B86A",
          dark:    "#A88830",
          muted:   "rgba(201,168,76,0.15)",
        },

        // Prune — Bella'Studio maison mère
        prune: {
          DEFAULT: "#5C2D5C",
          light:   "#7A3F7A",
          dark:    "#3E1E3E",
          muted:   "rgba(92,45,92,0.15)",
        },

        // Par branche
        odyssee:   { DEFAULT: "#6B3FA0", muted: "rgba(107,63,160,0.15)" },
        secret:    { DEFAULT: "#D4A0B5", muted: "rgba(212,160,181,0.12)" },
        food:      { DEFAULT: "#1E5C3A", muted: "rgba(30,92,58,0.15)"   },
        events:    { DEFAULT: "#1E5C3A", muted: "rgba(30,92,58,0.12)"   },
        invest:    { DEFAULT: "#0A1628", muted: "rgba(10,22,40,0.30)"   },
        vilo:      { DEFAULT: "#0A1628", muted: "rgba(10,22,40,0.25)"   },
        academy:   { DEFAULT: "#7A3050", muted: "rgba(122,48,80,0.12)"  },
        structure: { DEFAULT: "#7A3050", muted: "rgba(122,48,80,0.10)"  },

        // Sémantiques
        success:  "#4CAF50",
        warning:  "#FF9800",
        danger:   "#F44336",
        info:     "#2196F3",

        // Texte
        "text-primary":   "#F0E8D8",
        "text-secondary": "rgba(240,232,216,0.55)",
        "text-muted":     "rgba(240,232,216,0.30)",
      },

      // ── Typographie ───────────────────────────────────────────────────
      fontFamily: {
        serif: ["Cormorant Garamond", "Georgia", "Times New Roman", "serif"],
        sans:  ["Inter", "Arial", "Helvetica", "sans-serif"],
        mono:  ["Courier New", "Courier", "monospace"],
      },

      fontSize: {
        "2xs": ["0.625rem", { lineHeight: "1rem" }],
      },

      // ── Espacements ───────────────────────────────────────────────────
      borderRadius: {
        "4xl": "2rem",
      },

      // ── Animations ────────────────────────────────────────────────────
      keyframes: {
        pulse: {
          "0%, 100%": { opacity: "0.3", transform: "scale(0.8)" },
          "50%":       { opacity: "1",   transform: "scale(1.1)" },
        },
        "fade-in": {
          from: { opacity: "0", transform: "translateY(4px)" },
          to:   { opacity: "1", transform: "translateY(0)"   },
        },
        "slide-in": {
          from: { transform: "translateX(-100%)" },
          to:   { transform: "translateX(0)"     },
        },
      },
      animation: {
        pulse:    "pulse 1.2s ease-in-out infinite",
        "fade-in": "fade-in 0.2s ease-out",
        "slide-in": "slide-in 0.3s ease-out",
      },

      // ── Box shadows ───────────────────────────────────────────────────
      boxShadow: {
        or:    "0 0 12px rgba(201,168,76,0.3)",
        prune: "0 0 12px rgba(92,45,92,0.4)",
        glow:  "0 4px 24px rgba(201,168,76,0.15)",
      },

      // ── Scrollbar ─────────────────────────────────────────────────────
      // Utilisé avec le plugin scrollbar (optionnel)
    },
  },

  plugins: [],
};

export default config;
