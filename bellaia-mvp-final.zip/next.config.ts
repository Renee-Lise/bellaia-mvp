import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Active le strict mode React (détecte les effets de bord)
  reactStrictMode: true,

  images: {
    // Domaines autorisés pour next/image
    remotePatterns: [
      {
        protocol: "https",
        hostname: "*.supabase.co",
        pathname: "/storage/v1/object/public/**",
      },
    ],
  },

  // Headers de sécurité pour toutes les routes
  async headers() {
    return [
      {
        source: "/(.*)",
        headers: [
          { key: "X-Frame-Options",        value: "DENY" },
          { key: "X-Content-Type-Options",  value: "nosniff" },
          { key: "Referrer-Policy",         value: "strict-origin-when-cross-origin" },
          {
            key: "Permissions-Policy",
            value: "camera=(), microphone=(), geolocation=()",
          },
        ],
      },
    ];
  },

  // Variables d'environnement accessibles côté serveur uniquement
  // (les NEXT_PUBLIC_ sont déjà exposées automatiquement)
  serverRuntimeConfig: {
    supabaseServiceRoleKey: process.env.SUPABASE_SERVICE_ROLE_KEY,
    anthropicApiKey:        process.env.ANTHROPIC_API_KEY,
  },
};

export default nextConfig;
