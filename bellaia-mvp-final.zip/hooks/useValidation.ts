"use client";

import { useState, useCallback } from "react";
import type { AuditAction } from "@/lib/audit/logger";

/**
 * hooks/useValidation.ts
 *
 * Gère le workflow de validation fondatrice.
 * Toute action sensible (paiement, statut financier, publication…)
 * doit passer par ce hook avant d'être exécutée.
 *
 * Usage :
 *   const { request, pending, confirm, cancel, isLoading } = useValidation();
 *
 *   // Déclencher une validation :
 *   request({
 *     action:     "commande_statut_change",
 *     entite:     "commandes",
 *     entite_id:  commandeId,
 *     titre:      "Marquer l'acompte comme reçu",
 *     resume:     "Commande CMD-001 — Sophie M. — 89 €",
 *     impact:     "Acompte de 44 € marqué reçu. Statut → acompte_recu.",
 *     onConfirm:  async () => { await changerStatut(...); },
 *   });
 */

// ── Types ─────────────────────────────────────────────────────────────────────

export interface ValidationRequest {
  /** Action auditée (correspond à AuditAction dans logger.ts) */
  action:     AuditAction;
  /** Table concernée */
  entite:     string;
  /** ID de l'entité concernée */
  entite_id?: string;
  /** Titre affiché dans la modal (court) */
  titre:      string;
  /** Résumé affiché dans la modal (détail de l'action) */
  resume:     string;
  /** Impact financier ou légal décrit en clair */
  impact:     string;
  /** Fonction exécutée après confirmation fondatrice */
  onConfirm:  () => Promise<void>;
  /** Fonction optionnelle exécutée après annulation */
  onCancel?:  () => void;
}

export interface ValidationState {
  /** Requête de validation en attente (null = modal fermée) */
  pending:   ValidationRequest | null;
  /** True pendant l'exécution de onConfirm */
  isLoading: boolean;
  /** True si la dernière action a réussi */
  isSuccess: boolean;
  /** Message d'erreur si l'action a échoué */
  error:     string | null;
  /** Motif saisi par la fondatrice dans la modal */
  motif:     string;
}

export interface ValidationControls {
  pending:    ValidationRequest | null;
  isLoading:  boolean;
  isSuccess:  boolean;
  error:      string | null;
  motif:      string;
  setMotif:   (motif: string) => void;
  request:    (req: ValidationRequest) => void;
  confirm:    () => Promise<void>;
  cancel:     () => void;
  resetState: () => void;
}

// ── Hook ──────────────────────────────────────────────────────────────────────

export function useValidation(): ValidationControls {
  const [pending,   setPending]   = useState<ValidationRequest | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [error,     setError]     = useState<string | null>(null);
  const [motif,     setMotif]     = useState("");

  // ── Ouvrir la modal de validation ──────────────────────────────────────────
  const request = useCallback((req: ValidationRequest) => {
    setError(null);
    setIsSuccess(false);
    setMotif("");
    setPending(req);
  }, []);

  // ── Confirmer l'action (fondatrice clique "Je valide") ─────────────────────
  const confirm = useCallback(async () => {
    if (!pending) return;

    setIsLoading(true);
    setError(null);

    try {
      // Enregistrer dans l'audit log via l'API
      await fetch("/api/audit", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action:      pending.action,
          entite:      pending.entite,
          entite_id:   pending.entite_id ?? null,
          valeur_apres: {
            phase:  "confirmed",
            resume: pending.resume,
            motif:  motif || null,
          },
        }),
      });

      // Exécuter l'action métier
      await pending.onConfirm();

      setIsSuccess(true);
      setPending(null);
      setMotif("");
    } catch (err) {
      const message =
        err instanceof Error ? err.message : "Une erreur est survenue.";
      setError(message);
    } finally {
      setIsLoading(false);
    }
  }, [pending, motif]);

  // ── Annuler la validation ──────────────────────────────────────────────────
  const cancel = useCallback(() => {
    if (!pending) return;

    // Log l'annulation si une entité est spécifiée
    if (pending.entite_id) {
      fetch("/api/audit", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action:      pending.action,
          entite:      pending.entite,
          entite_id:   pending.entite_id,
          valeur_apres: { phase: "cancelled", resume: pending.resume },
        }),
      }).catch(() => {
        // Silencieux — l'annulation ne doit pas bloquer l'UI
      });
    }

    pending.onCancel?.();
    setPending(null);
    setMotif("");
    setError(null);
  }, [pending]);

  // ── Réinitialiser l'état (après succès affiché) ────────────────────────────
  const resetState = useCallback(() => {
    setIsSuccess(false);
    setError(null);
    setMotif("");
  }, []);

  return {
    pending,
    isLoading,
    isSuccess,
    error,
    motif,
    setMotif,
    request,
    confirm,
    cancel,
    resetState,
  };
}
