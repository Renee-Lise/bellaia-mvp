"use client";

import { useState, useCallback, useRef } from "react";
import type Anthropic from "@anthropic-ai/sdk";

/**
 * hooks/useBellaia.ts
 *
 * Hook pour interagir avec l'API Bellaïa depuis n'importe quel composant.
 * Maintient l'historique de conversation et gère le loading/error.
 */

export interface BellaiaMessage {
  role:    "user" | "assistant";
  content: string;
}

export interface UseBellaiaOptions {
  branch?: string;
  prenom?: string;
}

export function useBellaia(options: UseBellaiaOptions = {}) {
  const [messages,  setMessages]  = useState<BellaiaMessage[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error,     setError]     = useState<string | null>(null);

  // Historique format Anthropic (inclut les tool_result internes)
  const history = useRef<Anthropic.MessageParam[]>([]);

  const send = useCallback(async (userMessage: string): Promise<string | null> => {
    if (!userMessage.trim() || isLoading) return null;
    setError(null);
    setIsLoading(true);

    // Ajouter le message user à l'UI
    setMessages((prev) => [...prev, { role: "user", content: userMessage }]);

    const newHistory: Anthropic.MessageParam[] = [
      ...history.current,
      { role: "user", content: userMessage },
    ];

    try {
      const res = await fetch("/api/bellaia/chat", {
        method:  "POST",
        headers: { "Content-Type": "application/json" },
        body:    JSON.stringify({
          messages: newHistory,
          branch:   options.branch ?? "studio",
          prenom:   options.prenom,
        }),
      });

      if (!res.ok) {
        const j = await res.json().catch(() => ({}));
        throw new Error(j.error ?? `HTTP ${res.status}`);
      }

      const data = await res.json();
      const responseText: string = data.response;

      // Mettre à jour l'historique Anthropic
      if (data.updated_messages) {
        history.current = data.updated_messages;
      } else {
        history.current = [
          ...newHistory,
          { role: "assistant" as const, content: responseText },
        ];
      }

      // Ajouter la réponse à l'UI
      setMessages((prev) => [...prev, { role: "assistant", content: responseText }]);
      return responseText;

    } catch (err) {
      const message = err instanceof Error ? err.message : "Erreur de connexion.";
      setError(message);
      return null;
    } finally {
      setIsLoading(false);
    }
  }, [isLoading, options.branch, options.prenom]);

  const reset = useCallback(() => {
    history.current = [];
    setMessages([]);
    setError(null);
  }, []);

  return { messages, isLoading, error, send, reset };
}
