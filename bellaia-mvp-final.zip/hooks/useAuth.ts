"use client";

import { useEffect, useState, useCallback } from "react";
import { createClient } from "@/lib/supabase/client";
import type { User } from "@supabase/supabase-js";
import type { Profile } from "@/types/database";
import type { UserRole } from "@/constants/statuts";

/**
 * hooks/useAuth.ts
 *
 * Gère la session Supabase côté client.
 * À utiliser uniquement dans les composants 'use client'.
 *
 * Usage :
 *   const { user, profile, loading, isFondatrice } = useAuth();
 */

export interface AuthState {
  user:          User | null;
  profile:       Profile | null;
  loading:       boolean;
  role:          UserRole | null;
  isFondatrice:  boolean;
  isAuth:        boolean;
  refreshProfile: () => Promise<void>;
}

export function useAuth(): AuthState {
  const [user,    setUser]    = useState<User | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);

  const supabase = createClient();

  // ── Charger le profil depuis la DB ─────────────────────────────────────────
  const loadProfile = useCallback(
    async (userId: string) => {
      const { data, error } = await supabase
        .from("profiles")
        .select("*")
        .eq("id", userId)
        .single();

      if (error) {
        console.error("[useAuth] Erreur chargement profil:", error.message);
        setProfile(null);
      } else {
        setProfile(data);
      }
    },
    [supabase]
  );

  // ── Forcer un rechargement du profil (ex: après changement de rôle) ─────────
  const refreshProfile = useCallback(async () => {
    if (user) {
      await loadProfile(user.id);
    }
  }, [user, loadProfile]);

  // ── Initialisation + listener auth ─────────────────────────────────────────
  useEffect(() => {
    let mounted = true;

    const initialize = async () => {
      try {
        const {
          data: { session },
        } = await supabase.auth.getSession();

        if (!mounted) return;

        if (session?.user) {
          setUser(session.user);
          await loadProfile(session.user.id);
        } else {
          setUser(null);
          setProfile(null);
        }
      } catch (err) {
        console.error("[useAuth] Erreur initialisation:", err);
      } finally {
        if (mounted) setLoading(false);
      }
    };

    initialize();

    // ── Listener Supabase auth (SIGNED_IN, SIGNED_OUT, TOKEN_REFRESHED…) ─────
    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange(async (event, session) => {
      if (!mounted) return;

      if (session?.user) {
        setUser(session.user);
        await loadProfile(session.user.id);
      } else {
        setUser(null);
        setProfile(null);
      }

      // Arrêter le loading si ce n'est pas déjà fait
      if (mounted) setLoading(false);
    });

    return () => {
      mounted = false;
      subscription.unsubscribe();
    };
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  return {
    user,
    profile,
    loading,
    role:          (profile?.role as UserRole) ?? null,
    isFondatrice:  profile?.role === "fondatrice",
    isAuth:        !!user,
    refreshProfile,
  };
}
