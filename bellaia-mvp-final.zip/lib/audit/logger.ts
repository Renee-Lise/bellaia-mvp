import "server-only";

import type { SupabaseClient }  from "@supabase/supabase-js";
import type { Database, Json }  from "@/types/database";

/**
 * lib/audit/logger.ts
 *
 * Enregistre toutes les actions importantes dans audit_log.
 * La table est immuable (pas d'UPDATE ni de DELETE en base).
 *
 * Appeler UNE SEULE FOIS par mutation, après toutes les opérations DB.
 *
 * Usage :
 *   await auditLog({
 *     supabase,
 *     action:      "commande_statut_change",
 *     entite:      "commandes",
 *     entite_id:   commandeId,
 *     fait_par:    userId,
 *     valeur_avant: { statut: "demande_recue" },
 *     valeur_apres: { statut: "confirme" },
 *   });
 */

// ── Types ─────────────────────────────────────────────────────────────────────

export interface AuditEntry {
  supabase:     SupabaseClient<Database>;
  action:       AuditAction;
  entite:       string;
  entite_id?:   string;
  fait_par?:    string;
  valeur_avant?: Json;
  valeur_apres?: Json;
  ip_address?:   string;
}

// Actions traçables — étendre selon les besoins
export type AuditAction =
  // Commandes
  | "commande_created"
  | "commande_statut_change"
  | "commande_notes_updated"
  | "commande_revolut_link_set"
  // Paiements
  | "paiement_created"
  | "paiement_marked_received"
  | "paiement_cancelled"
  // Validation fondatrice
  | "validation_requested"
  | "validation_confirmed"
  | "validation_cancelled"
  // Factures
  | "facture_created"
  | "facture_emise"
  | "facture_annulee"
  // Clients
  | "cliente_created"
  | "cliente_updated"
  | "document_created"
  | "document_statut_change"
  | "document_sent"
  // Stocks
  | "stock_updated"
  | "stock_alerte_triggered"
  // Produits
  | "produit_created"
  | "produit_updated"
  // Accès coffre-fort
  | "coffre_accessed"
  | "coffre_document_added"
  // Mémoire métier
  | "memoire_added"
  | "memoire_archived"
  // Bellaïa IA
  | "bellaia_tool_called"
  | "bellaia_rapport_generated"
  // Auth
  | "user_role_changed"
  | "user_access_modified";

// ── Fonction principale ───────────────────────────────────────────────────────

/**
 * Enregistre une entrée dans audit_log.
 * Ne lève jamais d'exception — les erreurs d'audit sont logguées en console
 * mais ne bloquent pas l'action métier.
 */
export async function auditLog(entry: AuditEntry): Promise<void> {
  const {
    supabase,
    action,
    entite,
    entite_id,
    fait_par,
    valeur_avant,
    valeur_apres,
    ip_address,
  } = entry;

  try {
    const { error } = await supabase.from("audit_log").insert({
      action,
      entite,
      entite_id:    entite_id    ?? null,
      fait_par:     fait_par     ?? null,
      valeur_avant: valeur_avant ?? null,
      valeur_apres: valeur_apres ?? null,
      ip_address:   ip_address   ?? null,
    });

    if (error) {
      // Ne pas bloquer l'action métier, mais alerter en console
      console.error("[Audit] Erreur enregistrement audit_log:", error.message, {
        action,
        entite,
        entite_id,
      });
    }
  } catch (err) {
    console.error("[Audit] Exception inattendue:", err);
  }
}

// ── Helper raccourci pour validation fondatrice ───────────────────────────────

/**
 * Log spécifique pour les validations fondatrice.
 * Appelé automatiquement par ValidationModal via l'API.
 */
export async function auditValidation(
  supabase: SupabaseClient<Database>,
  options: {
    phase:     "requested" | "confirmed" | "cancelled";
    userId:    string;
    entite:    string;
    entite_id: string;
    resume:    string;
  }
): Promise<void> {
  const actionMap = {
    requested:  "validation_requested",
    confirmed:  "validation_confirmed",
    cancelled:  "validation_cancelled",
  } as const;

  await auditLog({
    supabase,
    action:      actionMap[options.phase],
    entite:      options.entite,
    entite_id:   options.entite_id,
    fait_par:    options.userId,
    valeur_apres: { resume: options.resume, phase: options.phase },
  });
}
