import "server-only";

import { createClient } from "@/lib/supabase/server";
import type { SupabaseClient } from "@supabase/supabase-js";
import type { Database, UserRole } from "@/types/database";

/**
 * lib/auth/guards.ts
 *
 * Guards à appeler en tête de chaque Route Handler protégé.
 * Retourne soit une réponse d'erreur (ok: false),
 * soit le userId et le client Supabase (ok: true).
 *
 * Usage dans une route fondatrice :
 *
 *   export async function GET(req: Request) {
 *     const guard = await withFondatrice();
 *     if (!guard.ok) return guard.error;
 *     const { userId, supabase } = guard;
 *     // ... logique métier
 *   }
 *
 * Règle absolue :
 * Bellaïa prépare. Renée-Lise décide.
 * Toute action financière, juridique ou stratégique
 * nécessite une validation fondatrice explicite.
 */

// ── Types ─────────────────────────────────────────────────────────────────────

type GuardSuccess = {
  ok:       true;
  userId:   string;
  supabase: SupabaseClient<Database>;
};

type GuardFailure = {
  ok:    false;
  error: Response;
};

type GuardResult = GuardSuccess | GuardFailure;

// ── withFondatrice ────────────────────────────────────────────────────────────

/**
 * Vérifie que l'utilisateur est authentifié ET a le rôle "fondatrice".
 * Renvoie 401 si non authentifié, 403 si rôle insuffisant.
 */
export async function withFondatrice(): Promise<GuardResult> {
  const supabase = createClient();

  const { data: { user }, error: authError } = await supabase.auth.getUser();

  if (authError || !user) {
    return {
      ok: false,
      error: Response.json(
        { error: "Non authentifié" },
        { status: 401 }
      ),
    };
  }

  const { data: profile, error: profileError } = await supabase
    .from("profiles")
    .select("role")
    .eq("id", user.id)
    .single();

  if (profileError || !profile) {
    return {
      ok: false,
      error: Response.json(
        { error: "Profil introuvable" },
        { status: 401 }
      ),
    };
  }

  if (profile.role !== "fondatrice") {
    return {
      ok: false,
      error: Response.json(
        {
          error:   "Validation fondatrice obligatoire avant exécution.",
          message: "Cette action nécessite le rôle fondatrice.",
        },
        { status: 403 }
      ),
    };
  }

  return {
    ok:       true,
    userId:   user.id,
    supabase, // client avec session utilisateur + RLS
  };
}

// ── withRole ──────────────────────────────────────────────────────────────────

/**
 * Vérifie que l'utilisateur a l'un des rôles autorisés.
 * Plus flexible que withFondatrice pour les collaborateurs.
 */
export async function withRole(
  allowedRoles: UserRole[]
): Promise<GuardResult> {
  const supabase = createClient();

  const { data: { user }, error: authError } = await supabase.auth.getUser();

  if (authError || !user) {
    return {
      ok: false,
      error: Response.json({ error: "Non authentifié" }, { status: 401 }),
    };
  }

  const { data: profile } = await supabase
    .from("profiles")
    .select("role")
    .eq("id", user.id)
    .single();

  if (!profile || !allowedRoles.includes(profile.role as UserRole)) {
    return {
      ok: false,
      error: Response.json(
        { error: "Accès refusé pour ce rôle" },
        { status: 403 }
      ),
    };
  }

  return { ok: true, userId: user.id, supabase };
}

// ── withAuth ──────────────────────────────────────────────────────────────────

/**
 * Vérifie uniquement que l'utilisateur est authentifié (sans vérification de rôle).
 * Pour les routes accessibles à toutes les clientes.
 */
export async function withAuth(): Promise<GuardResult> {
  const supabase = createClient();

  const { data: { user }, error } = await supabase.auth.getUser();

  if (error || !user) {
    return {
      ok: false,
      error: Response.json({ error: "Non authentifié" }, { status: 401 }),
    };
  }

  return { ok: true, userId: user.id, supabase };
}
