import type Anthropic from "@anthropic-ai/sdk";

/**
 * lib/bellaia/tools.ts
 *
 * Définitions des outils disponibles pour Bellaïa via function calling.
 * Ces définitions sont passées à l'API Anthropic dans le paramètre "tools".
 *
 * Chaque outil est en lecture ou préparation uniquement.
 * Aucun outil ne valide un paiement, ne publie un document,
 * ni n'exécute une décision financière ou stratégique.
 */

export const BELLAIA_TOOLS: Anthropic.Tool[] = [

  // ── 1. Rapport quotidien ───────────────────────────────────────────────────
  {
    name: "get_daily_report",
    description:
      "Génère le rapport quotidien de Bellaïa : urgences critiques, commandes en attente, " +
      "alertes stocks, paiements en attente, sessions boudoirs à venir. " +
      "Appeler quand l'utilisatrice demande un bilan, un résumé du jour, ou les priorités.",
    input_schema: {
      type: "object" as const,
      properties: {
        branches: {
          type: "array",
          items: { type: "string" },
          description: "Branches à inclure. Vide = toutes les branches.",
        },
      },
      required: [],
    },
  },

  // ── 2. Lire les commandes ──────────────────────────────────────────────────
  {
    name: "get_commandes",
    description:
      "Lit les commandes depuis Supabase. Peut filtrer par statut, branche ou recherche textuelle. " +
      "Appeler pour répondre à des questions sur les commandes, leur statut, ou les urgences.",
    input_schema: {
      type: "object" as const,
      properties: {
        statut: {
          type: "string",
          enum: [
            "demande_recue", "en_attente_validation", "lien_paiement_envoye",
            "acompte_recu", "paiement_complet", "solde_restant",
            "confirme", "en_preparation", "livre", "annule",
          ],
          description: "Filtrer par statut. Omis = toutes.",
        },
        branche: {
          type: "string",
          description: "Filtrer par branche (ex: secret_home).",
        },
        limit: {
          type: "number",
          description: "Nombre de commandes à retourner. Défaut : 10.",
        },
      },
      required: [],
    },
  },

  // ── 3. Lire les stocks ─────────────────────────────────────────────────────
  {
    name: "get_stocks",
    description:
      "Lit les niveaux de stock depuis Supabase. Peut filtrer par branche ou par statut d'alerte. " +
      "Appeler pour répondre aux questions sur les stocks, les ruptures, les alertes.",
    input_schema: {
      type: "object" as const,
      properties: {
        branche: {
          type: "string",
          description: "Filtrer par branche.",
        },
        alerte_seulement: {
          type: "boolean",
          description: "Si true, retourne uniquement les produits en faible ou rupture.",
        },
      },
      required: [],
    },
  },

  // ── 4. Lire le CRM ─────────────────────────────────────────────────────────
  {
    name: "get_clientes",
    description:
      "Lit les profils clientes du CRM. Peut filtrer par statut CRM ou recherche par nom. " +
      "Appeler pour répondre aux questions sur les clientes, leur fidélité, leur historique.",
    input_schema: {
      type: "object" as const,
      properties: {
        statut_crm: {
          type: "string",
          enum: ["prospect", "prospect_qualifie", "active", "vip", "inactive"],
          description: "Filtrer par statut CRM.",
        },
        search: {
          type: "string",
          description: "Recherche par nom ou email.",
        },
        limit: {
          type: "number",
          description: "Nombre de résultats. Défaut : 10.",
        },
      },
      required: [],
    },
  },

  // ── 5. Créer un devis brouillon ────────────────────────────────────────────
  {
    name: "create_devis",
    description:
      "Crée un devis en statut BROUILLON dans Supabase. " +
      "Ne jamais émettre ni envoyer — statut BROUILLON uniquement. " +
      "Validation fondatrice obligatoire avant toute émission officielle. " +
      "Appeler quand l'utilisatrice demande de préparer un devis.",
    input_schema: {
      type: "object" as const,
      properties: {
        client_nom: {
          type: "string",
          description: "Nom du client ou de la cliente.",
        },
        client_email: {
          type: "string",
          description: "Email (optionnel).",
        },
        branche: {
          type: "string",
          description: "Branche concernée (ex: events, odyssee).",
        },
        articles: {
          type: "array",
          items: {
            type: "object",
            properties: {
              description:   { type: "string" },
              quantite:      { type: "number" },
              prix_unitaire: { type: "number" },
            },
            required: ["description", "quantite", "prix_unitaire"],
          },
          description: "Liste des articles du devis.",
        },
        notes: {
          type: "string",
          description: "Notes ou conditions particulières.",
        },
        validite_jours: {
          type: "number",
          description: "Durée de validité en jours. Défaut : 30.",
        },
      },
      required: ["client_nom", "branche", "articles"],
    },
  },

  // ── 6. Sauvegarder mémoire métier ──────────────────────────────────────────
  {
    name: "save_memoire_metier",
    description:
      "Sauvegarde un élément dans la mémoire métier de Bellaïa. " +
      "À appeler UNIQUEMENT si l'utilisatrice a dit explicitement " +
      "'validé', 'approuvé', 'on garde', 'sauvegarde ça' ou équivalent. " +
      "Jamais automatiquement, toujours proposer d'abord.",
    input_schema: {
      type: "object" as const,
      properties: {
        label: {
          type: "string",
          description: "Libellé court de l'élément à mémoriser.",
        },
        univers: {
          type: "string",
          description: "Branche concernée (ex: Bella'Odyssée, Secret Home).",
        },
        type: {
          type: "string",
          enum: ["tarif", "procedure", "produit", "fournisseur", "document", "visuel", "general"],
          description: "Type d'élément.",
        },
        valeur: {
          type: "string",
          description: "Contenu ou valeur à mémoriser.",
        },
        version: {
          type: "string",
          description: "Version de l'élément (ex: v1.0). Défaut : v1.0.",
        },
      },
      required: ["label", "univers", "type", "valeur"],
    },
  },

  // ── 7. Lire la mémoire métier ──────────────────────────────────────────────
  {
    name: "get_memoire_metier",
    description:
      "Lit les éléments de la mémoire métier validés par Renée-Lise. " +
      "Appeler pour retrouver des tarifs, procédures, ou informations validées.",
    input_schema: {
      type: "object" as const,
      properties: {
        univers: {
          type: "string",
          description: "Filtrer par branche.",
        },
        type: {
          type: "string",
          enum: ["tarif", "procedure", "produit", "fournisseur", "document", "visuel", "general"],
          description: "Filtrer par type.",
        },
      },
      required: [],
    },
  },

  // ── 8. Préparer un récapitulatif commande ──────────────────────────────────
  {
    name: "get_commande_recap",
    description:
      "Génère un récapitulatif complet d'une commande spécifique : " +
      "articles, statut, historique, paiements, prochaine étape recommandée. " +
      "Appeler quand l'utilisatrice demande le détail ou un résumé d'une commande.",
    input_schema: {
      type: "object" as const,
      properties: {
        commande_id: {
          type: "string",
          description: "UUID de la commande.",
        },
      },
      required: ["commande_id"],
    },
  },
];

// ── Types des inputs outils ───────────────────────────────────────────────────

export interface ToolInput_GetDailyReport {
  branches?: string[];
}

export interface ToolInput_GetCommandes {
  statut?:  string;
  branche?: string;
  limit?:   number;
}

export interface ToolInput_GetStocks {
  branche?:          string;
  alerte_seulement?: boolean;
}

export interface ToolInput_GetClientes {
  statut_crm?: string;
  search?:     string;
  limit?:      number;
}

export interface ToolInput_CreateDevis {
  client_nom:     string;
  client_email?:  string;
  branche:        string;
  articles:       { description: string; quantite: number; prix_unitaire: number }[];
  notes?:         string;
  validite_jours?: number;
}

export interface ToolInput_SaveMemoireMetier {
  label:    string;
  univers:  string;
  type:     "tarif" | "procedure" | "produit" | "fournisseur" | "document" | "visuel" | "general";
  valeur:   string;
  version?: string;
}

export interface ToolInput_GetMemoireMetier {
  univers?: string;
  type?:    string;
}

export interface ToolInput_GetCommandeRecap {
  commande_id: string;
}
