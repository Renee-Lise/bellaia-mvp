import "server-only";

import { createAdminClient }  from "@/lib/supabase/server";
import { auditLog }           from "@/lib/audit/logger";
import type {
  ToolInput_GetDailyReport,
  ToolInput_GetCommandes,
  ToolInput_GetStocks,
  ToolInput_GetClientes,
  ToolInput_CreateDevis,
  ToolInput_SaveMemoireMetier,
  ToolInput_GetMemoireMetier,
  ToolInput_GetCommandeRecap,
} from "@/lib/bellaia/tools";

/**
 * lib/bellaia/executor.ts
 *
 * Exécute les outils IA après qu'Anthropic ait décidé de les appeler.
 * Toutes les opérations sont en lecture ou création de brouillons.
 * Aucune action financière ni stratégique n'est exécutée ici.
 *
 * Chaque outil retourne un objet sérialisable en JSON.
 * En cas d'erreur, retourne { error: string } sans lever d'exception
 * pour ne pas interrompre la conversation.
 */

// ── Types ─────────────────────────────────────────────────────────────────────

type ToolName =
  | "get_daily_report"
  | "get_commandes"
  | "get_stocks"
  | "get_clientes"
  | "create_devis"
  | "save_memoire_metier"
  | "get_memoire_metier"
  | "get_commande_recap";

interface ExecuteResult {
  success: boolean;
  data:    unknown;
}

// ── Dispatcher principal ──────────────────────────────────────────────────────

export async function executeTool(
  toolName: string,
  input:    Record<string, unknown>,
  userId:   string
): Promise<ExecuteResult> {
  const name = toolName as ToolName;

  try {
    switch (name) {
      case "get_daily_report":
        return await execGetDailyReport(input as ToolInput_GetDailyReport, userId);
      case "get_commandes":
        return await execGetCommandes(input as ToolInput_GetCommandes);
      case "get_stocks":
        return await execGetStocks(input as ToolInput_GetStocks);
      case "get_clientes":
        return await execGetClientes(input as ToolInput_GetClientes);
      case "create_devis":
        return await execCreateDevis(input as ToolInput_CreateDevis, userId);
      case "save_memoire_metier":
        return await execSaveMemoireMetier(input as ToolInput_SaveMemoireMetier, userId);
      case "get_memoire_metier":
        return await execGetMemoireMetier(input as ToolInput_GetMemoireMetier);
      case "get_commande_recap":
        return await execGetCommandeRecap(input as ToolInput_GetCommandeRecap);
      default:
        return { success: false, data: { error: `Outil inconnu : ${toolName}` } };
    }
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    console.error(`[executor] ${toolName}:`, message);
    return { success: false, data: { error: message } };
  }
}

// ── Outil 1 — Rapport quotidien ───────────────────────────────────────────────

async function execGetDailyReport(
  input: ToolInput_GetDailyReport,
  userId: string
): Promise<ExecuteResult> {
  const sb = createAdminClient();

  const branchFilter = input.branches?.length ? input.branches : undefined;

  const [commandesRes, stocksRes, paiementsRes, sessionsRes] = await Promise.all([
    // Commandes urgentes
    (() => {
      let q = sb.from("commandes")
        .select("id, cliente_nom, total, statut, branche, created_at")
        .not("statut", "in", "(livre,annule)")
        .order("created_at", { ascending: false })
        .limit(15);
      if (branchFilter) q = q.in("branche", branchFilter);
      return q;
    })(),
    // Stocks en alerte
    (() => {
      let q = sb.from("stocks_avec_statut")
        .select("produit_id, produit_nom, quantite, unite, statut_stock, branche")
        .in("statut_stock", ["faible", "rupture"]);
      if (branchFilter) q = q.in("branche", branchFilter);
      return q;
    })(),
    // Paiements en attente
    sb.from("paiements")
      .select("id, montant, type_paiement, created_at")
      .eq("statut", "en_attente")
      .limit(10),
    // Sessions boudoirs à venir
    sb.from("sessions_boudoir")
      .select("id, titre, date_session, places_restantes, places_total, statut")
      .gte("date_session", new Date().toISOString().split("T")[0])
      .in("statut", ["ouvert", "complet"])
      .order("date_session", { ascending: true })
      .limit(5),
  ]);

  const commandes    = commandesRes.data ?? [];
  const stocks       = stocksRes.data    ?? [];
  const paiements    = paiementsRes.data ?? [];
  const sessions     = sessionsRes.data  ?? [];

  const urgences_critiques = commandes.filter((c) => c.statut === "demande_recue").length;
  const ruptures           = stocks.filter((s) => s.statut_stock === "rupture").length;
  const total_en_attente   = paiements.reduce((s, p) => s + (p.montant ?? 0), 0);

  await auditLog({
    supabase:    sb,
    action:      "bellaia_rapport_generated",
    entite:      "bellaia",
    fait_par:    userId,
    valeur_apres: { type: "quotidien", urgences_critiques, ruptures },
  });

  return {
    success: true,
    data: {
      date:                new Date().toLocaleDateString("fr-FR", { weekday: "long", day: "numeric", month: "long" }),
      urgences_critiques,
      commandes_actives:   commandes.length,
      commandes_demande:   commandes.filter((c) => c.statut === "demande_recue"),
      ruptures_stock:      ruptures,
      stocks_faibles:      stocks.filter((s) => s.statut_stock === "faible").length,
      paiements_en_attente: paiements.length,
      montant_en_attente:  total_en_attente,
      sessions_a_venir:    sessions,
      note_gouvernance:    "Toute validation de paiement ou changement de statut financier nécessite votre confirmation.",
    },
  };
}

// ── Outil 2 — Commandes ───────────────────────────────────────────────────────

async function execGetCommandes(
  input: ToolInput_GetCommandes
): Promise<ExecuteResult> {
  const sb    = createAdminClient();
  const limit = Math.min(input.limit ?? 10, 50);

  let query = sb
    .from("commandes")
    .select("id, cliente_nom, branche, total, acompte_paye, statut, created_at, updated_at")
    .order("created_at", { ascending: false })
    .limit(limit);

  if (input.statut)  query = query.eq("statut",  input.statut);
  if (input.branche) query = query.eq("branche", input.branche);

  const { data, error, count } = await query;
  if (error) return { success: false, data: { error: error.message } };

  const commandes = data ?? [];

  return {
    success: true,
    data: {
      commandes,
      total:         count ?? commandes.length,
      filtres_appliques: {
        statut:  input.statut  ?? "tous",
        branche: input.branche ?? "toutes",
      },
      note_gouvernance: "Les changements de statut financiers nécessitent une validation fondatrice.",
    },
  };
}

// ── Outil 3 — Stocks ──────────────────────────────────────────────────────────

async function execGetStocks(
  input: ToolInput_GetStocks
): Promise<ExecuteResult> {
  const sb = createAdminClient();

  let query = sb
    .from("stocks_avec_statut")
    .select("produit_id, produit_nom, quantite, unite, seuil_alerte, statut_stock, branche, categorie")
    .order("statut_stock", { ascending: true });

  if (input.branche)          query = query.eq("branche", input.branche);
  if (input.alerte_seulement) query = query.in("statut_stock", ["faible", "rupture"]);

  const { data, error } = await query;
  if (error) return { success: false, data: { error: error.message } };

  const stocks = data ?? [];

  return {
    success: true,
    data: {
      stocks,
      resume: {
        total:    stocks.length,
        ok:       stocks.filter((s) => s.statut_stock === "ok").length,
        faibles:  stocks.filter((s) => s.statut_stock === "faible").length,
        ruptures: stocks.filter((s) => s.statut_stock === "rupture").length,
      },
      note_gouvernance: "Toute décision de réassort nécessite une validation fondatrice avant commande fournisseur.",
    },
  };
}

// ── Outil 4 — CRM Clientes ────────────────────────────────────────────────────

async function execGetClientes(
  input: ToolInput_GetClientes
): Promise<ExecuteResult> {
  const sb    = createAdminClient();
  const limit = Math.min(input.limit ?? 10, 30);

  let query = sb
    .from("clientes_crm")
    .select("id, nom, email, statut_crm, score_fidelite, univers, nb_achats, ca_total, updated_at")
    .order("updated_at", { ascending: false })
    .limit(limit);

  if (input.statut_crm) query = query.eq("statut_crm", input.statut_crm);
  if (input.search) {
    query = query.or(
      `nom.ilike.%${input.search}%,email.ilike.%${input.search}%`
    );
  }

  const { data, error } = await query;
  if (error) return { success: false, data: { error: error.message } };

  const clientes = data ?? [];

  return {
    success: true,
    data: {
      clientes,
      total: clientes.length,
      filtres: {
        statut_crm: input.statut_crm ?? "tous",
        search:     input.search     ?? null,
      },
    },
  };
}

// ── Outil 5 — Créer devis brouillon ──────────────────────────────────────────

async function execCreateDevis(
  input:  ToolInput_CreateDevis,
  userId: string
): Promise<ExecuteResult> {
  const sb = createAdminClient();

  // Calcul total côté serveur
  const totalTTC = input.articles.reduce(
    (sum, a) => sum + a.quantite * a.prix_unitaire,
    0
  );

  // Date de validité
  const validite = new Date();
  validite.setDate(validite.getDate() + (input.validite_jours ?? 30));

  const { data, error } = await sb
    .from("factures")
    .insert({
      type:          "devis",
      client_nom:    input.client_nom,
      client_email:  input.client_email ?? "",
      branche:       input.branche,
      articles:      input.articles,
      total_ttc:     totalTTC,
      statut:        "BROUILLON",
      validite_date: validite.toISOString().split("T")[0],
      notes:         input.notes ?? "",
      valide_par:    null,
    })
    .select()
    .single();

  if (error) return { success: false, data: { error: error.message } };

  await auditLog({
    supabase:    sb,
    action:      "facture_created",
    entite:      "factures",
    entite_id:   data.id,
    fait_par:    userId,
    valeur_apres: { type: "devis", client: input.client_nom, total: totalTTC, statut: "BROUILLON" },
  });

  return {
    success: true,
    data: {
      devis:            data,
      total_calcule:    totalTTC,
      statut:           "BROUILLON",
      validite:         validite.toLocaleDateString("fr-FR"),
      note_gouvernance: "Devis créé en BROUILLON. Validation fondatrice obligatoire avant toute émission ou envoi au client.",
    },
  };
}

// ── Outil 6 — Sauvegarder mémoire métier ─────────────────────────────────────

async function execSaveMemoireMetier(
  input:  ToolInput_SaveMemoireMetier,
  userId: string
): Promise<ExecuteResult> {
  const sb = createAdminClient();

  const { data, error } = await sb
    .from("memoire_metier")
    .insert({
      label:      input.label,
      univers:    input.univers,
      type:       input.type,
      valeur:     input.valeur,
      version:    input.version ?? "v1.0",
      statut:     "VALIDE",
      valide_par: userId,
    })
    .select()
    .single();

  if (error) return { success: false, data: { error: error.message } };

  await auditLog({
    supabase:    sb,
    action:      "memoire_added",
    entite:      "memoire_metier",
    entite_id:   data.id,
    fait_par:    userId,
    valeur_apres: { label: input.label, univers: input.univers, type: input.type },
  });

  return {
    success: true,
    data: {
      element:  data,
      message:  `Élément "${input.label}" ajouté à la mémoire métier Bellaïa (${input.univers}).`,
    },
  };
}

// ── Outil 7 — Lire mémoire métier ─────────────────────────────────────────────

async function execGetMemoireMetier(
  input: ToolInput_GetMemoireMetier
): Promise<ExecuteResult> {
  const sb = createAdminClient();

  let query = sb
    .from("memoire_metier")
    .select("id, label, univers, type, valeur, version, created_at")
    .eq("statut", "VALIDE")
    .order("created_at", { ascending: false });

  if (input.univers) query = query.eq("univers", input.univers);
  if (input.type)    query = query.eq("type",    input.type);

  const { data, error } = await query;
  if (error) return { success: false, data: { error: error.message } };

  return {
    success: true,
    data: {
      elements: data ?? [],
      total:    (data ?? []).length,
    },
  };
}

// ── Outil 8 — Récapitulatif commande ─────────────────────────────────────────

async function execGetCommandeRecap(
  input: ToolInput_GetCommandeRecap
): Promise<ExecuteResult> {
  const sb = createAdminClient();

  const [commandeRes, historiqueRes, paiementsRes] = await Promise.all([
    sb.from("commandes")
      .select("id, cliente_nom, branche, articles, total, acompte_attendu, acompte_paye, statut, lien_revolut, discretion_colis, notes_cliente, notes_admin, created_at, updated_at")
      .eq("id", input.commande_id)
      .single(),
    sb.from("commandes_historique")
      .select("ancien_statut, nouveau_statut, commentaire, created_at")
      .eq("commande_id", input.commande_id)
      .order("created_at", { ascending: true }),
    sb.from("paiements")
      .select("montant, type_paiement, mode, statut, date_reception, created_at")
      .eq("commande_id", input.commande_id)
      .order("created_at", { ascending: false }),
  ]);

  if (commandeRes.error || !commandeRes.data) {
    return { success: false, data: { error: "Commande introuvable." } };
  }

  const commande   = commandeRes.data;
  const historique = historiqueRes.data ?? [];
  const paiements  = paiementsRes.data  ?? [];
  const solde      = commande.total - (commande.acompte_paye ?? 0);

  // Prochaine étape recommandée (lecture seule)
  const prochaine_etape = (() => {
    switch (commande.statut) {
      case "demande_recue":
        return "Examiner la commande et valider ou refuser. 🔒 Validation fondatrice requise.";
      case "en_attente_validation":
        return "Envoyer le lien de paiement Revolut à la cliente.";
      case "lien_paiement_envoye":
        return "Attendre réception du paiement. Relancer si > 3 jours.";
      case "acompte_recu":
        return `Solde restant : ${solde.toFixed(2)} €. Confirmer la commande et préparer.`;
      case "paiement_complet":
        return "Paiement complet reçu. Confirmer et démarrer la préparation.";
      case "confirme":
        return "Préparer la commande. Prévoir l'envoi.";
      case "en_preparation":
        return "Finaliser la préparation et expédier.";
      case "livre":
        return "Commande livrée. Clôturée.";
      case "annule":
        return "Commande annulée. Aucune action requise.";
      default:
        return "Vérifier le statut et agir en conséquence.";
    }
  })();

  return {
    success: true,
    data: {
      commande,
      historique,
      paiements,
      resume: {
        solde_restant:    solde,
        nb_articles:      Array.isArray(commande.articles) ? commande.articles.length : 0,
        nb_changements:   historique.length,
        paiements_recus:  paiements.filter((p) => p.statut === "recu").length,
      },
      prochaine_etape,
    },
  };
}
