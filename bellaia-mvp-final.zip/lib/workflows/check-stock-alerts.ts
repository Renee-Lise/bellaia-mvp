import "server-only";
import { createAdminClient } from "@/lib/supabase/server";
import { auditLog }          from "@/lib/audit/logger";

/**
 * lib/workflows/check-stock-alerts.ts
 *
 * Workflow : Surveiller les niveaux de stock et créer des alertes.
 *
 * Ce que fait ce workflow (Bellaïa prépare) :
 * - Scan tous les stocks via la vue stocks_avec_statut
 * - Détecte les ruptures et stocks faibles
 * - Prépare des recommandations de réassort par fournisseur
 * - Logue les alertes dans audit_log
 * - NE commande JAMAIS (validation fondatrice requise)
 */

export interface StockAlert {
  produit_id:    string;
  produit_nom:   string;
  branche:       string;
  quantite:      number;
  unite:         string;
  seuil_alerte:  number;
  statut_stock:  "faible" | "rupture";
  urgence:       "haute" | "critique";
}

export interface ReassortRecommandation {
  produit_nom:    string;
  branche:        string;
  quantite_actuelle: number;
  quantite_suggeree: number;
  unite:          string;
  action_suggeree: string;
}

export interface CheckStockResult {
  alertes:          StockAlert[];
  recommandations:  ReassortRecommandation[];
  ruptures:         number;
  faibles:          number;
  message:          string;
  note_gouvernance: string;
}

export async function workflowCheckStockAlerts(
  declencheParUserId: string,
  options: { branche?: string } = {}
): Promise<CheckStockResult> {
  const sb = createAdminClient();

  // Récupérer les stocks en alerte
  let query = sb
    .from("stocks_avec_statut")
    .select("produit_id, produit_nom, branche, categorie, quantite, unite, seuil_alerte, statut_stock")
    .in("statut_stock", ["faible", "rupture"])
    .order("statut_stock", { ascending: true }); // rupture en premier

  if (options.branche) {
    query = query.eq("branche", options.branche);
  }

  const { data: stocksAlerte, error } = await query;
  if (error) throw new Error(`stocks_avec_statut: ${error.message}`);

  const stocks   = stocksAlerte ?? [];
  const ruptures = stocks.filter((s) => s.statut_stock === "rupture");
  const faibles  = stocks.filter((s) => s.statut_stock === "faible");

  // Construire les alertes structurées
  const alertes: StockAlert[] = stocks.map((s) => ({
    produit_id:   s.produit_id,
    produit_nom:  s.produit_nom,
    branche:      s.branche,
    quantite:     s.quantite,
    unite:        s.unite,
    seuil_alerte: s.seuil_alerte,
    statut_stock: s.statut_stock as "faible" | "rupture",
    urgence:      s.statut_stock === "rupture" ? "critique" : "haute",
  }));

  // Construire les recommandations de réassort
  const recommandations: ReassortRecommandation[] = stocks.map((s) => {
    const qteSuggeree = s.statut_stock === "rupture"
      ? Math.max(s.seuil_alerte * 5, 10)
      : s.seuil_alerte * 3;

    return {
      produit_nom:       s.produit_nom,
      branche:           s.branche,
      quantite_actuelle: s.quantite,
      quantite_suggeree: qteSuggeree,
      unite:             s.unite,
      action_suggeree:   s.statut_stock === "rupture"
        ? `Commander en urgence — rupture totale`
        : `Commander avant épuisement — stock faible`,
    };
  });

  // Log dans audit_log si alertes détectées
  if (alertes.length > 0) {
    await auditLog({
      supabase:    sb,
      action:      "stock_alerte_triggered",
      entite:      "stocks",
      fait_par:    declencheParUserId,
      valeur_apres: {
        workflow:          "check_stock_alerts",
        nb_ruptures:       ruptures.length,
        nb_faibles:        faibles.length,
        produits_rupture:  ruptures.map((s) => s.produit_nom),
        produits_faibles:  faibles.map((s) => s.produit_nom),
        recommandations:   recommandations.length,
      },
    });
  }

  const message = alertes.length === 0
    ? "Tous les stocks sont à niveau normal."
    : `${ruptures.length} rupture(s) critique(s), ${faibles.length} stock(s) faible(s) détecté(s).`;

  return {
    alertes,
    recommandations,
    ruptures:         ruptures.length,
    faibles:          faibles.length,
    message,
    note_gouvernance: "Toute décision de réassort ou commande fournisseur nécessite une validation fondatrice.",
  };
}
