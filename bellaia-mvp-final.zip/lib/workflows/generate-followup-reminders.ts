import "server-only";
import { createAdminClient } from "@/lib/supabase/server";
import { auditLog }          from "@/lib/audit/logger";

/**
 * lib/workflows/generate-followup-reminders.ts
 *
 * Workflow : Générer des rappels de suivi client.
 *
 * Ce que fait ce workflow (Bellaïa prépare) :
 * - Clientes inactives depuis N jours → prépare message de relance
 * - Paiements en attente depuis N jours → prépare relance paiement
 * - Sessions boudoirs J-3 → prépare rappel de confirmation
 * - Anniversaires dans 7 jours → prépare message personnalisé
 *
 * Ce que ne fait PAS ce workflow :
 * - Envoyer des messages (V2)
 * - Modifier des statuts
 * - Valider automatiquement quoi que ce soit
 */

export interface Rappel {
  type:         "relance_cliente" | "relance_paiement" | "rappel_session" | "anniversaire";
  destinataire: string;
  email?:       string;
  telephone?:   string;
  objet:        string;
  message_prepare: string;
  entite_id:    string;
  entite_type:  string;
  urgence:      "haute" | "normale";
}

export interface FollowupResult {
  rappels:            Rappel[];
  clientes_relancer:  number;
  paiements_relancer: number;
  sessions_j3:        number;
  anniversaires:      number;
  message:            string;
}

const JOURS_INACTIVITE  = 90;
const JOURS_PAIEMENT    = 7;
const JOURS_ANNIVERSAIRE = 7;

export async function workflowGenerateFollowupReminders(
  declencheParUserId: string
): Promise<FollowupResult> {
  const sb   = createAdminClient();
  const now  = new Date();
  const rappels: Rappel[] = [];

  // ── 1. Clientes inactives ─────────────────────────────────────────────────
  const limitInactivite = new Date(now);
  limitInactivite.setDate(limitInactivite.getDate() - JOURS_INACTIVITE);

  const { data: clientesInactives } = await sb
    .from("clientes_crm")
    .select("id, nom, email, telephone, statut_crm, updated_at")
    .lt("updated_at", limitInactivite.toISOString())
    .in("statut_crm", ["active", "vip"])
    .limit(20);

  for (const c of clientesInactives ?? []) {
    const joursDepuis = Math.floor(
      (now.getTime() - new Date(c.updated_at).getTime()) / 86400000
    );
    rappels.push({
      type:             "relance_cliente",
      destinataire:     c.nom,
      email:            c.email || undefined,
      telephone:        c.telephone || undefined,
      objet:            `Relance cliente — ${c.nom}`,
      message_prepare:  `Bonjour ${c.nom.split(" ")[0]},\n\nNous n'avons pas eu de nouvelles depuis ${joursDepuis} jours. Nous serions ravies de vous retrouver chez Bella'Studio.\n\nN'hésitez pas à nous contacter pour prendre rendez-vous ou découvrir nos nouveautés.\n\nBelle journée,\nRenée-Lise`,
      entite_id:        c.id,
      entite_type:      "clientes_crm",
      urgence:          "normale",
    });
  }

  // ── 2. Paiements en attente depuis trop longtemps ─────────────────────────
  const limitPaiement = new Date(now);
  limitPaiement.setDate(limitPaiement.getDate() - JOURS_PAIEMENT);

  const { data: paiementsEnAttente } = await sb
    .from("paiements")
    .select("id, montant, type_paiement, created_at, commande_id")
    .eq("statut", "en_attente")
    .lt("created_at", limitPaiement.toISOString())
    .limit(10);

  for (const p of paiementsEnAttente ?? []) {
    const joursDepuis = Math.floor(
      (now.getTime() - new Date(p.created_at).getTime()) / 86400000
    );

    // Récupérer le nom de la cliente via la commande
    let clienteNom = "Cliente";
    if (p.commande_id) {
      const { data: cmd } = await sb
        .from("commandes")
        .select("cliente_nom")
        .eq("id", p.commande_id)
        .single();
      if (cmd) clienteNom = cmd.cliente_nom;
    }

    rappels.push({
      type:             "relance_paiement",
      destinataire:     clienteNom,
      objet:            `Relance paiement — ${clienteNom} — ${p.montant.toFixed(2)} €`,
      message_prepare:  `Bonjour ${clienteNom.split(" ")[0]},\n\nNous vous rappelons qu'un paiement de ${p.montant.toFixed(2)} € est attendu depuis ${joursDepuis} jours.\n\nMerci de procéder au règlement dès que possible.\n\nCordialement,\nRenée-Lise`,
      entite_id:        p.id,
      entite_type:      "paiements",
      urgence:          joursDepuis > 14 ? "haute" : "normale",
    });
  }

  // ── 3. Sessions boudoirs J-3 ──────────────────────────────────────────────
  const j3 = new Date(now);
  j3.setDate(j3.getDate() + 3);
  const j3str = j3.toISOString().split("T")[0];

  const { data: sessionsJ3 } = await sb
    .from("sessions_boudoir")
    .select("id, titre, date_session, places_total, places_restantes")
    .eq("date_session", j3str)
    .in("statut", ["ouvert", "complet"]);

  for (const s of sessionsJ3 ?? []) {
    rappels.push({
      type:             "rappel_session",
      destinataire:     "Fondatrice",
      objet:            `Rappel session — ${s.titre} — dans 3 jours`,
      message_prepare:  `La session "${s.titre}" a lieu dans 3 jours.\nPlaces : ${s.places_total - s.places_restantes}/${s.places_total} confirmées.\n\nPenser à :\n- Confirmer les réservations\n- Envoyer les confirmations aux participantes\n- Préparer le matériel nécessaire`,
      entite_id:        s.id,
      entite_type:      "sessions_boudoir",
      urgence:          "haute",
    });
  }

  // ── 4. Anniversaires dans 7 jours ─────────────────────────────────────────
  const mois  = String(now.getMonth() + 1).padStart(2, "0");
  const jours = Array.from({ length: JOURS_ANNIVERSAIRE }, (_, i) => {
    const d = new Date(now);
    d.setDate(d.getDate() + i);
    return `${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
  });

  const { data: clientesAnniv } = await sb
    .from("clientes_crm")
    .select("id, nom, email, anniversaire")
    .not("anniversaire", "is", null);

  for (const c of clientesAnniveraires(clientesAnniv ?? [], jours)) {
    rappels.push({
      type:             "anniversaire",
      destinataire:     c.nom,
      email:            c.email || undefined,
      objet:            `Joyeux anniversaire — ${c.nom}`,
      message_prepare:  `Chère ${c.nom.split(" ")[0]},\n\nToute l'équipe Bella'Studio vous souhaite un très joyeux anniversaire !\n\nPour célébrer ce jour spécial, nous vous offrons une surprise. Contactez-nous pour en savoir plus.\n\nAvec toute notre affection,\nRenée-Lise`,
      entite_id:        c.id,
      entite_type:      "clientes_crm",
      urgence:          "normale",
    });
  }

  // ── Log ───────────────────────────────────────────────────────────────────
  if (rappels.length > 0) {
    await auditLog({
      supabase:    sb,
      action:      "bellaia_rapport_generated",
      entite:      "bellaia",
      fait_par:    declencheParUserId,
      valeur_apres: {
        workflow:     "generate_followup_reminders",
        total_rappels: rappels.length,
        relances_clientes: (clientesInactives ?? []).length,
        relances_paiements: (paiementsEnAttente ?? []).length,
        sessions_j3:  (sessionsJ3 ?? []).length,
      },
    });
  }

  return {
    rappels,
    clientes_relancer:  (clientesInactives ?? []).length,
    paiements_relancer: (paiementsEnAttente ?? []).length,
    sessions_j3:        (sessionsJ3 ?? []).length,
    anniversaires:      rappels.filter((r) => r.type === "anniversaire").length,
    message:            rappels.length > 0
      ? `${rappels.length} rappel(s) préparé(s). Validation fondatrice requise avant envoi.`
      : "Aucun rappel à générer actuellement.",
  };
}

// ── Helper filtrage anniversaires ─────────────────────────────────────────────

interface ClienteAnniv {
  id: string; nom: string; email: string; anniversaire: string | null;
}

function clientesAnniveraires(clientes: ClienteAnniv[], joursMMJJ: string[]): ClienteAnniv[] {
  return clientes.filter((c) => {
    if (!c.anniversaire) return false;
    // anniversaire format YYYY-MM-DD → extraire MM-DD
    const mmjj = c.anniversaire.slice(5); // "MM-DD"
    return joursMMJJ.includes(mmjj);
  });
}
