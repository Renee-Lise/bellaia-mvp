import "server-only";
import { createAdminClient } from "@/lib/supabase/server";
import { auditLog }          from "@/lib/audit/logger";

/**
 * lib/workflows/auto-archive-documents.ts
 *
 * Workflow : Archiver automatiquement les documents expirés ou obsolètes.
 *
 * Ce que fait ce workflow (action non critique — pas de validation requise) :
 * - Identifie les devis expirés (validite_date dépassée, statut VALIDE)
 * - Archive les anciens brouillons (> 30 jours sans modification)
 * - Détecte les doublons (même type + même cliente + versions multiples)
 * - Logue chaque archivage dans audit_log
 *
 * L'archivage est NON critique (lecture + statut ARCHIVE uniquement).
 * Aucune suppression de données.
 */

export interface DocumentArchive {
  id:          string;
  type:        string;
  univers:     string;
  raison:      "devis_expire" | "brouillon_ancien" | "doublon_remplace";
  cliente_id:  string | null;
  version:     string;
}

export interface ArchiveResult {
  archives:        DocumentArchive[];
  devis_expires:   number;
  brouillons_vieux: number;
  doublons:        number;
  message:         string;
}

const JOURS_BROUILLON_EXPIRATION = 30;

export async function workflowAutoArchiveDocuments(
  declencheParUserId: string
): Promise<ArchiveResult> {
  const sb  = createAdminClient();
  const now = new Date();
  const archives: DocumentArchive[] = [];

  // ── 1. Devis expirés (validite_date < aujourd'hui, statut = VALIDE dans factures) ──
  // Note : pour les documents_clients, on cherche les consentements/CGV expirés
  const limitBrouillon = new Date(now);
  limitBrouillon.setDate(limitBrouillon.getDate() - JOURS_BROUILLON_EXPIRATION);

  const { data: vieuxBrouillons, error: bErr } = await sb
    .from("documents_clients")
    .select("id, type, univers, version, cliente_id, created_at")
    .eq("statut", "BROUILLON")
    .lt("created_at", limitBrouillon.toISOString())
    .limit(50);

  if (bErr) throw new Error(`documents_clients brouillons: ${bErr.message}`);

  const docsAAchiver: string[] = [];

  for (const doc of vieuxBrouillons ?? []) {
    archives.push({
      id:         doc.id,
      type:       doc.type,
      univers:    doc.univers,
      raison:     "brouillon_ancien",
      cliente_id: doc.cliente_id,
      version:    doc.version,
    });
    docsAAchiver.push(doc.id);
  }

  // ── 2. Doublons : même cliente + même type, garder la version la plus récente ──
  const { data: tousLesDocs } = await sb
    .from("documents_clients")
    .select("id, type, univers, version, cliente_id, created_at, statut")
    .in("statut", ["VALIDE", "EN_REVISION"])
    .order("created_at", { ascending: false });

  const vu = new Set<string>();
  const doublonIds: string[] = [];

  for (const doc of tousLesDocs ?? []) {
    if (!doc.cliente_id) continue;
    const cle = `${doc.cliente_id}|${doc.type}`;
    if (vu.has(cle)) {
      // C'est un doublon (version plus ancienne)
      doublonIds.push(doc.id);
      archives.push({
        id:         doc.id,
        type:       doc.type,
        univers:    doc.univers,
        raison:     "doublon_remplace",
        cliente_id: doc.cliente_id,
        version:    doc.version,
      });
    } else {
      vu.add(cle);
    }
  }

  // ── 3. Archiver tous les documents identifiés ─────────────────────────────
  const tousIds = [...docsAAchiver, ...doublonIds];

  if (tousIds.length > 0) {
    const { error: updateErr } = await sb
      .from("documents_clients")
      .update({ statut: "ARCHIVE" })
      .in("id", tousIds);

    if (updateErr) throw new Error(`archivage: ${updateErr.message}`);

    // Log chaque archivage
    await auditLog({
      supabase:    sb,
      action:      "document_statut_change",
      entite:      "documents_clients",
      fait_par:    declencheParUserId,
      valeur_avant:  { statut: "BROUILLON ou VALIDE" },
      valeur_apres: {
        statut:            "ARCHIVE",
        workflow:          "auto_archive_documents",
        nb_archives:       tousIds.length,
        brouillons_vieux:  docsAAchiver.length,
        doublons:          doublonIds.length,
        ids:               tousIds.slice(0, 20), // Limiter pour la lisibilité
      },
    });
  }

  const brouillonsVieux = docsAAchiver.length;
  const doublonsCount   = doublonIds.length;

  return {
    archives,
    devis_expires:    0, // Géré dans module factures
    brouillons_vieux: brouillonsVieux,
    doublons:         doublonsCount,
    message: tousIds.length === 0
      ? "Aucun document à archiver."
      : `${tousIds.length} document(s) archivé(s) : ${brouillonsVieux} brouillon(s) ancien(s), ${doublonsCount} doublon(s).`,
  };
}
