import "server-only";
import { createAdminClient } from "@/lib/supabase/server";
import { auditLog }          from "@/lib/audit/logger";

/**
 * lib/workflows/process-order-status.ts
 *
 * Workflow : Analyser l'état des commandes et préparer les actions.
 *
 * Ce que fait ce workflow (Bellaïa prépare) :
 * - Détecte les commandes bloquées (sans mouvement depuis N jours)
 * - Identifie les commandes urgentes
 * - Prépare les récapitulatifs d'action pour la fondatrice
 * - Génère les priorités de traitement
 * - NE change JAMAIS de statut automatiquement
 */

export interface CommandeBloquee {
  id:              string;
  cliente_nom:     string;
  total:           number;
  statut:          string;
  branche:         string;
  jours_sans_action: number;
  action_recommandee: string;
  urgence:         "critique" | "haute" | "normale";
}

export interface OrderStatusResult {
  commandes_urgentes:   CommandeBloquee[];
  commandes_bloquees:   CommandeBloquee[];
  commandes_a_relancer: CommandeBloquee[];
  nb_demandes_recues:   number;
  total_en_attente_eur: number;
  priorites:            string[];
  message:              string;
  note_gouvernance:     string;
}

const JOURS_BLOQUEE_URGENT = 3;
const JOURS_BLOQUEE_NORMAL = 7;

function getActionRecommandee(statut: string, jours: number): string {
  switch (statut) {
    case "demande_recue":
      return jours >= JOURS_BLOQUEE_URGENT
        ? "URGENT : Examiner et valider ou refuser cette demande"
        : "Examiner et décider de la suite";
    case "en_attente_validation":
      return "Envoyer le lien Revolut et passer au statut suivant";
    case "lien_paiement_envoye":
      return jours >= JOURS_BLOQUEE_URGENT
        ? "Relancer la cliente — pas de paiement reçu depuis plusieurs jours"
        : "Attendre le paiement";
    case "acompte_recu":
      return "Confirmer la commande et démarrer la préparation";
    case "solde_restant":
      return "Relancer pour le solde restant";
    case "confirme":
      return "Démarrer la préparation du colis";
    case "en_preparation":
      return jours >= JOURS_BLOQUEE_NORMAL
        ? "La préparation semble longue — vérifier l'état"
        : "Expédier dès que prêt";
    default:
      return "Vérifier le statut et agir";
  }
}

export async function workflowProcessOrderStatus(
  declencheParUserId: string
): Promise<OrderStatusResult> {
  const sb  = createAdminClient();
  const now = new Date();

  // Récupérer toutes les commandes actives (non terminées)
  const { data: commandes, error } = await sb
    .from("commandes")
    .select("id, cliente_nom, total, statut, branche, updated_at, created_at")
    .not("statut", "in", "(livre,annule)")
    .order("created_at", { ascending: true });

  if (error) throw new Error(`commandes: ${error.message}`);

  const cmds = commandes ?? [];
  const urgentes:   CommandeBloquee[] = [];
  const bloquees:   CommandeBloquee[] = [];
  const aRelancer:  CommandeBloquee[] = [];
  let totalAttente  = 0;

  for (const cmd of cmds) {
    const referenceDate = cmd.updated_at ?? cmd.created_at;
    const joursInactif  = Math.floor(
      (now.getTime() - new Date(referenceDate).getTime()) / 86400000
    );

    // Calculer le montant restant à recevoir
    if (["lien_paiement_envoye", "demande_recue", "en_attente_validation"].includes(cmd.statut)) {
      totalAttente += cmd.total;
    }

    const action   = getActionRecommandee(cmd.statut, joursInactif);
    const urgence: CommandeBloquee["urgence"] =
      (cmd.statut === "demande_recue" && joursInactif >= JOURS_BLOQUEE_URGENT) ||
      (cmd.statut === "lien_paiement_envoye" && joursInactif >= JOURS_BLOQUEE_URGENT)
        ? "critique"
        : joursInactif >= JOURS_BLOQUEE_NORMAL
        ? "haute"
        : "normale";

    const bloquee: CommandeBloquee = {
      id:                 cmd.id,
      cliente_nom:        cmd.cliente_nom,
      total:              cmd.total,
      statut:             cmd.statut,
      branche:            cmd.branche,
      jours_sans_action:  joursInactif,
      action_recommandee: action,
      urgence,
    };

    if (urgence === "critique") {
      urgentes.push(bloquee);
    } else if (cmd.statut === "lien_paiement_envoye" && joursInactif >= JOURS_BLOQUEE_URGENT) {
      aRelancer.push(bloquee);
    } else if (joursInactif >= JOURS_BLOQUEE_NORMAL) {
      bloquees.push(bloquee);
    }
  }

  const demandesRecues = cmds.filter((c) => c.statut === "demande_recue").length;

  // Priorités ordonnées pour la fondatrice
  const priorites: string[] = [];
  if (urgentes.length > 0)
    priorites.push(`🔴 ${urgentes.length} commande(s) critique(s) nécessitent une action immédiate`);
  if (demandesRecues > 0)
    priorites.push(`📥 ${demandesRecues} nouvelle(s) demande(s) à examiner`);
  if (aRelancer.length > 0)
    priorites.push(`✉️ ${aRelancer.length} cliente(s) à relancer pour paiement en attente`);
  if (bloquees.length > 0)
    priorites.push(`⏳ ${bloquees.length} commande(s) sans mouvement depuis plus de ${JOURS_BLOQUEE_NORMAL} jours`);

  // Log
  if (urgentes.length > 0 || bloquees.length > 0) {
    await auditLog({
      supabase:    sb,
      action:      "bellaia_rapport_generated",
      entite:      "commandes",
      fait_par:    declencheParUserId,
      valeur_apres: {
        workflow:        "process_order_status",
        urgentes:        urgentes.length,
        bloquees:        bloquees.length,
        a_relancer:      aRelancer.length,
        demandes_recues: demandesRecues,
        total_attente:   totalAttente,
      },
    });
  }

  return {
    commandes_urgentes:   urgentes,
    commandes_bloquees:   bloquees,
    commandes_a_relancer: aRelancer,
    nb_demandes_recues:   demandesRecues,
    total_en_attente_eur: totalAttente,
    priorites,
    message: priorites.length > 0
      ? priorites[0]
      : "Toutes les commandes sont à jour.",
    note_gouvernance: "Aucun statut n'est modifié automatiquement. Validation fondatrice obligatoire.",
  };
}
