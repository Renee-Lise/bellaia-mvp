import "server-only";
import { createAdminClient } from "@/lib/supabase/server";
import { auditLog }          from "@/lib/audit/logger";

/**
 * lib/workflows/send-client-documents.ts
 *
 * Workflow : Vérifier et préparer l'envoi de documents clients.
 *
 * Ce que fait ce workflow (Bellaïa prépare) :
 * - Identifie les documents validés non encore envoyés
 * - Vérifie les doublons (ne pas envoyer 2x)
 * - Prépare la liste de documents à envoyer
 * - Crée des notifications pour la fondatrice
 * - N'envoie JAMAIS automatiquement (validation fondatrice requise)
 *
 * Ce que ne fait PAS ce workflow :
 * - Envoyer des emails (V2 avec Brevo)
 * - Générer des PDF (V2 avec react-pdf)
 * - Valider automatiquement
 */

export interface DocumentToSend {
  document_id:  string;
  cliente_nom:  string;
  cliente_email: string;
  type:         string;
  univers:      string;
  version:      string;
  valide_le:    string;
}

export interface SendDocumentsResult {
  documents_a_envoyer: DocumentToSend[];
  doublons_evites:     number;
  notification_creee:  boolean;
  message:             string;
}

export async function workflowSendClientDocuments(
  declencheParUserId: string
): Promise<SendDocumentsResult> {
  const sb = createAdminClient();

  // 1. Récupérer tous les documents validés
  const { data: docsValides, error: docsErr } = await sb
    .from("documents_clients")
    .select(`
      id,
      type,
      univers,
      version,
      statut,
      date_validation,
      cliente_id
    `)
    .eq("statut", "VALIDE")
    .not("date_validation", "is", null)
    .order("date_validation", { ascending: true });

  if (docsErr) throw new Error(`documents_clients: ${docsErr.message}`);

  const docs = docsValides ?? [];
  if (docs.length === 0) {
    return {
      documents_a_envoyer: [],
      doublons_evites:     0,
      notification_creee:  false,
      message:             "Aucun document validé en attente d'envoi.",
    };
  }

  // 2. Récupérer les clientes associées (groupées pour éviter N+1)
  const clienteIds = [...new Set(docs.map((d) => d.cliente_id).filter(Boolean))];
  const { data: clientes } = await sb
    .from("clientes_crm")
    .select("id, nom, email")
    .in("id", clienteIds as string[]);

  const clienteMap = new Map(
    (clientes ?? []).map((c) => [c.id, c])
  );

  // 3. Vérifier les doublons : même cliente + même type + même version déjà envoyé
  //    MVP : on détecte les doublons par statut ARCHIVE (déjà traité)
  const { data: docsArchives } = await sb
    .from("documents_clients")
    .select("cliente_id, type, version")
    .eq("statut", "ARCHIVE");

  const archivesSet = new Set(
    (docsArchives ?? []).map((d) => `${d.cliente_id}|${d.type}|${d.version}`)
  );

  // 4. Filtrer les vrais documents à envoyer (sans doublons)
  let doublonsEvites = 0;
  const aEnvoyer: DocumentToSend[] = [];

  for (const doc of docs) {
    const key = `${doc.cliente_id}|${doc.type}|${doc.version}`;
    if (archivesSet.has(key)) {
      doublonsEvites++;
      continue;
    }

    const cliente = doc.cliente_id ? clienteMap.get(doc.cliente_id) : null;
    if (!cliente?.email) continue; // Ignorer les clientes sans email

    aEnvoyer.push({
      document_id:   doc.id,
      cliente_nom:   cliente.nom,
      cliente_email: cliente.email,
      type:          doc.type,
      univers:       doc.univers,
      version:       doc.version,
      valide_le:     doc.date_validation!,
    });
  }

  // 5. Créer une notification dans audit_log si des documents sont prêts
  let notifCreee = false;
  if (aEnvoyer.length > 0) {
    await auditLog({
      supabase:    sb,
      action:      "bellaia_rapport_generated",
      entite:      "documents_clients",
      fait_par:    declencheParUserId,
      valeur_apres: {
        workflow:           "send_client_documents",
        documents_prets:    aEnvoyer.length,
        doublons_evites:    doublonsEvites,
        message_fondatrice: `${aEnvoyer.length} document(s) validé(s) prêt(s) à envoyer. Validation fondatrice requise avant envoi.`,
        documents:          aEnvoyer.map((d) => ({
          type:   d.type,
          client: d.cliente_nom,
          univers: d.univers,
        })),
      },
    });
    notifCreee = true;
  }

  return {
    documents_a_envoyer: aEnvoyer,
    doublons_evites:     doublonsEvites,
    notification_creee:  notifCreee,
    message:             aEnvoyer.length > 0
      ? `${aEnvoyer.length} document(s) prêt(s). Validation fondatrice obligatoire avant envoi.`
      : "Aucun nouveau document à envoyer.",
  };
}
