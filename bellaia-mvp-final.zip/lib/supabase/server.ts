import "server-only";

import { createServerClient }                    from "@supabase/ssr";
import { createClient as createSupabaseClient }  from "@supabase/supabase-js";
import { cookies }                               from "next/headers";
import type { Database }                         from "@/types/database";

/**
 * lib/supabase/server.ts
 *
 * Deux clients Supabase côté serveur :
 *
 * 1. createClient()      — respecte la session utilisateur + RLS.
 *    Usage : Server Components, Server Actions, Route Handlers publics.
 *
 * 2. createAdminClient() — bypasse RLS via service_role.
 *    Usage : uniquement dans les Route Handlers protégés par withFondatrice().
 *    ⚠️  NE JAMAIS importer dans du code client ('use client').
 *    ⚠️  NE JAMAIS exposer la clé service_role côté client.
 */

// ── Client standard (session utilisateur + RLS) ───────────────────────────────
export function createClient() {
  const jar = cookies();

  return createServerClient<Database>(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        getAll() {
          return jar.getAll();
        },
        setAll(cookiesToSet) {
          try {
            cookiesToSet.forEach(({ name, value, options }) =>
              jar.set(name, value, options)
            );
          } catch {
            // Dans un Server Component en lecture seule, set() lève une erreur.
            // C'est attendu et sans conséquence fonctionnelle.
          }
        },
      },
    }
  );
}

// ── Client admin (bypass RLS — SERVER ONLY) ───────────────────────────────────
export function createAdminClient() {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;

  if (!url || !key) {
    throw new Error(
      "[Bellaïa] NEXT_PUBLIC_SUPABASE_URL ou SUPABASE_SERVICE_ROLE_KEY manquant. " +
      "Vérifier le fichier .env.local."
    );
  }

  return createSupabaseClient<Database>(url, key, {
    auth: {
      autoRefreshToken: false,
      persistSession:   false,
    },
  });
}
