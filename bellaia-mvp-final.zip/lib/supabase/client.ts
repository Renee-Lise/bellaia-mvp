import { createBrowserClient } from "@supabase/ssr";
import type { Database } from "@/types/database";

/**
 * lib/supabase/client.ts
 *
 * Client Supabase pour le navigateur (composants 'use client').
 * Respecte la session utilisateur et les politiques RLS.
 *
 * Usage :
 *   import { createClient } from "@/lib/supabase/client";
 *   const supabase = createClient();
 */
export function createClient() {
  return createBrowserClient<Database>(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
  );
}
