# Bellaïa MVP — Déploiement Vercel

## Prérequis

- Projet Supabase de production créé (région Europe West)
- Repository GitHub **privé** créé
- Compte Vercel (gratuit)

---

## Étape 1 — Préparer Supabase production

1. **Supabase Dashboard** → Settings → API → copier :
   - Project URL
   - anon public key
   - service_role key (CONFIDENTIEL)

2. **Authentication** → URL Configuration :
   ```
   Site URL:       https://VOTRE_PROJET.vercel.app
   Redirect URLs:  https://VOTRE_PROJET.vercel.app/api/auth/callback
   ```

3. **SQL Editor** → Exécuter `docs/schema.sql`

---

## Étape 2 — Pousser sur GitHub

```bash
git init
git add .
git commit -m "Bellaïa MVP — Initial commit"
git remote add origin https://github.com/VOUS/bellaia-mvp
git push -u origin main
```

---

## Étape 3 — Connecter Vercel

1. [vercel.com](https://vercel.com) → **New Project**
2. Import depuis GitHub → sélectionner `bellaia-mvp`
3. Framework Preset : **Next.js** (auto-détecté)
4. Root Directory : `./`

---

## Étape 4 — Variables d'environnement Vercel

Settings → Environment Variables → Ajouter **chaque variable** avec la valeur **production** :

| Variable | Valeur |
|---|---|
| `NEXT_PUBLIC_SUPABASE_URL` | URL Supabase prod |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | Clé anon prod |
| `SUPABASE_SERVICE_ROLE_KEY` | Clé service_role prod |
| `ANTHROPIC_API_KEY` | Clé Anthropic |
| `NEXTAUTH_SECRET` | Secret aléatoire (`openssl rand -base64 32`) |
| `NEXT_PUBLIC_APP_URL` | `https://VOTRE_PROJET.vercel.app` |

---

## Étape 5 — Déployer

Cliquer **Deploy** dans Vercel.

Le premier déploiement prend ~2 minutes. Ensuite, chaque `git push main` redéploie automatiquement.

---

## Étape 6 — Créer le compte fondatrice en production

```sql
-- Dans Supabase production SQL Editor
-- Après inscription via l'interface
UPDATE public.profiles
SET role = 'fondatrice'
WHERE id = 'UUID_DU_COMPTE_RENEE_LISE';
```

---

## Domaine personnalisé (optionnel)

Vercel → Settings → Domains → Add → Configurer les DNS chez votre registrar.

---

## Monitoring

- **Logs** : Vercel Dashboard → Functions → Logs
- **Erreurs** : Ajouter Sentry (V2) — `npm install @sentry/nextjs`
- **Performance** : Vercel Analytics (activé par défaut)

---

## Mises à jour

```bash
# Tester en local
npm run build && npm run type-check

# Déployer
git add . && git commit -m "feat: description" && git push
# Vercel redéploie automatiquement
```
