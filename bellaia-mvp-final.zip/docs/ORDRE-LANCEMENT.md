# Bellaïa MVP — Ordre exact de lancement

## Phase 0 — Avant de toucher au code (30 min)

1. **Créer compte Supabase** → supabase.com → New Project → Europe West
2. **Copier les 3 clés** : Project URL, anon key, service_role key
3. **Créer compte Anthropic** → console.anthropic.com → API Key
4. **Créer repo GitHub privé** → github.com → New repository (PRIVÉ)

---

## Phase 1 — Setup projet (20 min)

```bash
# 1. Cloner et installer
git clone https://github.com/VOUS/bellaia-mvp.git
cd bellaia-mvp
npm install

# 2. Variables d'environnement
cp .env.example .env.local
# → Remplir TOUTES les variables dans .env.local

# 3. Vérifier TypeScript
npm run type-check
# Doit retourner 0 erreur
```

---

## Phase 2 — Base de données (15 min)

```bash
# Dans Supabase SQL Editor
# 1. New Query → Coller docs/schema.sql → Run
# 2. Vérifier : Table Editor → 14 tables + 1 vue

# 3. Créer compte fondatrice via l'interface app
npm run dev
# → http://localhost:3000/connexion → S'inscrire

# 4. Dans Supabase SQL Editor :
UPDATE public.profiles SET role = 'fondatrice'
WHERE id = 'UUID_DU_COMPTE';
```

---

## Phase 3 — Test local (15 min)

```bash
npm run dev

# Test 1 — Connexion fondatrice
# → /connexion → email + mot de passe → /dashboard

# Test 2 — Dashboard charge
# → KPIs s'affichent (0 si base vide)

# Test 3 — Chatbot Bellaïa
# → /bellaia → "Rapport du jour" → réponse IA

# Test 4 — Créer une commande test
# → /commandes → créer manuellement via SQL ou interface

# Test 5 — Changer statut commande
# → ValidationModal s'ouvre → Je valide → audit_log créé
```

---

## Phase 4 — Déploiement Vercel (20 min)

```bash
# 1. Pousser sur GitHub
git add .
git commit -m "Bellaïa MVP — Prêt production"
git push origin main

# 2. Vercel → New Project → Import GitHub → bellaia-mvp
# 3. Ajouter TOUTES les variables d'env (valeurs PRODUCTION)
# 4. Deploy
# 5. Tester la production : connexion + dashboard + chatbot
```

---

## Phase 5 — Mise en service (10 min)

```bash
# En production Supabase :
# Auth → URL Configuration → Ajouter domaine Vercel

# Créer le compte fondatrice production :
# → S'inscrire sur le domaine Vercel
# → SET role = 'fondatrice' dans SQL Editor production

# Vérifier en production :
# ✓ /dashboard charge
# ✓ /bellaia répond
# ✓ ValidationModal fonctionne
# ✓ audit_log enregistre
```

---

## Ordre de remplissage des données (recommandé)

1. **Fournisseurs** (admin SQL) — les produits en dépendent
2. **Produits + stocks** — via `/stocks` → mouvement réception
3. **Clientes CRM** — via `/crm` → nouvelle cliente
4. **Première commande** — via formulaire client ou SQL direct
5. **Premier devis** — via `/facturation` → Nouveau devis
6. **Configurer Bellaïa** — tester les quick actions par branche

---

## Checklist go-live finale

```
[ ] npm run build → 0 erreur
[ ] npm run type-check → 0 erreur  
[ ] Supabase production : 14 tables créées
[ ] Compte fondatrice avec role='fondatrice'
[ ] Auth URL configurée avec domaine Vercel
[ ] Toutes les env vars dans Vercel
[ ] Test connexion production
[ ] Test chatbot Bellaïa production
[ ] Test ValidationModal → audit_log créé
[ ] .env.local NON committé (vérifier .gitignore)
```
