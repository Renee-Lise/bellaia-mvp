# Bellaïa MVP — Checklist Sécurité

## ✅ Sécurité authentification

- [x] Supabase Auth — JWT vérifié côté serveur à chaque requête
- [x] Middleware Next.js protège toutes les routes fondatrice
- [x] Vérification rôle fondatrice dans chaque route API sensible (`withFondatrice()`)
- [x] `SUPABASE_SERVICE_ROLE_KEY` uniquement côté serveur (`server-only`)
- [x] Sessions expirées → redirection automatique vers /connexion
- [x] `age_verifie` pour Secret Home 18+

## ✅ Sécurité données

- [x] Row Level Security activé sur toutes les tables
- [x] `audit_log` immuable (no UPDATE, no DELETE via SQL rules)
- [x] Total commandes recalculé côté serveur (anti-tampering)
- [x] Aucune clé sensible dans le code client
- [x] `.env.local` dans `.gitignore`
- [x] `server-only` sur tous les helpers serveur Supabase

## ✅ Headers HTTP

- [x] `X-Frame-Options: DENY` (anti-clickjacking)
- [x] `X-Content-Type-Options: nosniff`
- [x] `Referrer-Policy: strict-origin-when-cross-origin`
- [x] `Permissions-Policy` restreint caméra/micro/géoloc

## ✅ Gouvernance métier

- [x] Aucun paiement automatique — Revolut 100% manuel
- [x] `ValidationModal` obligatoire sur statuts financiers
- [x] Tous les changements critiques loggués dans `audit_log`
- [x] Mémoire métier : ajout uniquement sur signal explicite fondatrice
- [x] Workflows IA : "Bellaïa prépare. Renée-Lise décide."

## ⚠️ À compléter avant production

- [ ] Activer 2FA sur le compte Supabase
- [ ] Configurer `Content-Security-Policy` (bloquer XSS)
- [ ] Ajouter rate limiting sur routes `/api/bellaia/chat` (coût Anthropic)
- [ ] Configurer alertes Sentry pour erreurs 500
- [ ] Audit annuel des rôles collaborateurs
- [ ] Rotation des clés API tous les 90 jours
- [ ] Vérifier conformité RGPD : mentions légales + politique vie privée

## 🔴 Jamais faire

- ❌ Committer `.env.local` dans Git
- ❌ Exposer `SUPABASE_SERVICE_ROLE_KEY` côté client
- ❌ Désactiver RLS sur une table
- ❌ Modifier ou supprimer des entrées `audit_log`
- ❌ Donner le rôle `fondatrice` à un collaborateur
- ❌ Partager le coffre-fort sans validation fondatrice

## RGPD — Points d'attention

- Les données clientes sont stockées dans Supabase (EU West) ✓
- Prévoir une procédure de suppression de compte cliente
- Prévoir export des données sur demande (droit à la portabilité)
- Les questionnaires santé (Odyssée) sont des données médicales sensibles
