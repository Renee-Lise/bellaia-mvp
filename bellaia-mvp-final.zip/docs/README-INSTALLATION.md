# Bellaïa MVP — Installation locale

## Prérequis

- Node.js 18.17+ (`node --version`)
- npm 9+ (`npm --version`)
- Compte Supabase (gratuit sur supabase.com)
- Clé API Anthropic (console.anthropic.com)

---

## Étape 1 — Cloner et installer

```bash
# Dans votre dossier de travail
git clone https://github.com/VOTRE_USERNAME/bellaia-mvp.git
cd bellaia-mvp

# Installer toutes les dépendances
npm install
```

---

## Étape 2 — Variables d'environnement

```bash
# Copier le template
cp .env.example .env.local

# Editer .env.local avec vos vraies valeurs :
# NEXT_PUBLIC_SUPABASE_URL=https://VOTRE_ID.supabase.co
# NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJ...
# SUPABASE_SERVICE_ROLE_KEY=eyJ...   ← CONFIDENTIEL
# ANTHROPIC_API_KEY=sk-ant-api03-...
# NEXTAUTH_SECRET=$(openssl rand -base64 32)
```

---

## Étape 3 — Base de données Supabase

1. Aller sur [supabase.com](https://supabase.com) → New Project (région Europe West)
2. SQL Editor → New Query → coller tout le contenu de `docs/schema.sql`
3. Cliquer **Run**
4. Vérifier : Table Editor → 14 tables créées

---

## Étape 4 — Créer le compte fondatrice

Après avoir lancé l'app et créé un compte :

```sql
-- Dans Supabase SQL Editor
UPDATE public.profiles
SET role = 'fondatrice'
WHERE id = 'UUID_DU_COMPTE';

-- Vérifier
SELECT id, prenom, role FROM public.profiles WHERE role = 'fondatrice';
```

---

## Étape 5 — Lancer en développement

```bash
npm run dev
# → http://localhost:3000
# → Dashboard : http://localhost:3000/dashboard
# → Bellaïa IA : http://localhost:3000/bellaia
```

---

## Commandes disponibles

| Commande | Description |
|---|---|
| `npm run dev` | Serveur développement avec hot reload |
| `npm run build` | Build de production |
| `npm run start` | Démarrer la build de production |
| `npm run lint` | Vérifier le code ESLint |
| `npm run type-check` | Vérifier TypeScript sans compiler |

---

## Structure du projet

```
bellaia-mvp/
├── app/               # Pages et routes API Next.js 14 App Router
├── components/        # Composants React réutilisables
├── constants/         # Statuts, branches — source unique
├── hooks/             # Hooks React personnalisés
├── lib/               # Utilitaires serveur (Supabase, auth, audit, IA)
├── types/             # Types TypeScript (database.ts)
├── docs/              # Documentation et SQL
└── middleware.ts      # Protection des routes
```
