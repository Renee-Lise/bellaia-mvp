-- ============================================================
-- BELLAIA MVP — Schema PostgreSQL complet
-- Exécuter dans Supabase SQL Editor dans l'ordre
-- ============================================================

-- Extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pg_trgm";
CREATE SEQUENCE IF NOT EXISTS devis_seq   START 1;
CREATE SEQUENCE IF NOT EXISTS facture_seq START 1;

-- ── Profiles ────────────────────────────────────────────────
CREATE TABLE public.profiles (
  id           UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  prenom       TEXT NOT NULL DEFAULT '',
  nom          TEXT DEFAULT '',
  telephone    TEXT DEFAULT '',
  role         TEXT NOT NULL DEFAULT 'cliente'
               CHECK (role IN ('fondatrice','hote_boudoir','estheticienne',
               'assistante_admin','community_manager','photographe','decoratrice','cliente')),
  statut       TEXT NOT NULL DEFAULT 'actif' CHECK (statut IN ('actif','inactif','veille')),
  age_verifie  BOOLEAN NOT NULL DEFAULT FALSE,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
CREATE POLICY p_self        ON public.profiles FOR ALL USING (auth.uid() = id);
CREATE POLICY p_fondatrice  ON public.profiles FOR ALL USING (
  EXISTS(SELECT 1 FROM public.profiles WHERE id=auth.uid() AND role='fondatrice'));

CREATE OR REPLACE FUNCTION public.handle_new_user() RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles(id,prenom,nom) VALUES(
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'prenom',''),
    COALESCE(NEW.raw_user_meta_data->>'nom',''));
  RETURN NEW;
END; $$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE OR REPLACE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users FOR EACH ROW
  EXECUTE FUNCTION public.handle_new_user();

-- ── Fournisseurs & Produits & Stocks ────────────────────────
CREATE TABLE public.fournisseurs (
  id         UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  nom        TEXT NOT NULL,
  pays       TEXT DEFAULT '', contact TEXT DEFAULT '',
  categorie  TEXT DEFAULT '', delai TEXT DEFAULT '',
  conformite TEXT DEFAULT '',
  statut     TEXT DEFAULT 'actif' CHECK(statut IN('actif','evaluation','inactif')),
  notes      TEXT DEFAULT '', created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE public.produits (
  id             UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  nom            TEXT NOT NULL, description TEXT DEFAULT '',
  categorie      TEXT NOT NULL, branche TEXT NOT NULL,
  prix_public    DECIMAL(10,2) NOT NULL DEFAULT 0,
  prix_cout      DECIMAL(10,2) DEFAULT 0,
  tailles        TEXT[] DEFAULT '{}', couleurs TEXT[] DEFAULT '{}',
  photos         TEXT[] DEFAULT '{}',
  fournisseur_id UUID REFERENCES public.fournisseurs(id),
  statut         TEXT DEFAULT 'actif' CHECK(statut IN('actif','inactif','archive')),
  version        TEXT DEFAULT 'v1.0',
  created_at     TIMESTAMPTZ DEFAULT NOW(), updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE public.stocks (
  id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  produit_id   UUID NOT NULL REFERENCES public.produits(id) ON DELETE CASCADE,
  quantite     DECIMAL(10,3) NOT NULL DEFAULT 0,
  unite        TEXT DEFAULT 'unites',
  seuil_alerte DECIMAL(10,3) DEFAULT 2,
  derniere_maj TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE public.mouvements_stock (
  id         UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  produit_id UUID NOT NULL REFERENCES public.produits(id),
  type       TEXT CHECK(type IN('vente','retour','ajustement','reception')),
  quantite   DECIMAL(10,3) NOT NULL,
  raison     TEXT,
  fait_par   UUID REFERENCES public.profiles(id),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE OR REPLACE VIEW public.stocks_avec_statut AS
SELECT s.*, p.nom AS produit_nom, p.branche, p.categorie,
  CASE WHEN s.quantite=0 THEN 'rupture'
       WHEN s.quantite<=s.seuil_alerte THEN 'faible'
       ELSE 'ok' END AS statut_stock
FROM public.stocks s JOIN public.produits p ON s.produit_id=p.id;

-- ── Commandes & Paiements ───────────────────────────────────
CREATE TABLE public.commandes (
  id               UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  cliente_id       UUID REFERENCES public.profiles(id),
  cliente_nom      TEXT NOT NULL DEFAULT '',
  branche          TEXT NOT NULL DEFAULT 'secret_home',
  articles         JSONB NOT NULL DEFAULT '[]',
  total            DECIMAL(10,2) NOT NULL DEFAULT 0,
  acompte_attendu  DECIMAL(10,2) DEFAULT 0,
  acompte_paye     DECIMAL(10,2) DEFAULT 0,
  statut           TEXT NOT NULL DEFAULT 'demande_recue' CHECK(statut IN(
    'demande_recue','en_attente_validation','lien_paiement_envoye',
    'acompte_recu','paiement_complet','solde_restant',
    'confirme','en_preparation','livre','annule')),
  lien_revolut     TEXT,
  discretion_colis BOOLEAN DEFAULT FALSE,
  adresse_livraison JSONB DEFAULT '{}',
  notes_cliente    TEXT DEFAULT '', notes_admin TEXT DEFAULT '',
  created_at       TIMESTAMPTZ DEFAULT NOW(), updated_at TIMESTAMPTZ DEFAULT NOW()
);
ALTER TABLE public.commandes ENABLE ROW LEVEL SECURITY;
CREATE POLICY cmd_fondatrice ON public.commandes FOR ALL USING(
  EXISTS(SELECT 1 FROM public.profiles WHERE id=auth.uid() AND role='fondatrice'));
CREATE POLICY cmd_own ON public.commandes FOR SELECT USING(auth.uid()=cliente_id);

CREATE TABLE public.commandes_historique (
  id             UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  commande_id    UUID NOT NULL REFERENCES public.commandes(id) ON DELETE CASCADE,
  ancien_statut  TEXT, nouveau_statut TEXT NOT NULL,
  commentaire    TEXT DEFAULT '',
  fait_par       UUID REFERENCES public.profiles(id),
  created_at     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_hist_cmd ON public.commandes_historique(commande_id);
ALTER TABLE public.commandes_historique ENABLE ROW LEVEL SECURITY;
CREATE POLICY hist_fondatrice ON public.commandes_historique FOR ALL USING(
  EXISTS(SELECT 1 FROM public.profiles WHERE id=auth.uid() AND role='fondatrice'));

CREATE TABLE public.paiements (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  commande_id     UUID REFERENCES public.commandes(id),
  montant         DECIMAL(10,2) NOT NULL,
  type_paiement   TEXT CHECK(type_paiement IN('acompte','solde','complet')),
  mode            TEXT DEFAULT 'revolut' CHECK(mode IN('revolut','especes','virement','autre')),
  statut          TEXT DEFAULT 'en_attente' CHECK(statut IN('en_attente','recu','annule')),
  lien_revolut    TEXT, date_envoi_lien TIMESTAMPTZ, date_reception TIMESTAMPTZ,
  valide_par      UUID REFERENCES public.profiles(id),
  notes           TEXT DEFAULT '', created_at TIMESTAMPTZ DEFAULT NOW()
);
ALTER TABLE public.paiements ENABLE ROW LEVEL SECURITY;
CREATE POLICY pay_fondatrice ON public.paiements FOR ALL USING(
  EXISTS(SELECT 1 FROM public.profiles WHERE id=auth.uid() AND role='fondatrice'));

-- ── CRM & Facturation & Documents ──────────────────────────
CREATE TABLE public.clientes_crm (
  id             UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  profile_id     UUID REFERENCES public.profiles(id),
  nom            TEXT NOT NULL, email TEXT DEFAULT '', telephone TEXT DEFAULT '',
  statut_crm     TEXT DEFAULT 'prospect' CHECK(statut_crm IN(
    'prospect','prospect_qualifie','active','vip','inactive')),
  univers        TEXT[] DEFAULT '{}',
  score_fidelite INTEGER DEFAULT 0 CHECK(score_fidelite BETWEEN 0 AND 100),
  anniversaire   DATE, preferences JSONB DEFAULT '{}',
  nb_achats      INTEGER DEFAULT 0, ca_total DECIMAL(10,2) DEFAULT 0,
  notes_admin    TEXT DEFAULT '',
  created_at     TIMESTAMPTZ DEFAULT NOW(), updated_at TIMESTAMPTZ DEFAULT NOW()
);
ALTER TABLE public.clientes_crm ENABLE ROW LEVEL SECURITY;
CREATE POLICY crm_fondatrice ON public.clientes_crm FOR ALL USING(
  EXISTS(SELECT 1 FROM public.profiles WHERE id=auth.uid() AND role='fondatrice'));

CREATE TABLE public.factures (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  numero        TEXT UNIQUE,
  type          TEXT NOT NULL CHECK(type IN('devis','facture','avoir','bon_commande','bon_livraison')),
  client_nom    TEXT NOT NULL, client_email TEXT DEFAULT '',
  cliente_id    UUID REFERENCES public.clientes_crm(id),
  branche       TEXT NOT NULL,
  articles      JSONB NOT NULL DEFAULT '[]',
  total_ttc     DECIMAL(10,2) NOT NULL DEFAULT 0,
  acompte_recu  DECIMAL(10,2) DEFAULT 0,
  statut        TEXT DEFAULT 'BROUILLON' CHECK(statut IN(
    'BROUILLON','EN_REVISION','VALIDE','a_payer','partiellement_paye','paye','annule')),
  validite_date DATE, notes TEXT DEFAULT '',
  valide_par    UUID REFERENCES public.profiles(id),
  emis_le       TIMESTAMPTZ, created_at TIMESTAMPTZ DEFAULT NOW()
);
ALTER TABLE public.factures ENABLE ROW LEVEL SECURITY;
CREATE POLICY fac_fondatrice ON public.factures FOR ALL USING(
  EXISTS(SELECT 1 FROM public.profiles WHERE id=auth.uid() AND role='fondatrice'));

CREATE TABLE public.documents_clients (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  cliente_id  UUID REFERENCES public.clientes_crm(id),
  type        TEXT NOT NULL CHECK(type IN(
    'questionnaire','consentement','cgv','autorisation',
    'contrat','fiche_conseils','questionnaire_sante')),
  univers     TEXT NOT NULL,
  contenu     JSONB DEFAULT '{}',
  statut      TEXT DEFAULT 'BROUILLON' CHECK(statut IN(
    'BROUILLON','EN_REVISION','VALIDE','ARCHIVE')),
  version     TEXT DEFAULT 'v1.0',
  valide_par  UUID REFERENCES public.profiles(id),
  date_validation TIMESTAMPTZ, created_at TIMESTAMPTZ DEFAULT NOW()
);
ALTER TABLE public.documents_clients ENABLE ROW LEVEL SECURITY;
CREATE POLICY docs_fondatrice ON public.documents_clients FOR ALL USING(
  EXISTS(SELECT 1 FROM public.profiles WHERE id=auth.uid() AND role='fondatrice'));

-- ── Sessions & Réservations ─────────────────────────────────
CREATE TABLE public.sessions_boudoir (
  id               UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  titre            TEXT NOT NULL, description TEXT DEFAULT '',
  date_session     DATE NOT NULL, heure TIME, duree_minutes INTEGER DEFAULT 120,
  places_total     INTEGER NOT NULL DEFAULT 4,
  places_restantes INTEGER NOT NULL DEFAULT 4,
  acompte_requis   DECIMAL(10,2) DEFAULT 0,
  prix_total       DECIMAL(10,2) NOT NULL DEFAULT 0,
  statut           TEXT DEFAULT 'ouvert' CHECK(statut IN('ouvert','complet','annule','realise')),
  notes_admin      TEXT DEFAULT '', created_at TIMESTAMPTZ DEFAULT NOW()
);
ALTER TABLE public.sessions_boudoir ENABLE ROW LEVEL SECURITY;
CREATE POLICY sb_fondatrice ON public.sessions_boudoir FOR ALL USING(
  EXISTS(SELECT 1 FROM public.profiles WHERE id=auth.uid() AND role='fondatrice'));
CREATE POLICY sb_read_auth ON public.sessions_boudoir FOR SELECT
  USING(auth.uid() IS NOT NULL AND statut='ouvert');

CREATE TABLE public.reservations (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  session_id    UUID NOT NULL REFERENCES public.sessions_boudoir(id),
  cliente_id    UUID REFERENCES public.profiles(id),
  cliente_nom   TEXT NOT NULL DEFAULT '',
  statut        TEXT DEFAULT 'demande_recue' CHECK(statut IN(
    'demande_recue','en_attente_validation','lien_paiement_envoye',
    'acompte_recu','confirme','realise','annule')),
  acompte_paye  DECIMAL(10,2) DEFAULT 0,
  solde_paye    DECIMAL(10,2) DEFAULT 0,
  notes_cliente TEXT DEFAULT '', notes_admin TEXT DEFAULT '',
  created_at    TIMESTAMPTZ DEFAULT NOW()
);
ALTER TABLE public.reservations ENABLE ROW LEVEL SECURITY;
CREATE POLICY res_fondatrice ON public.reservations FOR ALL USING(
  EXISTS(SELECT 1 FROM public.profiles WHERE id=auth.uid() AND role='fondatrice'));
CREATE POLICY res_own ON public.reservations FOR SELECT USING(auth.uid()=cliente_id);

CREATE OR REPLACE FUNCTION public.decrement_places() RETURNS TRIGGER AS $$
BEGIN
  IF NEW.statut='confirme' AND (OLD.statut IS DISTINCT FROM 'confirme') THEN
    UPDATE public.sessions_boudoir SET places_restantes=places_restantes-1
    WHERE id=NEW.session_id AND places_restantes>0;
  END IF; RETURN NEW;
END; $$ LANGUAGE plpgsql;
CREATE TRIGGER trg_places AFTER UPDATE ON public.reservations
  FOR EACH ROW EXECUTE FUNCTION public.decrement_places();

-- ── Mémoire métier ──────────────────────────────────────────
CREATE TABLE public.memoire_metier (
  id         UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  label      TEXT NOT NULL, univers TEXT NOT NULL,
  type       TEXT DEFAULT 'general' CHECK(type IN(
    'tarif','procedure','produit','fournisseur','document','visuel','general')),
  valeur     TEXT DEFAULT '',
  statut     TEXT DEFAULT 'VALIDE' CHECK(statut IN('VALIDE','ARCHIVE')),
  version    TEXT DEFAULT 'v1.0',
  valide_par UUID REFERENCES public.profiles(id),
  notes      TEXT DEFAULT '', created_at TIMESTAMPTZ DEFAULT NOW()
);
ALTER TABLE public.memoire_metier ENABLE ROW LEVEL SECURITY;
CREATE POLICY mm_fondatrice ON public.memoire_metier FOR ALL USING(
  EXISTS(SELECT 1 FROM public.profiles WHERE id=auth.uid() AND role='fondatrice'));

-- ── Audit log IMMUABLE ──────────────────────────────────────
CREATE TABLE public.audit_log (
  id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  action       TEXT NOT NULL, entite TEXT NOT NULL,
  entite_id    UUID, fait_par UUID REFERENCES public.profiles(id),
  valeur_avant JSONB, valeur_apres JSONB,
  ip_address   TEXT, created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
ALTER TABLE public.audit_log ENABLE ROW LEVEL SECURITY;
CREATE POLICY audit_read ON public.audit_log FOR SELECT USING(
  EXISTS(SELECT 1 FROM public.profiles WHERE id=auth.uid() AND role='fondatrice'));
CREATE POLICY audit_insert ON public.audit_log FOR INSERT WITH CHECK(true);
CREATE RULE audit_no_update AS ON UPDATE TO public.audit_log DO INSTEAD NOTHING;
CREATE RULE audit_no_delete AS ON DELETE TO public.audit_log DO INSTEAD NOTHING;

-- ── Numérotation documents ──────────────────────────────────
CREATE OR REPLACE FUNCTION public.gen_num(t TEXT) RETURNS TEXT AS $$
DECLARE v INT; px TEXT;
BEGIN
  px := CASE t WHEN 'devis' THEN 'DEV' WHEN 'facture' THEN 'FAC'
               WHEN 'avoir' THEN 'AV'  WHEN 'bon_commande' THEN 'BC'
               WHEN 'bon_livraison' THEN 'BL' ELSE 'DOC' END;
  v  := CASE WHEN t='devis' THEN nextval('devis_seq') ELSE nextval('facture_seq') END;
  RETURN px||'-'||to_char(NOW(),'YYYY')||'-'||LPAD(v::TEXT,4,'0');
END; $$ LANGUAGE plpgsql;
