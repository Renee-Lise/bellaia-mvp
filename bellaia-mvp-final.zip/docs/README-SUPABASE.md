# Bellaïa MVP — Guide Supabase

## Tables créées (14)

| Table | Description | RLS |
|---|---|---|
| `profiles` | Utilisateurs + rôles | ✓ |
| `fournisseurs` | Fournisseurs produits | ✓ |
| `produits` | Catalogue produits | ✓ |
| `stocks` | Niveaux de stock | ✓ |
| `mouvements_stock` | Historique mouvements | ✓ |
| `commandes` | Commandes clientes | ✓ |
| `commandes_historique` | Historique statuts | ✓ |
| `paiements` | Paiements Revolut | ✓ |
| `clientes_crm` | Profils CRM | ✓ |
| `factures` | Devis et factures | ✓ |
| `documents_clients` | Documents consentements | ✓ |
| `sessions_boudoir` | Sessions Secret Home | ✓ |
| `reservations` | Réservations sessions | ✓ |
| `memoire_metier` | Mémoire Bellaïa IA | ✓ |
| `audit_log` | Journal immuable | ✓ |

## Vue créée

| Vue | Description |
|---|---|
| `stocks_avec_statut` | Stocks avec statut calculé (ok/faible/rupture) |

## Fonctions SQL créées

| Fonction | Description |
|---|---|
| `handle_new_user()` | Trigger création profil automatique à l'inscription |
| `decrement_places()` | Trigger décrémente places sessions boudoir |
| `gen_num(type)` | Génère numéros DEV/FAC/AV/BC/BL-YYYY-0001 |

## Règles de sécurité importantes

### audit_log — IMMUABLE
```sql
CREATE RULE audit_no_update AS ON UPDATE TO public.audit_log DO INSTEAD NOTHING;
CREATE RULE audit_no_delete AS ON DELETE TO public.audit_log DO INSTEAD NOTHING;
```
Aucune modification ou suppression possible sur le journal d'audit.

### RLS activé partout
Chaque table a Row Level Security activé.
- La fondatrice voit tout.
- Les clientes voient uniquement leurs propres données.
- Les collaborateurs voient uniquement leur périmètre.

## Rôles Supabase Auth

Les rôles sont définis dans `public.profiles.role` :
```
fondatrice | hote_boudoir | estheticienne | assistante_admin
community_manager | photographe | decoratrice | cliente
```

## Séquences de numérotation

```sql
-- Réinitialiser en cas de besoin (dev uniquement)
ALTER SEQUENCE devis_seq   RESTART WITH 1;
ALTER SEQUENCE facture_seq RESTART WITH 1;
```

## Backup

Supabase effectue des backups automatiques quotidiens (plan Pro).
Pour le plan gratuit : exporter manuellement via Settings → Database → Backups.

## Régénérer les types TypeScript

```bash
npx supabase gen types typescript \
  --project-id VOTRE_PROJECT_ID \
  --schema public \
  > types/database.ts
```
Remplace le stub actuel par les types réels générés depuis le schéma.
