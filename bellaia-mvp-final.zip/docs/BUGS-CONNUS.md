# Bellaïa MVP — Bugs connus et limitations

## 🔴 À corriger avant production

### B001 — Grilles 2 colonnes non responsives
**Fichiers** : `commandes/[id]`, `crm/[id]`, `facturation/[id]`, `documents/[id]`  
**Symptôme** : Sur mobile < 768px, les deux colonnes sont trop étroites.  
**Correction** : Ajouter `@media (max-width: 768px) { grid-template-columns: 1fr; }`

### B002 — StockTable déborde sur petits écrans
**Fichier** : `components/stocks/StockTable.tsx`  
**Symptôme** : 7 colonnes ne tiennent pas sur mobile.  
**Correction** : Masquer colonnes secondaires sur mobile ou ajouter `overflow-x: auto` sur le conteneur.

### B003 — types/database.ts est un stub
**Fichier** : `types/database.ts`  
**Symptôme** : Types génériques, pas générés depuis le schéma réel.  
**Correction** : Après déploiement DB → `npx supabase gen types typescript --project-id ID > types/database.ts`

### B004 — Notifications non persistées
**Fichier** : `components/notifications/NotificationCenter.tsx`  
**Symptôme** : Lu/non-lu repart à zéro à chaque rechargement.  
**Correction V2** : Ajouter table `notifications` dans Supabase avec colonne `lue boolean`.

## 🟡 Limitations MVP connues

### L001 — Pas de génération PDF
**Impact** : Devis et factures exportables uniquement en V2.  
**Workaround** : Impression navigateur (Ctrl+P) sur la page de détail.

### L002 — Pas d'envoi email réel
**Impact** : Documents et relances préparés mais envoi manuel requis.  
**Workaround** : Copier-coller le message préparé dans WhatsApp/email.  
**Correction V2** : Intégrer Brevo SDK avec `BREVO_API_KEY`.

### L003 — Paiement Revolut 100% manuel
**Impact** : Lien créé dans Revolut, copié-collé dans l'app manuellement.  
**Correction V3** : Intégrer Revolut Business API ou CCBill.

### L004 — Mouvements stock sans table dédiée
**Fichier** : `app/api/stocks/[id]/route.ts`  
**Symptôme** : La table `mouvements_stock` est insérée mais pas dans le schéma SQL fourni.  
**Correction** : Ajouter dans `docs/schema.sql` :
```sql
CREATE TABLE public.mouvements_stock (
  id         UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  produit_id UUID NOT NULL REFERENCES public.produits(id),
  type       TEXT CHECK(type IN('vente','retour','ajustement','reception')),
  quantite   DECIMAL(10,3) NOT NULL,
  raison     TEXT,
  fait_par   UUID REFERENCES public.profiles(id),
  created_at TIMESTAMPTZ DEFAULT NOW()
);
```

### L005 — Espace cliente non implémenté
**Fichier** : `app/(cliente)/espace/page.tsx` manquant  
**Impact** : Les clientes ne peuvent pas se connecter et suivre leurs commandes.  
**Correction V2** : Implémenter l'espace client (Couche 8).

### L006 — Coffre-fort et Brand Center non implémentés
**Impact** : Prévu dans l'architecture, non codé dans le MVP.  
**Correction V2** : Pages `/coffre-fort` et `/brand-center`.

## 🟢 Non-bugs (comportements normaux)

- Les workflows IA nécessitent une validation fondatrice → voulu
- Statuts financiers bloquent sans ValidationModal → voulu
- audit_log non modifiable → voulu
- Types database.ts sont des stubs → attendu jusqu'à génération Supabase CLI
