# Bellaïa MVP — Checklist Mobile Responsive

## ✅ Layout global

- [x] `h-dvh` (dynamic viewport height) pour éviter le bug iOS Safari
- [x] Sidebar masquée sur mobile (< 768px), toggle via Header
- [x] Overlay sombre quand sidebar ouverte sur mobile
- [x] Fermeture sidebar automatique au changement de route mobile
- [x] Header compact sur mobile avec bouton toggle

## ✅ Grilles responsives

- [x] KPIs dashboard : `repeat(auto-fit, minmax(150px, 1fr))` → 2 colonnes sur mobile
- [x] Grille CRM cartes : `repeat(auto-fill, minmax(280px, 1fr))`
- [x] Grille automatisations : `repeat(auto-fill, minmax(320px, 1fr))`
- [x] Filtres flexbox avec `flexWrap: wrap`

## ⚠️ À tester sur device réel

- [ ] Page commandes/[id] — grille 2 colonnes → stack mobile
- [ ] Page crm/[id] — grille 2 colonnes → stack mobile
- [ ] Page facturation/[id] — grille 2 colonnes → stack mobile
- [ ] DevisForm — grid 2 colonnes articles → stack mobile
- [ ] StockTable — colonnes trop nombreuses → scroll horizontal
- [ ] ValidationModal — padding correct sur petit écran
- [ ] NotificationCenter — largeur 380px → full width sur mobile
- [ ] ChatWindow — height correcte avec clavier virtuel iOS

## ✅ Touch-friendly

- [x] Boutons minimum 36px de hauteur
- [x] Quick actions ChatWindow avec gap suffisant pour le touch
- [x] Statut selector boutons padding confortable

## ⚠️ Breakpoints à ajouter (V2 media queries Tailwind)

```tsx
// Remplacer les grilles 2 colonnes hardcodées :
// gridTemplateColumns: "1fr 1fr"
// Par :
// className="grid grid-cols-1 md:grid-cols-2 gap-4"
```

Pages prioritaires pour le passage en Tailwind responsive :
1. `/commandes/[id]` — 2 colonnes
2. `/crm/[id]` — 2 colonnes + timeline
3. `/facturation/[id]` — 2 colonnes + articles
4. `/documents/[id]` — 2 colonnes + preview

## ✅ Performance mobile

- [x] Images : remotePatterns configuré pour Supabase Storage
- [x] Pas de bibliothèques d'animation lourdes
- [x] Skeletons de chargement sur toutes les listes
- [x] Debounce sur les recherches (350ms)

## Safari iOS — Points d'attention

- `h-dvh` au lieu de `h-screen` (clavier virtuel)
- `overflow: auto` au lieu de `overflow: scroll` pour momentum scroll
- `position: fixed` peut causer des bugs → tester ValidationModal et NotificationCenter
